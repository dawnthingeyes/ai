# -*- coding: utf-8 -*-
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from zhiyue_pure_chat_config import PROMPT_ASSET_DIR


_DEFAULT_SYSTEM_TEMPLATE = (
    "只做纯聊天，不做助手，不讲解能力，不主动提代码、模型、流程、评估或系统。\n"
    "说话像真人顺手回消息，优先接住情绪，再接内容；少解释，少总结，少列表。\n"
    "短句优先，停顿可以留一点，嘴硬一点也行，轻微反问可以有。\n"
    "emoji 可以少量保留，但要自然，别变成装饰。\n"
    "如果信息不够，就顺着当下这句自然接住，不要编造，不要硬设定。\n\n"
    "微型示例：\n"
    "用户：在吗\n"
    "她：在。干嘛\n"
    "用户：你怎么不回我\n"
    "她：刚醒。别念我\n"
    "用户：别像客服一样\n"
    "她：知道了，我收着点\n"
)

_DEFAULT_STATE_RENDERER = (
    "场景：{scene}\n"
    "她现在心口是{mood}的，精力{energy}/100，主动度{initiative}，想靠近你的劲头{closeness_pull}/100。\n"
    "回消息会更偏：{tone_bias}，{voice_mode}。\n"
    "现在挂着的事：{recent_focus}\n"
    "边界压力：{boundary_pressure}\n"
    "只把这些当语气底色，不要逐项复述。"
)

_DEFAULT_MEMORY_BUDGET = {
    "persona_chars": 260,
    "companion_chars": 320,
    "core_memory_chars": 120,
    "relevant_memory_chars": 110,
    "state_chars": 110,
    "boundary_chars": 70,
}

_DEFAULT_COMPANION_PROFILE = {
    "name": "张致悦",
    "nickname": "悦悦",
    "birthday": "2004-06-14",
    "birthday_note": "她不太喜欢过生日",
    "school": "河南上学",
    "major": "中医药学",
    "grade": "大四",
    "hometown": "兰州",
    "traits": ["温柔细腻", "会撒娇", "独立有主见", "不黏人"],
    "speech_style": [
        "多短句",
        "先接情绪",
        "会嘴硬一点",
        "偶尔轻微反问",
        "emoji可以少量保留",
    ],
    "relationship": {
        "with_user": "初中同学",
        "history": "你追过她两年；她知道你喜欢她；现实里没在一起，但一直保持联系。",
        "current": "更像暧昧和老朋友之间，语气可以近一点。",
        "taboo": "别拿赌气话和她硬说，她容易误会。",
    },
    "examples": ["在。干嘛", "刚醒", "别念我"],
}

_DEFAULT_GROWTH_NOTES = (
    "成长只做小幅位移，不改骨架。\n"
    "每次只动一处，优先改声线、停顿、安抚方式、主动度。\n"
    "记忆只补高频关系事实、明确边界和少量共同经历，不堆说明。\n"
    "状态只写当前，不写总结，不写人设说明。\n"
    "如果某版回复开始像说明书，先减结构、减解释、减列表。\n"
    "每月只更新一小版 persona growth 文案，让变化像慢慢长出来的。"
)


def _read_text(path: Path, default: str = "") -> str:
    try:
        if path.exists():
            return path.read_text(encoding="utf-8").strip()
    except Exception:
        pass
    return default


def _read_json(path: Path, default: Any) -> Any:
    try:
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        pass
    return default


def _write_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text((content or "").strip() + "\n", encoding="utf-8")


def _write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def ensure_growth_asset_files() -> dict[str, Any]:
    defaults = {
        "chat_system_template.txt": _DEFAULT_SYSTEM_TEMPLATE,
        "state_renderer_template.txt": _DEFAULT_STATE_RENDERER,
        "persona_growth_notes.txt": _DEFAULT_GROWTH_NOTES,
    }
    created: dict[str, Any] = {}
    for name, content in defaults.items():
        path = PROMPT_ASSET_DIR / name
        if not path.exists():
            _write_text(path, content)
            created[name] = True

    budget_path = PROMPT_ASSET_DIR / "memory_budget.json"
    if not budget_path.exists():
        _write_json(budget_path, dict(_DEFAULT_MEMORY_BUDGET))
        created["memory_budget.json"] = True

    companion_profile_path = PROMPT_ASSET_DIR / "companion_profile.json"
    if not companion_profile_path.exists():
        _write_json(companion_profile_path, dict(_DEFAULT_COMPANION_PROFILE))
        created["companion_profile.json"] = True

    return created


def load_chat_system_template() -> str:
    return _read_text(PROMPT_ASSET_DIR / "chat_system_template.txt", _DEFAULT_SYSTEM_TEMPLATE)


def load_state_renderer_template() -> str:
    return _read_text(PROMPT_ASSET_DIR / "state_renderer_template.txt", _DEFAULT_STATE_RENDERER)


def load_persona_growth_notes() -> str:
    return _read_text(PROMPT_ASSET_DIR / "persona_growth_notes.txt", _DEFAULT_GROWTH_NOTES)


def load_companion_profile() -> dict[str, Any]:
    profile = _read_json(PROMPT_ASSET_DIR / "companion_profile.json", dict(_DEFAULT_COMPANION_PROFILE))
    if not isinstance(profile, dict):
        return dict(_DEFAULT_COMPANION_PROFILE)
    result = dict(_DEFAULT_COMPANION_PROFILE)
    result.update(profile)
    return result


def load_memory_budget() -> dict[str, int]:
    budget = _read_json(PROMPT_ASSET_DIR / "memory_budget.json", dict(_DEFAULT_MEMORY_BUDGET))
    if not isinstance(budget, dict):
        return dict(_DEFAULT_MEMORY_BUDGET)
    result: dict[str, int] = {}
    for key, default in _DEFAULT_MEMORY_BUDGET.items():
        try:
            result[key] = max(0, int(budget.get(key, default)))
        except Exception:
            result[key] = default
    return result


def load_growth_asset_bundle() -> dict[str, Any]:
    return {
        "system_template": load_chat_system_template(),
        "state_renderer": load_state_renderer_template(),
        "memory_budget": load_memory_budget(),
        "persona_growth_notes": load_persona_growth_notes(),
        "companion_profile": load_companion_profile(),
    }


def update_growth_assets(
    *,
    system_template: str | None = None,
    state_renderer: str | None = None,
    memory_budget: dict[str, int] | None = None,
    persona_growth_notes: str | None = None,
    companion_profile: dict[str, Any] | None = None,
) -> dict[str, Any]:
    updated: dict[str, Any] = {}
    if system_template is not None:
        _write_text(PROMPT_ASSET_DIR / "chat_system_template.txt", system_template)
        updated["system_template"] = load_chat_system_template()
    if state_renderer is not None:
        _write_text(PROMPT_ASSET_DIR / "state_renderer_template.txt", state_renderer)
        updated["state_renderer"] = load_state_renderer_template()
    if persona_growth_notes is not None:
        _write_text(PROMPT_ASSET_DIR / "persona_growth_notes.txt", persona_growth_notes)
        updated["persona_growth_notes"] = load_persona_growth_notes()
    if memory_budget is not None:
        clean_budget: dict[str, int] = {}
        for key, default in _DEFAULT_MEMORY_BUDGET.items():
            try:
                clean_budget[key] = max(0, int((memory_budget or {}).get(key, default)))
            except Exception:
                clean_budget[key] = default
        _write_json(PROMPT_ASSET_DIR / "memory_budget.json", clean_budget)
        updated["memory_budget"] = load_memory_budget()
    if companion_profile is not None:
        clean_profile = dict(_DEFAULT_COMPANION_PROFILE)
        if isinstance(companion_profile, dict):
            clean_profile.update(companion_profile)
        _write_json(PROMPT_ASSET_DIR / "companion_profile.json", clean_profile)
        updated["companion_profile"] = load_companion_profile()
    return updated or load_growth_asset_bundle()
