param(
  [string]$ProjectRoot = "E:\\chat-project",
  [string]$AppDir = "E:\\chat-project\\deploy\\android_apk\\kivy_app"
)

$ErrorActionPreference = "Stop"

$bundle = Join-Path $AppDir "zhiyue_bundle"
New-Item -ItemType Directory -Force -Path $bundle | Out-Null

foreach ($name in @("core","modules","config")) {
  $src = Join-Path $ProjectRoot $name
  $dst = Join-Path $bundle $name
  if (Test-Path $dst) { Remove-Item -LiteralPath $dst -Recurse -Force }
  Copy-Item -LiteralPath $src -Destination $dst -Recurse -Force
}

Write-Host "Bundle prepared in: $bundle"

