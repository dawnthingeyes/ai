param(
  [string]$ProjectRoot = "E:\\chat-project",
  [string]$AppDir = "E:\\chat-project\\deploy\\android_apk\\kivy_app"
)

$ErrorActionPreference = "Stop"

$bundle = Join-Path $AppDir "zhiyue_bundle"
New-Item -ItemType Directory -Force -Path $bundle | Out-Null

foreach ($name in @("core","modules","config")) {
  $src = Join-Path $ProjectRoot $name
  $dst = Join-Path $bundle $name
  if (Test-Path $dst) { Remove-Item -LiteralPath $dst -Recurse -Force }
  Copy-Item -LiteralPath $src -Destination $dst -Recurse -Force
}

# Do not ship any local data/memory/prompts snapshots inside the APK bundle.
# The app must start clean and create its own databases inside app-private storage.
$prune = @(
  (Join-Path $bundle "modules\\data"),
  (Join-Path $bundle "modules\\runtime"),
  (Join-Path $bundle "core\\__pycache__"),
  (Join-Path $bundle "modules\\__pycache__")
)
foreach ($path in $prune) {
  if (Test-Path $path) { Remove-Item -LiteralPath $path -Recurse -Force }
}
Get-ChildItem -Path $bundle -Recurse -Force -Include *.pyc | Remove-Item -Force -ErrorAction SilentlyContinue
Get-ChildItem -Path $bundle -Recurse -Force -Include *.db | Remove-Item -Force -ErrorAction SilentlyContinue

Write-Host "Bundle prepared in: $bundle"
