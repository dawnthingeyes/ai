# 独立 APK（Kivy + python-for-android / Buildozer）

这个目录用于打包一个**独立 APK**：
- APK 内含一个“前台常驻服务”，在手机上启动本机 `127.0.0.1:8908` 的 **OpenAI 兼容接口**
- Tavo 直接连手机的 localhost（不需要电脑常驻）
- App 自带一个极简配置 UI：上游 API、main/state/review 三模型、Mobile Token、存档(Profile)、导入导出备份

## 1) Windows 侧：准备 bundle
先在 Windows 上执行（会把 `core/ modules/ config/` 拷进 APK 工程的 `zhiyue_bundle/`）：

```powershell
powershell -ExecutionPolicy Bypass -File E:\chat-project\deploy\android_apk\kivy_app\prepare_bundle.ps1
```

## 2) Linux/WSL2 侧：Buildozer 构建 APK
Buildozer 推荐在 Linux 环境构建（WSL2 Ubuntu 22.04/24.04 均可）。

进入工程目录：
```bash
cd /mnt/e/chat-project/deploy/android_apk/kivy_app
```

安装依赖（示例）：
```bash
sudo apt update
sudo apt install -y python3 python3-pip git openjdk-17-jdk unzip zip
python3 -m pip install --upgrade pip
python3 -m pip install buildozer cython
```

构建 debug APK：
```bash
buildozer -v android debug
```

输出 APK 一般在 `bin/` 目录。

## 3) 小米/MIUI 必做设置
见同目录：[MIUI_SETUP.md](./MIUI_SETUP.md)

## 4) Tavo 配置（手机端）
1. 先在 App 里填好上游 API 和 Mobile Token，然后点【启动】。
2. 在 Tavo 里填：
- Base URL：`http://127.0.0.1:8908/v1`
- API Key：填写 App 里设置的 `Mobile Token`
- Model：`zhiyue`（或 `zhiyue-main` 也可以）

## 5) 自检
App 里有【自检】按钮：会调用 `/v1/models` 和 `/v1/chat/completions` 做最小烟测。

