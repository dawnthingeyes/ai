[app]
title = Zhiyue Companion
package.name = zhiyuecompanion
package.domain = com.zhiyue
source.dir = .
source.include_exts = py,png,jpg,kv,json,txt,md
version = 0.1.0

# Minimal Python deps: UI + HTTP server + upstream API
requirements = python3,kivy,flask,requests,tzdata,androidstorage4kivy

orientation = portrait
fullscreen = 0

# Foreground service (keeps MIUI from killing it too easily)
services = companion:service.py:foreground:sticky

# Network + foreground service permissions. Keep targetSdk <= 32 to avoid Android 13 notification runtime permission.
android.permissions = INTERNET,FOREGROUND_SERVICE,WAKE_LOCK
android.api = 32
android.minapi = 24

# Build output
android.archs = arm64-v8a

# CI-friendly: accept Android SDK licenses non-interactively.
android.accept_sdk_license = True

[buildozer]
log_level = 2
warn_on_root = 1
