import json
import os
import sys
from pathlib import Path


def _load_cfg(cfg_path: Path) -> dict:
    try:
        if cfg_path.exists():
            data = json.loads(cfg_path.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
    except Exception:
        return {}
    return {}


def main():
    # Try to locate the same user_data_dir used by the UI process.
    # p4a sets ANDROID_PRIVATE which points to the app's private files dir.
    base = Path(os.environ.get("ANDROID_PRIVATE") or os.getcwd())
    cfg_path = base / "mobile_cfg.json"
    cfg = _load_cfg(cfg_path)

    # Ask Android to auto-restart the foreground service if it gets killed (best-effort; MIUI still may be aggressive).
    try:
        from jnius import autoclass  # type: ignore

        svc = autoclass("org.kivy.android.PythonService")
        svc.setAutoRestartService(True)
    except Exception:
        pass

    # Base runtime toggles.
    os.environ["ZHIYUE_REMOTE_COMPANION"] = "1"
    os.environ["ZHIYUE_HOST"] = "127.0.0.1"
    os.environ["ZHIYUE_PORT"] = str(cfg.get("port") or 8908)
    os.environ["ZHIYUE_OPENAI_HISTORY_MODE"] = str(cfg.get("history_mode") or "last_user_only").strip() or "last_user_only"
    os.environ["ZHIYUE_MOBILE_TOKEN"] = str(cfg.get("mobile_token") or "mob").strip()
    os.environ["ZHIYUE_SYNC_TOKEN"] = str(cfg.get("sync_token") or "sync").strip()

    # Keep data inside app storage (cwd).
    os.environ["ZHIYUE_DATA_DIR"] = str(base / "mobile_data")
    os.environ["ZHIYUE_RUNTIME_DIR"] = str(base / "mobile_runtime")
    os.environ["ZHIYUE_ARTIFACTS_DIR"] = str(base / "mobile_artifacts")

    # Multi-persona profile (optional). If not set, defaults to "default".
    profile_id = str(cfg.get("profile_id") or "").strip()
    if profile_id:
        os.environ["ZHIYUE_PROFILE_ID"] = profile_id

    # Add bundled project to Python path.
    bundle = Path(__file__).resolve().parent / "zhiyue_bundle"
    sys.path.insert(0, str(bundle / "core"))
    sys.path.insert(0, str(bundle / "modules"))
    sys.path.insert(0, str(bundle / "config"))

    # Persist provider config (supports per-role overrides later without env explosion).
    try:
        from zhiyue_llm_provider import save_provider_config as _save_provider_config

        def _role(role: str, model_key: str, url_key: str, key_key: str) -> dict:
            out = {"model": str(cfg.get(model_key) or "").strip()}
            base_url = str(cfg.get(url_key) or "").strip()
            api_key = str(cfg.get(key_key) or "").strip()
            if base_url:
                out["base_url"] = base_url
            if api_key:
                out["api_key"] = api_key
            return out

        provider_cfg = {
            "enabled": True,
            "protocol": str(cfg.get("protocol") or "openai_compatible").strip(),
            "base_url": str(cfg.get("base_url") or "").strip(),
            "api_key": str(cfg.get("api_key") or "").strip(),
            "roles": {
                "main": _role("main", "main_model", "main_base_url", "main_api_key"),
                "state": _role("state", "state_model", "state_base_url", "state_api_key"),
                "review": _role("review", "review_model", "review_base_url", "review_api_key"),
            },
        }
        _save_provider_config(provider_cfg)
    except Exception:
        # If this fails, zhiyue_connected will surface "API not configured".
        pass

    # Start the locked-down companion server.
    import zhiyue_connected  # type: ignore

    # zhiyue_connected runs app.run() in __main__; call the Flask app directly.
    zhiyue_connected.app.run(
        host=os.environ["ZHIYUE_HOST"],
        port=int(os.environ["ZHIYUE_PORT"]),
        debug=False,
        threaded=True,
    )


if __name__ == "__main__":
    main()
