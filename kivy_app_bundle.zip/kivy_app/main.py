import base64
import json
import os
import socket
import sys
import time
from pathlib import Path

from kivy.app import App
from kivy.lang import Builder
from kivy.uix.boxlayout import BoxLayout
from kivy.clock import Clock

try:
    from jnius import autoclass  # type: ignore
except Exception:
    autoclass = None

# Allow the UI process to access bundled project modules for backup/export.
_BUNDLE = Path(__file__).resolve().parent / "zhiyue_bundle"
if (_BUNDLE / "modules").exists():
    sys.path.insert(0, str(_BUNDLE / "core"))
    sys.path.insert(0, str(_BUNDLE / "modules"))
    sys.path.insert(0, str(_BUNDLE / "config"))

# Ensure UI and service share the same data roots (for profiles/backup).
_BASE_PRIVATE = os.environ.get("ANDROID_PRIVATE")
if _BASE_PRIVATE:
    os.environ.setdefault("ZHIYUE_DATA_DIR", str(Path(_BASE_PRIVATE) / "mobile_data"))
    os.environ.setdefault("ZHIYUE_RUNTIME_DIR", str(Path(_BASE_PRIVATE) / "mobile_runtime"))
    os.environ.setdefault("ZHIYUE_ARTIFACTS_DIR", str(Path(_BASE_PRIVATE) / "mobile_artifacts"))


KV = r"""
#:import dp kivy.metrics.dp

<SectionLabel@Label>:
  size_hint_y: None
  height: dp(28)
  bold: True
  color: (0.12, 0.12, 0.12, 1)
  text_size: self.width, None
  valign: "middle"

<Root>:
  orientation: "vertical"
  padding: dp(12)
  spacing: dp(10)

  canvas.before:
    Color:
      rgba: (0.98, 0.98, 0.98, 1)
    Rectangle:
      pos: self.pos
      size: self.size

  BoxLayout:
    size_hint_y: None
    height: dp(46)
    spacing: dp(8)
    Label:
      text: "知悦 Companion"
      bold: True
      font_size: "18sp"
      color: (0.05, 0.05, 0.05, 1)
      halign: "left"
      valign: "middle"
      text_size: self.size
    Label:
      id: header_hint
      text: "Tavo: http://127.0.0.1:8908/v1"
      font_size: "12sp"
      color: (0.35, 0.35, 0.35, 1)
      halign: "right"
      valign: "middle"
      text_size: self.size

  ScrollView:
    do_scroll_x: False
    bar_width: dp(6)
    GridLayout:
      id: form
      cols: 2
      size_hint_y: None
      height: self.minimum_height
      row_default_height: dp(44)
      row_force_default: True
      spacing: dp(10)

      SectionLabel:
        text: "上游 API"
      Widget:
        size_hint_y: None
        height: dp(28)

      Label:
        text: "协议"
        halign: "left"
        valign: "middle"
        text_size: self.size
      Spinner:
        id: protocol
        text: "openai_compatible"
        values: ["openai_compatible", "anthropic", "gemini"]

      Label:
        text: "Base URL"
        halign: "left"
        valign: "middle"
        text_size: self.size
      TextInput:
        id: base_url
        multiline: False
        hint_text: "https://xxx/v1"

      Label:
        text: "API Key"
        halign: "left"
        valign: "middle"
        text_size: self.size
      TextInput:
        id: api_key
        multiline: False
        password: True
        hint_text: "sk-..."

      SectionLabel:
        text: "三角色模型"
      Widget:
        size_hint_y: None
        height: dp(28)

      Label:
        text: "主模型(main)"
        halign: "left"
        valign: "middle"
        text_size: self.size
      BoxLayout:
        spacing: dp(8)
        TextInput:
          id: main_model
          multiline: False
        Spinner:
          id: main_pick
          text: ""
          values: [""]
          size_hint_x: None
          width: dp(140)
          on_text: root._apply_pick("main", self.text)

      Label:
        text: "状态(state)"
        halign: "left"
        valign: "middle"
        text_size: self.size
      BoxLayout:
        spacing: dp(8)
        TextInput:
          id: state_model
          multiline: False
        Spinner:
          id: state_pick
          text: ""
          values: [""]
          size_hint_x: None
          width: dp(140)
          on_text: root._apply_pick("state", self.text)

      Label:
        text: "校对(review)"
        halign: "left"
        valign: "middle"
        text_size: self.size
      BoxLayout:
        spacing: dp(8)
        TextInput:
          id: review_model
          multiline: False
        Spinner:
          id: review_pick
          text: ""
          values: [""]
          size_hint_x: None
          width: dp(140)
          on_text: root._apply_pick("review", self.text)

      SectionLabel:
        text: "手机入口/存档"
      Widget:
        size_hint_y: None
        height: dp(28)

      Label:
        text: "Mobile Token"
        halign: "left"
        valign: "middle"
        text_size: self.size
      TextInput:
        id: mobile_token
        multiline: False
        hint_text: "Tavo 里当 API Key 用"

      Label:
        text: "存档(Profile)"
        halign: "left"
        valign: "middle"
        text_size: self.size
      BoxLayout:
        spacing: dp(8)
        Spinner:
          id: profile_pick
          text: "default"
          values: ["default"]
          on_text: root.on_pick_profile(self.text)
        Button:
          text: "新建"
          size_hint_x: None
          width: dp(90)
          on_release: root.create_profile()

      Label:
        text: "Profile ID"
        halign: "left"
        valign: "middle"
        text_size: self.size
      TextInput:
        id: profile_id
        multiline: False
        hint_text: "default / work / ..."

      SectionLabel:
        text: "高级(可选)"
      CheckBox:
        id: advanced
        active: False

      Label:
        text: "端口"
        halign: "left"
        valign: "middle"
        text_size: self.size
      TextInput:
        id: port
        multiline: False
        text: "8908"

      Label:
        text: "Auto-start"
        halign: "left"
        valign: "middle"
        text_size: self.size
      CheckBox:
        id: auto_start
        active: True

      Label:
        text: "Sync Token"
        halign: "left"
        valign: "middle"
        text_size: self.size
      TextInput:
        id: sync_token
        multiline: False
        hint_text: "PC sync (可空)"
        opacity: 1 if advanced.active else 0
        disabled: not advanced.active

  BoxLayout:
    size_hint_y: None
    height: dp(52)
    spacing: dp(8)
    Button:
      text: "保存"
      on_release: root.save_cfg()
    Button:
      text: "拉取模型"
      on_release: root.fetch_models()
    Button:
      text: "自检"
      on_release: root.self_test()
    Button:
      text: "启动"
      on_release: root.start_service()
    Button:
      text: "停止"
      on_release: root.stop_service()

  BoxLayout:
    size_hint_y: None
    height: dp(44)
    spacing: dp(8)
    Button:
      text: "导出备份"
      on_release: root.export_backup()
    Button:
      text: "导入备份"
      on_release: root.import_backup()
    Button:
      text: "列表"
      on_release: root.show_profiles()

  Label:
    id: status
    text: "状态：idle"
    size_hint_y: None
    height: dp(72)
    color: (0.15, 0.15, 0.15, 1)
    text_size: self.width, None
"""


class Root(BoxLayout):
    def _apply_pick(self, role: str, model_id: str):
        mid = (model_id or "").strip()
        if not mid:
            return
        if role == "main":
            self.ids.main_model.text = mid
        elif role == "state":
            self.ids.state_model.text = mid
        elif role == "review":
            self.ids.review_model.text = mid

    def fetch_models(self):
        # Fetch /v1/models from upstream and populate pickers.
        import threading
        import requests

        base_url = (self.ids.base_url.text or "").strip()
        if not base_url:
            self.ids.status.text = "Status: set Base URL first"
            return
        api_key = (self.ids.api_key.text or "").strip()

        def _normalize_models_url(url: str) -> str:
            root = url.rstrip("/")
            if root.endswith("/models") or root.endswith("/v1/models"):
                return root
            if root.endswith("/v1"):
                return root + "/models"
            return root + "/v1/models"

        def _run():
            try:
                url = _normalize_models_url(base_url)
                headers = {"Accept": "application/json"}
                if api_key:
                    headers["Authorization"] = f"Bearer {api_key}"
                resp = requests.get(url, headers=headers, timeout=15)
                if resp.status_code >= 400:
                    raise RuntimeError(f"HTTP {resp.status_code}")
                payload = resp.json() if resp.content else {}
                data = payload.get("data") if isinstance(payload, dict) else None
                models = []
                if isinstance(data, list):
                    for item in data:
                        if isinstance(item, dict) and item.get("id"):
                            models.append(str(item["id"]))
                models = sorted(set(models))

                def _apply(_dt):
                    values = [""] + models
                    for wid in ("main_pick", "state_pick", "review_pick"):
                        if wid in self.ids:
                            self.ids[wid].values = values
                    self.ids.status.text = f"Status: models loaded ({len(models)})"

                Clock.schedule_once(_apply, 0)
            except Exception as e:
                Clock.schedule_once(lambda _dt: setattr(self.ids.status, "text", f"Status: fetch failed: {e}"), 0)

        threading.Thread(target=_run, daemon=True).start()

    def self_test(self):
        # Minimal on-device smoke test for Tavo compatibility.
        import threading
        import requests

        try:
            port = int((self.ids.port.text or "8908").strip() or "8908")
        except Exception:
            port = 8908
        token = (self.ids.mobile_token.text or "").strip()
        base = f"http://127.0.0.1:{port}"

        def _run():
            try:
                headers = {"Accept": "application/json"}
                if token:
                    headers["Authorization"] = f"Bearer {token}"

                r_models = requests.get(base + "/v1/models", headers=headers, timeout=8)
                if r_models.status_code >= 400:
                    raise RuntimeError(f"/v1/models HTTP {r_models.status_code}")

                payload = {
                    "model": "zhiyue",
                    "messages": [{"role": "user", "content": "ping"}],
                }
                r_chat = requests.post(base + "/v1/chat/completions", headers=headers, json=payload, timeout=20)
                if r_chat.status_code >= 400:
                    raise RuntimeError(f"/v1/chat/completions HTTP {r_chat.status_code}")

                data = r_chat.json() if r_chat.content else {}
                preview = ""
                try:
                    preview = ((data.get("choices") or [{}])[0].get("message") or {}).get("content") or ""
                except Exception:
                    preview = ""
                preview = str(preview).strip().replace("\n", " ")
                if len(preview) > 80:
                    preview = preview[:80] + "..."

                def _ok(_dt):
                    self.ids.status.text = "状态：自检通过 (/v1/models + chat ok) " + (f"reply='{preview}'" if preview else "")

                Clock.schedule_once(_ok, 0)
            except Exception as e:
                Clock.schedule_once(lambda _dt: setattr(self.ids.status, "text", f"状态：自检失败：{e}"), 0)

        self.ids.status.text = "状态：自检中..."
        threading.Thread(target=_run, daemon=True).start()
    def _cfg_path(self) -> Path:
        base = os.environ.get("ANDROID_PRIVATE") or App.get_running_app().user_data_dir
        return Path(base) / "mobile_cfg.json"

    def load_cfg(self):
        p = self._cfg_path()
        if not p.exists():
            return
        try:
            cfg = json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            return
        if not isinstance(cfg, dict):
            return
        self.ids.protocol.text = cfg.get("protocol") or "openai_compatible"
        self.ids.base_url.text = cfg.get("base_url") or ""
        self.ids.api_key.text = cfg.get("api_key") or ""
        self.ids.main_model.text = cfg.get("main_model") or ""
        self.ids.state_model.text = cfg.get("state_model") or ""
        self.ids.review_model.text = cfg.get("review_model") or ""
        self.ids.mobile_token.text = cfg.get("mobile_token") or ""
        self.ids.profile_id.text = cfg.get("profile_id") or ""
        try:
            self.refresh_profile_picker(select=self.ids.profile_id.text or None)
        except Exception:
            pass
        self.ids.sync_token.text = cfg.get("sync_token") or ""
        self.ids.port.text = str(cfg.get("port") or "8908")
        self.ids.auto_start.active = bool(cfg.get("auto_start", True))

    def save_cfg(self):
        p = self._cfg_path()
        cfg = {
            "protocol": self.ids.protocol.text.strip(),
            "base_url": self.ids.base_url.text.strip(),
            "api_key": self.ids.api_key.text.strip(),
            "main_model": self.ids.main_model.text.strip(),
            "state_model": self.ids.state_model.text.strip(),
            "review_model": self.ids.review_model.text.strip(),
            "mobile_token": self.ids.mobile_token.text.strip(),
            "profile_id": self.ids.profile_id.text.strip(),
            "sync_token": self.ids.sync_token.text.strip(),
            "port": int(self.ids.port.text.strip() or "8908"),
            "auto_start": bool(self.ids.auto_start.active),
        }
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
        self.ids.status.text = f"Status: saved to {p.name}"

    def start_service(self):
        self.save_cfg()
        if autoclass is None:
            self.ids.status.text = "Status: PyJNIus not available"
            return
        try:
            # python-for-android generates a Java class for each service:
            # <package>.Service<Servicename>, where Servicename is capitalized.
            service = autoclass("com.zhiyue.zhiyuecompanion.ServiceCompanion")
            mActivity = autoclass("org.kivy.android.PythonActivity").mActivity
            # Best-effort restart to apply new profile/config.
            try:
                service.stop(mActivity)
            except Exception:
                pass
            # Argument is exposed as PYTHON_SERVICE_ARGUMENT in the service process.
            service.start(mActivity, "")
            self.ids.status.text = "Status: service start requested"
        except Exception as e:
            self.ids.status.text = f"Status: start failed: {e}"

    def stop_service(self):
        if autoclass is None:
            self.ids.status.text = "Status: PyJNIus not available"
            return
        try:
            service = autoclass("com.zhiyue.zhiyuecompanion.ServiceCompanion")
            mActivity = autoclass("org.kivy.android.PythonActivity").mActivity
            # stop() is available on recent p4a templates. If unavailable, user can still force-stop from Android settings.
            service.stop(mActivity)
            self.ids.status.text = "Status: stop requested"
        except Exception as e:
            self.ids.status.text = f"Status: stop failed: {e}"

    def export_backup(self):
        try:
            from zhiyue_sync_bundle import build_sync_bundle
        except Exception as e:
            self.ids.status.text = f"Status: export unavailable: {e}"
            return
        try:
            pid = (self.ids.profile_id.text or "").strip()
            if pid:
                os.environ["ZHIYUE_PROFILE_ID"] = pid
            bundle = build_sync_bundle()
            raw = base64.b64decode((bundle.get("archive_b64") or "").encode("ascii"), validate=False)
            base = os.environ.get("ANDROID_PRIVATE") or App.get_running_app().user_data_dir
            suffix = pid if pid else "default"
            out = Path(base) / f"zhiyue_backup_{suffix}_{int(time.time())}.zip"
            out.write_bytes(raw)
            try:
                from androidstorage4kivy import ShareSheet, SharedStorage
                ss = SharedStorage()
                shared_file = ss.copy_to_shared(str(out))
                if shared_file:
                    ShareSheet().share_file(shared_file)
                    self.ids.status.text = f"Status: backup shared: {out.name}"
                else:
                    self.ids.status.text = f"Status: backup written: {out}"
            except Exception:
                self.ids.status.text = f"Status: backup written: {out}"
        except Exception as e:
            self.ids.status.text = f"Status: export failed: {e}"

    def import_backup(self):
        # Pick a backup zip from Android shared storage, copy into app private cache, then apply.
        try:
            from androidstorage4kivy import Chooser
        except Exception as e:
            self.ids.status.text = f"Status: import unavailable: {e}"
            return
        try:
            self._backup_chooser = Chooser(self._on_backup_chosen)
            self._backup_chooser.choose_content("*/*")
            self.ids.status.text = "Status: pick a backup zip..."
        except Exception as e:
            self.ids.status.text = f"Status: import failed: {e}"

    def _on_backup_chosen(self, shared_file_list):
        try:
            from androidstorage4kivy import SharedStorage
            from zhiyue_sync_bundle import apply_sync_bundle
            import hashlib

            if not shared_file_list:
                self.ids.status.text = "Status: no file selected"
                return
            ss = SharedStorage()
            private_file = ss.copy_from_shared(shared_file_list[0])
            if not private_file:
                self.ids.status.text = "Status: failed to copy selected file"
                return
            raw = Path(private_file).read_bytes()
            sha = hashlib.sha256(raw).hexdigest()
            bundle = {"archive_b64": base64.b64encode(raw).decode("ascii"), "sha256": sha}

            pid = (self.ids.profile_id.text or "").strip()
            if pid:
                os.environ["ZHIYUE_PROFILE_ID"] = pid
            res = apply_sync_bundle(bundle, prefer_incoming_files=True)
            self.ids.status.text = "Import: " + json.dumps(res, ensure_ascii=False)
        except Exception as e:
            self.ids.status.text = f"Status: import apply failed: {e}"

    def show_profiles(self):
        try:
            from zhiyue_profile_registry import list_profiles
            info = list_profiles()
            self.ids.status.text = "Profiles: " + json.dumps(info, ensure_ascii=False)
        except Exception as e:
            self.ids.status.text = f"Status: profiles failed: {e}"

    def create_profile(self):
        pid = (self.ids.profile_id.text or "").strip()
        if not pid:
            self.ids.status.text = "Status: set Profile ID first"
            return
        try:
            from zhiyue_profile_registry import create_profile
            res = create_profile(name=pid, profile_id=pid)
            self.ids.status.text = "Create: " + json.dumps(res, ensure_ascii=False)
            try:
                self.refresh_profile_picker(select=pid)
            except Exception:
                pass
        except Exception as e:
            self.ids.status.text = f"Status: create failed: {e}"

    def refresh_profile_picker(self, select: str | None = None):
        try:
            from zhiyue_profile_registry import list_profiles
            info = list_profiles()
            profiles = info.get("profiles") or []
            values = [p.get("id") for p in profiles if isinstance(p, dict) and p.get("id")]
            values = list(dict.fromkeys(values)) or ["default"]
            self.ids.profile_pick.values = values
            cur = select or info.get("current_id") or values[0]
            if cur in values:
                self.ids.profile_pick.text = cur
        except Exception:
            self.ids.profile_pick.values = ["default"]
            self.ids.profile_pick.text = "default"

    def on_pick_profile(self, profile_id: str):
        pid = (profile_id or "").strip()
        if pid:
            self.ids.profile_id.text = pid


class ZhiyueApp(App):
    def build(self):
        Builder.load_string(KV)
        root = Root()
        root.load_cfg()
        try:
            if bool(root.ids.auto_start.active):
                root.start_service()
        except Exception:
            pass
        return root


if __name__ == "__main__":
    ZhiyueApp().run()
