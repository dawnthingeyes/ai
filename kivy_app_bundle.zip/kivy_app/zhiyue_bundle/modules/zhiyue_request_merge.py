# -*- coding: utf-8 -*-
from __future__ import annotations

import threading
import time


def get_merged_growth_payload(
    user_msg,
    *,
    source_history,
    channel,
    chat_history,
    input_merge_lock,
    input_merge_batches,
    input_merge_seconds,
    input_merge_max_seconds,
    get_growth_payload,
    **_unused,
):
    """
    Wait briefly for consecutive user messages and answer them as one thought.
    Later requests absorbed into the batch return coalesced_skip=True.
    """
    msg = (user_msg or "").strip()
    effective_history = source_history if source_history is not None else chat_history
    if not msg:
        return get_growth_payload(msg, source_history=source_history)

    request_marker = object()
    key = channel or "default"
    now = time.monotonic()
    with input_merge_lock:
        batch = input_merge_batches.get(key)
        stale = batch and (now - batch.get("created", now) > input_merge_max_seconds + 2)
        if not batch or batch.get("closed") or stale:
            batch = {
                "messages": [],
                "created": now,
                "updated": now,
                "owner": request_marker,
                "done": threading.Event(),
                "source_history": source_history,
                "closed": False,
            }
            input_merge_batches[key] = batch
        batch["messages"].append(msg)
        batch["updated"] = now
        is_owner = batch["owner"] is request_marker

    if not is_owner:
        batch["done"].wait(300)
        return {
            "reply": "",
            "messages": [],
            "error": False,
            "coalesced_skip": True,
        }

    start = time.monotonic()
    while True:
        time.sleep(input_merge_seconds)
        with input_merge_lock:
            quiet_for = time.monotonic() - batch["updated"]
            waited_for = time.monotonic() - start
            if quiet_for >= input_merge_seconds or waited_for >= input_merge_max_seconds:
                batch["closed"] = True
                combined_msg = "\n".join(batch["messages"])
                merged_count = len(batch["messages"])
                effective_history = batch["source_history"]
                break

    try:
        result = get_growth_payload(combined_msg, source_history=effective_history)
        result["merged_user_messages"] = merged_count
        if not result.get("coalesced_skip"):
            result["coalesced_skip"] = False
    finally:
        with input_merge_lock:
            batch["done"].set()
            if input_merge_batches.get(key) is batch:
                del input_merge_batches[key]
    return result
