# -*- coding: utf-8 -*-
from __future__ import annotations

import random


def _join(items, sep: str = " / ") -> str:
    return sep.join(str(item).strip() for item in (items or []) if str(item).strip())


def _looks_garbled(text: str) -> bool:
    raw = str(text or "")
    if not raw.strip():
        return True
    bad = raw.count("?") + raw.count("�")
    return bad >= max(3, len(raw) // 4)


def _voice_signature_lines(voice_signature):
    if isinstance(voice_signature, dict):
        mapping = [
            ("short_sentence", "short_sentence"),
            ("pause_style", "pause_style"),
            ("bluntness", "bluntness"),
            ("comfort_style", "comfort_style"),
            ("question_rate", "question_rate"),
            ("emotion_release", "emotion_release"),
        ]
        return [
            f"{label}:{str(voice_signature.get(key) or '').strip()}"
            for key, label in mapping
            if str(voice_signature.get(key) or "").strip()
        ]
    if isinstance(voice_signature, list):
        return [str(item).strip() for item in voice_signature if str(item).strip()]
    value = str(voice_signature or "").strip()
    return [value] if value else []


def get_recall_hint(*, user_msg, limit, extract_query_terms, recall_life_events, memory, clean_prompt_snippet):
    query_terms = extract_query_terms(user_msg, limit=4)
    events = recall_life_events(user_msg, limit=max(1, limit))
    if query_terms and events:
        item = events[0]
        title = clean_prompt_snippet(item.get("title"), 36)
        return f"\nHint: gentle callback (no explicit naming): {title}" if title else ""

    relevant = memory.get_relevant_memories(user_msg, limit=max(1, limit * 2))
    if query_terms and relevant:
        item = relevant[0]
        content = clean_prompt_snippet(item.get("content", ""), 42)
        if _looks_garbled(content):
            content = ""
        return f"\nHint: allude softly, don't over-explain: {content}" if content else ""

    if random.random() > 0.28:
        return ""

    recent = memory.get_recent(limit=4)
    if not recent:
        return ""
    item = str(random.choice(recent) or "").strip()[:42]
    return f"\nHint: optional gentle callback: {item}" if item else ""


def get_core_memory_inject(*, memory):
    return memory.get_core_memory_inject()


def get_persona_profile_inject(*, memory):
    profile = getattr(memory, "profile_cache", None) or getattr(memory, "_persona_profile_cache", None) or {}
    if not isinstance(profile, dict):
        return ""

    parts = []
    if profile.get("user_name"):
        parts.append(f"user_name: {str(profile.get('user_name')).strip()}")

    voice_signature = _voice_signature_lines(profile.get("voice_signature"))
    if voice_signature:
        parts.append("voice: " + _join(voice_signature[:3]))

    style_phrases = profile.get("style_phrases") or []
    if style_phrases:
        parts.append("style_phrases: " + _join(style_phrases[:4]))

    user_preferences = profile.get("user_preferences") or []
    if user_preferences:
        parts.append("preferences: " + _join(user_preferences[:2]))

    user_boundaries = profile.get("user_boundaries") or []
    if user_boundaries:
        parts.append("boundaries: " + _join(user_boundaries[:2]))

    return "=== USER PROFILE (brief) ===\n" + "\n".join(parts) if parts else ""


def get_companion_profile_inject(*, profile):
    if not isinstance(profile, dict):
        return ""

    parts = []
    if profile.get("name"):
        parts.append(f"name: {str(profile.get('name')).strip()}")
    if profile.get("nickname"):
        parts.append(f"nickname: {str(profile.get('nickname')).strip()}")

    relationship = profile.get("relationship") or {}
    if isinstance(relationship, dict):
        if relationship.get("with_user"):
            parts.append(f"relationship_with_user: {str(relationship.get('with_user')).strip()}")
        if relationship.get("current"):
            parts.append(f"relationship_current: {str(relationship.get('current')).strip()}")

    traits = [str(x).strip() for x in (profile.get("traits") or []) if str(x).strip()]
    if traits:
        parts.append("traits: " + _join(traits[:4]))

    return "=== COMPANION PROFILE (brief) ===\n" + "\n".join(parts) if parts else ""


def get_learning_notes_inject(*, user_msg, growth, learning_note_allows_chat_inject):
    notes = growth.get_learning_notes(limit=8, query=user_msg)
    if not notes:
        return ""
    kept = []
    for note_type, content, confidence, created_at, scope, allow_chat_inject, expires_at in notes:
        if not int(allow_chat_inject or 0):
            continue
        if not learning_note_allows_chat_inject(note_type, content, confidence, created_at):
            continue
        kept.append(str(content).strip())
    if not kept:
        return ""
    return "nudges: " + _join(kept[:2])


def get_good_replies_inject(*, user_msg, growth, clean_prompt_snippet):
    examples = growth.get_relevant_good_replies(user_msg, limit=2)
    if not examples:
        return ""
    parts = []
    for item in examples:
        reply_part = clean_prompt_snippet(item.get("ai_reply", ""), 32)
        if reply_part:
            parts.append("good_style: " + reply_part)
    return _join(parts[:2])


def get_bad_reply_avoid_inject(*, user_msg, observability, clean_prompt_snippet, state_bucket="", question_type=""):
    if not observability:
        return ""
    try:
        examples = observability.get_relevant_bad_human_replies(
            user_msg,
            state_bucket=state_bucket,
            question_type=question_type,
            limit=2,
        )
    except TypeError:
        examples = observability.get_relevant_bad_human_replies(
            user_msg,
            state_bucket=state_bucket,
            limit=2,
        )
    except Exception:
        return ""
    if not examples:
        return ""

    parts = []
    for item in examples:
        reply_part = clean_prompt_snippet(item.get("reply", ""), 24)
        issues = _join([clean_prompt_snippet(x, 12) for x in (item.get("issues") or [])][:2])
        if reply_part:
            parts.append(f"avoid_like: {reply_part}" + (f" ({issues})" if issues else ""))
    if not parts:
        return ""
    return f"avoid_samples({question_type or 'unknown'}): " + _join(parts[:2])


def get_relevant_memory_inject(*, user_msg, memory, recall_life_events, clean_prompt_snippet, memory_allows_chat_inject):
    items = [item for item in memory.get_relevant_memories(user_msg, limit=5) if memory_allows_chat_inject(item)][:3]
    parts = []

    events = recall_life_events(user_msg, limit=3)
    for item in events:
        title = clean_prompt_snippet(item.get("title", ""), 24)
        if title:
            parts.append("recent_event: " + title)

    if items:
        for item in items:
            content = clean_prompt_snippet(item.get("content", ""), 28)
            if _looks_garbled(content):
                continue
            if content:
                parts.append("relevant_memory: " + content)
        return _join(parts[:3])

    if events:
        return _join(parts[:2])

    layered = memory.get_layered_memories(max_per_type=1)
    if not layered:
        return ""
    for type_label, values in layered.items():
        for value in values[:1]:
            text = clean_prompt_snippet(value, 24)
            if _looks_garbled(text):
                continue
            if text:
                parts.append(f"{type_label}:{text}")
    return _join(parts[:2])


def get_runtime_policy_inject(*, layers):
    if not layers or not hasattr(layers, "self_improvement"):
        return ""
    try:
        context = layers.self_improvement.active_policy_context(limit=6)
    except Exception:
        return ""
    inject = context.get("prompt_inject") if isinstance(context, dict) else ""
    if not inject:
        return ""
    return "runtime_policy: " + str(inject).strip()

