from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from zhiyue_project_paths import DATA_DIR


PROFILES_DIR = (DATA_DIR / "profiles").resolve()
INDEX_FILE = PROFILES_DIR / "index.json"
CURRENT_FILE = PROFILES_DIR / "current.json"


def _now_iso() -> str:
    try:
        from datetime import datetime
        from zoneinfo import ZoneInfo

        tz = os.environ.get("ZHIYUE_TIMEZONE", "Asia/Shanghai") or "Asia/Shanghai"
        return datetime.now(ZoneInfo(tz)).isoformat()
    except Exception:
        from datetime import datetime

        return datetime.now().isoformat()


def _safe_load_json(path: Path, default: Any) -> Any:
    try:
        if path.exists():
            raw = path.read_text(encoding="utf-8")
            return json.loads(raw) if raw.strip() else default
    except Exception:
        return default
    return default


def _safe_write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _sanitize_profile_id(value: str) -> str:
    s = (value or "").strip().lower()
    s = re.sub(r"[^a-z0-9_-]+", "-", s).strip("-")
    return s or "default"


def ensure_default_profile() -> None:
    PROFILES_DIR.mkdir(parents=True, exist_ok=True)
    idx = _safe_load_json(INDEX_FILE, {})
    if not isinstance(idx, dict):
        idx = {}
    profiles = idx.get("profiles")
    if not isinstance(profiles, list):
        profiles = []
    if not any(isinstance(p, dict) and p.get("id") == "default" for p in profiles):
        profiles.append({"id": "default", "name": "默认", "created_at": _now_iso()})
    idx["profiles"] = profiles
    _safe_write_json(INDEX_FILE, idx)

    cur = _safe_load_json(CURRENT_FILE, {})
    if not isinstance(cur, dict) or not cur.get("id"):
        _safe_write_json(CURRENT_FILE, {"id": "default", "updated_at": _now_iso()})


def list_profiles() -> dict[str, Any]:
    ensure_default_profile()
    idx = _safe_load_json(INDEX_FILE, {})
    if not isinstance(idx, dict):
        idx = {}
    profiles = idx.get("profiles")
    if not isinstance(profiles, list):
        profiles = []
    cur = _safe_load_json(CURRENT_FILE, {})
    current_id = str(cur.get("id") or "default")
    return {"profiles": profiles, "current_id": current_id}


def create_profile(*, name: str, profile_id: str | None = None) -> dict[str, Any]:
    ensure_default_profile()
    pid = _sanitize_profile_id(profile_id or name)
    if pid in {"", "default"}:
        pid = "default"
    idx = _safe_load_json(INDEX_FILE, {})
    if not isinstance(idx, dict):
        idx = {}
    profiles = idx.get("profiles")
    if not isinstance(profiles, list):
        profiles = []
    if any(isinstance(p, dict) and p.get("id") == pid for p in profiles):
        return {"ok": False, "error": "profile_exists", "id": pid}
    profiles.append({"id": pid, "name": (name or pid).strip() or pid, "created_at": _now_iso()})
    idx["profiles"] = profiles
    _safe_write_json(INDEX_FILE, idx)
    (PROFILES_DIR / pid).mkdir(parents=True, exist_ok=True)
    return {"ok": True, "id": pid}


def set_current_profile(profile_id: str) -> dict[str, Any]:
    ensure_default_profile()
    pid = _sanitize_profile_id(profile_id)
    info = list_profiles()
    if not any(isinstance(p, dict) and p.get("id") == pid for p in info["profiles"]):
        return {"ok": False, "error": "profile_not_found", "id": pid}
    _safe_write_json(CURRENT_FILE, {"id": pid, "updated_at": _now_iso()})
    return {"ok": True, "id": pid}


def get_current_profile_id() -> str:
    ensure_default_profile()
    cur = _safe_load_json(CURRENT_FILE, {})
    if isinstance(cur, dict):
        return str(cur.get("id") or "default")
    return "default"
