# -*- coding: utf-8 -*-
from __future__ import annotations


def preprocess_growth_turn(
    user_msg,
    *,
    source_history,
    chat_history,
    maybe_decay_learning_notes,
    prune_expired_state,
    maybe_compact_memories,
    clean_reply,
    build_display_messages,
    detect_user_directive,
    load_user_directives,
    save_user_directives,
    state_hygiene_reply,
    append_history_turn,
    intimacy,
):
    maybe_decay_learning_notes()
    prune_expired_state()
    maybe_compact_memories()

    effective_history = source_history if source_history is not None else chat_history
    if not user_msg:
        return {
            "done": True,
            "result": {
                "reply": "",
                "messages": [],
                "error": True,
                "error_code": "empty_user_msg",
                "error_message": "empty user message",
                "reply_source": "service_unavailable",
                "used_fallback": False,
                "reply_repaired": False,
            },
        }

    new_directive = detect_user_directive(user_msg)
    active_directives = load_user_directives()
    if new_directive:
        active_directives.append(new_directive)
        save_user_directives(active_directives)
        active_directives = load_user_directives()

    hygiene = state_hygiene_reply(user_msg)
    if hygiene:
        cand = clean_reply(hygiene)
        if cand:
            return {
                "done": True,
                "result": {
                    "reply": cand,
                    "messages": build_display_messages(user_msg, cand, allow_followup=False),
                    "error": False,
                    "rule_reply": "state_hygiene",
                    "reply_source": "rule_hint",
                    "used_fallback": False,
                    "reply_repaired": False,
                    "coalesced_skip": True,
                    "level": intimacy.data["level"],
                    "stage": intimacy.get_stage(),
                },
            }

    return {
        "done": False,
        "effective_history": effective_history,
        "active_directives": active_directives,
    }
