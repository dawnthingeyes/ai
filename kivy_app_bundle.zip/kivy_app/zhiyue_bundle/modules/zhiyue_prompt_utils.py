from __future__ import annotations

import hashlib
import json
import re
from typing import Any


def sanitize_prompt_history(messages: Any, limit: int = 12) -> list[dict[str, str]]:
    if not isinstance(messages, list):
        return []
    cleaned: list[dict[str, str]] = []
    for item in messages:
        if not isinstance(item, dict):
            continue
        role = str(item.get("role") or item.get("type") or item.get("sender") or "").lower()
        content = str(item.get("content") or item.get("text") or item.get("message") or "").strip()
        if not content:
            continue
        if role in {"assistant", "ai", "bot"}:
            norm_role = "assistant"
        else:
            norm_role = "user"
        if cleaned and cleaned[-1]["role"] == norm_role:
            cleaned[-1]["content"] = f"{cleaned[-1]['content']}\n{content}".strip()
            continue
        cleaned.append({"role": norm_role, "content": content})
    if len(cleaned) > limit:
        cleaned = cleaned[-limit:]
    return cleaned


def build_model_user_message(user_msg: Any) -> str:
    text = str(user_msg or "").strip()
    if not text:
        return ""
    if text.lstrip().startswith("/no_think"):
        return text
    return f"/no_think\n{text}"


def choose_lm_reply_max_tokens(user_msg: Any, history: Any = None, *, compact: bool = False, rewrite: bool = False) -> int:
    # Qwen3.6-35B MoE needs much higher limits — internal reasoning
    # consumes a large fraction even with thinking disabled.
    limit = 1024
    msg = str(user_msg or "").strip()
    history_len = len(history or [])
    if rewrite:
        target = 640 if compact or len(msg) <= 24 else 768
    elif compact or len(msg) <= 18:
        target = 512
    elif len(msg) <= 80 and history_len <= 6:
        target = 640
    else:
        target = 768
    return max(320, min(limit, target))


def build_prompt_cache_fingerprint(*, user_msg: Any, history: Any = None, system_prefix: Any = "", route: str = "", user_directives: Any = None) -> str:
    normalized_history = sanitize_prompt_history(history or [])
    compact_history = [
        {"role": item.get("role", ""), "content": re.sub(r"\s+", " ", str(item.get("content") or "")).strip()[:180]}
        for item in normalized_history[-6:]
    ]
    normalized_directives = []
    for directive in user_directives or []:
        if not isinstance(directive, dict):
            continue
        normalized_directives.append({
            "action": str(directive.get("action") or "").strip()[:80],
            "scope": str(directive.get("scope") or "").strip()[:40],
        })
    payload = {
        "route": str(route or "").strip(),
        "system_prefix": re.sub(r"\s+", " ", str(system_prefix or "")).strip()[:600],
        "user_msg": re.sub(r"\s+", " ", str(user_msg or "")).strip()[:240],
        "history": compact_history,
        "directives": normalized_directives,
    }
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8", errors="ignore")).hexdigest()
