# -*- coding: utf-8 -*-
"""
Optional enhancement layers for zhiyue_connected.py.

The module keeps the default project runnable with only the standard library.
External systems such as Qdrant, faster-whisper, Piper, Promptfoo, Langfuse or
Phoenix can be attached through env vars and API boundaries without changing the
chat loop.
"""
from __future__ import annotations

import hashlib
import importlib
import json
import math
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time
import uuid
import webbrowser
import threading
from dataclasses import dataclass
from datetime import datetime
from html import unescape
from pathlib import Path
from typing import Any, Callable
from urllib.parse import urlparse
from zoneinfo import ZoneInfo

import requests
import zhiyue_connected as _zc
from zhiyue_project_paths import (
    BASE_DIR,
    EMOJI_MANIFEST_PATH,
    IMAGE_MANIFEST_PATH,
    OBSERVABILITY_DB,
    SELF_MONITOR_FINDINGS_FILE,
    VOICE_PROFILE_FILE,
)

import zhiyue_memory_v2 as _mv2

try:
    import indextts  # type: ignore
except Exception:
    indextts = None  # type: ignore


JsonDict = dict[str, Any]
IMAGE_MANIFEST_FILE = IMAGE_MANIFEST_PATH
EMOJI_MANIFEST_FILE = EMOJI_MANIFEST_PATH
EMOJI_LIBRARY_DIR = Path(os.environ.get("ZHIYUE_EMOJI_DIR", str(BASE_DIR / "emojis")))
TIMEZONE_NAME = os.environ.get("ZHIYUE_TIMEZONE", "Asia/Shanghai").strip() or "Asia/Shanghai"
try:
    APP_TIMEZONE = ZoneInfo(TIMEZONE_NAME)
except Exception:
    APP_TIMEZONE = ZoneInfo("Asia/Shanghai")
    TIMEZONE_NAME = "Asia/Shanghai"


STOPWORDS = {
    "我", "你", "他", "她", "它", "我们", "你们", "他们", "这个", "那个", "这些", "那些",
    "今天", "明天", "后天", "刚才", "现在", "一下", "一点", "有点", "什么", "怎么", "为什么",
    "可以", "不是", "还是", "然后", "一下子", "这个事", "那个事", "事情", "问题", "还有",
    "就是", "感觉", "觉得", "现在", "是不是", "有没有", "行不行",
}

DOMAIN_TERMS = [
    "央企", "笔试", "面试", "考试", "行测", "申论", "错题", "刷题", "睡过头", "闹钟",
    "熬夜", "睡不着", "夜猫子", "累", "焦虑", "难受", "崩溃", "委屈", "陪我",
    "甜食", "甜的", "不能吃辣", "吃辣", "辣", "生日", "兰州", "河南", "中医",
    "程序员", "说教", "讲道理", "客服", "首先", "其次", "别问", "记住",
    "别忘", "吃醋", "微信", "名字", "张凯", "张致悦",
]


def now_local() -> datetime:
    return datetime.now(APP_TIMEZONE)


def now_iso() -> str:
    return now_local().isoformat()


def parse_datetime_local(value: str | None) -> datetime | None:
    if not value:
        return None
    dt = datetime.fromisoformat(str(value))
    if dt.tzinfo is None:
        return dt.replace(tzinfo=APP_TIMEZONE)
    return dt.astimezone(APP_TIMEZONE)


def json_dumps(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def safe_json_loads(value: str | None, default: Any = None) -> Any:
    if not value:
        return default
    try:
        return json.loads(value)
    except Exception:
        return default


def load_voice_profile() -> JsonDict:
    if not VOICE_PROFILE_FILE.exists():
        return {}
    try:
        data = json.loads(VOICE_PROFILE_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def save_voice_profile(data: JsonDict) -> None:
    try:
        VOICE_PROFILE_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        return


def normalize_text_key(text: str | None) -> str:
    text = (text or "").strip().lower()
    return re.sub(r"\W+", "", text)


def clean_snippet(text: str | None, limit: int = 120) -> str:
    value = re.sub(r"\s+", " ", (text or "").strip())
    if len(value) > limit:
        return value[:limit].rstrip()
    return value


def tokenize(text: str | None, limit: int = 80) -> list[str]:
    raw = (text or "").strip().lower()
    if not raw:
        return []

    tokens: list[str] = []
    seen: set[str] = set()

    def push(token: str) -> None:
        token = (token or "").strip().lower()
        if len(token) < 2 or token in STOPWORDS or token in seen:
            return
        seen.add(token)
        tokens.append(token)

    for token in re.findall(r"[a-z0-9][a-z0-9_+\-.]{1,}", raw):
        push(token)
        if len(tokens) >= limit:
            return tokens[:limit]

    for term in DOMAIN_TERMS:
        if term in raw:
            push(term)
            if len(tokens) >= limit:
                return tokens[:limit]

    for block in re.findall(r"[\u4e00-\u9fff]{2,}", raw):
        if block in STOPWORDS:
            continue
        if len(block) <= 8:
            push(block)
        for size in (2, 3, 4):
            for idx in range(0, len(block) - size + 1):
                push(block[idx:idx + size])
                if len(tokens) >= limit:
                    return tokens[:limit]

    return tokens[:limit]


def recency_bonus(*values: str | None) -> float:
    best = 0.0
    now = now_local()
    for value in values:
        if not value:
            continue
        try:
            dt = parse_datetime_local(str(value))
        except Exception:
            continue
        age_days = max(0.0, (now - dt).total_seconds() / 86400.0)
        best = max(best, max(0.0, 1.3 - age_days * 0.09))
    return best


def memory_priority(mem_type: str | None, source: str | None = None, category: str | None = None) -> tuple[float, list[str]]:
    mem_type = (mem_type or "fact").strip().lower()
    source = (source or "chat").strip().lower()
    category = (category or "").strip()
    bonus = 0.0
    reasons: list[str] = []
    if source == "correction" or category == "纠错":
        bonus += 4.0
        reasons.append("priority:correction")
    if mem_type == "boundary":
        bonus += 2.2
        reasons.append("priority:boundary")
    elif mem_type == "preference":
        bonus += 1.0
        reasons.append("priority:preference")
    elif mem_type == "experience":
        bonus += 0.8
        reasons.append("priority:experience")
    elif mem_type == "fact":
        bonus += 0.5
        reasons.append("priority:fact")
    if source and source != "chat":
        reasons.append(f"source:{source}")
    return bonus, reasons


def _resolve_observability_db_path(db_path: Path | str, fallback_base: Path | str | None = None) -> Path:
    path = Path(db_path).expanduser()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        return path
    except Exception:
        if fallback_base is None:
            raise
        base = Path(fallback_base).expanduser()
        base.mkdir(parents=True, exist_ok=True)
        return base / (path.name or "zhiyue_observability.db")


def _connect_observability_db(db_path: Path | str, fallback_base: Path | str | None = None) -> sqlite3.Connection:
    primary = _resolve_observability_db_path(db_path, fallback_base)
    try:
        return sqlite3.connect(str(primary), check_same_thread=False)
    except sqlite3.OperationalError:
        if fallback_base is None:
            raise
        fallback = _resolve_observability_db_path(Path(fallback_base) / primary.name, fallback_base)
        return sqlite3.connect(str(fallback), check_same_thread=False)


@dataclass
class LayerConfig:
    base_dir: Path
    memory_db: Path
    growth_db: Path
    observability_db: Path
    memory_backend: str
    qdrant_url: str
    qdrant_collection: str
    qdrant_api_key: str
    embedding_url: str
    embedding_model: str
    desktop_enabled: bool
    piper_exe: str
    piper_model: str
    skills_dir: Path
    local_read_roots: list[Path]
    local_write_output_dir: Path
    browser_allowed_domains: set[str]
    skill_allowlist: set[str]
    enabled_toolsets: set[str]

    @classmethod
    def from_env(cls, base_dir: Path | str, memory_db: Path | str, growth_db: Path | str) -> "LayerConfig":
        base = Path(base_dir)
        observability_db = _resolve_observability_db_path(
            os.environ.get("ZHIYUE_OBSERVABILITY_DB", str(OBSERVABILITY_DB)),
            base,
        )
        browser_allowed_domains_raw = os.environ.get("ZHIYUE_BROWSER_ALLOWED_DOMAINS", "").strip() or "localhost,127.0.0.1"
        skill_allowlist_raw = os.environ.get("ZHIYUE_SKILL_ALLOWLIST", "").strip() or (
            "memory.search,memory.add,agent.plan,relationship.proactive,"
            "voice.transcribe,"
            "local_files.read,local_files.list,local_files.search,"
            "local_files.mkdir,local_files.copy,local_files.move,local_files.delete,local_files.write_text,"
            "local_images.define,"
            "local_docs.rewrite,local_docs.extract,"
            "browser.read,browser.fill_form"
        )
        enabled_toolsets_raw = os.environ.get("ZHIYUE_ENABLED_TOOLSETS", "").strip() or "memory,agent,relationship,filesystem,browser"
        return cls(
            base_dir=base,
            memory_db=Path(memory_db),
            growth_db=Path(growth_db),
            observability_db=observability_db,
            memory_backend=os.environ.get("ZHIYUE_MEMORY_BACKEND", "qdrant").strip().lower(),
            qdrant_url=os.environ.get("ZHIYUE_QDRANT_URL", "http://127.0.0.1:6333").strip(),
            qdrant_collection=os.environ.get("ZHIYUE_QDRANT_COLLECTION", "zhiyue_memory").strip(),
            qdrant_api_key=os.environ.get("ZHIYUE_QDRANT_API_KEY", "").strip(),
            embedding_url=os.environ.get("ZHIYUE_EMBEDDING_URL", "").strip(),
            embedding_model=os.environ.get("ZHIYUE_EMBEDDING_MODEL", "text-embedding-nomic-embed-text-v1.5").strip(),
            desktop_enabled=os.environ.get("ZHIYUE_DESKTOP_ENABLE", "0").strip() == "1",
            piper_exe=os.environ.get("ZHIYUE_PIPER_EXE", "").strip(),
            piper_model=os.environ.get("ZHIYUE_PIPER_MODEL", "").strip(),
            skills_dir=Path(os.environ.get("ZHIYUE_SKILLS_DIR", str(base / "skills"))),
            local_read_roots=_default_local_read_roots(base),
            local_write_output_dir=_default_local_write_output_dir(base),
            browser_allowed_domains={
                item.strip().lower()
                for item in browser_allowed_domains_raw.split(",")
                if item.strip()
            },
            skill_allowlist={
                item.strip()
                for item in skill_allowlist_raw.split(",")
                if item.strip()
            },
            enabled_toolsets={
                item.strip().lower()
                for item in enabled_toolsets_raw.split(",")
                if item.strip()
            },
        )


def _default_local_read_roots(base: Path) -> list[Path]:
    configured = os.environ.get("ZHIYUE_LOCAL_READ_ROOTS", "").strip()
    roots: list[Path] = []
    if configured:
        for item in configured.split(";"):
            item = item.strip()
            if item:
                roots.append(Path(item).expanduser().resolve())
        return roots

    home = Path.home()
    candidates = [
        base.resolve(),
        (base / "workspace").resolve(),
        (home / "Desktop").resolve(),
        (home / "Documents").resolve(),
        (home / "Downloads").resolve(),
    ]
    seen: set[str] = set()
    result: list[Path] = []
    for item in candidates:
        key = str(item).lower()
        if key in seen:
            continue
        seen.add(key)
        result.append(item)
    return result


def _default_local_write_output_dir(base: Path) -> Path:
    configured = os.environ.get("ZHIYUE_LOCAL_WRITE_OUTPUT_DIR", "").strip()
    if configured:
        return Path(configured).expanduser().resolve()
    return (base / "workspace" / "exports").resolve()


class MemoryRetrievalLayer:
    """Hybrid local retrieval with an optional vector backend boundary."""

    def __init__(self, config: LayerConfig):
        self.config = config
        self.last_sync_count = 0
        self.last_sync_at: str | None = None
        self.last_error = ""
        self.vector_sync_count = 0
        self.vector_sync_at: str | None = None
        self.vector_sync_error = ""
        self.vector_fallback_count = 0
        self._qdrant_client_cache = None
        self.vector_status = self._detect_vector_backend()
        _mv2._inject_deps({
            "tokenize": tokenize,
            "clean_snippet": clean_snippet,
            "normalize_text_key": normalize_text_key,
            "parse_datetime_local": parse_datetime_local,
            "now_local": globals().get("now_local"),
            "now_iso": globals().get("now_iso"),
            "memory_priority": memory_priority,
            "recency_bonus": recency_bonus,
            "cosine_similarity": globals().get("cosine_similarity"),
        })
        self._init_index()
        self._init_fts5()

    def _connect(self) -> sqlite3.Connection:
        return sqlite3.connect(str(self.config.memory_db), check_same_thread=False)

    def _init_index(self) -> None:
        try:
            conn = self._connect()
            try:
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS memory_retrieval_index (
                        memory_id INTEGER PRIMARY KEY,
                        search_text TEXT NOT NULL,
                        tokens_json TEXT NOT NULL,
                        content_key TEXT NOT NULL,
                        mem_type TEXT DEFAULT 'fact',
                        category TEXT DEFAULT 'general',
                        source TEXT DEFAULT 'chat',
                        indexed_at TEXT NOT NULL
                    )
                """)
                conn.commit()
            finally:
                conn.close()
        except Exception as err:
            self.last_error = str(err)

    def _init_fts5(self) -> None:
        """Initialize FTS5 virtual table for BM25 keyword search."""
        try:
            _mv2.init_fts5(self.config.memory_db)
        except Exception as err:
            self.last_error = f"fts5 init failed: {err}"

    def _detect_vector_backend(self) -> JsonDict:
        backend = self.config.memory_backend
        status = {
            "requested": backend,
            "active": "local_hybrid",
            "qdrant_ready": False,
            "embedding_ready": True,
            "embedding_mode": "remote" if self.config.embedding_url else "local_hash",
            "qdrant_url": self.config.qdrant_url,
            "qdrant_collection": self.config.qdrant_collection,
            "client": "none",
            "reason": "",
        }
        if backend not in {"qdrant", "qdrant_rest", "vector"}:
            return status
        if not self.config.qdrant_url:
            status["reason"] = "ZHIYUE_QDRANT_URL not set"
            return status

        headers = self._qdrant_headers()
        try:
            resp = requests.get(f"{self.config.qdrant_url.rstrip('/')}/collections", headers=headers, timeout=1.5)
            if resp.status_code < 500:
                status["active"] = "qdrant"
                status["qdrant_ready"] = True
                status["client"] = "rest"
                return status
        except Exception as err:
            status["reason"] = f"qdrant REST unavailable: {err}"

        try:
            from qdrant_client import QdrantClient  # type: ignore
            kwargs = {"url": self.config.qdrant_url}
            if self.config.qdrant_api_key:
                kwargs["api_key"] = self.config.qdrant_api_key
            client = QdrantClient(**kwargs)
            probe = getattr(client, "get_collections", None)
            if callable(probe):
                probe()
            else:
                client.get_collection(self.config.qdrant_collection)
            status["active"] = "qdrant"
            status["qdrant_ready"] = True
            status["client"] = "sdk"
            status["reason"] = "qdrant REST unavailable; SDK probe succeeded"
        except Exception as err:
            if not status["reason"]:
                status["reason"] = f"qdrant unavailable: {err}"
            else:
                status["reason"] = f"{status['reason']}; SDK probe unavailable: {err}"
        return status

    def _qdrant_headers(self) -> dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if self.config.qdrant_api_key:
            headers["api-key"] = self.config.qdrant_api_key
        return headers

    def _qdrant_rest_url(self, path: str) -> str:
        return f"{self.config.qdrant_url.rstrip('/')}/{path.lstrip('/')}"

    def _qdrant_rest_request(self, method: str, path: str, **kwargs: Any) -> requests.Response:
        headers = kwargs.pop("headers", {}) or {}
        merged_headers = {**self._qdrant_headers(), **headers}
        return requests.request(
            method,
            self._qdrant_rest_url(path),
            headers=merged_headers,
            timeout=kwargs.pop("timeout", 20),
            **kwargs,
        )

    def _hash_embedding(self, text: str, dim: int = 128) -> list[float]:
        vector = [0.0] * dim
        terms = tokenize(text, limit=96)
        if not terms and text:
            terms = [text[:32]]
        for term in terms:
            digest = hashlib.blake2b(term.encode("utf-8", errors="ignore"), digest_size=16).digest()
            primary = int.from_bytes(digest[:4], "little") % dim
            secondary = int.from_bytes(digest[8:12], "little") % dim
            sign = 1.0 if digest[4] % 2 else -1.0
            weight = 1.0 + min(len(term), 8) * 0.06
            vector[primary] += sign * weight
            vector[secondary] += weight * 0.35
        norm = math.sqrt(sum(item * item for item in vector)) or 1.0
        return [item / norm for item in vector]

    def _remote_embedding(self, text: str) -> list[float] | None:
        if not self.config.embedding_url:
            return None
        try:
            resp = requests.post(
                self.config.embedding_url,
                json={"model": self.config.embedding_model, "input": text},
                timeout=30,
            )
            if resp.status_code >= 400:
                self.vector_sync_error = f"embedding HTTP {resp.status_code}: {resp.text[:200]}"
                return None
            data = resp.json()
            if isinstance(data, dict) and isinstance(data.get("data"), list) and data["data"]:
                embedding = data["data"][0].get("embedding")
                if isinstance(embedding, list):
                    return [float(item) for item in embedding]
            if isinstance(data, dict) and isinstance(data.get("embedding"), list):
                return [float(item) for item in data["embedding"]]
            if isinstance(data, list):
                return [float(item) for item in data]
        except Exception as err:
            self.vector_sync_error = f"embedding failed: {err}"
        return None

    def _embed_text(self, text: str) -> list[float]:
        return self._remote_embedding(text) or self._hash_embedding(text)

    def embedding_health(self) -> JsonDict:
        if not self.config.embedding_url:
            return {
                "ok": True,
                "mode": "local_hash",
                "model": "hash-token-128",
                "dim": 128,
                "reason": "ZHIYUE_EMBEDDING_URL not set",
            }
        vector = self._remote_embedding("张致悦记忆检索健康检查")
        if vector:
            return {
                "ok": True,
                "mode": "remote",
                "model": self.config.embedding_model,
                "dim": len(vector),
                "url": self.config.embedding_url,
            }
        return {
            "ok": False,
            "mode": "remote",
            "model": self.config.embedding_model,
            "url": self.config.embedding_url,
            "reason": self.vector_sync_error or "embedding probe failed",
            "fallback": "local_hash",
        }

    def _qdrant_client(self):
        if self._qdrant_client_cache is not None:
            return self._qdrant_client_cache
        if self.vector_status.get("active") != "qdrant":
            return None
        if self.vector_status.get("client") == "rest":
            return None
        try:
            from qdrant_client import QdrantClient  # type: ignore
            kwargs = {"url": self.config.qdrant_url}
            if self.config.qdrant_api_key:
                kwargs["api_key"] = self.config.qdrant_api_key
            self._qdrant_client_cache = QdrantClient(**kwargs)
            return self._qdrant_client_cache
        except Exception as err:
            self.vector_sync_error = f"qdrant client failed: {err}"
            return None

    def _ensure_qdrant_collection_rest(self, vector_size: int) -> bool:
        try:
            resp = self._qdrant_rest_request("GET", f"/collections/{self.config.qdrant_collection}", timeout=5)
            if resp.status_code == 200:
                return True
            if resp.status_code not in {404, 400}:
                self.vector_sync_error = f"qdrant collection check HTTP {resp.status_code}: {resp.text[:200]}"
                return False
            create = self._qdrant_rest_request(
                "PUT",
                f"/collections/{self.config.qdrant_collection}",
                json={"vectors": {"size": int(vector_size), "distance": "Cosine"}},
                timeout=20,
            )
            if create.status_code in {200, 201}:
                return True
            self.vector_sync_error = f"qdrant collection create HTTP {create.status_code}: {create.text[:200]}"
        except Exception as err:
            self.vector_sync_error = f"qdrant REST collection failed: {err}"
        return False

    def _ensure_qdrant_collection(self, vector_size: int) -> bool:
        if self.vector_status.get("client") == "rest":
            return self._ensure_qdrant_collection_rest(vector_size)
        client = self._qdrant_client()
        if not client:
            return False
        try:
            client.get_collection(self.config.qdrant_collection)
            return True
        except Exception as err:
            self.vector_sync_error = f"qdrant get_collection failed before create: {err}"
        try:
            from qdrant_client.models import Distance, VectorParams  # type: ignore
            client.create_collection(
                collection_name=self.config.qdrant_collection,
                vectors_config=VectorParams(size=int(vector_size), distance=Distance.COSINE),
            )
            return True
        except Exception as err:
            self.vector_sync_error = f"qdrant collection failed: {err}"
            return False

    def _sync_qdrant(self, rows: list[JsonDict]) -> JsonDict:
        if self.vector_status.get("active") != "qdrant":
            return {"ok": False, "indexed": 0, "reason": "qdrant not active"}
        if self.vector_status.get("client") == "rest":
            return self._sync_qdrant_rest(rows)
        client = self._qdrant_client()
        if not client:
            return {"ok": False, "indexed": 0, "error": self.vector_sync_error}

        try:
            from qdrant_client.models import PointStruct  # type: ignore
            points = []
            collection_ready = False
            for row in rows:
                memory_id = int(row.get("id") or 0)
                if memory_id <= 0:
                    continue
                content = str(row.get("content") or "")
                summary = str(row.get("summary") or "")
                search_text = " ".join(
                    item for item in [content, summary, str(row.get("category") or ""), str(row.get("mem_type") or "")] if item
                )
                vector = self._embed_text(search_text)
                if not collection_ready:
                    if not self._ensure_qdrant_collection(len(vector)):
                        return {"ok": False, "indexed": 0, "error": self.vector_sync_error}
                    collection_ready = True
                points.append(PointStruct(
                    id=memory_id,
                    vector=vector,
                    payload={
                        "memory_id": memory_id,
                        "content": clean_snippet(content, 240),
                        "summary": clean_snippet(summary, 160),
                        "category": row.get("category") or "general",
                        "mem_type": row.get("mem_type") or "fact",
                        "source": row.get("source") or "chat",
                        "importance": int(row.get("importance") or 1),
                        "recall_count": int(row.get("recall_count") or 0),
                        "created_at": row.get("created_at"),
                        "last_recall": row.get("last_recall"),
                    },
                ))
            for idx in range(0, len(points), 64):
                client.upsert(
                    collection_name=self.config.qdrant_collection,
                    points=points[idx:idx + 64],
                )
            self.vector_sync_count = len(points)
            self.vector_sync_at = now_iso()
            self.vector_sync_error = ""
            return {"ok": True, "indexed": len(points)}
        except Exception as err:
            self.vector_sync_error = str(err)
            return {"ok": False, "indexed": 0, "error": str(err)}

    def _sync_qdrant_rest(self, rows: list[JsonDict]) -> JsonDict:
        try:
            points = []
            collection_ready = False
            for row in rows:
                memory_id = int(row.get("id") or 0)
                if memory_id <= 0:
                    continue
                content = str(row.get("content") or "")
                summary = str(row.get("summary") or "")
                search_text = " ".join(
                    item for item in [content, summary, str(row.get("category") or ""), str(row.get("mem_type") or "")] if item
                )
                vector = self._embed_text(search_text)
                if not collection_ready:
                    if not self._ensure_qdrant_collection(len(vector)):
                        return {"ok": False, "indexed": 0, "error": self.vector_sync_error}
                    collection_ready = True
                points.append({
                    "id": memory_id,
                    "vector": vector,
                    "payload": {
                        "memory_id": memory_id,
                        "content": clean_snippet(content, 240),
                        "summary": clean_snippet(summary, 160),
                        "category": row.get("category") or "general",
                        "mem_type": row.get("mem_type") or "fact",
                        "source": row.get("source") or "chat",
                        "importance": int(row.get("importance") or 1),
                        "recall_count": int(row.get("recall_count") or 0),
                        "created_at": row.get("created_at"),
                        "last_recall": row.get("last_recall"),
                        "confidence": row.get("confidence") or 1.0,
                        "verified_count": row.get("verified_count") or 0,
                    },
                })
            for idx in range(0, len(points), 64):
                resp = self._qdrant_rest_request(
                    "PUT",
                    f"/collections/{self.config.qdrant_collection}/points?wait=true",
                    json={"points": points[idx:idx + 64]},
                    timeout=30,
                )
                if resp.status_code >= 400:
                    self.vector_sync_error = f"qdrant upsert HTTP {resp.status_code}: {resp.text[:200]}"
                    return {"ok": False, "indexed": idx, "error": self.vector_sync_error}
            self.vector_sync_count = len(points)
            self.vector_sync_at = now_iso()
            self.vector_sync_error = ""
            return {"ok": True, "indexed": len(points), "client": "rest"}
        except Exception as err:
            self.vector_sync_error = f"qdrant REST sync failed: {err}"
            return {"ok": False, "indexed": 0, "error": self.vector_sync_error}

    def _search_qdrant(self, query: str | None, limit: int, mem_types: list[str] | tuple[str, ...] | None) -> list[JsonDict]:
        if self.vector_status.get("active") != "qdrant" or not (query or "").strip():
            return []
        if self.vector_status.get("client") == "rest":
            return self._search_qdrant_rest(query, limit=limit, mem_types=mem_types)
        client = self._qdrant_client()
        if not client:
            return []
        try:
            query_vector = self._embed_text(query or "")
            search_limit = max(limit * 4, 16)
            try:
                hits = client.search(
                    collection_name=self.config.qdrant_collection,
                    query_vector=query_vector,
                    limit=search_limit,
                    with_payload=True,
                )
            except AttributeError:
                response = client.query_points(
                    collection_name=self.config.qdrant_collection,
                    query=query_vector,
                    limit=search_limit,
                    with_payload=True,
                )
                hits = getattr(response, "points", response)
        except Exception as err:
            self.vector_sync_error = f"qdrant search failed: {err}"
            return []

        rows = {int(row.get("id") or 0): row for row in self._load_memory_rows(limit=1000)}
        type_filter = set(mem_types or [])
        type_labels = {
            "fact": "事实",
            "preference": "偏好",
            "boundary": "底线",
            "experience": "共同经历",
        }
        result: list[JsonDict] = []
        seen: set[str] = set()
        for hit in hits:
            payload = getattr(hit, "payload", None) or {}
            memory_id = int(payload.get("memory_id") or getattr(hit, "id", 0) or 0)
            row = rows.get(memory_id) or payload
            mem_type = row.get("mem_type") or payload.get("mem_type") or "fact"
            if type_filter and mem_type not in type_filter:
                continue
            text = (row.get("summary") or row.get("content") or payload.get("summary") or payload.get("content") or "").strip()
            key = normalize_text_key(text)
            if not text or key in seen:
                continue
            seen.add(key)
            base_score = float(getattr(hit, "score", 0.0) or 0.0)
            importance = int(row.get("importance") or payload.get("importance") or 1)
            recall_count = int(row.get("recall_count") or payload.get("recall_count") or 0)
            source = row.get("source") or payload.get("source") or "chat"
            category = row.get("category") or payload.get("category") or "general"
            priority_bonus, priority_reasons = memory_priority(mem_type, source=source, category=category)
            recent = recency_bonus(row.get("last_recall") or payload.get("last_recall"), row.get("created_at") or payload.get("created_at"))
            final_score = base_score * 8.0 + importance * 0.5 + min(recall_count, 8) * 0.1 + priority_bonus + recent
            result.append({
                "id": memory_id,
                "content": text,
                "summary": row.get("summary") or payload.get("summary") or "",
                "category": category,
                "importance": importance,
                "created_at": row.get("created_at") or payload.get("created_at"),
                "last_recall": row.get("last_recall") or payload.get("last_recall"),
                "recall_count": recall_count,
                "mem_type": mem_type,
                "source": source,
                "status": row.get("status") or "active",
                "confidence": row.get("confidence") or 1.0,
                "last_verified": row.get("last_verified"),
                "verified_count": row.get("verified_count") or 0,
                "type_label": type_labels.get(mem_type, mem_type),
                "score": round(final_score, 3),
                "matched_terms": [],
                "hit_reason": ["vector:qdrant", f"vector_score:{base_score:.3f}", f"importance:{importance}"] + priority_reasons + (["recent"] if recent > 0 else []),
                "retrieval_backend": "qdrant",
            })
            if len(result) >= limit:
                break
        return result

    def _search_qdrant_rest(self, query: str | None, limit: int, mem_types: list[str] | tuple[str, ...] | None) -> list[JsonDict]:
        try:
            query_vector = self._embed_text(query or "")
            search_limit = max(limit * 4, 16)
            payload: JsonDict = {
                "vector": query_vector,
                "limit": search_limit,
                "with_payload": True,
            }
            type_filter = set(mem_types or [])
            if type_filter:
                payload["filter"] = {
                    "must": [
                        {"key": "mem_type", "match": {"any": sorted(type_filter)}}
                    ]
                }
            resp = self._qdrant_rest_request(
                "POST",
                f"/collections/{self.config.qdrant_collection}/points/search",
                json=payload,
                timeout=20,
            )
            if resp.status_code >= 400:
                self.vector_sync_error = f"qdrant search HTTP {resp.status_code}: {resp.text[:200]}"
                return []
            data = resp.json()
            hits = data.get("result") if isinstance(data, dict) else []
            if not isinstance(hits, list):
                return []
        except Exception as err:
            self.vector_sync_error = f"qdrant REST search failed: {err}"
            return []

        rows = {int(row.get("id") or 0): row for row in self._load_memory_rows(limit=1000)}
        type_labels = {
            "fact": "事实",
            "preference": "偏好",
            "boundary": "底线",
            "experience": "共同经历",
        }
        result: list[JsonDict] = []
        seen: set[str] = set()
        for hit in hits:
            payload = hit.get("payload") if isinstance(hit, dict) else {}
            payload = payload if isinstance(payload, dict) else {}
            memory_id = int(payload.get("memory_id") or hit.get("id") or 0)
            row = rows.get(memory_id) or payload
            mem_type = row.get("mem_type") or payload.get("mem_type") or "fact"
            text = (row.get("summary") or row.get("content") or payload.get("summary") or payload.get("content") or "").strip()
            key = normalize_text_key(text)
            if not text or key in seen:
                continue
            seen.add(key)
            base_score = float(hit.get("score") or 0.0)
            importance = int(row.get("importance") or payload.get("importance") or 1)
            recall_count = int(row.get("recall_count") or payload.get("recall_count") or 0)
            source = row.get("source") or payload.get("source") or "chat"
            category = row.get("category") or payload.get("category") or "general"
            priority_bonus, priority_reasons = memory_priority(mem_type, source=source, category=category)
            recent = recency_bonus(row.get("last_recall") or payload.get("last_recall"), row.get("created_at") or payload.get("created_at"))
            final_score = base_score * 8.0 + importance * 0.5 + min(recall_count, 8) * 0.1 + priority_bonus + recent
            result.append({
                "id": memory_id,
                "content": text,
                "summary": row.get("summary") or payload.get("summary") or "",
                "category": category,
                "importance": importance,
                "created_at": row.get("created_at") or payload.get("created_at"),
                "last_recall": row.get("last_recall") or payload.get("last_recall"),
                "recall_count": recall_count,
                "mem_type": mem_type,
                "source": source,
                "status": row.get("status") or "active",
                "confidence": row.get("confidence") or payload.get("confidence") or 1.0,
                "last_verified": row.get("last_verified"),
                "verified_count": row.get("verified_count") or payload.get("verified_count") or 0,
                "type_label": type_labels.get(mem_type, mem_type),
                "score": round(final_score, 3),
                "matched_terms": [],
                "hit_reason": ["vector:qdrant", "client:rest", f"vector_score:{base_score:.3f}", f"importance:{importance}"] + priority_reasons + (["recent"] if recent > 0 else []),
                "retrieval_backend": "qdrant",
            })
            if len(result) >= limit:
                break
        return result

    # === Multi-Signal Fusion (Optimization 1+2) ===

    def _search_fts5(self, query, limit=20):
        try:
            return _mv2.search_fts5(self.config.memory_db, query, self._load_memory_rows, limit=limit)
        except Exception:
            return []

    def _extract_entities(self, text):
        return _mv2.extract_entities(text)

    def _search_entity(self, query, limit=10):
        try:
            return _mv2.search_entity(self.config.memory_db, query, self._load_memory_rows, limit=limit)
        except Exception:
            return []

    def _fuse_search_results(self, vector_results, fts5_results, entity_results, limit):
        return _mv2.fuse_search_results(vector_results, fts5_results, entity_results, limit)

    def _apply_temporal_filter(self, memories, query):
        return _mv2.apply_temporal_filter(memories, query)

    # === LLM Auto-Extraction (Optimization 3) ===

    def extract_memories_from_conversation(self, messages, max_new=3):
        return _mv2.extract_memories_from_conversation(messages, self, max_new=max_new)

    # === Semantic Dedup & Conflict Detection (Optimization 4) ===

    def _find_semantic_duplicates(self, content, threshold=0.82):
        return _mv2.find_semantic_duplicates(content, self, threshold=threshold)

    def _detect_semantic_conflicts(self, content, mem_type):
        return _mv2.detect_semantic_conflicts(content, mem_type, self)

    def _add_memory_with_dedup(self, content, category="general", importance=1,
                                mem_type="fact", source="chat", confidence=1.0, status="active"):
        return _mv2.check_memory_before_add(
            content, category, importance, mem_type, source, confidence, status, self)

    # === Memory Lifecycle Management (Optimization 5) ===

    def consolidate_memories(self, max_merge=10, min_importance=1, max_age_days=90):
        return _mv2.consolidate_memories(self, max_merge=max_merge, min_importance=min_importance, max_age_days=max_age_days)

    def run_memory_consolidation(self, max_merge=10, min_importance=1, max_age_days=90):
        return self.consolidate_memories(max_merge=max_merge, min_importance=min_importance, max_age_days=max_age_days)

    def _load_memory_rows(self, limit: int = 1000) -> list[JsonDict]:
        conn = self._connect()
        try:
            cols = {row[1] for row in conn.execute("PRAGMA table_info(memories)").fetchall()}
            if not cols:
                return []
            where = "status='active'" if "status" in cols else "1=1"
            order_bits = []
            for col in ("importance", "recall_count", "last_recall", "id"):
                if col in cols:
                    order_bits.append(f"{col} DESC")
            order_sql = ", ".join(order_bits) or "id DESC"
            cur = conn.execute(
                f"SELECT * FROM memories WHERE {where} ORDER BY {order_sql} LIMIT ?",
                (int(limit),),
            )
            names = [item[0] for item in cur.description]
            return [dict(zip(names, row)) for row in cur.fetchall()]
        finally:
            conn.close()

    def sync(self, limit: int = 1000, force: bool = False) -> JsonDict:
        if not force and self.vector_status.get("active") == "qdrant" and self.last_sync_at:
            try:
                synced_at = parse_datetime_local(self.last_sync_at)
                if synced_at and (now_local() - synced_at).total_seconds() < 30:
                    return {"ok": True, "indexed": self.last_sync_count, "skipped": True}
            except Exception as err:
                self.last_error = f"invalid last_sync_at: {err}"
        rows = self._load_memory_rows(limit=limit)
        active_ids = [int(row.get("id")) for row in rows if row.get("id") is not None]
        conn = self._connect()
        try:
            for row in rows:
                memory_id = int(row.get("id"))
                content = row.get("content") or ""
                summary = row.get("summary") or ""
                category = row.get("category") or "general"
                mem_type = row.get("mem_type") or "fact"
                source = row.get("source") or "chat"
                search_text = " ".join(
                    item for item in [str(content), str(summary), str(category), str(mem_type)] if item
                )
                tokens = tokenize(search_text)
                conn.execute(
                    """INSERT OR REPLACE INTO memory_retrieval_index
                       (memory_id, search_text, tokens_json, content_key, mem_type, category, source, indexed_at)
                       VALUES (?,?,?,?,?,?,?,?)""",
                    (
                        memory_id,
                        clean_snippet(search_text, 500),
                        json_dumps(tokens),
                        normalize_text_key(content or summary),
                        mem_type,
                        category,
                        source,
                        now_iso(),
                    ),
                )
            if active_ids:
                placeholders = ",".join("?" for _ in active_ids)
                conn.execute(
                    f"DELETE FROM memory_retrieval_index WHERE memory_id NOT IN ({placeholders})",
                    active_ids,
                )
            else:
                conn.execute("DELETE FROM memory_retrieval_index")
            conn.commit()
            self.last_sync_count = len(rows)
            self.last_sync_at = now_iso()
            self.last_error = ""
            if self.vector_status.get("active") == "qdrant":
                self._sync_qdrant(rows)
            return {"ok": True, "indexed": len(rows)}
        except Exception as err:
            self.last_error = str(err)
            return {"ok": False, "indexed": 0, "error": str(err)}
        finally:
            conn.close()

    def _indexed_docs(self) -> dict[int, JsonDict]:
        conn = self._connect()
        try:
            cur = conn.execute(
                "SELECT memory_id, search_text, tokens_json FROM memory_retrieval_index"
            )
            docs: dict[int, JsonDict] = {}
            for memory_id, search_text, tokens_json in cur.fetchall():
                tokens = safe_json_loads(tokens_json, []) or []
                docs[int(memory_id)] = {
                    "text": search_text or "",
                    "tokens": [str(item) for item in tokens if item],
                }
            return docs
        except Exception as err:
            self.last_error = f"index_docs failed: {err}"
            return {}
        finally:
            conn.close()

    def search(self, query: str | None, limit: int = 5, mem_types: list[str] | tuple[str, ...] | None = None) -> list[JsonDict]:
        self.sync(limit=1000)
        rows = self._load_memory_rows(limit=1000)
        if not rows:
            return []

        qdrant_results = self._search_qdrant(query, limit=limit, mem_types=mem_types)
        # Always compute FTS5 + entity (independent of Qdrant)
        fts5_results = self._search_fts5(query, limit=max(limit * 2, 10))
        entity_results = self._search_entity(query, limit=max(limit, 8))
        if qdrant_results:
            # Multi-signal fusion: Qdrant + FTS5 + entity + temporal
            if fts5_results or entity_results:
                fusion_results = self._fuse_search_results(
                    qdrant_results, fts5_results, entity_results, limit
                )
                fusion_results = self._apply_temporal_filter(fusion_results, query)
                result = _mv2.convert_fusion_to_result(fusion_results, limit)
                if result:
                    return result
            return qdrant_results[:limit]
        if self.vector_status.get("requested") in {"qdrant", "qdrant_rest", "vector"}:
            self.vector_fallback_count += 1

        docs = self._indexed_docs()
        query_tokens = tokenize(query, limit=40)
        query_key = normalize_text_key(query)
        query_text = query or ""
        wants_boundary = any(word in query_text for word in ["边界", "别", "不要", "不想", "不喜欢", "讨厌", "说教", "大道理", "小子", "陪"])
        wants_correction = any(word in query_text for word in ["纠错", "叫什么", "我是谁", "名字", "不是", "别把我当", "认错"])
        identity_probe = any(word in query_text for word in ["叫什么", "我是谁", "名字", "叫我什么"])
        negative_fact_probe = any(word in query_text for word in ["不是", "别把我当", "程序员", "认错"])
        wants_preference = any(word in query_text for word in ["喜欢", "偏好", "口味", "甜", "辣"])
        type_filter = set(mem_types or [])

        df: dict[str, int] = {token: 0 for token in query_tokens}
        for doc in docs.values():
            doc_terms = set(doc.get("tokens") or [])
            for token in query_tokens:
                if token in doc_terms:
                    df[token] += 1

        total_docs = max(1, len(docs) or len(rows))
        scored: list[tuple[float, JsonDict, list[str], list[str], float, float, float, bool]] = []
        for row in rows:
            memory_id = int(row.get("id") or 0)
            mem_type = row.get("mem_type") or "fact"
            if type_filter and mem_type not in type_filter:
                continue

            content = str(row.get("content") or "")
            summary = str(row.get("summary") or "")
            text = summary or content
            category_text = str(row.get("category") or "")
            source = row.get("source") or "chat"
            doc = docs.get(memory_id) or {"text": text, "tokens": tokenize(text)}
            doc_tokens = doc.get("tokens") or []
            doc_counts = {token: doc_tokens.count(token) for token in set(doc_tokens)}
            matched: list[str] = []
            lexical_score = 0.0
            for token in query_tokens:
                freq = doc_counts.get(token, 0)
                if freq <= 0:
                    continue
                matched.append(token)
                idf = math.log((total_docs + 1.0) / (1.0 + df.get(token, 0))) + 1.0
                lexical_score += idf * (1.0 + min(freq, 4) * 0.25) * (1.15 if len(token) >= 3 else 1.0)

            content_key = normalize_text_key(text)
            phrase_score = 0.0
            if query_key and (query_key in content_key or content_key in query_key):
                phrase_score = 2.0
            probe_match = False
            if wants_boundary and (mem_type == "boundary" or category_text in {"边界", "风格", "陪伴方式"}):
                probe_match = True
            if wants_correction and (
                source == "correction"
                or (category_text == "纠错" and not identity_probe)
                or (identity_probe and (category_text == "人物" or any(k in text for k in ["名字", "张凯"])))
                or (negative_fact_probe and any(k in text for k in ["不是程序员", "别把我当", "不是"]))
            ):
                probe_match = True
            if wants_preference and (mem_type == "preference" or category_text == "偏好"):
                probe_match = True
            if query_tokens and lexical_score <= 0 and phrase_score <= 0 and not probe_match:
                continue

            importance = int(row.get("importance") or 1)
            recall_count = int(row.get("recall_count") or 0)
            confidence = float(row.get("confidence") or 1.0)
            verified_count = int(row.get("verified_count") or 0)
            priority_bonus, priority_reasons = memory_priority(mem_type, source=source, category=row.get("category") or "general")
            recent = recency_bonus(row.get("last_recall"), row.get("created_at"))
            source_bonus = 0.35 if source != "chat" else 0.0
            verified_bonus = min(1.0, verified_count * 0.12)
            final_score = (
                lexical_score * 1.8
                + phrase_score
                + importance * 0.65
                + min(recall_count, 8) * 0.12
                + min(confidence, 5.0) * 0.22
                + verified_bonus
                + source_bonus
                + priority_bonus
                + recent
                + (1.4 if probe_match else 0.0)
            )
            if not query_tokens:
                final_score = (
                    importance * 0.75
                    + min(recall_count, 8) * 0.14
                    + min(confidence, 5.0) * 0.22
                    + verified_bonus
                    + source_bonus
                    + priority_bonus
                    + recent
                    + (1.4 if probe_match else 0.0)
                )
            scored.append((final_score, row, matched, priority_reasons, lexical_score, phrase_score, recent, probe_match))

        scored.sort(key=lambda item: (item[0], int(item[1].get("importance") or 0), int(item[1].get("id") or 0)), reverse=True)
        seen: set[str] = set()
        result: list[JsonDict] = []
        type_labels = {
            "fact": "事实",
            "preference": "偏好",
            "boundary": "底线",
            "experience": "共同经历",
        }
        for final_score, row, matched, priority_reasons, lexical_score, phrase_score, recent, probe_match in scored:
            text = (row.get("summary") or row.get("content") or "").strip()
            key = normalize_text_key(text)
            if not text or key in seen:
                continue
            seen.add(key)
            mem_type = row.get("mem_type") or "fact"
            result.append({
                "id": row.get("id"),
                "content": text,
                "summary": row.get("summary") or "",
                "category": row.get("category") or "general",
                "importance": row.get("importance") or 1,
                "created_at": row.get("created_at"),
                "last_recall": row.get("last_recall"),
                "recall_count": row.get("recall_count") or 0,
                "mem_type": mem_type,
                "source": row.get("source") or "chat",
                "status": row.get("status") or "active",
                "confidence": row.get("confidence") or 1.0,
                "last_verified": row.get("last_verified"),
                "verified_count": row.get("verified_count") or 0,
                "type_label": type_labels.get(mem_type, mem_type),
                "score": round(float(final_score), 3),
                "matched_terms": matched[:8],
                "hit_reason": (
                    (["lexical:" + ",".join(matched[:5])] if matched else [])
                    + (["phrase_overlap"] if phrase_score > 0 else [])
                    + (["probe_match"] if probe_match else [])
                    + priority_reasons
                    + [f"importance:{row.get('importance') or 1}"]
                    + (["verified"] if int(row.get("verified_count") or 0) else [])
                    + (["recent"] if recent > 0 else [])
                ),
                "retrieval_backend": self.vector_status.get("active") or "local_hybrid",
            })
            if len(result) >= limit:
                break
        # Add FTS5 + entity bonus results (always available, no Qdrant needed)
        if fts5_results or entity_results:
            for item in (fts5_results + entity_results):
                row = item.get("row", item)
                text = (row.get("summary") or row.get("content") or "").strip()
                key = normalize_text_key(text)
                if not text or key in seen:
                    continue
                seen.add(key)
                mt = row.get("mem_type") or "fact"
                result.append({
                    "id": row.get("id"),
                    "content": text,
                    "summary": row.get("summary") or "",
                    "category": row.get("category") or "general",
                    "importance": row.get("importance") or 1,
                    "created_at": row.get("created_at"),
                    "last_recall": row.get("last_recall"),
                    "recall_count": row.get("recall_count") or 0,
                    "mem_type": mt,
                    "source": row.get("source") or "chat",
                    "status": row.get("status") or "active",
                    "confidence": row.get("confidence") or 1.0,
                    "last_verified": row.get("last_verified"),
                    "verified_count": row.get("verified_count") or 0,
                    "type_label": type_labels.get(mt, mt),
                    "score": round(float(item.get("score", 0.5)), 3),
                    "matched_terms": [],
                    "hit_reason": ["fts5_bonus:" + (item.get("source") or "fts5")],
                    "retrieval_backend": "local_hybrid_fts5",
                })
                if len(result) >= limit:
                    break
        return result

    def status(self) -> JsonDict:
        return {
            "backend": self.vector_status,
            "last_sync_at": self.last_sync_at,
            "last_sync_count": self.last_sync_count,
            "last_error": self.last_error,
            "vector_sync_at": self.vector_sync_at,
            "vector_sync_count": self.vector_sync_count,
            "vector_sync_error": self.vector_sync_error,
            "vector_fallback_count": self.vector_fallback_count,
            "embedding": self.embedding_health(),
            "index": "memory_retrieval_index",
        }


class ObservabilityLayer:
    """Local trace and deterministic eval store."""

    def __init__(self, config: LayerConfig):
        self.config = config
        self.db_path = config.observability_db
        self._write_count = 0
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        return _connect_observability_db(self.db_path, self.config.base_dir)

    def _init_db(self) -> None:
        conn = self._connect()
        try:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS traces (
                    id TEXT PRIMARY KEY,
                    created_at TEXT NOT NULL,
                    channel TEXT DEFAULT 'web',
                    route TEXT DEFAULT '',
                    user_msg TEXT DEFAULT '',
                    reply TEXT DEFAULT '',
                    score REAL DEFAULT 0,
                    reasons_json TEXT DEFAULT '[]',
                    recalled_json TEXT DEFAULT '[]',
                    metrics_json TEXT DEFAULT '{}',
                    latency_ms INTEGER DEFAULT 0,
                    meta_json TEXT DEFAULT '{}'
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS eval_runs (
                    id TEXT PRIMARY KEY,
                    created_at TEXT NOT NULL,
                    name TEXT DEFAULT '',
                    summary_json TEXT DEFAULT '{}',
                    result_json TEXT DEFAULT '{}'
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS agent_runs (
                    id TEXT PRIMARY KEY,
                    created_at TEXT NOT NULL,
                    channel TEXT DEFAULT 'web',
                    route TEXT DEFAULT '',
                    user_msg TEXT DEFAULT '',
                    reply TEXT DEFAULT '',
                    engine TEXT DEFAULT '',
                    mode TEXT DEFAULT '',
                    node_status_json TEXT DEFAULT '{}',
                    degraded INTEGER DEFAULT 0,
                    degraded_nodes_json TEXT DEFAULT '[]',
                    latency_ms INTEGER DEFAULT 0,
                    run_json TEXT DEFAULT '{}',
                    trace_id TEXT DEFAULT '',
                    meta_json TEXT DEFAULT '{}'
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS learning_events (
                    id TEXT PRIMARY KEY,
                    created_at TEXT NOT NULL,
                    stage TEXT DEFAULT '',
                    source TEXT DEFAULT '',
                    skill_name TEXT DEFAULT '',
                    user_msg TEXT DEFAULT '',
                    effect TEXT DEFAULT '',
                    judge_score REAL DEFAULT 0,
                    meta_json TEXT DEFAULT '{}'
                )
            """)
            conn.commit()
        finally:
            conn.close()

    def _maybe_prune_db(self) -> None:
        """滚动清理：DB 超过 1 GB 时每表保留最新 2/3 记录。"""
        try:
            size = os.path.getsize(str(self.db_path)) if os.path.isfile(str(self.db_path)) else 0
        except OSError:
            size = 0
        if size < 1_073_741_824:
            return
        try:
            conn = self._connect()
            try:
                tables = ["traces", "agent_runs", "eval_runs", "learning_events"]
                for table in tables:
                    try:
                        cursor = conn.execute(
                            "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name=?",
                            (table,),
                        )
                        if not cursor.fetchone()[0]:
                            continue
                        row = conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()
                        total = row[0] if row else 0
                        if total < 1000:
                            continue
                        keep = max(1000, total * 2 // 3)
                        conn.execute(
                            f"DELETE FROM {table} WHERE id NOT IN ("
                            f"SELECT id FROM {table} ORDER BY created_at DESC LIMIT ?"
                            f")",
                            (keep,),
                        )
                        conn.commit()
                        _dbg.info("ObservabilityLayer pruned %s: kept %d/%d", table, keep, total)
                    except Exception as err:
                        _dbg.debug("ObservabilityLayer prune skipped for %s: %s", table, err)
                try:
                    conn.execute("VACUUM")
                except Exception as err:
                    _dbg.debug("ObservabilityLayer vacuum skipped: %s", err)
            finally:
                conn.close()
        except Exception as err:
            _dbg.debug("ObservabilityLayer prune failed: %s", err)

    def _after_write(self) -> None:
        self._write_count += 1
        if self._write_count % 50 == 0:
            self._maybe_prune_db()

    def evaluate_reply(self, user_msg: str, reply: str, recalled: list[JsonDict] | None = None) -> JsonDict:
        text = (reply or "").strip()
        msg = user_msg or ""
        recalled = recalled or []
        flags: list[str] = []
        score = 10.0

        if not text:
            flags.append("empty_reply")
            score -= 5
        if len(text) > 120:
            flags.append("too_long")
            score -= 1.5
        if re.search(r"(^|\n)\s*[-*]\s+", text) or re.search(r"(^|\n)\s*\d+[\.、]", text):
            flags.append("list_tone")
            score -= 1.2
        leak_words = [
            "作为AI", "语言模型", "人工智能", "大模型", "OpenAI", "LM Studio", "系统提示",
            "提示词", "数据库", "成长系统", "角色扮演", "虚拟角色",
        ]
        if any(word.lower() in text.lower() for word in leak_words):
            flags.append("ooc_or_system_leak")
            score -= 4
        bad_chars = ["�", "锟", "Ã", "Â", "鎴", "浣", "璇", "鐨", "鍙", "銆", "涓"]
        if sum(text.count(item) for item in bad_chars) >= 2:
            flags.append("mojibake")
            score -= 4
        if "---" in text and text.count("---") > 2:
            flags.append("too_many_bubbles")
            score -= 0.8

        memory_probe = any(word in msg for word in ["我叫什么", "我叫啥", "刚才", "记得", "记住", "别忘", "我是谁"])
        if memory_probe and not recalled:
            flags.append("memory_probe_no_recall")
            score -= 2

        return {
            "score": round(max(0.0, min(10.0, score)), 2),
            "flags": flags,
            "memory_hit_count": len(recalled),
            "memory_top": clean_snippet(recalled[0].get("content"), 80) if recalled else "",
        }

    def record_trace(
        self,
        user_msg: str,
        reply: str,
        channel: str = "web",
        route: str = "chat",
        recalled: list[JsonDict] | None = None,
        eval_result: JsonDict | None = None,
        latency_ms: int = 0,
        meta: JsonDict | None = None,
    ) -> str:
        trace_id = f"trace-{uuid.uuid4().hex[:16]}"
        recalled = recalled or []
        eval_result = eval_result or self.evaluate_reply(user_msg, reply, recalled)
        conn = self._connect()
        try:
            conn.execute(
                """INSERT INTO traces
                   (id, created_at, channel, route, user_msg, reply, score, reasons_json,
                    recalled_json, metrics_json, latency_ms, meta_json)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    trace_id,
                    now_iso(),
                    channel,
                    route,
                    clean_snippet(user_msg, 500),
                    clean_snippet(reply, 800),
                    float(eval_result.get("score", 0)),
                    json_dumps(eval_result.get("flags", [])),
                    json_dumps(recalled[:8]),
                    json_dumps(eval_result),
                    int(latency_ms or 0),
                    json_dumps(meta or {}),
                ),
            )
            conn.commit()
        finally:
            conn.close()
        self._after_write()
        return trace_id

    def record_agent_run(
        self,
        run: JsonDict,
        user_msg: str = "",
        reply: str = "",
        channel: str = "web",
        route: str = "",
        trace_id: str = "",
        meta: JsonDict | None = None,
    ) -> str:
        run_id = str(run.get("id") or f"agent-{uuid.uuid4().hex[:16]}")
        route_payload = run.get("route") if isinstance(run.get("route"), dict) else {}
        route_name = route or str(route_payload.get("name") or "")
        conn = self._connect()
        try:
            conn.execute(
                """INSERT OR REPLACE INTO agent_runs
                   (id, created_at, channel, route, user_msg, reply, engine, mode,
                    node_status_json, degraded, degraded_nodes_json, latency_ms,
                    run_json, trace_id, meta_json)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    run_id,
                    now_iso(),
                    channel,
                    clean_snippet(route_name, 120),
                    clean_snippet(user_msg, 500),
                    clean_snippet(reply, 800),
                    clean_snippet(run.get("engine"), 120),
                    clean_snippet(run.get("mode"), 80),
                    json_dumps(run.get("node_status") or {}),
                    1 if run.get("degraded") else 0,
                    json_dumps(run.get("degraded_nodes") or []),
                    int(run.get("latency_ms") or 0),
                    json_dumps(run),
                    clean_snippet(trace_id, 120),
                    json_dumps(meta or {}),
                ),
            )
            conn.commit()
        finally:
            conn.close()
        self._after_write()
        return run_id

    def list_agent_runs(self, limit: int = 50) -> list[JsonDict]:
        conn = self._connect()
        try:
            cur = conn.execute(
                """SELECT id, created_at, channel, route, user_msg, reply, engine, mode,
                          node_status_json, degraded, degraded_nodes_json, latency_ms,
                          run_json, trace_id, meta_json
                   FROM agent_runs ORDER BY created_at DESC LIMIT ?""",
                (max(1, min(200, int(limit))),),
            )
            result = []
            for row in cur.fetchall():
                run = safe_json_loads(row[12], {}) or {}
                result.append({
                    "id": row[0],
                    "created_at": row[1],
                    "channel": row[2],
                    "route": row[3],
                    "user_msg": row[4],
                    "reply": row[5],
                    "engine": row[6],
                    "mode": row[7],
                    "node_status": safe_json_loads(row[8], {}) or {},
                    "degraded": bool(row[9]),
                    "degraded_nodes": safe_json_loads(row[10], []) or [],
                    "latency_ms": row[11],
                    "run": run,
                    "trace_id": row[13],
                    "meta": safe_json_loads(row[14], {}) or {},
                })
            return result
        finally:
            conn.close()

    def agent_run_summary(self, limit: int = 200) -> JsonDict:
        runs = self.list_agent_runs(limit=limit)
        if not runs:
            return {
                "total": 0,
                "degraded_count": 0,
                "degraded_rate": 0,
                "avg_latency_ms": 0,
                "routes": {},
                "node_degraded": {},
            }
        routes: dict[str, int] = {}
        node_degraded: dict[str, int] = {}
        for run in runs:
            route = run.get("route") or "unknown"
            routes[route] = routes.get(route, 0) + 1
            for node in run.get("degraded_nodes") or []:
                node_degraded[node] = node_degraded.get(node, 0) + 1
        degraded_count = sum(1 for run in runs if run.get("degraded"))
        return {
            "total": len(runs),
            "degraded_count": degraded_count,
            "degraded_rate": round(degraded_count / max(1, len(runs)), 3),
            "avg_latency_ms": round(sum(int(run.get("latency_ms") or 0) for run in runs) / len(runs), 1),
            "routes": routes,
            "node_degraded": node_degraded,
            "latest": runs[0],
        }

    def list_traces(self, limit: int = 50) -> list[JsonDict]:
        conn = self._connect()
        try:
            cur = conn.execute(
                """SELECT id, created_at, channel, route, user_msg, reply, score,
                          reasons_json, recalled_json, metrics_json, latency_ms, meta_json
                   FROM traces ORDER BY created_at DESC LIMIT ?""",
                (max(1, min(200, int(limit))),),
            )
            result = []
            for row in cur.fetchall():
                flags = safe_json_loads(row[7], []) or []
                recalled = safe_json_loads(row[8], []) or []
                metrics = safe_json_loads(row[9], {}) or {}
                meta = safe_json_loads(row[11], {}) or {}
                memory_hit_count = int(metrics.get("memory_hit_count") or len(recalled) or 0)
                result.append({
                    "id": row[0],
                    "created_at": row[1],
                    "channel": row[2],
                    "route": row[3],
                    "user_msg": row[4],
                    "reply": row[5],
                    "score": row[6],
                    "flags": flags,
                    "recalled": recalled,
                    "metrics": metrics,
                    "memory_hit": memory_hit_count > 0,
                    "memory_hit_count": memory_hit_count,
                    "memory_top": metrics.get("memory_top") or clean_snippet(recalled[0].get("content"), 80) if recalled else "",
                    "latency_ms": row[10],
                    "meta": meta,
                })
            return result
        finally:
            conn.close()

    def summary(self, limit: int = 200) -> JsonDict:
        traces = self.list_traces(limit=limit)
        if not traces:
            return {"total": 0, "avg_score": 0, "flags": {}, "avg_latency_ms": 0, "memory_hit_rate": 0, "low_score_count": 0}
        flag_counts: dict[str, int] = {}
        for item in traces:
            for flag in item.get("flags") or []:
                flag_counts[flag] = flag_counts.get(flag, 0) + 1
        low_score = [item for item in traces if float(item.get("score") or 0) < 7]
        memory_hits = sum(1 for item in traces if item.get("memory_hit"))
        return {
            "total": len(traces),
            "avg_score": round(sum(float(item.get("score") or 0) for item in traces) / len(traces), 3),
            "flags": flag_counts,
            "memory_hit_rate": round(memory_hits / max(1, len(traces)), 3),
            "memory_hit_count": memory_hits,
            "low_score_count": len(low_score),
            "low_score_examples": low_score[:8],
            "avg_latency_ms": round(sum(int(item.get("latency_ms") or 0) for item in traces) / len(traces), 1),
            "latest": traces[0],
        }

    def human_likeness_summary(self, limit: int = 200) -> JsonDict:
        traces = self.list_traces(limit=limit)
        if not traces:
            return {
                "total": 0,
                "avg_score": 0,
                "low_score_count": 0,
                "rewrite_applied_count": 0,
                "rewrite_rate": 0,
                "issues": {},
                "question_types": {},
                "attitudes": {},
                "user_attitudes": {},
            }
        scores = []
        issues: dict[str, int] = {}
        question_types: dict[str, int] = {}
        attitudes: dict[str, int] = {}
        user_attitudes: dict[str, int] = {}
        rewrite_applied = 0
        low_score = 0
        latest = None
        for item in traces:
            meta = item.get("meta") if isinstance(item.get("meta"), dict) else {}
            human = meta.get("human_likeness") if isinstance(meta.get("human_likeness"), dict) else {}
            correction = meta.get("self_correction") if isinstance(meta.get("self_correction"), dict) else {}
            score = float(human.get("score") or 0)
            if score:
                scores.append(score)
            if score and score < 7.2:
                low_score += 1
            if correction.get("applied"):
                rewrite_applied += 1
            for issue in human.get("issues") or []:
                issues[str(issue)] = issues.get(str(issue), 0) + 1
            qtype = str(human.get("question_type") or "").strip() or "unknown"
            question_types[qtype] = question_types.get(qtype, 0) + 1
            attitude = str(human.get("attitude") or "").strip() or "unknown"
            attitudes[attitude] = attitudes.get(attitude, 0) + 1
            user_attitude = str(human.get("user_attitude") or "").strip() or "unknown"
            user_attitudes[user_attitude] = user_attitudes.get(user_attitude, 0) + 1
            if latest is None and human:
                latest = {
                    "trace_id": item.get("id"),
                    "score": score,
                    "issues": human.get("issues") or [],
                    "self_correction": correction,
                }
        return {
            "total": len(traces),
            "avg_score": round(sum(scores) / len(scores), 3) if scores else 0,
            "low_score_count": low_score,
            "rewrite_applied_count": rewrite_applied,
            "rewrite_rate": round(rewrite_applied / max(1, len(traces)), 3),
            "issues": issues,
            "question_types": question_types,
            "attitudes": attitudes,
            "user_attitudes": user_attitudes,
            "latest": latest or {},
        }

    def get_trace(self, trace_id: str) -> JsonDict | None:
        conn = self._connect()
        try:
            cur = conn.execute(
                """SELECT id, created_at, channel, route, user_msg, reply, score,
                          reasons_json, recalled_json, metrics_json, latency_ms, meta_json
                   FROM traces WHERE id=? LIMIT 1""",
                (trace_id,),
            )
            row = cur.fetchone()
            if not row:
                return None
            flags = safe_json_loads(row[7], []) or []
            recalled = safe_json_loads(row[8], []) or []
            metrics = safe_json_loads(row[9], {}) or {}
            return {
                "id": row[0],
                "created_at": row[1],
                "channel": row[2],
                "route": row[3],
                "user_msg": row[4],
                "reply": row[5],
                "score": row[6],
                "flags": flags,
                "recalled": recalled,
                "metrics": metrics,
                "memory_hit": bool(recalled),
                "memory_hit_count": int(metrics.get("memory_hit_count") or len(recalled) or 0),
                "latency_ms": row[10],
                "meta": safe_json_loads(row[11], {}) or {},
            }
        finally:
            conn.close()

    def record_eval_run(self, name: str, results: list[JsonDict]) -> str:
        run_id = f"eval-{uuid.uuid4().hex[:12]}"
        summary = {
            "cases": len(results),
            "avg_score": round(sum(float(item.get("score") or 0) for item in results) / max(1, len(results)), 3),
            "failed": sum(1 for item in results if item.get("failed")),
        }
        conn = self._connect()
        try:
            conn.execute(
                "INSERT INTO eval_runs (id, created_at, name, summary_json, result_json) VALUES (?,?,?,?,?)",
                (run_id, now_iso(), name, json_dumps(summary), json_dumps(results)),
            )
            conn.commit()
        finally:
            conn.close()
        self._after_write()
        return run_id

    def record_learning_event(
        self,
        *,
        stage: str,
        source: str = "",
        skill_name: str = "",
        user_msg: str = "",
        effect: str = "",
        judge_score: float = 0,
        meta: JsonDict | None = None,
    ) -> str:
        event_id = f"learn-{uuid.uuid4().hex[:16]}"
        conn = self._connect()
        try:
            conn.execute(
                """INSERT INTO learning_events
                   (id, created_at, stage, source, skill_name, user_msg, effect, judge_score, meta_json)
                   VALUES (?,?,?,?,?,?,?,?,?)""",
                (
                    event_id,
                    now_iso(),
                    clean_snippet(stage, 80),
                    clean_snippet(source, 120),
                    clean_snippet(skill_name, 120),
                    clean_snippet(user_msg, 500),
                    clean_snippet(effect, 200),
                    float(judge_score or 0),
                    json_dumps(meta or {}),
                ),
            )
            conn.commit()
        finally:
            conn.close()
        self._after_write()
        return event_id

    def learning_summary(self, limit: int = 200) -> JsonDict:
        conn = self._connect()
        try:
            cur = conn.execute(
                """SELECT stage, source, skill_name, effect, judge_score
                   FROM learning_events ORDER BY created_at DESC LIMIT ?""",
                (max(1, min(1000, int(limit))),),
            )
            rows = cur.fetchall()
        finally:
            conn.close()
        by_stage: dict[str, int] = {}
        by_skill: dict[str, int] = {}
        scores: list[float] = []
        for stage, source, skill_name, effect, judge_score in rows:
            stage_key = stage or "unknown"
            by_stage[stage_key] = by_stage.get(stage_key, 0) + 1
            if skill_name:
                by_skill[skill_name] = by_skill.get(skill_name, 0) + 1
            try:
                scores.append(float(judge_score or 0))
            except Exception:
                continue
        return {
            "events": len(rows),
            "by_stage": by_stage,
            "by_skill": by_skill,
            "avg_judge_score": round(sum(scores) / len(scores), 2) if scores else 0.0,
        }

    def bad_human_reply_summary(self, limit: int = 200) -> JsonDict:
        conn = self._connect()
        try:
            cur = conn.execute(
                """SELECT id, created_at, user_msg, effect, judge_score, meta_json
                   FROM learning_events
                   WHERE stage='human_like_bad_reply'
                   ORDER BY created_at DESC LIMIT ?""",
                (max(1, min(1000, int(limit))),),
            )
            rows = cur.fetchall()
        finally:
            conn.close()
        issue_counts: dict[str, int] = {}
        question_types: dict[str, int] = {}
        state_buckets: dict[str, int] = {}
        attitudes: dict[str, int] = {}
        user_attitudes: dict[str, int] = {}
        items = []
        for event_id, created_at, user_msg, effect, judge_score, meta_json in rows:
            meta = safe_json_loads(meta_json, {}) or {}
            human = meta.get("human_likeness") if isinstance(meta.get("human_likeness"), dict) else {}
            issues = [str(x) for x in (human.get("issues") or []) if str(x)]
            for issue in issues:
                issue_counts[issue] = issue_counts.get(issue, 0) + 1
            qtype = str(human.get("question_type") or meta.get("question_type") or "unknown")
            question_types[qtype] = question_types.get(qtype, 0) + 1
            state_bucket = str(meta.get("state_bucket") or "neutral")
            state_buckets[state_bucket] = state_buckets.get(state_bucket, 0) + 1
            attitude = str(human.get("attitude") or "unknown")
            attitudes[attitude] = attitudes.get(attitude, 0) + 1
            user_attitude = str(human.get("user_attitude") or "unknown")
            user_attitudes[user_attitude] = user_attitudes.get(user_attitude, 0) + 1
            items.append({
                "id": event_id,
                "created_at": created_at,
                "user_msg": user_msg,
                "reply": effect,
                "score": float(judge_score or 0),
                "issues": issues,
                "question_type": qtype,
                "state_bucket": state_bucket,
                "attitude": attitude,
                "user_attitude": user_attitude,
                "trace_id": meta.get("trace_id") or "",
                "route": meta.get("route") or "",
                "channel": meta.get("channel") or "",
            })
        return {
            "events": len(items),
            "issues": issue_counts,
            "question_types": question_types,
            "state_buckets": state_buckets,
            "attitudes": attitudes,
            "user_attitudes": user_attitudes,
            "items": items,
        }

    def get_relevant_bad_human_replies(
        self,
        user_msg: str,
        *,
        state_bucket: str = "",
        question_type: str = "",
        limit: int = 2,
    ) -> list[JsonDict]:
        conn = self._connect()
        try:
            cur = conn.execute(
                """SELECT id, created_at, user_msg, effect, judge_score, meta_json
                   FROM learning_events
                   WHERE stage='human_like_bad_reply'
                   ORDER BY created_at DESC LIMIT 220"""
            )
            rows = cur.fetchall()
        finally:
            conn.close()
        msg_tokens = set(tokenize(user_msg, limit=20))
        state_tokens = set(tokenize(state_bucket, limit=12))
        scored: list[tuple[float, JsonDict]] = []
        for event_id, created_at, bad_user_msg, bad_reply, judge_score, meta_json in rows:
            meta = safe_json_loads(meta_json, {}) or {}
            human = meta.get("human_likeness") if isinstance(meta.get("human_likeness"), dict) else {}
            bad_msg_tokens = set(tokenize(bad_user_msg, limit=20))
            bad_reply_tokens = set(tokenize(bad_reply, limit=20))
            overlap = len(msg_tokens & bad_msg_tokens) * 1.6 + len(msg_tokens & bad_reply_tokens) * 0.35
            event_question_type = str(human.get("question_type") or meta.get("question_type") or "unknown")
            if question_type and event_question_type != "unknown" and event_question_type == question_type:
                overlap += 0.6
            state_value = str(meta.get("state_bucket") or "")
            if state_tokens and state_value:
                overlap += len(state_tokens & set(tokenize(state_value, limit=12))) * 0.45
            if state_bucket and state_value and state_bucket == state_value:
                overlap += 0.8
            score_penalty = max(0.0, 10.0 - float(judge_score or 0)) * 0.18
            issue_bonus = min(1.2, len(human.get("issue_buckets") or human.get("issues") or []) * 0.18)
            final_score = overlap + score_penalty + issue_bonus + recency_bonus(created_at)
            if final_score <= 0:
                continue
            scored.append((
                final_score,
                {
                    "id": event_id,
                    "created_at": created_at,
                    "user_msg": bad_user_msg,
                    "reply": bad_reply,
                    "score": float(judge_score or 0),
                    "issues": [str(x) for x in (human.get("issue_buckets") or human.get("issues") or []) if str(x)],
                    "question_type": event_question_type,
                    "state_bucket": state_value or "neutral",
                    "attitude": str(human.get("attitude") or "unknown"),
                    "user_attitude": str(human.get("user_attitude") or "unknown"),
                },
            ))
        scored.sort(key=lambda item: (item[0], -item[1].get("score", 0), item[1].get("created_at", "")), reverse=True)
        result: list[JsonDict] = []
        seen = set()
        for _, item in scored:
            key = normalize_text_key(item.get("reply"))
            if not key or key in seen:
                continue
            seen.add(key)
            result.append(item)
            if len(result) >= max(1, int(limit)):
                break
        return result

    def status(self) -> JsonDict:
        return {
            "db": str(self.db_path),
            "summary": self.summary(limit=100),
            "agent_runs": self.agent_run_summary(limit=100),
            "learning": self.learning_summary(limit=200),
            "bad_human_replies": self.bad_human_reply_summary(limit=100),
        }


class AgentOrchestrationLayer:
    """Local lightweight state machine for the chat workflow."""

    NODE_ORDER = ["sense", "retrieve", "route", "skill", "plan", "generate", "observe", "learn", "compact", "proactive"]

    def __init__(self, config: LayerConfig):
        self.config = config

    def _select_skill(self, user_msg: str, sense: JsonDict, route: JsonDict, context: JsonDict) -> JsonDict:
        msg = (user_msg or "").strip()
        lowered = msg.lower()
        available = []
        skills_dir = Path(self.config.skills_dir)
        if skills_dir.exists() and skills_dir.is_dir():
            for skill_dir in sorted(path for path in skills_dir.iterdir() if path.is_dir()):
                skill_md = skill_dir / "SKILL.md"
                skill_json = skill_dir / "skill.json"
                if skill_md.exists() or skill_json.exists():
                    available.append({
                        "name": f"skill.{skill_dir.name}",
                        "slug": skill_dir.name,
                        "path": str(skill_dir),
                        "skill_md": str(skill_md) if skill_md.exists() else "",
                        "skill_json": str(skill_json) if skill_json.exists() else "",
                    })
        result = {
            "selected_skill": "",
            "reason": "",
            "available_disk_skills": available,
        }
        if context.get("skill_name"):
            result["selected_skill"] = str(context.get("skill_name") or "").strip()
            result["reason"] = "context.skill_name"
            return result
        for term in ["睡不着", "失眠", "晚安", "先睡了", "困了", "半夜", "夜里"]:
            if term in msg:
                result["selected_skill"] = "skill.late_night_companion"
                result["reason"] = "late-night companion keyword"
                return result
        for term in ["好累", "很累", "难受", "委屈", "焦虑", "崩溃", "烦", "撑不住", "低落", "不舒服"]:
            if term in msg:
                result["selected_skill"] = "skill.comforting"
                result["reason"] = "comforting keyword"
                return result
        for term in ["陪我", "陪我一会", "你在吗", "在不在", "别走", "陪着我"]:
            if term in msg:
                result["selected_skill"] = "skill.late_night_companion"
                result["reason"] = "companion keyword"
                return result
        for term in ["你刚刚说得好怪", "别像系统公告一样", "怪", "太官方", "太像机器人", "不对味", "别这么说"]:
            if term in msg:
                result["selected_skill"] = "skill.relationship_repair"
                result["reason"] = "relationship repair keyword"
                return result
        for term in ["怎么回复更自然", "别太像系统", "太结构化", "太长了", "像公告", "说话方式"]:
            if term in msg:
                result["selected_skill"] = "skill.reply_style_guard"
                result["reason"] = "reply style guard keyword"
                return result
        for term in ["code review", "bug", "stack trace", "traceback", ".py", ".json"]:
            if term in lowered:
                result["selected_skill"] = "skill.technical_review"
                result["reason"] = "technical keyword"
                return result
        for term in ["代码", "源码", "文件", "报错", "异常", "逻辑", "接口", "排查", "技术", "项目", "看看", "问题", "分析"]:
            if term in msg:
                result["selected_skill"] = "skill.technical_review"
                result["reason"] = "technical zh keyword"
                return result
        if route.get("name") in {"sensitive_probe", "identity_probe", "boundary"}:
            result["reason"] = "guarded route"
            return result
        return result

    def _compact_payload(self, value: Any, str_limit: int = 360) -> Any:
        if isinstance(value, str):
            return clean_snippet(value, str_limit)
        if isinstance(value, (int, float, bool)) or value is None:
            return value
        if isinstance(value, list):
            return [self._compact_payload(item, str_limit=str_limit) for item in value[:8]]
        if isinstance(value, tuple):
            return [self._compact_payload(item, str_limit=str_limit) for item in value[:8]]
        if isinstance(value, dict):
            result: JsonDict = {}
            for idx, (key, item) in enumerate(value.items()):
                if idx >= 40:
                    result["_truncated_keys"] = max(0, len(value) - idx)
                    break
                result[str(key)] = self._compact_payload(item, str_limit=str_limit)
            return result
        return clean_snippet(str(value), str_limit)

    def _node_result(
        self,
        node: str,
        node_input: JsonDict,
        output: JsonDict | None,
        start: float,
        status: str = "ok",
        error: str = "",
    ) -> JsonDict:
        return {
            "node": node,
            "status": status,
            "ok": status not in {"degraded", "failed"},
            "input": self._compact_payload(node_input),
            "output": self._compact_payload(output or {}),
            "latency_ms": int((time.monotonic() - start) * 1000),
            "error": clean_snippet(error, 300) if error else "",
        }

    def _sense(self, user_msg: str, context: JsonDict, history_size: int = 0) -> JsonDict:
        msg = user_msg or ""
        lower = msg.lower()
        memory_terms = ["记得", "记住", "别忘", "刚才", "我叫什么", "我叫啥", "我是谁", "提醒"]
        safety_terms = ["prompt", "openai", "lm studio", "数据库", "系统提示", "提示词", "源码", "后台", "成长系统"]
        low_state_terms = ["累", "难受", "焦虑", "睡不着", "失眠", "委屈", "崩溃", "不开心"]
        boundary_terms = ["裸照", "隐私", "身份证", "银行卡", "密码", "地址", "滚", "闭嘴", "必须", "立刻"]
        event_terms = ["考试", "笔试", "面试", "明天", "后天", "今天", "今晚", "周末", "提醒", "记一下", "睡过头", "错题"]
        identity_terms = ["是不是ai", "机器人", "装人", "你到底是不是", "你是张致悦"]

        memory_probe = any(term in msg for term in memory_terms)
        safety_probe = any(term in lower for term in safety_terms)
        low_state = any(term in msg for term in low_state_terms)
        boundary_probe = any(term in msg for term in boundary_terms)
        life_event_candidate = any(term in msg for term in event_terms)
        identity_probe = any(term in lower for term in identity_terms)
        quiet_mode = bool(context.get("quiet_mode"))
        proactive_due = bool(context.get("proactive_due"))

        mode = "quiet" if quiet_mode else ("support" if low_state else "chat")
        flags = []
        for flag, enabled in (
            ("memory_probe", memory_probe),
            ("safety_probe", safety_probe),
            ("low_state", low_state),
            ("boundary_probe", boundary_probe),
            ("life_event_candidate", life_event_candidate),
            ("identity_probe", identity_probe),
            ("proactive_due", proactive_due),
        ):
            if enabled:
                flags.append(flag)

        return {
            "message_chars": len(msg),
            "history_size": history_size,
            "mode": mode,
            "flags": flags,
            "memory_probe": memory_probe,
            "safety_probe": safety_probe,
            "low_state": low_state,
            "boundary_probe": boundary_probe,
            "life_event_candidate": life_event_candidate,
            "identity_probe": identity_probe,
            "quiet_mode": quiet_mode,
            "proactive_due": proactive_due,
        }

    def _summarize_retrieval(self, data: JsonDict | None) -> JsonDict:
        data = data or {}
        memories = data.get("memories") or data.get("memory") or data.get("archival") or []
        life_events = data.get("life_events") or data.get("events") or []
        task_context = data.get("task_context") if isinstance(data.get("task_context"), dict) else {}
        tasks = data.get("tasks") or task_context.get("matches") or []
        if not isinstance(memories, list):
            memories = []
        if not isinstance(life_events, list):
            life_events = []
        if not isinstance(tasks, list):
            tasks = []
        return {
            "memory_hit_count": len(memories),
            "life_event_hit_count": len(life_events),
            "task_hit_count": len(tasks),
            "hit_count": len(memories) + len(life_events),
            "backend": data.get("backend") or data.get("retrieval_backend") or "",
            "memories": memories[:5],
            "life_events": life_events[:5],
            "tasks": tasks[:5],
            "task_context": {**task_context, "matches": tasks[:5]},
            "top_memory": memories[0] if memories else {},
            "top_event": life_events[0] if life_events else {},
            "top_task": tasks[0] if tasks else {},
        }

    def _route(self, sense: JsonDict, retrieved: JsonDict, context: JsonDict, route_hint: str | None = None) -> JsonDict:
        hint = (route_hint or context.get("route_hint") or "").strip()
        source = "hint" if hint else "heuristic"
        if hint:
            name = hint
            reason = "chat result supplied the actual route"
        elif sense.get("safety_probe"):
            name = "sensitive_probe"
            reason = "system or implementation probe"
        elif sense.get("identity_probe"):
            name = "identity_probe"
            reason = "identity boundary"
        elif sense.get("boundary_probe"):
            name = "boundary"
            reason = "boundary or coercive input"
        elif sense.get("low_state"):
            name = "user_low_state"
            reason = "supportive deterministic path"
        elif sense.get("memory_probe") and int(retrieved.get("hit_count") or 0) > 0:
            name = "memory_recall"
            reason = "memory probe with retrieval hits"
        elif sense.get("proactive_due") and not context.get("user_is_active"):
            name = "proactive"
            reason = "scheduled proactive care is due"
        else:
            name = "lm"
            reason = "open generation path"

        return {
            "name": name,
            "source": source,
            "reason": reason,
            "deterministic": name not in {"lm", "open_generation", "lm_fallback"},
            "needs_generation": True,
            "needs_observation": True,
            "needs_learning": bool(context.get("commit_learning")) or name in {"lm", "user_low_state", "memory_recall"},
            "needs_compaction": True,
            "needs_proactive": bool(sense.get("proactive_due")) or bool(context.get("scheduled_followup")),
            "fallback_ok": True,
        }

    def _planned_learning(self, sense: JsonDict, route: JsonDict, reply: str | None = None) -> list[JsonDict]:
        actions: list[JsonDict] = []
        if sense.get("life_event_candidate"):
            actions.append({"action": "learn_life_event", "reason": "event-like user message"})
        if sense.get("low_state"):
            actions.append({"action": "schedule_care_followup", "reason": "low user state"})
            actions.append({"action": "learn_comfort_strategy", "reason": "support turn"})
        if route.get("name") in {"lm", "memory_recall", "user_low_state"} and reply:
            actions.append({"action": "autonomous_learn", "reason": "reply available"})
            actions.append({"action": "relationship_learn", "reason": "relationship thread update"})
        if route.get("name") in {"sensitive_probe", "identity_probe", "boundary"}:
            actions.append({"action": "no_profile_learning", "reason": "guarded route"})
        return actions

    def _plan_actions(self, user_msg: str, sense: JsonDict, route: JsonDict, retrieved: JsonDict, context: JsonDict) -> JsonDict:
        task_context = retrieved.get("task_context") if isinstance(retrieved.get("task_context"), dict) else {}
        task_matches = task_context.get("matches") if isinstance(task_context, dict) else []
        if not isinstance(task_matches, list):
            task_matches = []
        msg = user_msg or ""
        done_terms = ["完成", "做完", "改完", "过了", "结束", "不用了", "取消", "不用管"]
        defer_terms = ["等会", "晚点", "一会", "先不用", "明天再说", "等等"]
        actions: list[JsonDict] = []
        focus = task_matches[0] if task_matches else {}

        if focus:
            action_type = "task.follow_next_action"
            requires_confirm = False
            reason = "matched active task"
            if any(term in msg for term in done_terms):
                action_type = "task.mark_done_candidate"
                requires_confirm = True
                reason = "user message may indicate completion"
            elif any(term in msg for term in defer_terms):
                action_type = "task.wait_candidate"
                requires_confirm = False
                reason = "user message may defer task"
            actions.append({
                "action_type": action_type,
                "task_id": focus.get("id") or "",
                "task_title": focus.get("title") or "",
                "next_action": focus.get("next_action") or "",
                "requires_confirm": requires_confirm,
                "risk": "low",
                "reason": reason,
            })
        elif sense.get("life_event_candidate"):
            actions.append({
                "action_type": "task.create_candidate",
                "task_id": "",
                "task_title": clean_snippet(msg, 80),
                "next_action": "confirm whether this should become a tracked task",
                "requires_confirm": True,
                "risk": "low",
                "reason": "event-like message without matching task",
            })

        return {
            "task_focus": focus,
            "actions": actions,
            "action_count": len(actions),
            "decision": actions[0].get("action_type") if actions else "chat_only",
            "requires_confirm": any(bool(item.get("requires_confirm")) for item in actions),
            "source": "local_task_planner_v1",
            "route": route.get("name"),
            "task_context": task_context,
        }

    def plan(self, user_msg: str = "", context: JsonDict | None = None) -> JsonDict:
        context = context or {}
        sense = self._sense(user_msg or "", context)
        route = self._route(sense, {"hit_count": 0}, context)
        skill = self._select_skill(user_msg or "", sense, route, context)
        nodes = [
            {"node": "sense", "status": "ready", "reason": "classify input, mode and probes"},
            {"node": "retrieve", "status": "required" if sense.get("memory_probe") else "ready", "reason": "memory + life-event recall"},
            {"node": "route", "status": "ready", "reason": route.get("reason")},
            {"node": "skill", "status": "ready" if skill.get("selected_skill") else "idle", "reason": skill.get("reason") or "no matching skill"},
            {"node": "plan", "status": "ready", "reason": "task and action planning"},
            {"node": "generate", "status": "ready", "reason": "existing deterministic branch or LM path"},
            {"node": "observe", "status": "ready", "reason": "quality, memory hit and leak scoring"},
            {"node": "learn", "status": "ready", "reason": "facts/preferences/events/thread extraction"},
            {"node": "compact", "status": "ready", "reason": "daily memory/learning cleanup"},
            {"node": "proactive", "status": "ready" if sense.get("proactive_due") else "idle", "reason": "scheduled care or relationship thread"},
        ]
        return {
            "ok": True,
            "engine": "local_lightweight_state_machine",
            "mode": sense.get("mode"),
            "memory_needed": sense.get("memory_probe"),
            "safety_probe": sense.get("safety_probe"),
            "low_state": sense.get("low_state"),
            "route_hint": route,
            "skill": skill,
            "node_order": self.NODE_ORDER,
            "nodes": nodes,
        }

    def run(
        self,
        user_msg: str = "",
        context: JsonDict | None = None,
        history: list[JsonDict] | None = None,
        route_hint: str | None = None,
        reply: str | None = None,
        retrieve_fn: Callable[[JsonDict], JsonDict] | None = None,
        generate_fn: Callable[[JsonDict], JsonDict] | None = None,
        observe_fn: Callable[[JsonDict], JsonDict] | None = None,
        plan_fn: Callable[[JsonDict], JsonDict] | None = None,
        learn_fn: Callable[[JsonDict], JsonDict] | None = None,
        compact_fn: Callable[[JsonDict], JsonDict] | None = None,
        proactive_fn: Callable[[JsonDict], JsonDict] | None = None,
    ) -> JsonDict:
        context = context or {}
        history = history or []
        run_start = time.monotonic()
        nodes: list[JsonDict] = []
        state: JsonDict = {"user_msg": user_msg or "", "context": context, "history_size": len(history)}

        def add_node(node: str, node_input: JsonDict, fn):
            start = time.monotonic()
            try:
                raw = fn()
                status = "ok"
                if isinstance(raw, tuple):
                    output, status = raw
                else:
                    output = raw or {}
                result = self._node_result(node, node_input, output, start, status=status)
            except Exception as err:
                result = self._node_result(
                    node,
                    node_input,
                    {"ok": False, "degraded": True, "error": str(err)},
                    start,
                    status="degraded",
                    error=str(err),
                )
            nodes.append(result)
            return result.get("output") or {}

        sense = add_node("sense", {"user_msg": user_msg or "", "context": context, "history_size": len(history)}, lambda: self._sense(user_msg or "", context, len(history)))
        state["sense"] = sense

        def retrieve_step():
            if not retrieve_fn:
                return {
                    "memories": [],
                    "life_events": [],
                    "memory_hit_count": 0,
                    "life_event_hit_count": 0,
                    "hit_count": 0,
                    "reason": "no retrieve_fn supplied",
                }, "skipped"
            data = retrieve_fn({"user_msg": user_msg or "", "context": context, "history": history, "sense": sense, "limit": 5}) or {}
            return self._summarize_retrieval(data), "ok"

        retrieved = add_node("retrieve", {"user_msg": user_msg or "", "limit": 5, "sense_flags": sense.get("flags", [])}, retrieve_step)
        state["retrieve"] = retrieved

        route = add_node(
            "route",
            {"sense": sense, "retrieved": {"hit_count": retrieved.get("hit_count", 0)}, "route_hint": route_hint or context.get("route_hint")},
            lambda: self._route(sense, retrieved, context, route_hint=route_hint),
        )
        state["route"] = route
        skill = add_node(
            "skill",
            {"route": route.get("name"), "sense_flags": sense.get("flags", []), "context_skill_name": context.get("skill_name")},
            lambda: self._select_skill(user_msg or "", sense, route, context),
        )
        state["skill"] = skill

        def plan_step():
            if plan_fn:
                data = plan_fn({
                    "user_msg": user_msg or "",
                    "context": context,
                    "sense": sense,
                    "retrieved": retrieved,
                    "route": route,
                    "skill": skill,
                }) or {}
                return data, "ok"
            return self._plan_actions(user_msg or "", sense, route, retrieved, context), "planned"

        planned = add_node(
            "plan",
            {
                "route": route.get("name"),
                "selected_skill": skill.get("selected_skill") or "",
                "task_hit_count": retrieved.get("task_hit_count", 0),
                "life_event_candidate": sense.get("life_event_candidate"),
            },
            plan_step,
        )
        state["plan"] = planned

        def generate_step():
            if generate_fn:
                data = generate_fn({"user_msg": user_msg or "", "context": context, "route": route, "retrieved": retrieved, "plan": planned, "skill": skill, "reply": reply}) or {}
                return data, "ok"
            if reply:
                return {
                    "source": "provided_reply",
                    "route": route.get("name"),
                    "reply": reply,
                    "reply_chars": len(reply),
                }, "ok"
            return {
                "source": "planned_only",
                "route": route.get("name"),
                "reply": "",
                "reason": "no reply or generate_fn supplied",
            }, "skipped"

        generated = add_node("generate", {"route": route, "has_reply": bool(reply), "has_generate_fn": bool(generate_fn)}, generate_step)
        state["generate"] = generated
        generated_reply = str(generated.get("reply") or reply or "")

        def observe_step():
            if not generated_reply:
                return {"reason": "no reply to observe", "score": None, "flags": []}, "skipped"
            if observe_fn:
                data = observe_fn({
                    "user_msg": user_msg or "",
                    "reply": generated_reply,
                    "retrieved": retrieved,
                    "route": route,
                }) or {}
                return data, "ok"
            return {"reason": "no observe_fn supplied", "reply_chars": len(generated_reply)}, "skipped"

        observed = add_node("observe", {"has_reply": bool(generated_reply), "route": route.get("name")}, observe_step)
        state["observe"] = observed

        def learn_step():
            if learn_fn:
                data = learn_fn({
                    "user_msg": user_msg or "",
                    "reply": generated_reply,
                    "sense": sense,
                    "route": route,
                    "retrieved": retrieved,
                    "plan": planned,
                    "observe": observed,
                }) or {}
                return data, "ok"
            return {"committed": False, "actions": self._planned_learning(sense, route, reply=generated_reply)}, "planned"

        learned = add_node("learn", {"route": route.get("name"), "has_reply": bool(generated_reply)}, learn_step)
        state["learn"] = learned

        def compact_step():
            if compact_fn:
                data = compact_fn({"context": context, "route": route, "sense": sense}) or {}
                return data, "ok"
            return {
                "committed": False,
                "actions": ["decay_learning_notes", "compact_memories"],
                "reason": "handled by existing growth payload guards",
            }, "planned"

        compacted = add_node("compact", {"daily_guarded": True}, compact_step)
        state["compact"] = compacted

        def proactive_step():
            if proactive_fn:
                data = proactive_fn({"context": context, "route": route, "sense": sense}) or {}
                return data, "ok"
            due = bool(sense.get("proactive_due") or context.get("proactive_due"))
            scheduled = bool(context.get("scheduled_followup"))
            return {
                "due": due,
                "scheduled_followup": scheduled,
                "quiet_mode": bool(sense.get("quiet_mode")),
                "action": "ready" if due or scheduled else "idle",
            }, "ready" if due or scheduled else "idle"

        proactive = add_node("proactive", {"proactive_due": sense.get("proactive_due"), "scheduled_followup": context.get("scheduled_followup")}, proactive_step)
        state["proactive"] = proactive

        degraded_nodes = [node["node"] for node in nodes if node.get("status") == "degraded"]
        return {
            "ok": True,
            "engine": "local_lightweight_state_machine",
            "schema_version": 1,
            "node_order": self.NODE_ORDER,
            "mode": sense.get("mode"),
            "route": route,
            "skill": skill,
            "degraded": bool(degraded_nodes),
            "degraded_nodes": degraded_nodes,
            "latency_ms": int((time.monotonic() - run_start) * 1000),
            "node_status": {node["node"]: node["status"] for node in nodes},
            "state": state,
            "nodes": nodes,
        }

    def status(self) -> JsonDict:
        return {
            "engine": "local_lightweight_state_machine",
            "upgrade_path": ["LangGraph", "OpenAI Agents SDK"],
            "nodes": self.NODE_ORDER,
        }


class AgentActionApplyError(Exception):
    def __init__(self, message: str, status_code: int = 400, action: JsonDict | None = None):
        super().__init__(message)
        self.status_code = status_code
        self.action = action or {}


class AgentTaskLayer:
    """Persistent goal/task state for multi-turn agent work."""

    VALID_TASK_STATUSES = {"active", "waiting", "done", "archived"}
    VALID_ACTION_STATUSES = {"planned", "executed", "rejected", "failed"}
    APPLICABLE_ACTION_TYPES = {
        "task.follow_next_action",
        "task.mark_done_candidate",
        "task.wait_candidate",
        "task.create_candidate",
    }

    def __init__(self, config: LayerConfig):
        self.config = config
        self.db_path = config.observability_db
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        return _connect_observability_db(self.db_path, self.config.base_dir)

    def _init_db(self) -> None:
        conn = self._connect()
        try:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS agent_tasks (
                    id TEXT PRIMARY KEY,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    title TEXT NOT NULL,
                    status TEXT DEFAULT 'active',
                    priority INTEGER DEFAULT 3,
                    source TEXT DEFAULT 'manual',
                    goal TEXT DEFAULT '',
                    next_action TEXT DEFAULT '',
                    due_time TEXT,
                    last_run_at TEXT,
                    evidence TEXT DEFAULT '',
                    meta_json TEXT DEFAULT '{}'
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS agent_actions (
                    id TEXT PRIMARY KEY,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    run_id TEXT DEFAULT '',
                    task_id TEXT DEFAULT '',
                    action_type TEXT NOT NULL,
                    payload_json TEXT DEFAULT '{}',
                    status TEXT DEFAULT 'planned',
                    risk TEXT DEFAULT 'low',
                    requires_confirm INTEGER DEFAULT 0,
                    result_json TEXT DEFAULT '{}',
                    error TEXT DEFAULT ''
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_agent_tasks_status_due ON agent_tasks(status, due_time)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_agent_tasks_updated ON agent_tasks(updated_at)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_agent_actions_task ON agent_actions(task_id, created_at)")
            conn.commit()
        finally:
            conn.close()

    def _normalize_status(self, status: str | None, allowed: set[str], default: str) -> str:
        value = (status or default).strip().lower()
        return value if value in allowed else default

    def _row_to_task(self, row: tuple[Any, ...]) -> JsonDict:
        return {
            "id": row[0],
            "created_at": row[1],
            "updated_at": row[2],
            "title": row[3],
            "status": row[4],
            "priority": row[5],
            "source": row[6],
            "goal": row[7],
            "next_action": row[8],
            "due_time": row[9],
            "last_run_at": row[10],
            "evidence": row[11],
            "meta": safe_json_loads(row[12], {}) or {},
        }

    def _row_to_action(self, row: tuple[Any, ...]) -> JsonDict:
        return {
            "id": row[0],
            "created_at": row[1],
            "updated_at": row[2],
            "run_id": row[3],
            "task_id": row[4],
            "action_type": row[5],
            "payload": safe_json_loads(row[6], {}) or {},
            "status": row[7],
            "risk": row[8],
            "requires_confirm": bool(row[9]),
            "result": safe_json_loads(row[10], {}) or {},
            "error": row[11],
        }

    def create_task(
        self,
        title: str,
        goal: str = "",
        next_action: str = "",
        due_time: str | None = None,
        priority: int = 3,
        source: str = "manual",
        evidence: str = "",
        status: str = "active",
        meta: JsonDict | None = None,
    ) -> JsonDict:
        title = clean_snippet(title, 160)
        if not title:
            raise ValueError("empty task title")
        task_id = f"task-{uuid.uuid4().hex[:16]}"
        now = now_iso()
        normalized_status = self._normalize_status(status, self.VALID_TASK_STATUSES, "active")
        conn = self._connect()
        try:
            conn.execute(
                """INSERT INTO agent_tasks
                   (id, created_at, updated_at, title, status, priority, source, goal,
                    next_action, due_time, evidence, meta_json)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    task_id,
                    now,
                    now,
                    title,
                    normalized_status,
                    max(1, min(5, int(priority or 3))),
                    clean_snippet(source or "manual", 80),
                    clean_snippet(goal, 500),
                    clean_snippet(next_action, 300),
                    clean_snippet(due_time, 80) if due_time else None,
                    clean_snippet(evidence, 500),
                    json_dumps(meta or {}),
                ),
            )
            conn.commit()
        finally:
            conn.close()
        task = self.get_task(task_id)
        if not task:
            raise RuntimeError("created task not found")
        return task

    def get_task(self, task_id: str) -> JsonDict | None:
        conn = self._connect()
        try:
            row = conn.execute(
                """SELECT id, created_at, updated_at, title, status, priority, source,
                          goal, next_action, due_time, last_run_at, evidence, meta_json
                   FROM agent_tasks WHERE id=? LIMIT 1""",
                (task_id,),
            ).fetchone()
            return self._row_to_task(row) if row else None
        finally:
            conn.close()

    def update_task(self, task_id: str, patch: JsonDict) -> JsonDict | None:
        existing = self.get_task(task_id)
        if not existing:
            return None
        allowed = {
            "title": lambda v: clean_snippet(v, 160),
            "status": lambda v: self._normalize_status(str(v), self.VALID_TASK_STATUSES, existing.get("status") or "active"),
            "priority": lambda v: max(1, min(5, int(v or 3))),
            "source": lambda v: clean_snippet(v, 80),
            "goal": lambda v: clean_snippet(v, 500),
            "next_action": lambda v: clean_snippet(v, 300),
            "due_time": lambda v: clean_snippet(v, 80) if v else None,
            "last_run_at": lambda v: clean_snippet(v, 80) if v else None,
            "evidence": lambda v: clean_snippet(v, 500),
        }
        updates: dict[str, Any] = {}
        for key, normalizer in allowed.items():
            if key in patch:
                updates[key] = normalizer(patch.get(key))
        if "meta" in patch and isinstance(patch.get("meta"), dict):
            merged_meta = {**(existing.get("meta") or {}), **patch["meta"]}
            updates["meta_json"] = json_dumps(merged_meta)
        if not updates:
            return existing
        updates["updated_at"] = now_iso()
        assignments = ", ".join(f"{key}=?" for key in updates)
        values = list(updates.values()) + [task_id]
        conn = self._connect()
        try:
            conn.execute(f"UPDATE agent_tasks SET {assignments} WHERE id=?", values)
            conn.commit()
        finally:
            conn.close()
        return self.get_task(task_id)

    def list_tasks(self, status: str | None = None, limit: int = 50, query: str | None = None) -> list[JsonDict]:
        clauses = []
        params: list[Any] = []
        if status and status != "all":
            clauses.append("status=?")
            params.append(self._normalize_status(status, self.VALID_TASK_STATUSES, "active"))
        if query:
            like = f"%{query[:80]}%"
            clauses.append("(title LIKE ? OR goal LIKE ? OR next_action LIKE ? OR evidence LIKE ?)")
            params.extend([like, like, like, like])
        where = "WHERE " + " AND ".join(clauses) if clauses else ""
        params.append(max(1, min(200, int(limit or 50))))
        conn = self._connect()
        try:
            cur = conn.execute(
                f"""SELECT id, created_at, updated_at, title, status, priority, source,
                           goal, next_action, due_time, last_run_at, evidence, meta_json
                    FROM agent_tasks {where}
                    ORDER BY
                        CASE status WHEN 'active' THEN 0 WHEN 'waiting' THEN 1 WHEN 'done' THEN 2 ELSE 3 END,
                        priority DESC,
                        COALESCE(due_time, '9999') ASC,
                        updated_at DESC
                    LIMIT ?""",
                params,
            )
            return [self._row_to_task(row) for row in cur.fetchall()]
        finally:
            conn.close()

    def search_context(self, query: str | None, limit: int = 5) -> JsonDict:
        tasks = self.list_tasks(status="active", limit=100)
        tasks.extend(self.list_tasks(status="waiting", limit=100))
        query_tokens = set(tokenize(query, limit=40))
        query_key = normalize_text_key(query)
        scored: list[tuple[float, JsonDict, list[str]]] = []
        for task in tasks:
            text = " ".join(
                str(task.get(field) or "")
                for field in ("title", "goal", "next_action", "evidence", "source")
            )
            task_tokens = set(tokenize(text, limit=80))
            matched = sorted(query_tokens & task_tokens)
            score = len(matched) * 2.0 + float(task.get("priority") or 3) * 0.4
            title_key = normalize_text_key(task.get("title"))
            if query_key and title_key and (query_key in title_key or title_key in query_key):
                score += 3.0
            if task.get("due_time"):
                score += 0.5
            if matched or score >= 2.0:
                scored.append((score, task, matched[:8]))
        scored.sort(key=lambda item: (item[0], item[1].get("priority") or 0, item[1].get("updated_at") or ""), reverse=True)
        matches = []
        for score, task, matched in scored[: max(1, min(20, int(limit or 5)))]:
            matches.append({
                **task,
                "score": round(score, 3),
                "matched_terms": matched,
            })
        return {
            "active_count": len([task for task in tasks if task.get("status") == "active"]),
            "waiting_count": len([task for task in tasks if task.get("status") == "waiting"]),
            "matches": matches,
            "top": matches[0] if matches else {},
        }

    def record_action(
        self,
        action_type: str,
        payload: JsonDict | None = None,
        task_id: str = "",
        run_id: str = "",
        status: str = "planned",
        risk: str = "low",
        requires_confirm: bool = False,
        result: JsonDict | None = None,
        error: str = "",
    ) -> JsonDict:
        action_type = clean_snippet(action_type, 120)
        if not action_type:
            raise ValueError("empty action type")
        action_id = f"action-{uuid.uuid4().hex[:16]}"
        now = now_iso()
        normalized_status = self._normalize_status(status, self.VALID_ACTION_STATUSES, "planned")
        conn = self._connect()
        try:
            conn.execute(
                """INSERT INTO agent_actions
                   (id, created_at, updated_at, run_id, task_id, action_type, payload_json,
                    status, risk, requires_confirm, result_json, error)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    action_id,
                    now,
                    now,
                    clean_snippet(run_id, 120),
                    clean_snippet(task_id, 120),
                    action_type,
                    json_dumps(payload or {}),
                    normalized_status,
                    clean_snippet(risk or "low", 40),
                    1 if requires_confirm else 0,
                    json_dumps(result or {}),
                    clean_snippet(error, 300),
                ),
            )
            conn.commit()
        finally:
            conn.close()
        return self.get_action(action_id) or {"id": action_id, "action_type": action_type, "status": normalized_status}

    def get_action(self, action_id: str) -> JsonDict | None:
        conn = self._connect()
        try:
            row = conn.execute(
                """SELECT id, created_at, updated_at, run_id, task_id, action_type,
                          payload_json, status, risk, requires_confirm, result_json, error
                   FROM agent_actions WHERE id=? LIMIT 1""",
                (action_id,),
            ).fetchone()
            return self._row_to_action(row) if row else None
        finally:
            conn.close()

    def update_action(self, action_id: str, patch: JsonDict) -> JsonDict | None:
        existing = self.get_action(action_id)
        if not existing:
            return None
        updates: dict[str, Any] = {}
        if "status" in patch:
            updates["status"] = self._normalize_status(
                str(patch.get("status")),
                self.VALID_ACTION_STATUSES,
                existing.get("status") or "planned",
            )
        if "risk" in patch:
            updates["risk"] = clean_snippet(patch.get("risk") or "low", 40)
        if "requires_confirm" in patch:
            updates["requires_confirm"] = 1 if bool(patch.get("requires_confirm")) else 0
        if "error" in patch:
            updates["error"] = clean_snippet(patch.get("error"), 300)
        if "payload" in patch and isinstance(patch.get("payload"), dict):
            updates["payload_json"] = json_dumps(patch.get("payload") or {})
        if "result" in patch and isinstance(patch.get("result"), dict):
            updates["result_json"] = json_dumps(patch.get("result") or {})
        if not updates:
            return existing
        updates["updated_at"] = now_iso()
        assignments = ", ".join(f"{key}=?" for key in updates)
        values = list(updates.values()) + [action_id]
        conn = self._connect()
        try:
            conn.execute(f"UPDATE agent_actions SET {assignments} WHERE id=?", values)
            conn.commit()
        finally:
            conn.close()
        return self.get_action(action_id)

    def _append_action_audit(self, result: JsonDict | None, event: JsonDict) -> JsonDict:
        current = result if isinstance(result, dict) else {}
        audit = current.get("audit") if isinstance(current.get("audit"), list) else []
        audit = [item for item in audit if isinstance(item, dict)][-9:]
        entry = {key: value for key, value in (event or {}).items() if value not in (None, "")}
        audit.append(entry)
        return {
            **current,
            "audit": audit,
        }

    def apply_action(self, action_id: str, confirm: bool = False) -> JsonDict:
        action = self.get_action(action_id)
        if not action:
            raise AgentActionApplyError("action not found", status_code=404)

        action_type = action.get("action_type") or ""
        action_status = action.get("status") or "planned"
        attempted_at = now_iso()
        payload = action.get("payload") if isinstance(action.get("payload"), dict) else {}
        task_id = clean_snippet(action.get("task_id") or "", 120)
        confirm_required = bool(action.get("requires_confirm")) or action_type in {
            "task.mark_done_candidate",
            "task.create_candidate",
        }

        def _raise_with_update(
            message: str,
            *,
            stored_status: str,
            status_code: int = 400,
            extra_result: JsonDict | None = None,
        ) -> None:
            result = self._append_action_audit(
                action.get("result"),
                {
                    "event": "apply_attempt",
                    "at": attempted_at,
                    "status": stored_status,
                    "confirm": bool(confirm),
                    "reason": message,
                },
            )
            merged_result = {
                **result,
                "applied": False,
                "status": stored_status,
                "reason": message,
                "applied_at": attempted_at,
                "confirm": bool(confirm),
                "action_type": action_type,
            }
            if isinstance(extra_result, dict):
                merged_result.update(extra_result)
            updated = self.update_action(
                action_id,
                {
                    "status": stored_status,
                    "result": merged_result,
                    "error": message,
                },
            ) or action
            raise AgentActionApplyError(message, status_code=status_code, action=updated)

        if action_status != "planned":
            raise AgentActionApplyError(f"action already {action_status}", status_code=409, action=action)
        if clean_snippet(action.get("risk") or "low", 40) != "low":
            _raise_with_update("only low-risk internal actions may be applied", stored_status="rejected")
        if action_type not in self.APPLICABLE_ACTION_TYPES:
            _raise_with_update("action type is not applyable", stored_status="rejected")
        if confirm_required and not confirm:
            _raise_with_update(
                "confirm=true required for this action",
                stored_status="planned",
                extra_result={"awaiting_confirm": True},
            )

        task: JsonDict | None = None
        created_task: JsonDict | None = None
        try:
            if action_type == "task.follow_next_action":
                if not task_id:
                    _raise_with_update("task_id required for follow_next_action", stored_status="failed")
                task = self.update_task(task_id, {"last_run_at": attempted_at})
                if not task:
                    _raise_with_update("task not found", stored_status="failed", status_code=404)
                outcome = {
                    "effect": "task_touched",
                    "task_id": task.get("id"),
                    "task_status": task.get("status"),
                    "last_run_at": task.get("last_run_at"),
                }
            elif action_type == "task.wait_candidate":
                if not task_id:
                    _raise_with_update("task_id required for wait_candidate", stored_status="failed")
                task = self.update_task(task_id, {"status": "waiting", "last_run_at": attempted_at})
                if not task:
                    _raise_with_update("task not found", stored_status="failed", status_code=404)
                outcome = {
                    "effect": "task_waiting",
                    "task_id": task.get("id"),
                    "task_status": task.get("status"),
                    "last_run_at": task.get("last_run_at"),
                }
            elif action_type == "task.mark_done_candidate":
                if not task_id:
                    _raise_with_update("task_id required for mark_done_candidate", stored_status="failed")
                task = self.update_task(task_id, {"status": "done", "last_run_at": attempted_at})
                if not task:
                    _raise_with_update("task not found", stored_status="failed", status_code=404)
                outcome = {
                    "effect": "task_done",
                    "task_id": task.get("id"),
                    "task_status": task.get("status"),
                    "last_run_at": task.get("last_run_at"),
                }
            else:
                title = (
                    payload.get("task_title")
                    or payload.get("title")
                    or payload.get("user_msg")
                    or payload.get("reason")
                    or "new task"
                )
                next_action = clean_snippet(payload.get("next_action"), 300)
                if normalize_text_key(next_action) == normalize_text_key("confirm whether this should become a tracked task"):
                    next_action = ""
                priority = 3
                try:
                    priority = max(1, min(5, int(payload.get("priority") or 3)))
                except Exception:
                    priority = 3
                created_task = self.create_task(
                    title=title,
                    goal=payload.get("goal") or payload.get("user_msg") or title,
                    next_action=next_action,
                    due_time=payload.get("due_time") or None,
                    priority=priority,
                    source=payload.get("source") or "agent_action_apply",
                    evidence=payload.get("evidence") or payload.get("user_msg") or payload.get("reason") or title,
                    status="active",
                    meta={
                        "created_from_action_id": action_id,
                        "created_from_run_id": action.get("run_id") or "",
                        "planner_route": payload.get("route") or "",
                        "apply_source": "agent_task_apply_v1",
                    },
                )
                task = created_task
                outcome = {
                    "effect": "task_created",
                    "task_id": created_task.get("id"),
                    "task_status": created_task.get("status"),
                    "created_task_id": created_task.get("id"),
                }
        except AgentActionApplyError:
            raise
        except Exception as err:
            _raise_with_update(clean_snippet(str(err), 300) or "apply action failed", stored_status="failed")

        result = self._append_action_audit(
            action.get("result"),
            {
                "event": "apply_attempt",
                "at": attempted_at,
                "status": "executed",
                "confirm": bool(confirm),
                "task_id": task.get("id") if isinstance(task, dict) else "",
                "effect": outcome.get("effect"),
            },
        )
        result.update({
            "applied": True,
            "status": "executed",
            "applied_at": attempted_at,
            "confirm": bool(confirm),
            "action_type": action_type,
            **outcome,
        })
        updated_action = self.update_action(
            action_id,
            {
                "status": "executed",
                "result": result,
                "error": "",
            },
        ) or action
        return {
            "action": updated_action,
            "task": task,
            "created_task": created_task,
        }

    def list_actions(self, task_id: str | None = None, limit: int = 50) -> list[JsonDict]:
        clauses = []
        params: list[Any] = []
        if task_id:
            clauses.append("task_id=?")
            params.append(task_id)
        where = "WHERE " + " AND ".join(clauses) if clauses else ""
        params.append(max(1, min(200, int(limit or 50))))
        conn = self._connect()
        try:
            cur = conn.execute(
                f"""SELECT id, created_at, updated_at, run_id, task_id, action_type,
                           payload_json, status, risk, requires_confirm, result_json, error
                    FROM agent_actions {where}
                    ORDER BY created_at DESC LIMIT ?""",
                params,
            )
            return [self._row_to_action(row) for row in cur.fetchall()]
        finally:
            conn.close()

    def summary(self, limit: int = 200) -> JsonDict:
        tasks = self.list_tasks(status="all", limit=limit)
        by_status: dict[str, int] = {}
        for task in tasks:
            status = task.get("status") or "active"
            by_status[status] = by_status.get(status, 0) + 1
        return {
            "total": len(tasks),
            "by_status": by_status,
            "active": by_status.get("active", 0),
            "waiting": by_status.get("waiting", 0),
            "done": by_status.get("done", 0),
            "latest": tasks[0] if tasks else {},
        }

    def status(self) -> JsonDict:
        return {
            "db": str(self.db_path),
            "tasks": self.summary(limit=100),
            "actions": len(self.list_actions(limit=100)),
        }


class SelfImprovementLayer:
    """Review-only improvement candidates derived from local observability data."""

    VALID_STATUSES = {
        "pending",
        "accepted",
        "rejected",
        "archived",
        "proposal_created",
        "auto_reviewed",
        "auto_applied",
        "needs_external_research",
        "failed",
    }
    VALID_POLICY_STATUSES = {"draft", "enabled", "disabled", "archived"}
    VALID_PROPOSAL_STATUSES = {
        "draft",
        "ready_for_sandbox",
        "approved",
        "rejected",
        "applied",
        "failed",
        "archived",
        "needs_external_research",
    }
    VALID_SANDBOX_STATUSES = {"running", "passed", "failed", "skipped"}
    SANDBOX_FILES = [
        "zhiyue_connected.py",
        "zhiyue_chat_pipeline.py",
        "zhiyue_companion_policy.py",
        "zhiyue_companion_closer.py",
        "zhiyue_learning_controller.py",
        "zhiyue_office_task_flow.py",
        "zhiyue_office_response.py",
        "zhiyue_db_migrations.py",
        "zhiyue_intimacy.py",
        "zhiyue_code_fix.py",
        "zhiyue_layers.py",
        "zhiyue_eval.py",
        "zhiyue_memory_injection.py",
        "zhiyue_state_hygiene.py",
        "zhiyue_technical_chat_flow.py",
        "zhiyue_runtime_chat_rules.py",
        "zhiyue_request_merge.py",
        "zhiyue_reply_quality.py",
        "zhiyue_growth_entry.py",
        "zhiyue_rule_hints.py",
        "zhiyue_growth_finalize.py",
        "zhiyue_cognitive.py",
        "zhiyue_conflicts.py",
        "_gateway_zhiyue.py",
        "zhiyue_prompt_utils.py",
        "zhiyue_technical_review.py",
        "zhiyue_technical_entry.py",
        "zhiyue_reply_payloads.py",
        "zhiyue_runtime_health.py",
        "zhiyue_monitor_reporting.py",
    ]
    SANDBOX_DIRS = ["evals"]
    ALLOWED_SANDBOX_COMMAND_PREFIXES = [
        "python -m py_compile ",
        "python zhiyue_eval.py --mode api-smoke --transport test-client",
        "python zhiyue_eval.py --mode memory-hit --transport test-client",
        "python -c \"import py_compile; py_compile.compile(",
        "python -c 'import py_compile; py_compile.compile(",
    ]
    MAX_SANDBOX_ATTEMPTS = 5
    AUTO_PIPELINE_CONFIRMATION = "__AUTO_SANDBOX_APPROVED__"
    AUTO_SOURCE_APPLY_CONFIRMATION = "__AUTO_SOURCE_APPLY__"
    AUTO_APPLY_ALLOWED_FILES = {
        "zhiyue_learning_controller.py",
        "zhiyue_db_migrations.py",
        "zhiyue_self_monitor.py",
        "zhiyue_eval.py",
        "zhiyue_rule_hints.py",
        "zhiyue_technical_chat_flow.py",
        # expanded for directive-aware self-improvement
        "zhiyue_intimacy.py",
        "zhiyue_companion_policy.py",
        "zhiyue_chat_pipeline.py",
        "zhiyue_connected.py",
        "zhiyue_layers.py",
        "zhiyue_growth_entry.py",
        "zhiyue_reply_quality.py",
        "zhiyue_human_like.py",
        "zhiyue_directive_self_fix.py",
        "zhiyue_runtime_chat_rules.py",
    }
    OFFICIAL_RESEARCH_SOURCES = {
        "python": [
            "https://docs.python.org/3/library/sqlite3.html",
            "https://docs.python.org/3/library/subprocess.html",
            "https://docs.python.org/3/library/pathlib.html",
        ],
        "sqlite": [
            "https://www.sqlite.org/lang.html",
            "https://www.sqlite.org/lang_createview.html",
            "https://www.sqlite.org/lang_createtable.html",
        ],
        "flask": [
            "https://flask.palletsprojects.com/en/stable/api/",
        ],
        "requests": [
            "https://requests.readthedocs.io/en/latest/user/quickstart/",
        ],
        "playwright": [
            "https://playwright.dev/python/docs/api/class-page",
        ],
        "git": [
            "https://git-scm.com/docs/git-apply",
        ],
    }

    def __init__(self, config: LayerConfig, observability: ObservabilityLayer, tasks: AgentTaskLayer):
        self.config = config
        self.observability = observability
        self.tasks = tasks
        self.db_path = config.observability_db
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        return _connect_observability_db(self.db_path, self.config.base_dir)

    def _init_db(self) -> None:
        conn = self._connect()
        try:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS self_improvement_candidates (
                    id TEXT PRIMARY KEY,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    status TEXT DEFAULT 'pending',
                    source TEXT DEFAULT '',
                    category TEXT DEFAULT '',
                    title TEXT NOT NULL,
                    recommendation TEXT DEFAULT '',
                    evidence_json TEXT DEFAULT '[]',
                    impact TEXT DEFAULT '',
                    risk TEXT DEFAULT 'low',
                    rollback TEXT DEFAULT '',
                    guardrail TEXT DEFAULT '',
                    fingerprint TEXT UNIQUE,
                    meta_json TEXT DEFAULT '{}'
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_self_improve_status ON self_improvement_candidates(status, updated_at)")
            conn.execute("""
                CREATE TABLE IF NOT EXISTS runtime_policies (
                    id TEXT PRIMARY KEY,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    status TEXT DEFAULT 'draft',
                    candidate_id TEXT DEFAULT '',
                    policy_type TEXT NOT NULL,
                    title TEXT NOT NULL,
                    instruction TEXT DEFAULT '',
                    params_json TEXT DEFAULT '{}',
                    priority INTEGER DEFAULT 3,
                    risk TEXT DEFAULT 'low',
                    evidence_json TEXT DEFAULT '[]',
                    rollback TEXT DEFAULT '',
                    guardrail TEXT DEFAULT '',
                    fingerprint TEXT UNIQUE,
                    meta_json TEXT DEFAULT '{}'
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_runtime_policies_status ON runtime_policies(status, priority, updated_at)")
            conn.execute("""
                CREATE TABLE IF NOT EXISTS code_change_proposals (
                    id TEXT PRIMARY KEY,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    status TEXT DEFAULT 'draft',
                    source_type TEXT DEFAULT '',
                    source_id TEXT DEFAULT '',
                    title TEXT NOT NULL,
                    plain_summary TEXT DEFAULT '',
                    target_files_json TEXT DEFAULT '[]',
                    diff_text TEXT DEFAULT '',
                    rationale TEXT DEFAULT '',
                    risk TEXT DEFAULT 'low',
                    rollback TEXT DEFAULT '',
                    test_commands_json TEXT DEFAULT '[]',
                    authorization_text TEXT DEFAULT '',
                    authorized_at TEXT,
                    fingerprint TEXT UNIQUE,
                    meta_json TEXT DEFAULT '{}'
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_code_proposals_status ON code_change_proposals(status, updated_at)")
            conn.execute("""
                CREATE TABLE IF NOT EXISTS code_sandbox_runs (
                    id TEXT PRIMARY KEY,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    proposal_id TEXT NOT NULL,
                    status TEXT DEFAULT 'running',
                    workspace_path TEXT DEFAULT '',
                    workspace_kept INTEGER DEFAULT 0,
                    applied_patch INTEGER DEFAULT 0,
                    test_commands_json TEXT DEFAULT '[]',
                    result_json TEXT DEFAULT '{}',
                    stdout_tail TEXT DEFAULT '',
                    stderr_tail TEXT DEFAULT '',
                    error TEXT DEFAULT '',
                    duration_ms INTEGER DEFAULT 0,
                    meta_json TEXT DEFAULT '{}'
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_code_sandbox_runs_proposal ON code_sandbox_runs(proposal_id, created_at)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_code_sandbox_runs_status ON code_sandbox_runs(status, created_at)")
            conn.execute("""
                CREATE TABLE IF NOT EXISTS code_apply_runs (
                    id TEXT PRIMARY KEY,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    proposal_id TEXT NOT NULL,
                    sandbox_run_id TEXT DEFAULT '',
                    status TEXT DEFAULT 'rejected',
                    changed_files_json TEXT DEFAULT '[]',
                    confirmation_text TEXT DEFAULT '',
                    result_json TEXT DEFAULT '{}',
                    error TEXT DEFAULT '',
                    meta_json TEXT DEFAULT '{}'
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_code_apply_runs_proposal ON code_apply_runs(proposal_id, created_at)")
            conn.execute(
                """
                CREATE VIEW IF NOT EXISTS code_proposals AS
                SELECT
                    id,
                    created_at,
                    updated_at,
                    status,
                    source_type,
                    source_id,
                    title,
                    plain_summary,
                    target_files_json,
                    diff_text,
                    rationale,
                    risk,
                    rollback,
                    test_commands_json,
                    authorization_text,
                    authorized_at,
                    fingerprint,
                    meta_json
                FROM code_change_proposals
                """
            )
            conn.commit()
        finally:
            conn.close()

    def _row_to_candidate(self, row: tuple[Any, ...]) -> JsonDict:
        return {
            "id": row[0],
            "created_at": row[1],
            "updated_at": row[2],
            "status": row[3],
            "source": row[4],
            "category": row[5],
            "title": row[6],
            "recommendation": row[7],
            "evidence": safe_json_loads(row[8], []) or [],
            "impact": row[9],
            "risk": row[10],
            "rollback": row[11],
            "guardrail": row[12],
            "fingerprint": row[13],
            "meta": safe_json_loads(row[14], {}) or {},
        }

    def _row_to_policy(self, row: tuple[Any, ...]) -> JsonDict:
        return {
            "id": row[0],
            "created_at": row[1],
            "updated_at": row[2],
            "status": row[3],
            "candidate_id": row[4],
            "policy_type": row[5],
            "title": row[6],
            "instruction": row[7],
            "params": safe_json_loads(row[8], {}) or {},
            "priority": row[9],
            "risk": row[10],
            "evidence": safe_json_loads(row[11], []) or [],
            "rollback": row[12],
            "guardrail": row[13],
            "fingerprint": row[14],
            "meta": safe_json_loads(row[15], {}) or {},
        }

    def _row_to_proposal(self, row: tuple[Any, ...]) -> JsonDict:
        return {
            "id": row[0],
            "created_at": row[1],
            "updated_at": row[2],
            "status": row[3],
            "source_type": row[4],
            "source_id": row[5],
            "title": row[6],
            "plain_summary": row[7],
            "target_files": safe_json_loads(row[8], []) or [],
            "diff_text": row[9],
            "rationale": row[10],
            "risk": row[11],
            "rollback": row[12],
            "test_commands": safe_json_loads(row[13], []) or [],
            "authorization_text": row[14],
            "authorized_at": row[15],
            "fingerprint": row[16],
            "meta": safe_json_loads(row[17], {}) or {},
        }

    def _merge_meta(self, base: JsonDict | None, patch: JsonDict | None) -> JsonDict:
        merged = dict(base or {})
        for key, value in (patch or {}).items():
            if isinstance(value, dict) and isinstance(merged.get(key), dict):
                merged[key] = {**merged.get(key, {}), **value}
            else:
                merged[key] = value
        return merged

    def _row_to_sandbox_run(self, row: tuple[Any, ...]) -> JsonDict:
        return {
            "id": row[0],
            "created_at": row[1],
            "updated_at": row[2],
            "proposal_id": row[3],
            "status": row[4],
            "workspace_path": row[5],
            "workspace_kept": bool(row[6]),
            "applied_patch": bool(row[7]),
            "test_commands": safe_json_loads(row[8], []) or [],
            "result": safe_json_loads(row[9], {}) or {},
            "stdout_tail": row[10],
            "stderr_tail": row[11],
            "error": row[12],
            "duration_ms": row[13],
            "meta": safe_json_loads(row[14], {}) or {},
        }

    def _row_to_apply_run(self, row: tuple[Any, ...]) -> JsonDict:
        return {
            "id": row[0],
            "created_at": row[1],
            "updated_at": row[2],
            "proposal_id": row[3],
            "sandbox_run_id": row[4],
            "status": row[5],
            "changed_files": safe_json_loads(row[6], []) or [],
            "confirmation_text": row[7],
            "result": safe_json_loads(row[8], {}) or {},
            "error": row[9],
            "meta": safe_json_loads(row[10], {}) or {},
        }

    def _fingerprint(self, category: str, title: str, evidence: list[JsonDict]) -> str:
        ids = [
            clean_snippet(str(item.get("id") or item.get("action_id") or item.get("run_id") or ""), 120)
            for item in evidence[:8]
            if isinstance(item, dict)
        ]
        raw = json_dumps({
            "category": category,
            "title": title,
            "ids": sorted(item for item in ids if item),
        })
        return hashlib.sha256(raw.encode("utf-8", errors="ignore")).hexdigest()[:24]

    def _policy_fingerprint(self, policy_type: str, candidate_id: str, title: str) -> str:
        raw = json_dumps({
            "policy_type": policy_type,
            "candidate_id": candidate_id,
            "title": title,
        })
        return hashlib.sha256(raw.encode("utf-8", errors="ignore")).hexdigest()[:24]

    def _proposal_fingerprint(self, source_type: str, source_id: str, title: str) -> str:
        raw = json_dumps({
            "source_type": source_type,
            "source_id": source_id,
            "title": title,
        })
        return hashlib.sha256(raw.encode("utf-8", errors="ignore")).hexdigest()[:24]

    def _natural_review_question(self, spec: JsonDict, evidence_count: int = 0) -> str:
        title = clean_snippet(spec.get("title"), 120)
        summary = clean_snippet(spec.get("plain_summary"), 180)
        evidence_note = f"我这边已经攒到 {evidence_count} 条相关迹象。" if evidence_count else "我这边看到一个可以优化的点。"
        return (
            f"{evidence_note}{summary}"
            f"我不会直接改正式代码。你要是愿意，我先只在临时沙箱里试着改和跑测试；"
            f"如果目标达成，我再把结果讲清楚，问你要不要应用到源码。要不要我处理这个：{title}？"
        )

    def record_candidate(
        self,
        *,
        source: str,
        category: str,
        title: str,
        recommendation: str,
        evidence: list[JsonDict] | None = None,
        impact: str = "",
        risk: str = "low",
        rollback: str = "archive this candidate and keep runtime behavior unchanged",
        guardrail: str = "manual review only; do not edit source or execute external tools",
        meta: JsonDict | None = None,
    ) -> JsonDict:
        title = clean_snippet(title, 180)
        if not title:
            raise ValueError("empty improvement title")
        evidence = evidence or []
        category = clean_snippet(category or "general", 80)
        fingerprint = self._fingerprint(category, title, evidence)
        existing = self.get_by_fingerprint(fingerprint)
        if existing:
            return existing
        now = now_iso()
        candidate_id = f"improve-{uuid.uuid4().hex[:16]}"
        conn = self._connect()
        try:
            conn.execute(
                """INSERT INTO self_improvement_candidates
                   (id, created_at, updated_at, status, source, category, title,
                    recommendation, evidence_json, impact, risk, rollback, guardrail,
                    fingerprint, meta_json)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    candidate_id,
                    now,
                    now,
                    "pending",
                    clean_snippet(source, 120),
                    category,
                    title,
                    clean_snippet(recommendation, 800),
                    json_dumps(evidence[:20]),
                    clean_snippet(impact, 500),
                    clean_snippet(risk or "low", 40),
                    clean_snippet(rollback, 500),
                    clean_snippet(guardrail, 500),
                    fingerprint,
                    json_dumps(meta or {}),
                ),
            )
            conn.commit()
        finally:
            conn.close()
        return self.get_candidate(candidate_id) or {"id": candidate_id, "title": title, "status": "pending"}

    def get_candidate(self, candidate_id: str) -> JsonDict | None:
        conn = self._connect()
        try:
            row = conn.execute(
                """SELECT id, created_at, updated_at, status, source, category, title,
                          recommendation, evidence_json, impact, risk, rollback, guardrail,
                          fingerprint, meta_json
                   FROM self_improvement_candidates WHERE id=? LIMIT 1""",
                (candidate_id,),
            ).fetchone()
            return self._row_to_candidate(row) if row else None
        finally:
            conn.close()

    def get_by_fingerprint(self, fingerprint: str) -> JsonDict | None:
        conn = self._connect()
        try:
            row = conn.execute(
                """SELECT id, created_at, updated_at, status, source, category, title,
                          recommendation, evidence_json, impact, risk, rollback, guardrail,
                          fingerprint, meta_json
                   FROM self_improvement_candidates WHERE fingerprint=? LIMIT 1""",
                (fingerprint,),
            ).fetchone()
            return self._row_to_candidate(row) if row else None
        finally:
            conn.close()

    def list_candidates(self, status: str | None = None, limit: int = 50) -> list[JsonDict]:
        clauses = []
        params: list[Any] = []
        if status and status != "all":
            value = clean_snippet(status, 40).lower()
            if value in self.VALID_STATUSES:
                clauses.append("status=?")
                params.append(value)
        where = "WHERE " + " AND ".join(clauses) if clauses else ""
        params.append(max(1, min(200, int(limit or 50))))
        conn = self._connect()
        try:
            cur = conn.execute(
                f"""SELECT id, created_at, updated_at, status, source, category, title,
                           recommendation, evidence_json, impact, risk, rollback, guardrail,
                           fingerprint, meta_json
                    FROM self_improvement_candidates {where}
                    ORDER BY created_at DESC LIMIT ?""",
                params,
            )
            return [self._row_to_candidate(row) for row in cur.fetchall()]
        finally:
            conn.close()

    def update_candidate(self, candidate_id: str, patch: JsonDict) -> JsonDict | None:
        existing = self.get_candidate(candidate_id)
        if not existing:
            return None
        updates: dict[str, Any] = {}
        if "status" in patch:
            status = clean_snippet(patch.get("status"), 40).lower()
            if status in self.VALID_STATUSES:
                updates["status"] = status
        if "meta" in patch and isinstance(patch.get("meta"), dict):
            updates["meta_json"] = json_dumps(self._merge_meta(existing.get("meta") or {}, patch["meta"]))
        if not updates:
            return existing
        updates["updated_at"] = now_iso()
        assignments = ", ".join(f"{key}=?" for key in updates)
        values = list(updates.values()) + [candidate_id]
        conn = self._connect()
        try:
            conn.execute(f"UPDATE self_improvement_candidates SET {assignments} WHERE id=?", values)
            conn.commit()
        finally:
            conn.close()
        return self.get_candidate(candidate_id)

    def _policy_from_candidate(self, candidate: JsonDict) -> JsonDict:
        category = str(candidate.get("category") or "")
        title = str(candidate.get("title") or "Runtime policy")
        meta = candidate.get("meta") if isinstance(candidate.get("meta"), dict) else {}
        params: JsonDict = {}
        policy_type = "agent_review"
        instruction = "Keep behavior conservative and record evidence before changing runtime behavior."
        priority = 3

        if category.startswith("reply_quality.too_long"):
            policy_type = "reply_style"
            instruction = "Prefer shorter conversational replies unless the user explicitly asks for detail."
            params = {"max_reply_chars_hint": 90, "avoid_list_tone": True}
            priority = 5
        elif category.startswith("reply_quality.list_tone"):
            policy_type = "reply_style"
            instruction = "Avoid bullet-list or lecture tone in companionship chat; answer as a natural short message."
            params = {"avoid_list_tone": True}
            priority = 5
        elif category.startswith("reply_quality.ooc_or_system_leak"):
            policy_type = "safety_style"
            instruction = "Do not mention prompts, internal systems, databases, tools, or model/provider details in character chat."
            params = {"avoid_internal_details": True}
            priority = 5
        elif category.startswith("reply_quality.memory_probe_no_recall") or category == "memory.retrieval":
            policy_type = "memory_recall"
            instruction = "When the user explicitly asks what you remember, prefer checking memory and events before giving a generic reply."
            params = {"memory_probe_recall_bias": True, "recall_limit_hint": 8}
            priority = 4
        elif category.startswith("agent.degraded."):
            policy_type = "agent_reliability"
            instruction = "If this agent node degrades again, keep the user-facing reply stable and record a focused regression candidate."
            params = {"watch_node": meta.get("node") or category.rsplit(".", 1)[-1]}
            priority = 3
        elif category.startswith("actions."):
            policy_type = "task_action_hygiene"
            instruction = "Keep task actions internal and low-risk; prefer explicit confirmation or archiving over leaving planned actions open."
            params = {"keep_actions_internal": True, "prefer_confirmation": True}
            priority = 4

        return {
            "policy_type": policy_type,
            "title": f"Runtime policy: {title}",
            "instruction": instruction,
            "params": params,
            "priority": priority,
            "risk": "low",
        }

    def get_policy(self, policy_id: str) -> JsonDict | None:
        conn = self._connect()
        try:
            row = conn.execute(
                """SELECT id, created_at, updated_at, status, candidate_id, policy_type,
                          title, instruction, params_json, priority, risk, evidence_json,
                          rollback, guardrail, fingerprint, meta_json
                   FROM runtime_policies WHERE id=? LIMIT 1""",
                (policy_id,),
            ).fetchone()
            return self._row_to_policy(row) if row else None
        finally:
            conn.close()

    def list_policies(self, status: str | None = None, limit: int = 50) -> list[JsonDict]:
        clauses = []
        params: list[Any] = []
        if status and status != "all":
            value = clean_snippet(status, 40).lower()
            if value in self.VALID_POLICY_STATUSES:
                clauses.append("status=?")
                params.append(value)
        where = "WHERE " + " AND ".join(clauses) if clauses else ""
        params.append(max(1, min(200, int(limit or 50))))
        conn = self._connect()
        try:
            cur = conn.execute(
                f"""SELECT id, created_at, updated_at, status, candidate_id, policy_type,
                           title, instruction, params_json, priority, risk, evidence_json,
                           rollback, guardrail, fingerprint, meta_json
                    FROM runtime_policies {where}
                    ORDER BY priority DESC, created_at DESC LIMIT ?""",
                params,
            )
            return [self._row_to_policy(row) for row in cur.fetchall()]
        finally:
            conn.close()

    def create_policy_from_candidate(
        self,
        candidate_id: str,
        *,
        status: str = "draft",
        meta: JsonDict | None = None,
    ) -> JsonDict:
        candidate = self.get_candidate(candidate_id)
        if not candidate:
            raise ValueError("candidate not found")
        if candidate.get("status") != "accepted":
            raise ValueError("candidate must be accepted before creating a runtime policy")
        spec = self._policy_from_candidate(candidate)
        status = clean_snippet(status, 40).lower()
        if status not in self.VALID_POLICY_STATUSES:
            status = "draft"
        fingerprint = self._policy_fingerprint(spec["policy_type"], candidate_id, spec["title"])
        existing = self.get_policy_by_fingerprint(fingerprint)
        if existing:
            return existing
        now = now_iso()
        policy_id = f"policy-{uuid.uuid4().hex[:16]}"
        conn = self._connect()
        try:
            conn.execute(
                """INSERT INTO runtime_policies
                   (id, created_at, updated_at, status, candidate_id, policy_type, title,
                    instruction, params_json, priority, risk, evidence_json, rollback,
                    guardrail, fingerprint, meta_json)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    policy_id,
                    now,
                    now,
                    status,
                    candidate_id,
                    spec["policy_type"],
                    clean_snippet(spec["title"], 180),
                    clean_snippet(spec["instruction"], 800),
                    json_dumps(spec.get("params") or {}),
                    int(spec.get("priority") or 3),
                    clean_snippet(spec.get("risk") or "low", 40),
                    json_dumps(candidate.get("evidence") or []),
                    clean_snippet(candidate.get("rollback") or "disable this policy", 500),
                    "runtime prompt hint only; no source edits and no tool execution",
                    fingerprint,
                    json_dumps({"candidate": candidate, **(meta or {})}),
                ),
            )
            conn.commit()
        finally:
            conn.close()
        return self.get_policy(policy_id) or {"id": policy_id, "status": status}

    def get_policy_by_fingerprint(self, fingerprint: str) -> JsonDict | None:
        conn = self._connect()
        try:
            row = conn.execute(
                """SELECT id, created_at, updated_at, status, candidate_id, policy_type,
                          title, instruction, params_json, priority, risk, evidence_json,
                          rollback, guardrail, fingerprint, meta_json
                   FROM runtime_policies WHERE fingerprint=? LIMIT 1""",
                (fingerprint,),
            ).fetchone()
            return self._row_to_policy(row) if row else None
        finally:
            conn.close()

    def update_policy(self, policy_id: str, patch: JsonDict) -> JsonDict | None:
        existing = self.get_policy(policy_id)
        if not existing:
            return None
        updates: dict[str, Any] = {}
        if "status" in patch:
            status = clean_snippet(patch.get("status"), 40).lower()
            if status in self.VALID_POLICY_STATUSES:
                updates["status"] = status
        if "priority" in patch:
            updates["priority"] = max(1, min(5, int(patch.get("priority") or existing.get("priority") or 3)))
        if "meta" in patch and isinstance(patch.get("meta"), dict):
            updates["meta_json"] = json_dumps(self._merge_meta(existing.get("meta") or {}, patch["meta"]))
        if not updates:
            return existing
        updates["updated_at"] = now_iso()
        assignments = ", ".join(f"{key}=?" for key in updates)
        values = list(updates.values()) + [policy_id]
        conn = self._connect()
        try:
            conn.execute(f"UPDATE runtime_policies SET {assignments} WHERE id=?", values)
            conn.commit()
        finally:
            conn.close()
        return self.get_policy(policy_id)

    def active_policy_context(self, limit: int = 6) -> JsonDict:
        policies = [
            item for item in self.list_policies(status="enabled", limit=limit)
            if item.get("risk") == "low"
        ][: max(1, min(12, int(limit or 6)))]
        params: JsonDict = {}
        lines = []
        for policy in policies:
            policy_params = policy.get("params") if isinstance(policy.get("params"), dict) else {}
            params.update(policy_params)
            instruction = clean_snippet(policy.get("instruction"), 180)
            if instruction:
                lines.append(f"- {instruction}")
        return {
            "enabled_count": len(policies),
            "policies": policies,
            "params": params,
            "prompt_inject": "\n=== Runtime Policies ===\n" + "\n".join(lines) if lines else "",
        }

    def _proposal_spec_from_source(self, source: JsonDict, source_type: str) -> JsonDict:
        category = str(source.get("category") or source.get("policy_type") or "")
        title = str(source.get("title") or "Code change proposal")
        source_id = str(source.get("id") or "")
        target_files = ["zhiyue_connected.py"]
        tests = [
            "python -m py_compile zhiyue_connected.py zhiyue_layers.py zhiyue_eval.py zhiyue_cognitive.py zhiyue_conflicts.py _gateway_zhiyue.py",
            "python zhiyue_eval.py --mode api-smoke --transport test-client",
            "python zhiyue_eval.py --mode memory-hit --transport test-client",
        ]
        plain_summary = "我发现一个可以优化的点。建议先在本地生成小补丁，再用临时库跑测试，通过后再考虑应用。"
        rationale = source.get("recommendation") or source.get("instruction") or "Derived from self-improvement evidence."
        risk = "low"
        diff_text = (
            "# Proposal only; no source change has been applied.\n"
            f"# Source: {source_type}:{source_id}\n"
            "# Next sandbox step should produce a concrete unified diff in an isolated copy.\n"
        )

        if category.startswith("reply_quality") or source.get("policy_type") in {"reply_style", "safety_style"}:
            title = f"Code proposal: tighten reply quality guard for {title}"
            plain_summary = "它想把回复质量检查再收紧一点，比如少说长段、少列表腔、别露出系统味。"
            target_files = ["zhiyue_connected.py"]
            rationale = "Recent evaluation evidence suggests reply style needs a focused guard or regression test."
        elif category.startswith("memory") or source.get("policy_type") == "memory_recall":
            title = f"Code proposal: improve memory recall guard for {title}"
            plain_summary = "它想让自己在你问“记不记得”这类问题时更稳地先查记忆和事件。"
            target_files = ["zhiyue_connected.py"]
            rationale = "Memory-probe failures should become stricter recall behavior and regression coverage."
        elif category.startswith("actions") or source.get("policy_type") == "task_action_hygiene":
            title = f"Code proposal: clean up task action lifecycle for {title}"
            plain_summary = "它想把卡着没处理的计划动作整理得更清楚，比如该确认、该归档、该失败就有明确状态。"
            target_files = ["zhiyue_layers.py"]
            rationale = "Open planned actions should have clearer lifecycle handling without opening tool permissions."
        elif category.startswith("agent.degraded") or source.get("policy_type") == "agent_reliability":
            title = f"Code proposal: add regression around agent node degradation for {title}"
            plain_summary = "它想给容易降级的 agent 节点补一个更明确的记录和回归测试。"
            target_files = ["zhiyue_layers.py"]
            rationale = "Degraded agent nodes need focused regression coverage before orchestration changes."
            risk = "medium"

        return {
            "title": clean_snippet(title, 180),
            "plain_summary": clean_snippet(plain_summary, 600),
            "target_files": target_files,
            "diff_text": diff_text,
            "rationale": clean_snippet(rationale, 1000),
            "risk": risk,
            "rollback": "Do not apply the patch, or revert the generated sandbox diff before touching the main project.",
            "test_commands": tests,
            "test_boundary": {
                "objective": clean_snippet(rationale, 300),
                "success_criteria": [
                    "py_compile passes",
                    "api-smoke test-client passes",
                    "memory-hit test-client passes",
                    "existing deterministic reply rules remain intact",
                    "voice.speak and desktop.open_url remain denied by default",
                ],
                "forbidden_changes": [
                    "do not open desktop or free tool execution",
                    "do not write real user databases during tests",
                    "do not remove qdrant-to-local_hybrid fallback",
                    "do not bypass explicit source-apply confirmation",
                    "do not weaken deterministic short reply branches",
                ],
                "allowed_files": target_files,
                "max_files_changed": 3,
                "requires_user_problem_or_accumulated_evidence": True,
            },
        }

    def _candidate_is_codeworthy(self, candidate: JsonDict) -> bool:
        category = str(candidate.get("category") or "").strip().lower()
        source = str(candidate.get("source") or "").strip().lower()
        if source in {"runtime_autonomous_learning", "explicit_user_directive", "self_monitor"}:
            return False
        return any(
            category.startswith(prefix)
            for prefix in ("reply_quality.", "memory.", "actions.", "agent.degraded.", "human_like.")
        )

    def _allowed_auto_apply_files(self) -> set[str]:
        raw = os.environ.get("ZHIYUE_AUTO_APPLY_ALLOWLIST", "").strip()
        if raw:
            return {
                item.replace("\\", "/").strip("/")
                for item in raw.split(",")
                if item.strip()
            }
        return set(self.AUTO_APPLY_ALLOWED_FILES)

    def _proposal_auto_apply_allowed(self, proposal: JsonDict, sandbox_run: JsonDict | None = None) -> JsonDict:
        target_files = [
            str(item).replace("\\", "/").strip("/")
            for item in (proposal.get("target_files") or [])
            if isinstance(item, str) and item.strip()
        ]
        allowed_files = self._allowed_auto_apply_files()
        if not target_files:
            return {"ok": False, "reason": "proposal has no target files"}
        blocked = [name for name in target_files if name not in allowed_files]
        if blocked:
            return {"ok": False, "reason": f"file not auto-applicable: {blocked[0]}", "blocked_files": blocked}
        if str(proposal.get("risk") or "low").strip().lower() not in {"low"}:
            return {"ok": False, "reason": "only low-risk proposals may auto-apply"}
        if len(target_files) > 2:
            return {"ok": False, "reason": "auto-apply is limited to at most two files"}
        validation = self._validate_proposal_diff(proposal)
        if not validation.get("ok"):
            return {"ok": False, "reason": str(validation.get("error") or "diff validation failed")}
        boundary = self._validate_test_boundary(proposal)
        if not boundary.get("ok"):
            return {"ok": False, "reason": str(boundary.get("error") or "boundary validation failed")}
        run = sandbox_run or self.get_sandbox_run(str((proposal.get("meta") or {}).get("latest_sandbox_run_id") or ""))
        if not run:
            return {"ok": False, "reason": "missing sandbox run"}
        if run.get("status") != "passed":
            return {"ok": False, "reason": "sandbox did not pass"}
        result = run.get("result") if isinstance(run.get("result"), dict) else {}
        judgment = result.get("judgment") if isinstance(result.get("judgment"), dict) else {}
        if not judgment.get("objective_met"):
            return {"ok": False, "reason": "sandbox objective not met"}
        return {"ok": True, "allowed_files": target_files, "validation": validation, "boundary": boundary}

    def get_code_proposal(self, proposal_id: str) -> JsonDict | None:
        conn = self._connect()
        try:
            row = conn.execute(
                """SELECT id, created_at, updated_at, status, source_type, source_id, title,
                          plain_summary, target_files_json, diff_text, rationale, risk,
                          rollback, test_commands_json, authorization_text, authorized_at,
                          fingerprint, meta_json
                   FROM code_change_proposals WHERE id=? LIMIT 1""",
                (proposal_id,),
            ).fetchone()
            return self._row_to_proposal(row) if row else None
        finally:
            conn.close()

    def list_code_proposals(self, status: str | None = None, limit: int = 50) -> list[JsonDict]:
        clauses = []
        params: list[Any] = []
        if status and status != "all":
            value = clean_snippet(status, 40).lower()
            if value in self.VALID_PROPOSAL_STATUSES:
                clauses.append("status=?")
                params.append(value)
        where = "WHERE " + " AND ".join(clauses) if clauses else ""
        params.append(max(1, min(200, int(limit or 50))))
        conn = self._connect()
        try:
            cur = conn.execute(
                f"""SELECT id, created_at, updated_at, status, source_type, source_id, title,
                           plain_summary, target_files_json, diff_text, rationale, risk,
                           rollback, test_commands_json, authorization_text, authorized_at,
                           fingerprint, meta_json
                    FROM code_change_proposals {where}
                    ORDER BY created_at DESC LIMIT ?""",
                params,
            )
            return [self._row_to_proposal(row) for row in cur.fetchall()]
        finally:
            conn.close()

    def create_code_proposal(
        self,
        *,
        source_type: str,
        source_id: str,
        status: str = "draft",
        meta: JsonDict | None = None,
    ) -> JsonDict:
        source_type = clean_snippet(source_type, 80)
        source: JsonDict | None = None
        if source_type == "candidate":
            source = self.get_candidate(source_id)
        elif source_type == "runtime_policy":
            source = self.get_policy(source_id)
        if not source:
            raise ValueError("proposal source not found")
        spec = self._proposal_spec_from_source(source, source_type)
        evidence = source.get("evidence") if isinstance(source.get("evidence"), list) else []
        status = clean_snippet(status, 40).lower()
        if status not in self.VALID_PROPOSAL_STATUSES:
            status = "draft"
        fingerprint = self._proposal_fingerprint(source_type, source_id, spec["title"])
        existing = self.get_code_proposal_by_fingerprint(fingerprint)
        if existing:
            return existing
        now = now_iso()
        proposal_id = f"proposal-{uuid.uuid4().hex[:16]}"
        conn = self._connect()
        try:
            source_meta = source.get("meta") if isinstance(source.get("meta"), dict) else {}
            lane = "code_candidate" if source_type in {"candidate", "runtime_policy"} else "unknown"
            conn.execute(
                """INSERT INTO code_change_proposals
                   (id, created_at, updated_at, status, source_type, source_id, title,
                    plain_summary, target_files_json, diff_text, rationale, risk, rollback,
                    test_commands_json, authorization_text, authorized_at, fingerprint, meta_json)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    proposal_id,
                    now,
                    now,
                    status,
                    source_type,
                    clean_snippet(source_id, 120),
                    spec["title"],
                    spec["plain_summary"],
                    json_dumps(spec["target_files"]),
                    spec["diff_text"],
                    spec["rationale"],
                    clean_snippet(spec["risk"], 40),
                    spec["rollback"],
                    json_dumps(spec["test_commands"]),
                    "",
                    None,
                    fingerprint,
                    json_dumps({
                        "source": source,
                        "lane": lane,
                        "trigger": {
                            "reason": spec["rationale"],
                            "source_type": source_type,
                            "source_id": source_id,
                            "category": source.get("category") or source.get("policy_type") or "",
                            "title": source.get("title") or "",
                        },
                        "impact_scope": {
                            "target_files": spec["target_files"],
                            "risk": spec["risk"],
                            "rollback": spec["rollback"],
                        },
                        "verification": {
                            "required_tests": spec["test_commands"],
                            "last_sandbox_run_id": "",
                            "last_sandbox_status": "",
                            "last_apply_run_id": "",
                            "last_apply_status": "",
                            "result": {},
                        },
                        "safety": {
                            "sandbox_only_by_default": True,
                            "auto_apply_candidate": False,
                            "auto_apply_allowlist": sorted(self._allowed_auto_apply_files()),
                            "source_apply_requires_second_confirmation": True,
                        },
                        "test_boundary": spec.get("test_boundary") or {},
                        "workflow": {
                            "state": "awaiting_user_sandbox_approval",
                            "human_question": self._natural_review_question(spec, len(evidence)),
                            "approval_scope": "sandbox_only",
                            "attempts": 0,
                            "max_attempts": self.MAX_SANDBOX_ATTEMPTS,
                            "decision_owner": "user",
                            "source_apply_requires_second_confirmation": True,
                        },
                        "source_meta_snapshot": source_meta,
                        **(meta or {}),
                    }),
                ),
            )
            conn.commit()
        finally:
            conn.close()
        return self.get_code_proposal(proposal_id) or {"id": proposal_id, "status": status}

    def get_code_proposal_by_fingerprint(self, fingerprint: str) -> JsonDict | None:
        conn = self._connect()
        try:
            row = conn.execute(
                """SELECT id, created_at, updated_at, status, source_type, source_id, title,
                          plain_summary, target_files_json, diff_text, rationale, risk,
                          rollback, test_commands_json, authorization_text, authorized_at,
                          fingerprint, meta_json
                   FROM code_change_proposals WHERE fingerprint=? LIMIT 1""",
                (fingerprint,),
            ).fetchone()
            return self._row_to_proposal(row) if row else None
        finally:
            conn.close()

    def update_code_proposal(self, proposal_id: str, patch: JsonDict) -> JsonDict | None:
        existing = self.get_code_proposal(proposal_id)
        if not existing:
            return None
        updates: dict[str, Any] = {}
        editable_content_fields = {
            "title",
            "plain_summary",
            "target_files",
            "diff_text",
            "rationale",
            "risk",
            "rollback",
            "test_commands",
        }
        wants_content_edit = any(key in patch for key in editable_content_fields)
        if wants_content_edit and existing.get("status") not in {"draft", "ready_for_sandbox", "approved", "needs_external_research"}:
            raise ValueError("proposal content can only be edited before or during sandbox review")
        if "status" in patch:
            status = clean_snippet(patch.get("status"), 40).lower()
            if status in self.VALID_PROPOSAL_STATUSES:
                updates["status"] = status
        for key, limit in [
            ("title", 180),
            ("plain_summary", 1200),
            ("rationale", 2000),
            ("risk", 40),
            ("rollback", 1200),
        ]:
            if key in patch:
                updates[key] = clean_snippet(patch.get(key), limit)
        if "diff_text" in patch:
            diff_text = str(patch.get("diff_text") or "")
            if len(diff_text) > 120_000:
                raise ValueError("proposal diff is too large")
            updates["diff_text"] = diff_text
        if "target_files" in patch:
            target_files = [
                str(item).replace("\\", "/").strip("/")
                for item in (patch.get("target_files") or [])
                if isinstance(item, str) and item.strip()
            ]
            allowed = {name.replace("\\", "/") for name in self.SANDBOX_FILES}
            blocked = [name for name in target_files if name not in allowed or "/" in name]
            if blocked:
                raise ValueError(f"target file is not allowed: {blocked[0]}")
            if len(target_files) > 3:
                raise ValueError("proposal target files exceed max_files_changed")
            updates["target_files_json"] = json_dumps(target_files)
        if "test_commands" in patch:
            commands = [
                str(command).strip()
                for command in (patch.get("test_commands") or [])
                if isinstance(command, str) and command.strip()
            ]
            blocked = [command for command in commands if not self._allowed_sandbox_command(command)]
            if blocked:
                raise ValueError(f"sandbox command not allowed: {blocked[0]}")
            updates["test_commands_json"] = json_dumps(commands)
        if "meta" in patch and isinstance(patch.get("meta"), dict):
            updates["meta_json"] = json_dumps({**(existing.get("meta") or {}), **patch["meta"]})
        elif wants_content_edit:
            meta = existing.get("meta") or {}
            workflow = meta.get("workflow") if isinstance(meta.get("workflow"), dict) else {}
            meta["workflow"] = {
                **workflow,
                "state": "awaiting_user_sandbox_approval",
                "approval_scope": "sandbox_only",
                "content_updated_at": now_iso(),
                "source_apply_requires_second_confirmation": True,
            }
            updates["meta_json"] = json_dumps(meta)
        if not updates:
            return existing
        updates["updated_at"] = now_iso()
        assignments = ", ".join(f"{key}=?" for key in updates)
        values = list(updates.values()) + [proposal_id]
        conn = self._connect()
        try:
            conn.execute(f"UPDATE code_change_proposals SET {assignments} WHERE id=?", values)
            conn.commit()
        finally:
            conn.close()
        return self.get_code_proposal(proposal_id)

    def authorize_code_proposal(self, proposal_id: str, text: str) -> JsonDict:
        proposal = self.get_code_proposal(proposal_id)
        if not proposal:
            raise ValueError("proposal not found")
        candidate_text = (text or "").strip()
        normalized = normalize_text_key(candidate_text)
        raw = candidate_text.lower()
        if candidate_text == self.AUTO_PIPELINE_CONFIRMATION:
            allowed = True
            approval_mode = "auto_pipeline"
        else:
            allowed_phrases = [
                "同意",
                "批准",
                "授权",
                "可以",
                "行",
                "好",
                "嗯",
                "去做",
                "改吧",
                "可以改",
                "允许",
                "approve",
                "approved",
                "yes",
                "ok",
            ]
            allowed = raw in {"行", "可以", "好", "好吧", "嗯", "嗯嗯", "去做", "改吧", "可以改", "允许", "确认", "同意", "批准", "授权", "approve", "approved", "yes", "ok", "y"} or any(
                phrase in candidate_text for phrase in allowed_phrases
            ) or any(token in normalized for token in {"approve", "approved", "yes", "ok"})
            approval_mode = "natural_language"
        if not allowed:
            raise ValueError("authorization text did not clearly approve sandbox review")
        now = now_iso()
        existing_meta = proposal.get("meta") or {}
        workflow = existing_meta.get("workflow") if isinstance(existing_meta.get("workflow"), dict) else {}
        workflow = {
            **workflow,
            "state": "approved_for_sandbox",
            "approval_scope": "sandbox_only",
            "sandbox_approved_at": now,
            "source_apply_requires_second_confirmation": True,
        }
        meta = {
            **existing_meta,
            "workflow": workflow,
            "authorization": {
                "text": clean_snippet(text, 300),
                "authorized_at": now,
                "mode": approval_mode,
                "effect": "proposal approved only; source not modified",
            },
        }
        conn = self._connect()
        try:
            conn.execute(
                """UPDATE code_change_proposals
                   SET status=?, authorization_text=?, authorized_at=?, updated_at=?, meta_json=?
                   WHERE id=?""",
                ("approved", clean_snippet(text, 300), now, now, json_dumps(meta), proposal_id),
            )
            conn.commit()
        finally:
            conn.close()
        updated = self.get_code_proposal(proposal_id)
        if not updated:
            raise ValueError("proposal not found after authorization")
        return updated

    def code_proposal_summary(self, limit: int = 200) -> JsonDict:
        proposals = self.list_code_proposals(status="all", limit=limit)
        by_status: dict[str, int] = {}
        for item in proposals:
            status = item.get("status") or "draft"
            by_status[status] = by_status.get(status, 0) + 1
        sandbox_runs = self.list_sandbox_runs(limit=limit)
        apply_runs = self.list_apply_runs(limit=limit)
        sandbox_by_status: dict[str, int] = {}
        for item in sandbox_runs:
            status = item.get("status") or "unknown"
            sandbox_by_status[status] = sandbox_by_status.get(status, 0) + 1
        apply_by_status: dict[str, int] = {}
        for item in apply_runs:
            status = item.get("status") or "unknown"
            apply_by_status[status] = apply_by_status.get(status, 0) + 1
        return {
            "total": len(proposals),
            "by_status": by_status,
            "sandbox_runs_total": len(sandbox_runs),
            "sandbox_runs_by_status": sandbox_by_status,
            "apply_runs_total": len(apply_runs),
            "apply_runs_by_status": apply_by_status,
            "latest": proposals[0] if proposals else {},
        }

    def _insert_sandbox_run(self, proposal_id: str, commands: list[str], workspace_path: str, keep_workspace: bool) -> str:
        now = now_iso()
        run_id = f"sandbox-{uuid.uuid4().hex[:16]}"
        conn = self._connect()
        try:
            conn.execute(
                """INSERT INTO code_sandbox_runs
                   (id, created_at, updated_at, proposal_id, status, workspace_path,
                    workspace_kept, applied_patch, test_commands_json, result_json, meta_json)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    run_id,
                    now,
                    now,
                    proposal_id,
                    "running",
                    workspace_path,
                    1 if keep_workspace else 0,
                    0,
                    json_dumps(commands),
                    json_dumps({}),
                    json_dumps({"main_source_modified": False, "mode": "isolated_copy"}),
                ),
            )
            conn.commit()
        finally:
            conn.close()
        return run_id

    def _update_sandbox_run(self, run_id: str, patch: JsonDict) -> None:
        updates: dict[str, Any] = {"updated_at": now_iso()}
        for key in [
            "status",
            "workspace_path",
            "workspace_kept",
            "applied_patch",
            "test_commands_json",
            "result_json",
            "stdout_tail",
            "stderr_tail",
            "error",
            "duration_ms",
            "meta_json",
        ]:
            if key in patch:
                updates[key] = patch[key]
        assignments = ", ".join(f"{key}=?" for key in updates)
        values = list(updates.values()) + [run_id]
        conn = self._connect()
        try:
            conn.execute(f"UPDATE code_sandbox_runs SET {assignments} WHERE id=?", values)
            conn.commit()
        finally:
            conn.close()

    def get_sandbox_run(self, run_id: str) -> JsonDict | None:
        conn = self._connect()
        try:
            row = conn.execute(
                """SELECT id, created_at, updated_at, proposal_id, status, workspace_path,
                          workspace_kept, applied_patch, test_commands_json, result_json,
                          stdout_tail, stderr_tail, error, duration_ms, meta_json
                   FROM code_sandbox_runs WHERE id=? LIMIT 1""",
                (run_id,),
            ).fetchone()
            return self._row_to_sandbox_run(row) if row else None
        finally:
            conn.close()

    def list_sandbox_runs(self, proposal_id: str | None = None, status: str | None = None, limit: int = 50) -> list[JsonDict]:
        clauses = []
        params: list[Any] = []
        if proposal_id:
            clauses.append("proposal_id=?")
            params.append(clean_snippet(proposal_id, 120))
        if status and status != "all":
            value = clean_snippet(status, 40).lower()
            if value in self.VALID_SANDBOX_STATUSES:
                clauses.append("status=?")
                params.append(value)
        where = "WHERE " + " AND ".join(clauses) if clauses else ""
        params.append(max(1, min(200, int(limit or 50))))
        conn = self._connect()
        try:
            cur = conn.execute(
                f"""SELECT id, created_at, updated_at, proposal_id, status, workspace_path,
                           workspace_kept, applied_patch, test_commands_json, result_json,
                           stdout_tail, stderr_tail, error, duration_ms, meta_json
                    FROM code_sandbox_runs {where}
                    ORDER BY created_at DESC LIMIT ?""",
                params,
            )
            return [self._row_to_sandbox_run(row) for row in cur.fetchall()]
        finally:
            conn.close()

    def _allowed_sandbox_command(self, command: str) -> bool:
        normalized = " ".join((command or "").strip().split())
        return any(normalized.startswith(prefix) for prefix in self.ALLOWED_SANDBOX_COMMAND_PREFIXES)

    def _has_concrete_diff(self, diff_text: str | None) -> bool:
        text = diff_text or ""
        return bool(re.search(r"(?m)^(--- |\+\+\+ |@@ )", text)) and "Proposal only; no source change" not in text

    def _extract_diff_files(self, diff_text: str | None) -> list[str]:
        files: list[str] = []
        for line in (diff_text or "").splitlines():
            if line.startswith("+++ "):
                raw = line[4:].strip()
                if raw == "/dev/null":
                    continue
                if raw.startswith("b/"):
                    raw = raw[2:]
                raw = raw.replace("\\", "/").strip("/")
                if raw and raw not in files:
                    files.append(raw)
        return files

    def _validate_proposal_diff(self, proposal: JsonDict) -> JsonDict:
        diff_text = str(proposal.get("diff_text") or "")
        if not self._has_concrete_diff(diff_text):
            return {
                "ok": False,
                "error": "proposal has no concrete unified diff",
                "files": [],
            }
        allowed = {name.replace("\\", "/") for name in self.SANDBOX_FILES}
        declared = {
            str(name).replace("\\", "/").strip("/")
            for name in (proposal.get("target_files") or [])
            if isinstance(name, str)
        }
        files = self._extract_diff_files(diff_text)
        if not files:
            return {"ok": False, "error": "diff has no target files", "files": []}
        blocked = [
            name for name in files
            if name not in allowed or (declared and name not in declared) or "/" in name
        ]
        if blocked:
            return {
                "ok": False,
                "error": f"diff target is not allowed: {blocked[0]}",
                "files": files,
            }
        return {"ok": True, "files": files}

    def _validate_test_boundary(self, proposal: JsonDict) -> JsonDict:
        meta = proposal.get("meta") if isinstance(proposal.get("meta"), dict) else {}
        boundary = meta.get("test_boundary") if isinstance(meta.get("test_boundary"), dict) else {}
        if not boundary:
            return {"ok": False, "error": "proposal missing test boundary", "boundary": {}}
        objective = clean_snippet(boundary.get("objective"), 500)
        success_criteria = boundary.get("success_criteria") if isinstance(boundary.get("success_criteria"), list) else []
        forbidden_changes = boundary.get("forbidden_changes") if isinstance(boundary.get("forbidden_changes"), list) else []
        allowed_files = [
            str(item).replace("\\", "/").strip("/")
            for item in (boundary.get("allowed_files") or [])
            if isinstance(item, str) and item.strip()
        ]
        target_files = [
            str(item).replace("\\", "/").strip("/")
            for item in (proposal.get("target_files") or [])
            if isinstance(item, str) and item.strip()
        ]
        if len(objective) < 12:
            return {"ok": False, "error": "test boundary objective is too vague", "boundary": boundary}
        if len(success_criteria) < 2:
            return {"ok": False, "error": "test boundary needs success criteria", "boundary": boundary}
        if len(forbidden_changes) < 2:
            return {"ok": False, "error": "test boundary needs forbidden changes", "boundary": boundary}
        if not allowed_files:
            return {"ok": False, "error": "test boundary needs allowed files", "boundary": boundary}
        if set(target_files) - set(allowed_files):
            return {"ok": False, "error": "proposal target files exceed boundary allowed files", "boundary": boundary}
        try:
            max_files = max(1, int(boundary.get("max_files_changed") or 3))
        except Exception:
            max_files = 3
        if len(target_files) > max_files:
            return {"ok": False, "error": "proposal changes too many files for boundary", "boundary": boundary}
        commands = proposal.get("test_commands") if isinstance(proposal.get("test_commands"), list) else []
        for required in ["py_compile", "api-smoke", "memory-hit"]:
            if not any(required in str(command) for command in commands):
                return {"ok": False, "error": f"test boundary missing required test: {required}", "boundary": boundary}
        return {
            "ok": True,
            "boundary": boundary,
            "objective": objective,
            "allowed_files": allowed_files,
            "success_criteria": success_criteria,
            "forbidden_changes": forbidden_changes,
        }

    def _apply_unified_diff_python(self, diff_text: str, cwd: Path) -> JsonDict:
        current_file = ""
        hunks: dict[str, list[dict[str, Any]]] = {}
        old_start = 0
        old_count = 0
        new_start = 0
        new_count = 0
        hunk_lines: list[str] | None = None

        def flush_hunk() -> None:
            nonlocal hunk_lines
            if current_file and hunk_lines is not None:
                hunks.setdefault(current_file, []).append({
                    "old_start": old_start,
                    "old_count": old_count,
                    "new_start": new_start,
                    "new_count": new_count,
                    "lines": hunk_lines,
                })
            hunk_lines = None

        for line in diff_text.splitlines():
            if line.startswith("--- "):
                flush_hunk()
                continue
            if line.startswith("+++ "):
                raw = line[4:].strip()
                if raw.startswith("b/"):
                    raw = raw[2:]
                current_file = raw.replace("\\", "/").strip("/")
                continue
            if line.startswith("@@ "):
                flush_hunk()
                match = re.match(r"@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@", line)
                if not match:
                    return {"ok": False, "error": f"unsupported hunk header: {line}"}
                old_start = int(match.group(1))
                old_count = int(match.group(2) or "1")
                new_start = int(match.group(3))
                new_count = int(match.group(4) or "1")
                hunk_lines = []
                continue
            if hunk_lines is not None and (line.startswith(" ") or line.startswith("-") or line.startswith("+") or line == "\\ No newline at end of file"):
                hunk_lines.append(line)
        flush_hunk()

        changed: list[str] = []
        for filename, file_hunks in hunks.items():
            if not filename or filename == "/dev/null" or "/" in filename:
                return {"ok": False, "error": f"unsupported patch target: {filename}"}
            path = cwd / filename
            if not path.exists() or not path.is_file():
                return {"ok": False, "error": f"patch target does not exist: {filename}"}
            original = path.read_text(encoding="utf-8").splitlines()
            output: list[str] = []
            cursor = 0
            for hunk in file_hunks:
                start = max(0, int(hunk["old_start"]) - 1)
                if start < cursor:
                    return {"ok": False, "error": f"overlapping hunk in {filename}"}
                output.extend(original[cursor:start])
                cursor = start
                for hline in hunk["lines"]:
                    if not hline or hline == "\\ No newline at end of file":
                        continue
                    marker = hline[0]
                    text = hline[1:]
                    if marker == " ":
                        if cursor >= len(original) or original[cursor] != text:
                            return {"ok": False, "error": f"context mismatch in {filename}: {text[:80]}"}
                        output.append(original[cursor])
                        cursor += 1
                    elif marker == "-":
                        if cursor >= len(original) or original[cursor] != text:
                            return {"ok": False, "error": f"remove mismatch in {filename}: {text[:80]}"}
                        cursor += 1
                    elif marker == "+":
                        output.append(text)
                changed.append(filename)
            output.extend(original[cursor:])
            path.write_text("\n".join(output) + "\n", encoding="utf-8")
        return {"ok": True, "changed_files": sorted(set(changed)), "engine": "python_unified_diff"}

    def _judge_sandbox_result(self, proposal: JsonDict, result: JsonDict, status: str, attempt: int) -> JsonDict:
        commands = result.get("commands") if isinstance(result.get("commands"), list) else []
        failed_commands = [
            item for item in commands
            if isinstance(item, dict) and not item.get("passed")
        ]
        boundary = result.get("test_boundary") if isinstance(result.get("test_boundary"), dict) else {}
        has_concrete_diff = self._has_concrete_diff(str(proposal.get("diff_text") or ""))
        objective_met = (
            status == "passed"
            and not failed_commands
            and bool(boundary.get("ok"))
            and has_concrete_diff
            and bool(result.get("applied_patch"))
        )
        if objective_met:
            state = "sandbox_goal_met_awaiting_source_confirmation"
            next_question = (
                "沙箱测试过了，目标边界也没越。我还没有改正式源码。"
                "如果你确认要应用到源码，请明确说：确认应用到源码。"
            )
            summary = "Sandbox goal met; awaiting user decision for source apply."
        elif status == "passed" and not failed_commands and bool(boundary.get("ok")) and not has_concrete_diff:
            state = "sandbox_needs_another_iteration"
            next_question = (
                "Sandbox ran successfully, but the proposal still has no concrete unified diff."
                " Fill in a real diff before trying source apply."
            )
            summary = "Sandbox passed, but no concrete diff is available for source apply."
        elif attempt >= self.MAX_SANDBOX_ATTEMPTS:
            state = "sandbox_attempts_exhausted_awaiting_user_decision"
            next_question = (
                f"我已经试了 {attempt} 次沙箱修改/测试，还没稳定达成目标。"
                "我先停下，不继续乱改。你要我继续缩小范围、换方案，还是先放弃这次修改？"
            )
            summary = "Sandbox attempts exhausted; user decision required."
        else:
            state = "sandbox_needs_another_iteration"
            next_question = (
                "这轮沙箱还没完全达标。我会只围绕原目标和边界继续分析下一版，"
                "不会扩大修改范围，也不会改正式源码。"
            )
            summary = "Sandbox did not meet objective; another bounded iteration is allowed."
        return {
            "objective_met": objective_met,
            "state": state,
            "attempt": attempt,
            "max_attempts": self.MAX_SANDBOX_ATTEMPTS,
            "failed_commands": failed_commands,
            "has_concrete_diff": has_concrete_diff,
            "summary": summary,
            "next_question": next_question,
        }

    def _apply_unified_diff(self, diff_text: str, cwd: Path, timeout_sec: int = 30) -> JsonDict:
        proc = subprocess.run(
            ["python", "-c", "import sys, pathlib; pathlib.Path('_zhiyue_patch.diff').write_text(sys.stdin.read(), encoding='utf-8')"],
            cwd=str(cwd),
            input=diff_text,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout_sec,
            shell=False,
        )
        if proc.returncode != 0:
            return {"ok": False, "error": proc.stderr[-1000:] or "failed to write patch file"}
        git_apply = shutil.which("git")
        if git_apply:
            apply_proc = subprocess.run(
                [git_apply, "apply", "--whitespace=nowarn", "_zhiyue_patch.diff"],
                cwd=str(cwd),
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=timeout_sec,
                shell=False,
            )
            return {
                "ok": apply_proc.returncode == 0,
                "returncode": apply_proc.returncode,
                "stdout_tail": (apply_proc.stdout or "")[-1000:],
                "stderr_tail": (apply_proc.stderr or "")[-1000:],
                "error": "" if apply_proc.returncode == 0 else ((apply_proc.stderr or "")[-1000:] or "git apply failed"),
            }
        return self._apply_unified_diff_python(diff_text, cwd)

    def _proposal_source_roots(self) -> list[Path]:
        source_root = Path(__file__).resolve().parent
        candidates = [
            source_root,
            source_root.parent / "core",
            source_root.parent / "modules",
        ]
        roots: list[Path] = []
        seen: set[str] = set()
        for candidate in candidates:
            key = str(candidate).lower()
            if key in seen or not candidate.exists() or not candidate.is_dir():
                continue
            seen.add(key)
            roots.append(candidate)
        return roots

    def _resolve_proposal_source_file(self, name: str) -> Path | None:
        target_name = Path(str(name or "")).name
        if not target_name:
            return None
        for root in self._proposal_source_roots():
            candidate = root / target_name
            if candidate.exists() and candidate.is_file():
                return candidate
        return None

    def _sync_applied_source_files(self, workspace: Path, changed_files: list[str]) -> JsonDict:
        copies: list[tuple[Path, Path]] = []
        for name in changed_files:
            target_name = Path(str(name or "")).name
            source = self._resolve_proposal_source_file(target_name)
            staged = workspace / target_name
            if source is None:
                return {"ok": False, "error": f"source file missing: {target_name}"}
            if not staged.exists() or not staged.is_file():
                return {"ok": False, "error": f"patched sandbox file missing: {target_name}"}
            copies.append((staged, source))
        for staged, source in copies:
            shutil.copy2(staged, source)
        return {
            "ok": True,
            "changed_files": [source.name for _, source in copies],
            "source_paths": [str(source) for _, source in copies],
        }

    def _copy_sandbox_workspace(self, workspace: Path) -> None:
        for name in self.SANDBOX_FILES:
            source = self._resolve_proposal_source_file(name)
            if source is not None and source.exists() and source.is_file():
                shutil.copy2(source, workspace / name)
        source_root = Path(__file__).resolve().parent
        for name in self.SANDBOX_DIRS:
            source = source_root / name
            target = workspace / name
            if source.exists() and source.is_dir():
                shutil.copytree(source, target, ignore=shutil.ignore_patterns("__pycache__", "*.db", "*.sqlite", "*.log"))

    def run_code_proposal_sandbox(
        self,
        proposal_id: str,
        *,
        keep_workspace: bool = False,
        timeout_sec: int = 180,
    ) -> JsonDict:
        proposal = self.get_code_proposal(proposal_id)
        if not proposal:
            raise ValueError("proposal not found")
        if proposal.get("status") != "approved":
            raise ValueError("proposal must be approved before sandbox run")
        proposal_meta = proposal.get("meta") if isinstance(proposal.get("meta"), dict) else {}
        workflow_before = proposal_meta.get("workflow") if isinstance(proposal_meta.get("workflow"), dict) else {}
        attempts_before = int(workflow_before.get("attempts") or 0)
        if attempts_before >= self.MAX_SANDBOX_ATTEMPTS:
            raise ValueError("sandbox attempt limit reached; user decision required")
        commands = [
            str(command)
            for command in (proposal.get("test_commands") or [])
            if isinstance(command, str) and command.strip()
        ]
        if not commands:
            # Provide only allowlisted verification commands.
            target_files = proposal.get("target_files") or ["zhiyue_connected.py"]
            commands = [
                f"python -m py_compile {' '.join(target_files)}",
                "python zhiyue_eval.py --mode api-smoke --transport test-client",
                "python zhiyue_eval.py --mode memory-hit --transport test-client",
            ]
        blocked = [command for command in commands if not self._allowed_sandbox_command(command)]
        if blocked:
            raise ValueError(f"sandbox command not allowed: {blocked[0]}")
        proposal_for_boundary = dict(proposal)
        proposal_for_boundary["test_commands"] = commands
        boundary_validation = self._validate_test_boundary(proposal_for_boundary)
        if not boundary_validation.get("ok"):
            raise ValueError(str(boundary_validation.get("error") or "test boundary invalid"))

        timeout_sec = max(10, min(600, int(timeout_sec or 180)))
        workspace = Path(tempfile.mkdtemp(prefix="zhiyue_sandbox_"))
        run_id = self._insert_sandbox_run(proposal_id, commands, str(workspace), keep_workspace)
        start = time.time()
        command_results: list[JsonDict] = []
        stdout_parts: list[str] = []
        stderr_parts: list[str] = []
        status = "passed"
        error = ""
        applied_patch = False
        patch_result: JsonDict = {"ok": False, "skipped": True, "reason": "no concrete unified diff"}
        try:
            self._copy_sandbox_workspace(workspace)
            diff_validation = self._validate_proposal_diff(proposal)
            if diff_validation.get("ok"):
                patch_result = self._apply_unified_diff(str(proposal.get("diff_text") or ""), workspace)
                if not patch_result.get("ok"):
                    status = "failed"
                    error = str(patch_result.get("error") or "sandbox patch failed")
                else:
                    applied_patch = True
            env = os.environ.copy()
            env["PYTHONIOENCODING"] = "utf-8"
            env["ZHIYUE_SANDBOX_RUNNING"] = "1"
            env["ZHIYUE_DESKTOP_ENABLE"] = "0"
            for command in commands if status == "passed" else []:
                started = time.time()
                parts = command.split()
                proc = subprocess.run(
                    parts,
                    cwd=str(workspace),
                    env=env,
                    capture_output=True,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                    timeout=timeout_sec,
                    shell=False,
                )
                elapsed_ms = int((time.time() - started) * 1000)
                stdout = proc.stdout or ""
                stderr = proc.stderr or ""
                stdout_parts.append(stdout[-2000:])
                stderr_parts.append(stderr[-2000:])
                command_results.append({
                    "command": command,
                    "returncode": proc.returncode,
                    "latency_ms": elapsed_ms,
                    "passed": proc.returncode == 0,
                    "stdout_tail": stdout[-1000:],
                    "stderr_tail": stderr[-1000:],
                })
                if proc.returncode != 0:
                    status = "failed"
                    error = f"command failed: {command}"
                    break
        except Exception as err:
            status = "failed"
            error = str(err)
        finally:
            duration_ms = int((time.time() - start) * 1000)
            if not keep_workspace:
                shutil.rmtree(workspace, ignore_errors=True)
            result = {
                "proposal_id": proposal_id,
                "main_source_modified": False,
                "applied_patch": applied_patch,
                "patch_result": patch_result,
                "test_boundary": boundary_validation,
                "commands": command_results,
                "note": "sandbox ran in an isolated copy; main source was not modified",
            }
            attempt = attempts_before + 1
            judgment = self._judge_sandbox_result(proposal, result, status, attempt)
            result["judgment"] = judgment
            self._update_sandbox_run(
                run_id,
                {
                    "status": status,
                    "workspace_path": str(workspace) if keep_workspace else "",
                    "workspace_kept": 1 if keep_workspace else 0,
                    "applied_patch": 1 if applied_patch else 0,
                    "result_json": json_dumps(result),
                    "stdout_tail": "\n".join(stdout_parts)[-4000:],
                    "stderr_tail": "\n".join(stderr_parts)[-4000:],
                    "error": clean_snippet(error, 1000),
                    "duration_ms": duration_ms,
                    "meta_json": json_dumps({
                        "main_source_modified": False,
                        "mode": "isolated_copy",
                        "workspace_deleted": not keep_workspace,
                        "patch_applied_in_sandbox": applied_patch,
                        "test_boundary": boundary_validation,
                    }),
                },
            )
            proposal_meta = {
                **(proposal.get("meta") or {}),
                "latest_sandbox_run_id": run_id,
                "latest_sandbox_status": status,
                "latest_sandbox_at": now_iso(),
                "verification": {
                    **((proposal.get("meta") or {}).get("verification") if isinstance((proposal.get("meta") or {}).get("verification"), dict) else {}),
                    "required_tests": commands,
                    "last_sandbox_run_id": run_id,
                    "last_sandbox_status": status,
                    "result": {
                        "sandbox_passed": status == "passed",
                        "applied_patch": applied_patch,
                        "error": clean_snippet(error, 500),
                    },
                },
                "workflow": {
                    **workflow_before,
                    "state": judgment.get("state"),
                    "attempts": attempt,
                    "max_attempts": self.MAX_SANDBOX_ATTEMPTS,
                    "latest_judgment": judgment,
                    "next_question": judgment.get("next_question"),
                    "source_apply_requires_second_confirmation": True,
                },
            }
            self.update_code_proposal(proposal_id, {"meta": proposal_meta})
        run = self.get_sandbox_run(run_id)
        if not run:
            raise ValueError("sandbox run disappeared")
        return run

    def list_apply_runs(self, proposal_id: str | None = None, limit: int = 50) -> list[JsonDict]:
        clauses = []
        params: list[Any] = []
        if proposal_id:
            clauses.append("proposal_id=?")
            params.append(clean_snippet(proposal_id, 120))
        where = "WHERE " + " AND ".join(clauses) if clauses else ""
        params.append(max(1, min(200, int(limit or 50))))
        conn = self._connect()
        try:
            cur = conn.execute(
                f"""SELECT id, created_at, updated_at, proposal_id, sandbox_run_id, status,
                           changed_files_json, confirmation_text, result_json, error, meta_json
                    FROM code_apply_runs {where}
                    ORDER BY created_at DESC LIMIT ?""",
                params,
            )
            return [self._row_to_apply_run(row) for row in cur.fetchall()]
        finally:
            conn.close()

    def _record_apply_run(
        self,
        *,
        proposal_id: str,
        sandbox_run_id: str = "",
        status: str,
        changed_files: list[str] | None = None,
        confirmation_text: str = "",
        result: JsonDict | None = None,
        error: str = "",
        meta: JsonDict | None = None,
    ) -> JsonDict:
        now = now_iso()
        run_id = f"apply-{uuid.uuid4().hex[:16]}"
        conn = self._connect()
        try:
            conn.execute(
                """INSERT INTO code_apply_runs
                   (id, created_at, updated_at, proposal_id, sandbox_run_id, status,
                    changed_files_json, confirmation_text, result_json, error, meta_json)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    run_id,
                    now,
                    now,
                    proposal_id,
                    sandbox_run_id,
                    clean_snippet(status, 40),
                    json_dumps(changed_files or []),
                    clean_snippet(confirmation_text, 300),
                    json_dumps(result or {}),
                    clean_snippet(error, 1000),
                    json_dumps(meta or {}),
                ),
            )
            conn.commit()
        finally:
            conn.close()
        runs = self.list_apply_runs(proposal_id=proposal_id, limit=1)
        return runs[0] if runs else {"id": run_id, "status": status}

    def _confirmation_allows_source_apply(self, text: str) -> bool:
        candidate_text = (text or "").strip()
        if candidate_text == self.AUTO_SOURCE_APPLY_CONFIRMATION:
            return True
        normalized = normalize_text_key(candidate_text)
        raw = candidate_text.lower()
        short_approvals = {
            "行",
            "可以",
            "好",
            "好吧",
            "嗯",
            "嗯嗯",
            "改吧",
            "去做",
            "开始",
            "确认",
            "ok",
            "yes",
            "y",
        }
        terms = [
            "确认应用到源码",
            "确认修改源码",
            "同意应用源码",
            "批准应用源码",
            "改到源码",
            "应用到源码",
            "正式改",
            "正式应用",
            "就这样改",
            "按这个改",
            "可以改",
            "你改吧",
            "开始改",
            "applytosource",
            "applysource",
            "yesapplysource",
            "approvedapplysource",
        ]
        return raw in short_approvals or any(term in candidate_text for term in terms) or any(
            token in normalized for token in {"applytosource", "applysource", "yesapplysource", "approvedapplysource"}
        )

    def apply_code_proposal_to_source(self, proposal_id: str, *, confirmation_text: str) -> JsonDict:
        proposal = self.get_code_proposal(proposal_id)
        if not proposal:
            raise ValueError("proposal not found")
        sandbox_run_id = str((proposal.get("meta") or {}).get("latest_sandbox_run_id") or "")
        latest_sandbox_status = str((proposal.get("meta") or {}).get("latest_sandbox_status") or "")
        validation = self._validate_proposal_diff(proposal)
        boundary_validation = self._validate_test_boundary(proposal)
        if not self._confirmation_allows_source_apply(confirmation_text):
            run = self._record_apply_run(
                proposal_id=proposal_id,
                sandbox_run_id=sandbox_run_id,
                status="rejected",
                confirmation_text=confirmation_text,
                error="explicit source-apply confirmation required",
                meta={"gate": "confirmation"},
            )
            raise ValueError(f"explicit source-apply confirmation required; apply_run={run.get('id')}")
        if proposal.get("status") != "approved":
            run = self._record_apply_run(
                proposal_id=proposal_id,
                sandbox_run_id=sandbox_run_id,
                status="rejected",
                confirmation_text=confirmation_text,
                error="proposal must be approved before source apply",
                meta={"gate": "proposal_status"},
            )
            raise ValueError(f"proposal must be approved before source apply; apply_run={run.get('id')}")
        if not boundary_validation.get("ok"):
            run = self._record_apply_run(
                proposal_id=proposal_id,
                sandbox_run_id=sandbox_run_id,
                status="rejected",
                confirmation_text=confirmation_text,
                error=str(boundary_validation.get("error") or "test boundary invalid"),
                meta={"gate": "test_boundary", "boundary_validation": boundary_validation},
            )
            raise ValueError(f"{boundary_validation.get('error')}; apply_run={run.get('id')}")
        if latest_sandbox_status != "passed" or not sandbox_run_id:
            run = self._record_apply_run(
                proposal_id=proposal_id,
                sandbox_run_id=sandbox_run_id,
                status="rejected",
                confirmation_text=confirmation_text,
                error="latest sandbox run must pass before source apply",
                meta={"gate": "sandbox"},
            )
            raise ValueError(f"latest sandbox run must pass before source apply; apply_run={run.get('id')}")
        if not validation.get("ok"):
            run = self._record_apply_run(
                proposal_id=proposal_id,
                sandbox_run_id=sandbox_run_id,
                status="rejected",
                confirmation_text=confirmation_text,
                error=str(validation.get("error") or "diff validation failed"),
                meta={"gate": "diff_validation", "validation": validation},
            )
            raise ValueError(f"{validation.get('error')}; apply_run={run.get('id')}")

        changed_files = validation.get("files") or []
        apply_workspace = Path(tempfile.mkdtemp(prefix="zhiyue_source_apply_"))
        try:
            self._copy_sandbox_workspace(apply_workspace)
            patch_result = self._apply_unified_diff(str(proposal.get("diff_text") or ""), apply_workspace)
            if patch_result.get("ok"):
                sync_result = self._sync_applied_source_files(apply_workspace, changed_files)
                if not sync_result.get("ok"):
                    patch_result = sync_result
        finally:
            shutil.rmtree(apply_workspace, ignore_errors=True)
        if not patch_result.get("ok"):
            run = self._record_apply_run(
                proposal_id=proposal_id,
                sandbox_run_id=sandbox_run_id,
                status="failed",
                changed_files=changed_files,
                confirmation_text=confirmation_text,
                result=patch_result,
                error=str(patch_result.get("error") or "source patch failed"),
                meta={"gate": "source_patch"},
            )
            raise ValueError(f"source patch failed; apply_run={run.get('id')}")

        run = self._record_apply_run(
            proposal_id=proposal_id,
            sandbox_run_id=sandbox_run_id,
            status="applied",
            changed_files=changed_files,
            confirmation_text=confirmation_text,
            result={
                "applied": True,
                "changed_files": changed_files,
                "sandbox_run_id": sandbox_run_id,
                "test_boundary": boundary_validation,
                "note": "source changed only after explicit confirmation and passed sandbox",
            },
            meta={"gate": "source_apply", "validation": validation, "boundary_validation": boundary_validation},
        )
        meta = {
            **(proposal.get("meta") or {}),
            "latest_apply_run_id": run.get("id"),
            "latest_apply_status": "applied",
            "latest_apply_at": now_iso(),
            "verification": {
                **((proposal.get("meta") or {}).get("verification") if isinstance((proposal.get("meta") or {}).get("verification"), dict) else {}),
                "last_apply_run_id": run.get("id"),
                "last_apply_status": "applied",
                "result": {
                    "applied": True,
                    "changed_files": changed_files,
                    "sandbox_run_id": sandbox_run_id,
                },
            },
            "workflow": {
                **(((proposal.get("meta") or {}).get("workflow")) if isinstance(((proposal.get("meta") or {}).get("workflow")), dict) else {}),
                "state": "source_applied",
                "source_applied_at": now_iso(),
            },
        }
        self.update_code_proposal(proposal_id, {"status": "applied", "meta": meta})
        return run

    def _mark_proposal_for_external_research(self, proposal_id: str, reason: str, *, sandbox_run: JsonDict | None = None) -> JsonDict | None:
        proposal = self.get_code_proposal(proposal_id)
        if not proposal:
            return None
        meta = proposal.get("meta") if isinstance(proposal.get("meta"), dict) else {}
        verification = meta.get("verification") if isinstance(meta.get("verification"), dict) else {}
        workflow = meta.get("workflow") if isinstance(meta.get("workflow"), dict) else {}
        updates = {
            "status": "needs_external_research",
            "meta": {
                "workflow": {
                    **workflow,
                    "state": "needs_external_research",
                    "external_research_recommended": True,
                    "external_research_reason": clean_snippet(reason, 400),
                },
                "verification": {
                    **verification,
                    "result": {
                        **(verification.get("result") if isinstance(verification.get("result"), dict) else {}),
                        "external_research_recommended": True,
                        "reason": clean_snippet(reason, 400),
                        "sandbox_run_id": sandbox_run.get("id") if isinstance(sandbox_run, dict) else verification.get("last_sandbox_run_id", ""),
                    },
                },
            },
        }
        return self.update_code_proposal(proposal_id, updates)

    def _strip_html_to_text(self, html: str, *, max_chars: int = 2500) -> str:
        text = re.sub(r"(?is)<(script|style).*?>.*?</\1>", " ", html or "")
        text = re.sub(r"(?is)<[^>]+>", " ", text)
        text = unescape(text)
        text = re.sub(r"\s+", " ", text).strip()
        return text[:max_chars]

    def _research_topics_for_proposal(self, proposal: JsonDict) -> list[str]:
        combined = " ".join(
            [
                str(proposal.get("title") or ""),
                str(proposal.get("plain_summary") or ""),
                str(proposal.get("rationale") or ""),
                str((proposal.get("meta") or {}).get("trigger", {}).get("category") or ""),
            ]
        ).lower()
        topics: list[str] = []
        if any(term in combined for term in ["sqlite", "sql", "database", "view", "table"]):
            topics.extend(["sqlite", "python"])
        if any(term in combined for term in ["subprocess", "timeout", "process", "command", "shell"]):
            topics.append("python")
        if any(term in combined for term in ["flask", "route", "api", "request", "response"]):
            topics.append("flask")
        if any(term in combined for term in ["requests", "http", "urlopen", "urllib"]):
            topics.extend(["requests", "python"])
        if any(term in combined for term in ["browser", "playwright", "page", "domcontentloaded"]):
            topics.append("playwright")
        if any(term in combined for term in ["git apply", "diff", "patch", "unified diff"]):
            topics.append("git")
        topics.append("python")
        deduped: list[str] = []
        for topic in topics:
            if topic not in deduped:
                deduped.append(topic)
        return deduped[:3]

    def _official_research_urls(self, proposal: JsonDict) -> list[str]:
        urls: list[str] = []
        for topic in self._research_topics_for_proposal(proposal):
            for url in self.OFFICIAL_RESEARCH_SOURCES.get(topic, []):
                if url not in urls:
                    urls.append(url)
        return urls[:6]

    def _fetch_official_reference(self, url: str, *, timeout_sec: int = 20) -> JsonDict:
        try:
            resp = requests.get(url, timeout=timeout_sec, headers={"User-Agent": "ZhiyueSelfImprovement/1.0"})
            status_code = int(resp.status_code or 0)
            content = self._strip_html_to_text(resp.text, max_chars=2800) if status_code < 400 else ""
            return {
                "ok": status_code < 400 and bool(content),
                "url": url,
                "status_code": status_code,
                "content_preview": content[:1200],
                "fetched_at": now_iso(),
            }
        except Exception as err:
            return {
                "ok": False,
                "url": url,
                "error": clean_snippet(str(err), 300),
                "fetched_at": now_iso(),
            }

    def perform_external_research_for_proposal(self, proposal_id: str, *, max_sources: int = 4) -> JsonDict:
        proposal = self.get_code_proposal(proposal_id)
        if not proposal:
            raise ValueError("proposal not found")
        urls = self._official_research_urls(proposal)[: max(1, min(8, int(max_sources or 4)))]
        findings = [self._fetch_official_reference(url) for url in urls]
        ok_findings = [item for item in findings if item.get("ok")]
        summary_lines = []
        for item in ok_findings[:3]:
            preview = clean_snippet(item.get("content_preview"), 260)
            if preview:
                summary_lines.append(f"{item.get('url')}: {preview}")
        research_result = {
            "sources": findings,
            "successful_sources": len(ok_findings),
            "topics": self._research_topics_for_proposal(proposal),
            "summary": summary_lines,
            "completed_at": now_iso(),
        }
        updated = self.update_code_proposal(
            proposal_id,
            {
                "status": "needs_external_research",
                "meta": {
                    "external_research": research_result,
                    "workflow": {
                        "state": "needs_external_research",
                        "external_research_completed": True,
                        "external_research_completed_at": research_result["completed_at"],
                    },
                    "verification": {
                        "result": {
                            "external_research_completed": True,
                            "successful_sources": len(ok_findings),
                        },
                    },
                },
            },
        )
        return {
            "ok": True,
            "proposal": updated or proposal,
            "research": research_result,
        }

    def run_external_research_cycle(self, *, limit: int = 3) -> JsonDict:
        proposals = self.list_code_proposals(status="needs_external_research", limit=max(1, min(20, int(limit or 3))))
        processed = []
        for proposal in proposals:
            try:
                result = self.perform_external_research_for_proposal(str(proposal.get("id") or ""))
                processed.append({
                    "proposal_id": proposal.get("id") or "",
                    "successful_sources": result.get("research", {}).get("successful_sources", 0),
                    "status": "researched",
                })
            except Exception as err:
                processed.append({
                    "proposal_id": proposal.get("id") or "",
                    "status": "failed",
                    "error": clean_snippet(str(err), 300),
                })
        return {
            "ok": True,
            "processed": processed,
            "count": len(processed),
        }

    def regenerate_diff_after_research(self, proposal_id: str, *, max_retries: int = 2, base_dir: str | None = None) -> JsonDict:
        """
        After external research completes, use research findings to generate an improved
        v2 unified diff and re-run the sandbox.

        If the v2 sandbox passes and auto-apply is allowed, the diff is auto-applied.
        If it fails, retries up to max_retries before flagging for human review.
        """
        import zhiyue_connected

        proposal = self.get_code_proposal(proposal_id)
        if not proposal:
            raise ValueError("proposal not found")

        meta = proposal.get("meta") if isinstance(proposal.get("meta"), dict) else {}
        research = meta.get("external_research") if isinstance(meta.get("external_research"), dict) else {}

        if not research.get("completed_at"):
            raise ValueError("external research not completed; cannot regenerate diff")

        workflow = meta.get("workflow") if isinstance(meta.get("workflow"), dict) else {}
        retry_attempt = int(workflow.get("research_enhanced_retry_attempt") or 0)
        max_retries = max(1, min(5, int(max_retries or 2)))

        if retry_attempt >= max_retries:
            self.update_code_proposal(
                proposal_id,
                {
                    "status": "research_enhanced_failed",
                    "meta": {
                        "workflow": {
                            **workflow,
                            "state": "research_enhanced_failed",
                            "research_enhanced_failed_at": now_iso(),
                            "research_enhanced_fail_reason": f"max retries ({max_retries}) exceeded",
                            "research_enhanced_failed": True,
                        },
                    },
                },
            )
            return {
                "ok": False,
                "proposal_id": proposal_id,
                "status": "research_enhanced_failed",
                "reason": f"max retries ({max_retries}) exceeded",
            }

        _base_dir = base_dir if base_dir else (str(self.config.base_dir) if hasattr(self, "config") and hasattr(self.config, "base_dir") else "D:/chat")
        v2_result = zhiyue_connected.generate_research_enhanced_diff(proposal, research, base_dir=_base_dir)

        v2_diff_text = str(v2_result.get("diff_text") or "").strip()
        v2_test_commands = v2_result.get("test_commands") or []

        if len(v2_diff_text) > 120_000:
            v2_diff_text = v2_diff_text[:120_000]

        if not v2_diff_text:
            self.update_code_proposal(
                proposal_id,
                {
                    "meta": {
                        "workflow": {
                            **workflow,
                            "state": "research_enhanced_failed",
                            "research_enhanced_failed_at": now_iso(),
                            "research_enhanced_fail_reason": "LLM returned empty v2 diff",
                            "research_enhanced_failed": True,
                        },
                    },
                },
            )
            return {
                "ok": False,
                "proposal_id": proposal_id,
                "status": "research_enhanced_failed",
                "reason": "LLM returned empty v2 diff",
            }

        # Validate v2 test commands against sandbox allowlist
        allowed_commands: list[str] = []
        blocked_commands: list[str] = []
        for cmd in v2_test_commands:
            if not isinstance(cmd, str) or not cmd.strip():
                continue
            if self._allowed_sandbox_command(str(cmd).strip()):
                allowed_commands.append(str(cmd).strip())
            else:
                blocked_commands.append(str(cmd).strip())
        if blocked_commands and not allowed_commands:
            self.update_code_proposal(
                proposal_id,
                {
                    "meta": {
                        "workflow": {
                            **workflow,
                            "state": "research_enhanced_failed",
                            "research_enhanced_fail_reason": f"sandbox command not allowed: {blocked_commands[0]}",
                            "research_enhanced_failed": True,
                        },
                    },
                },
            )
            return {
                "ok": False,
                "proposal_id": proposal_id,
                "status": "research_enhanced_failed",
                "reason": f"v2 test command blocked: {blocked_commands[0]}",
            }

        # Store v2 diff metadata for audit trail
        patches_v2 = {
            "generated_at": now_iso(),
            "source": "external_research_enhanced",
            "research_sources_used": [s.get("url") for s in research.get("sources", []) if isinstance(s, dict) and s.get("ok")][:5],
            "diff_text_v2_preview": v2_diff_text[:2000],
            "test_commands_v2": allowed_commands[:5],
            "diff_v2_length": len(v2_diff_text),
        }

        # Update proposal: change status to approved, set v2 diff, store patches_v2
        merged_meta = {
            **meta,
            "patches_v2": patches_v2,
            "workflow": {
                **workflow,
                "state": "approved_for_sandbox_v2",
                "research_enhanced_retry_attempt": retry_attempt + 1,
                "research_enhanced_at": now_iso(),
                "previous_diff_text_size": len(str(proposal.get("diff_text") or "")),
            },
            "verification": {
                **(meta.get("verification") if isinstance(meta.get("verification"), dict) else {}),
                "v2_diff_generated": True,
                "v2_generated_at": now_iso(),
                "v2_diff_length": len(v2_diff_text),
            },
        }

        # Direct DB update to change status, diff_text, test_commands, and meta
        conn = self._connect()
        try:
            conn.execute(
                """UPDATE code_change_proposals
                   SET status=?, diff_text=?, test_commands_json=?, updated_at=?, meta_json=?
                   WHERE id=?""",
                (
                    "approved",
                    v2_diff_text,
                    json_dumps(allowed_commands),
                    now_iso(),
                    json_dumps(merged_meta),
                    proposal_id,
                ),
            )
            conn.commit()
        finally:
            conn.close()

        # Re-run sandbox with v2 diff
        try:
            v2_sandbox_run = self.run_code_proposal_sandbox(proposal_id, keep_workspace=False, timeout_sec=180)
        except Exception as sandbox_err:
            proposal_now = self.get_code_proposal(proposal_id) or proposal
            proposal_meta_now = proposal_now.get("meta") if isinstance(proposal_now.get("meta"), dict) else {}
            self.update_code_proposal(
                proposal_id,
                {
                    "meta": {
                        "workflow": {
                            **(proposal_meta_now.get("workflow") if isinstance(proposal_meta_now.get("workflow"), dict) else {}),
                            "state": "research_enhanced_failed",
                            "research_enhanced_fail_reason": f"v2 sandbox execution error: {clean_snippet(str(sandbox_err), 200)}",
                            "research_enhanced_failed": True,
                        },
                    },
                },
            )
            return {
                "ok": False,
                "proposal_id": proposal_id,
                "status": "research_enhanced_failed",
                "reason": f"v2 sandbox execution error: {str(sandbox_err)[:200]}",
            }

        v2_sandbox_status = v2_sandbox_run.get("status", "")
        v2_result_obj = v2_sandbox_run.get("result") if isinstance(v2_sandbox_run.get("result"), dict) else {}
        v2_judgment = v2_result_obj.get("judgment") if isinstance(v2_result_obj.get("judgment"), dict) else {}

        proposal_now = self.get_code_proposal(proposal_id) or proposal
        proposal_meta_now = proposal_now.get("meta") if isinstance(proposal_now.get("meta"), dict) else {}

        if v2_sandbox_status == "passed" and v2_judgment.get("objective_met"):
            auto_apply_gate = self._proposal_auto_apply_allowed(proposal_now, v2_sandbox_run)

            if auto_apply_gate.get("ok"):
                try:
                    apply_run = self.apply_code_proposal_to_source(
                        proposal_id,
                        confirmation_text=self.AUTO_SOURCE_APPLY_CONFIRMATION,
                    )
                except Exception as apply_err:
                    self.update_code_proposal(
                        proposal_id,
                        {
                            "meta": {
                                "verification": {
                                    **(proposal_meta_now.get("verification") if isinstance(proposal_meta_now.get("verification"), dict) else {}),
                                    "v2_sandbox_passed": True,
                                    "v2_auto_apply_error": clean_snippet(str(apply_err), 300),
                                },
                                "workflow": {
                                    **(proposal_meta_now.get("workflow") if isinstance(proposal_meta_now.get("workflow"), dict) else {}),
                                    "state": "research_enhanced_reviewed",
                                    "research_enhanced_auto_apply_failed": True,
                                },
                            },
                        },
                    )
                    return {
                        "ok": True,
                        "proposal_id": proposal_id,
                        "status": "research_enhanced_reviewed",
                        "v2_sandbox_run_id": v2_sandbox_run.get("id"),
                        "reason": f"v2 sandbox passed but auto-apply failed: {str(apply_err)[:200]}",
                    }

                self.update_code_proposal(
                    proposal_id,
                    {
                        "meta": {
                            "verification": {
                                **(proposal_meta_now.get("verification") if isinstance(proposal_meta_now.get("verification"), dict) else {}),
                                "v2_sandbox_passed": True,
                                "v2_auto_applied": True,
                                "v2_apply_run_id": apply_run.get("id") or "",
                            },
                            "workflow": {
                                **(proposal_meta_now.get("workflow") if isinstance(proposal_meta_now.get("workflow"), dict) else {}),
                                "state": "research_enhanced_auto_applied",
                                "research_enhanced_auto_applied_at": now_iso(),
                            },
                        },
                    },
                )
                return {
                    "ok": True,
                    "proposal_id": proposal_id,
                    "status": "research_enhanced_auto_applied",
                    "v2_sandbox_run_id": v2_sandbox_run.get("id"),
                    "apply_run_id": apply_run.get("id"),
                }
            else:
                self.update_code_proposal(
                    proposal_id,
                    {
                        "meta": {
                            "verification": {
                                **(proposal_meta_now.get("verification") if isinstance(proposal_meta_now.get("verification"), dict) else {}),
                                "v2_sandbox_passed": True,
                                "v2_auto_apply_block_reason": auto_apply_gate.get("reason") or "",
                            },
                            "workflow": {
                                **(proposal_meta_now.get("workflow") if isinstance(proposal_meta_now.get("workflow"), dict) else {}),
                                "state": "research_enhanced_reviewed",
                            },
                        },
                    },
                )
                return {
                    "ok": True,
                    "proposal_id": proposal_id,
                    "status": "research_enhanced_reviewed",
                    "v2_sandbox_run_id": v2_sandbox_run.get("id"),
                    "reason": auto_apply_gate.get("reason") or "v2 sandbox passed but not auto-apply eligible",
                }

        # V2 sandbox failed or objective not met
        if retry_attempt + 1 >= max_retries:
            self.update_code_proposal(
                proposal_id,
                {
                    "status": "research_enhanced_failed",
                    "meta": {
                        "verification": {
                            **(proposal_meta_now.get("verification") if isinstance(proposal_meta_now.get("verification"), dict) else {}),
                            "v2_sandbox_passed": False,
                            "v2_sandbox_status": v2_sandbox_status,
                            "v2_judgment_summary": v2_judgment.get("summary") or "",
                        },
                        "workflow": {
                            **(proposal_meta_now.get("workflow") if isinstance(proposal_meta_now.get("workflow"), dict) else {}),
                            "state": "research_enhanced_failed",
                            "research_enhanced_failed_at": now_iso(),
                            "research_enhanced_fail_reason": f"v2 sandbox {v2_sandbox_status} after {retry_attempt + 1} attempt(s)",
                            "research_enhanced_failed": True,
                        },
                    },
                },
            )
            return {
                "ok": False,
                "proposal_id": proposal_id,
                "status": "research_enhanced_failed",
                "reason": f"v2 sandbox {v2_sandbox_status} after {retry_attempt + 1} attempt(s)",
                "v2_sandbox_run_id": v2_sandbox_run.get("id"),
            }

        # Allow another retry via run_research_enhanced_cycle
        self.update_code_proposal(
            proposal_id,
            {
                "meta": {
                    "verification": {
                        **(proposal_meta_now.get("verification") if isinstance(proposal_meta_now.get("verification"), dict) else {}),
                        "v2_sandbox_failed_attempt": retry_attempt + 1,
                        "v2_sandbox_status": v2_sandbox_status,
                        "v2_last_sandbox_run_id": v2_sandbox_run.get("id") or "",
                    },
                    "workflow": {
                        **(proposal_meta_now.get("workflow") if isinstance(proposal_meta_now.get("workflow"), dict) else {}),
                        "state": "needs_external_research",
                        "research_enhanced_retry_attempt": retry_attempt + 1,
                        "v2_retry_needed": True,
                    },
                },
            },
        )
        return {
            "ok": False,
            "proposal_id": proposal_id,
            "status": "needs_external_research",
            "reason": f"v2 sandbox {v2_sandbox_status}; {max_retries - retry_attempt - 1} retries remaining",
            "v2_sandbox_run_id": v2_sandbox_run.get("id"),
        }

    def run_research_enhanced_cycle(self, *, limit: int = 3, base_dir: str | None = None, auto_attempt_v2: bool = True) -> JsonDict:
        """
        Find all proposals with completed external research and trigger v2 diff
        regeneration + sandbox re-run for each.

        Pass auto_attempt_v2=False to only list eligible proposals without running them.
        """
        # Find proposals that have completed external research but no v2 attempt yet
        proposals = self.list_code_proposals(status="all", limit=max(10, int(limit or 3) * 5))
        eligible: list[JsonDict] = []
        for proposal in proposals:
            meta = proposal.get("meta") if isinstance(proposal.get("meta"), dict) else {}
            research = meta.get("external_research") if isinstance(meta.get("external_research"), dict) else {}
            workflow = meta.get("workflow") if isinstance(meta.get("workflow"), dict) else {}
            patches_v2 = meta.get("patches_v2") if isinstance(meta.get("patches_v2"), dict) else {}
            has_research = bool(research.get("completed_at") and int(research.get("successful_sources") or 0) > 0)
            v2_already_attempted = bool(patches_v2.get("generated_at") or workflow.get("research_enhanced_at"))
            retry_count = int(workflow.get("research_enhanced_retry_attempt") or 0)
            is_exhausted = bool(workflow.get("research_enhanced_failed") or workflow.get("state") in {"research_enhanced_failed", "research_enhanced_auto_applied", "research_enhanced_reviewed"})
            if has_research and not is_exhausted:
                if not v2_already_attempted or retry_count > 0:
                    if retry_count < 2:
                        eligible.append(proposal)
        eligible = eligible[: max(1, min(20, int(limit or 3)))]

        if not auto_attempt_v2:
            return {
                "ok": True,
                "eligible": [{"id": p.get("id"), "title": p.get("title")} for p in eligible],
                "count": len(eligible),
            }

        processed: list[JsonDict] = []
        for proposal in eligible:
            pid = str(proposal.get("id") or "")
            try:
                result = self.regenerate_diff_after_research(pid, max_retries=2, base_dir=base_dir)
                processed.append({
                    "proposal_id": pid,
                    "title": proposal.get("title") or "",
                    "status": result.get("status") or "",
                    "ok": bool(result.get("ok")),
                    "reason": result.get("reason") or "",
                })
            except Exception as err:
                processed.append({
                    "proposal_id": pid,
                    "title": proposal.get("title") or "",
                    "status": "failed",
                    "ok": False,
                    "error": clean_snippet(str(err), 300),
                })

        return {
            "ok": True,
            "processed": processed,
            "count": len(processed),
            "eligible_total": len(eligible),
        }

    def _promote_candidate_to_code_proposal(self, candidate: JsonDict) -> JsonDict:
        proposal = self.create_code_proposal(
            source_type="candidate",
            source_id=str(candidate.get("id") or ""),
            status="draft",
            meta={"created_by": "self_improvement.auto_pipeline"},
        )
        candidate_meta = candidate.get("meta") if isinstance(candidate.get("meta"), dict) else {}
        self.update_candidate(
            str(candidate.get("id") or ""),
            {
                "status": "proposal_created",
                "meta": {
                    **candidate_meta,
                    "proposal_id": proposal.get("id") or "",
                    "proposal_created_at": now_iso(),
                },
            },
        )
        return proposal

    def run_autonomous_code_review_cycle(
        self,
        *,
        limit: int = 5,
        auto_apply: bool = True,
        research_enhanced: bool = True,
    ) -> JsonDict:
        candidates = self.list_candidates(status="all", limit=max(10, limit * 4))
        queue = [
            item for item in candidates
            if self._candidate_is_codeworthy(item)
            and (item.get("status") in {"pending", "accepted", "proposal_created", "failed", "needs_external_research"})
        ][: max(1, min(20, int(limit or 5)))]
        processed: list[JsonDict] = []
        skipped: list[JsonDict] = []
        for candidate in queue:
            candidate_id = str(candidate.get("id") or "")
            candidate_meta = candidate.get("meta") if isinstance(candidate.get("meta"), dict) else {}
            proposal_id = str(candidate_meta.get("proposal_id") or "")
            try:
                proposal = self.get_code_proposal(proposal_id) if proposal_id else None
                if not proposal:
                    proposal = self._promote_candidate_to_code_proposal(candidate)
                proposal_id = str(proposal.get("id") or "")
                if proposal.get("status") == "draft":
                    proposal = self.authorize_code_proposal(proposal_id, self.AUTO_PIPELINE_CONFIRMATION)
                sandbox_run = self.run_code_proposal_sandbox(proposal_id, keep_workspace=False, timeout_sec=180)
                sandbox_result = sandbox_run.get("result") if isinstance(sandbox_run.get("result"), dict) else {}
                sandbox_judgment = sandbox_result.get("judgment") if isinstance(sandbox_result.get("judgment"), dict) else {}
                proposal = self.get_code_proposal(proposal_id) or proposal
                auto_apply_gate = self._proposal_auto_apply_allowed(proposal, sandbox_run)
                verification_patch = {
                    "verification": {
                        "required_tests": proposal.get("test_commands") or [],
                        "last_sandbox_run_id": sandbox_run.get("id") or "",
                        "last_sandbox_status": sandbox_run.get("status") or "",
                        "last_apply_run_id": "",
                        "last_apply_status": "",
                        "result": {
                            "sandbox_objective_met": bool(sandbox_judgment.get("objective_met")),
                            "auto_apply_eligible": bool(auto_apply_gate.get("ok")),
                            "auto_apply_reason": auto_apply_gate.get("reason") or "",
                        },
                    },
                    "safety": {
                        "auto_apply_candidate": bool(auto_apply_gate.get("ok")),
                    },
                    "workflow": {
                        "auto_reviewed_at": now_iso(),
                        "auto_review_state": sandbox_judgment.get("state") or "",
                    },
                }
                proposal = self.update_code_proposal(proposal_id, {"meta": verification_patch}) or proposal
                if auto_apply and auto_apply_gate.get("ok"):
                    apply_run = self.apply_code_proposal_to_source(
                        proposal_id,
                        confirmation_text=self.AUTO_SOURCE_APPLY_CONFIRMATION,
                    )
                    self.update_candidate(
                        candidate_id,
                        {
                            "status": "auto_applied",
                            "meta": {
                                "proposal_id": proposal_id,
                                "auto_applied_at": now_iso(),
                                "apply_run_id": apply_run.get("id") or "",
                            },
                        },
                    )
                    self.update_code_proposal(
                        proposal_id,
                        {
                            "meta": {
                                "verification": {
                                    "last_apply_run_id": apply_run.get("id") or "",
                                    "last_apply_status": apply_run.get("status") or "",
                                    "result": {
                                        "applied": True,
                                        "changed_files": apply_run.get("changed_files") or [],
                                    },
                                },
                                "workflow": {
                                    "state": "auto_applied",
                                    "auto_applied_at": now_iso(),
                                },
                            },
                        },
                    )
                    processed.append({
                        "candidate_id": candidate_id,
                        "proposal_id": proposal_id,
                        "sandbox_run_id": sandbox_run.get("id") or "",
                        "apply_run_id": apply_run.get("id") or "",
                        "status": "auto_applied",
                    })
                    continue
                if sandbox_judgment.get("state") == "sandbox_attempts_exhausted_awaiting_user_decision":
                    self._mark_proposal_for_external_research(
                        proposal_id,
                        "bounded sandbox attempts were exhausted without a reliable fix",
                        sandbox_run=sandbox_run,
                    )
                    research_result = self.perform_external_research_for_proposal(proposal_id)
                    v2_result: JsonDict | None = None
                    if research_enhanced:
                        try:
                            v2_result = self.regenerate_diff_after_research(proposal_id, max_retries=2)
                        except Exception as v2_ex:
                            print(f"[V2] regenerate failed for {proposal_id}: {v2_ex}")
                    self.update_candidate(
                        candidate_id,
                        {
                            "status": "needs_external_research" if not v2_result else (
                                "research_enhanced_auto_applied" if v2_result.get("status") == "research_enhanced_auto_applied" else (
                                    "research_enhanced_reviewed" if v2_result.get("ok") else
                                    "needs_external_research"
                                )
                            ),
                            "meta": {
                                "proposal_id": proposal_id,
                                "research_reason": "sandbox_attempts_exhausted",
                                "external_research_completed_at": now_iso(),
                                "v2_regenerated": bool(v2_result),
                                "v2_status": (v2_result or {}).get("status") or "",
                            },
                        },
                    )
                    processed.append({
                        "candidate_id": candidate_id,
                        "proposal_id": proposal_id,
                        "sandbox_run_id": sandbox_run.get("id") or "",
                        "status": "research_enhanced_auto_applied" if v2_result and v2_result.get("status") == "research_enhanced_auto_applied" else (
                            "research_enhanced_reviewed" if v2_result and v2_result.get("ok") else
                            "needs_external_research"
                        ),
                        "researched_sources": research_result.get("research", {}).get("successful_sources", 0),
                        "v2_regenerated": bool(v2_result),
                        "v2_status": (v2_result or {}).get("status") or "",
                    })
                    continue
                self.update_candidate(
                    candidate_id,
                    {
                        "status": "auto_reviewed",
                        "meta": {
                            "proposal_id": proposal_id,
                            "sandbox_run_id": sandbox_run.get("id") or "",
                            "auto_apply_block_reason": auto_apply_gate.get("reason") or "",
                        },
                    },
                )
                skipped.append({
                    "candidate_id": candidate_id,
                    "proposal_id": proposal_id,
                    "sandbox_run_id": sandbox_run.get("id") or "",
                    "status": "auto_reviewed",
                    "reason": auto_apply_gate.get("reason") or sandbox_judgment.get("summary") or "",
                })
            except Exception as err:
                self.update_candidate(
                    candidate_id,
                    {
                        "status": "failed",
                        "meta": {
                            "proposal_id": proposal_id,
                            "last_error": clean_snippet(str(err), 500),
                            "failed_at": now_iso(),
                        },
                    },
                )
                skipped.append({
                    "candidate_id": candidate_id,
                    "proposal_id": proposal_id,
                    "status": "failed",
                    "reason": clean_snippet(str(err), 500),
                })
        return {
            "ok": True,
            "processed": processed,
            "skipped": skipped,
            "queue_size": len(queue),
            "auto_apply_enabled": bool(auto_apply),
            "auto_apply_allowlist": sorted(self._allowed_auto_apply_files()),
        }

    def generate_candidates(self, limit: int = 100) -> JsonDict:
        traces = self.observability.list_traces(limit=limit)
        runs = self.observability.list_agent_runs(limit=limit)
        actions = self.tasks.list_actions(limit=limit)
        created: list[JsonDict] = []
        reused: list[JsonDict] = []

        def add_candidate(**kwargs: Any) -> None:
            before = self.get_by_fingerprint(
                self._fingerprint(kwargs.get("category", "general"), kwargs.get("title", ""), kwargs.get("evidence") or [])
            )
            candidate = self.record_candidate(**kwargs)
            if before:
                reused.append(candidate)
            else:
                created.append(candidate)

        low_score = [trace for trace in traces if float(trace.get("score") or 0) < 7]
        flag_counts: dict[str, int] = {}
        for trace in low_score:
            for flag in trace.get("flags") or []:
                flag_counts[str(flag)] = flag_counts.get(str(flag), 0) + 1
        for flag, count in sorted(flag_counts.items(), key=lambda item: item[1], reverse=True)[:5]:
            examples = [
                {
                    "id": trace.get("id"),
                    "score": trace.get("score"),
                    "flags": trace.get("flags"),
                    "user_msg": clean_snippet(trace.get("user_msg"), 120),
                    "reply": clean_snippet(trace.get("reply"), 160),
                }
                for trace in low_score
                if flag in (trace.get("flags") or [])
            ][:5]
            add_candidate(
                source="observability.traces",
                category=f"reply_quality.{flag}",
                title=f"Reduce reply quality regressions: {flag}",
                recommendation="Tune runtime reply policy or regression cases for this recurring flag before changing code.",
                evidence=examples,
                impact=f"{count} recent low-score trace(s) include this flag.",
                risk="low",
                meta={"flag": flag, "count": count},
            )

        memory_probe_misses = [
            trace for trace in low_score
            if "memory_probe_no_recall" in (trace.get("flags") or [])
        ]
        if memory_probe_misses:
            add_candidate(
                source="observability.traces",
                category="memory.retrieval",
                title="Improve memory recall for explicit memory probes",
                recommendation="Review recall limits, event merging, and memory-hit regression cases for explicit memory questions.",
                evidence=[
                    {
                        "id": trace.get("id"),
                        "user_msg": clean_snippet(trace.get("user_msg"), 160),
                        "memory_hit_count": trace.get("memory_hit_count"),
                    }
                    for trace in memory_probe_misses[:5]
                ],
                impact=f"{len(memory_probe_misses)} recent probe trace(s) had no recall.",
                risk="low",
                meta={"count": len(memory_probe_misses)},
            )

        degraded_runs = [run for run in runs if run.get("degraded")]
        node_counts: dict[str, int] = {}
        for run in degraded_runs:
            for node in run.get("degraded_nodes") or []:
                node_counts[str(node)] = node_counts.get(str(node), 0) + 1
        for node, count in sorted(node_counts.items(), key=lambda item: item[1], reverse=True)[:5]:
            add_candidate(
                source="observability.agent_runs",
                category=f"agent.degraded.{node}",
                title=f"Investigate degraded agent node: {node}",
                recommendation="Inspect recent agent run state for this node and add a focused regression before changing orchestration behavior.",
                evidence=[
                    {
                        "run_id": run.get("id"),
                        "route": run.get("route"),
                        "degraded_nodes": run.get("degraded_nodes"),
                        "latency_ms": run.get("latency_ms"),
                    }
                    for run in degraded_runs
                    if node in (run.get("degraded_nodes") or [])
                ][:5],
                impact=f"{count} recent agent run(s) degraded at this node.",
                risk="medium",
                meta={"node": node, "count": count},
            )

        failed_actions = [
            action for action in actions
            if action.get("status") in {"failed", "rejected"} or action.get("error")
        ]
        action_type_counts: dict[str, int] = {}
        for action in failed_actions:
            action_type = action.get("action_type") or "unknown"
            action_type_counts[action_type] = action_type_counts.get(action_type, 0) + 1
        for action_type, count in sorted(action_type_counts.items(), key=lambda item: item[1], reverse=True)[:5]:
            add_candidate(
                source="agent_actions",
                category=f"actions.{action_type}",
                title=f"Review repeated action failures: {action_type}",
                recommendation="Review action planning and confirmation UX for this action type; keep external tool permissions unchanged.",
                evidence=[
                    {
                        "action_id": action.get("id"),
                        "task_id": action.get("task_id"),
                        "status": action.get("status"),
                        "error": action.get("error"),
                        "result": action.get("result"),
                    }
                    for action in failed_actions
                    if (action.get("action_type") or "unknown") == action_type
                ][:5],
                impact=f"{count} recent action(s) failed or were rejected.",
                risk="low",
                meta={"action_type": action_type, "count": count},
            )

        pending_confirm = [
            action for action in actions
            if action.get("status") == "planned" and action.get("requires_confirm")
        ]
        if pending_confirm:
            add_candidate(
                source="agent_actions",
                category="actions.pending_confirmation",
                title="Expose pending confirmations more clearly",
                recommendation="Surface pending low-risk internal task confirmations in the UI/API so the user can approve or reject them deliberately.",
                evidence=[
                    {
                        "action_id": action.get("id"),
                        "action_type": action.get("action_type"),
                        "task_id": action.get("task_id"),
                        "payload": action.get("payload"),
                    }
                    for action in pending_confirm[:5]
                ],
                impact=f"{len(pending_confirm)} action(s) are waiting for confirmation.",
                risk="low",
                meta={"count": len(pending_confirm)},
            )

        planned_open = [
            action for action in actions
            if action.get("status") == "planned"
        ]
        if planned_open:
            add_candidate(
                source="agent_actions",
                category="actions.open_planned",
                title="Review open planned actions",
                recommendation="Add an explicit apply, reject, or archive path for planned actions that should not stay open indefinitely.",
                evidence=[
                    {
                        "action_id": action.get("id"),
                        "action_type": action.get("action_type"),
                        "task_id": action.get("task_id"),
                        "requires_confirm": action.get("requires_confirm"),
                        "payload": action.get("payload"),
                    }
                    for action in planned_open[:5]
                ],
                impact=f"{len(planned_open)} planned action(s) are still open.",
                risk="low",
                meta={"count": len(planned_open)},
            )

        human_summary = self.observability.human_likeness_summary(limit=limit)
        human_issue_counts = human_summary.get("issues") if isinstance(human_summary.get("issues"), dict) else {}
        for issue, count in sorted(human_issue_counts.items(), key=lambda item: item[1], reverse=True)[:5]:
            evidence = []
            for trace in traces:
                meta = trace.get("meta") if isinstance(trace.get("meta"), dict) else {}
                human = meta.get("human_likeness") if isinstance(meta.get("human_likeness"), dict) else {}
                if issue not in (human.get("issues") or []):
                    continue
                evidence.append({
                    "id": trace.get("id"),
                    "score": human.get("score"),
                    "issues": human.get("issues") or [],
                    "user_msg": clean_snippet(trace.get("user_msg"), 120),
                    "reply": clean_snippet(trace.get("reply"), 160),
                })
                if len(evidence) >= 5:
                    break
            add_candidate(
                source="observability.human_likeness",
                category=f"human_like.{issue}",
                title=f"Reduce human-likeness regressions: {issue}",
                recommendation="Tune long-term persona state, message splitting, and rewrite hints to reduce this recurring machine-feel pattern.",
                evidence=evidence,
                impact=f"{count} recent trace(s) showed this human-likeness issue.",
                risk="low",
                meta={"issue": issue, "count": count, "avg_score": human_summary.get("avg_score", 0)},
            )

        if float(human_summary.get("rewrite_rate") or 0) >= 0.25:
            add_candidate(
                source="observability.human_likeness",
                category="human_like.rewrite_dependency",
                title="Reduce dependency on post-generation human-like rewrites",
                recommendation="Shift more style control into persistent persona state and lighter prompt guidance so the first draft is already more natural.",
                evidence=[human_summary],
                impact=f"Rewrite rate is {human_summary.get('rewrite_rate')} across recent traces.",
                risk="medium",
                meta={"rewrite_rate": human_summary.get("rewrite_rate", 0), "avg_score": human_summary.get("avg_score", 0)},
            )
        if float(human_summary.get("avg_score") or 0) and float(human_summary.get("avg_score") or 0) < 7.8:
            add_candidate(
                source="observability.human_likeness",
                category="human_like.persona_state_binding",
                title="Strengthen state-to-persona binding for natural replies",
                recommendation="Convert dominant runtime state into compact scene-like prompt flavor and state-matched few-shot selection, so naturalness comes earlier than post-rewrite.",
                evidence=[human_summary],
                impact=f"Average human-likeness score is {human_summary.get('avg_score')} across recent traces.",
                risk="medium",
                meta={"avg_score": human_summary.get("avg_score", 0), "rewrite_rate": human_summary.get("rewrite_rate", 0)},
            )

        return {
            "ok": True,
            "created": created,
            "reused": reused,
            "created_count": len(created),
            "reused_count": len(reused),
            "analyzed": {
                "traces": len(traces),
                "agent_runs": len(runs),
                "actions": len(actions),
            },
        }

    def summary(self, limit: int = 200) -> JsonDict:
        candidates = self.list_candidates(status="all", limit=limit)
        policies = self.list_policies(status="all", limit=limit)
        proposals = self.list_code_proposals(status="all", limit=limit)
        by_status: dict[str, int] = {}
        by_category: dict[str, int] = {}
        for item in candidates:
            status = item.get("status") or "pending"
            category = item.get("category") or "general"
            by_status[status] = by_status.get(status, 0) + 1
            by_category[category] = by_category.get(category, 0) + 1
        policy_by_status: dict[str, int] = {}
        for policy in policies:
            status = policy.get("status") or "draft"
            policy_by_status[status] = policy_by_status.get(status, 0) + 1
        proposal_by_status: dict[str, int] = {}
        for proposal in proposals:
            status = proposal.get("status") or "draft"
            proposal_by_status[status] = proposal_by_status.get(status, 0) + 1
        apply_summary = self.code_proposal_summary(limit=limit)
        chat_strategy_candidates = [
            item for item in candidates
            if not self._candidate_is_codeworthy(item)
        ]
        code_candidates = [
            item for item in candidates
            if self._candidate_is_codeworthy(item)
        ]
        merged_skill_updates = [
            item for item in chat_strategy_candidates
            if item.get("status") in {"accepted", "archived"}
        ]
        code_applied = [
            item for item in proposals
            if item.get("status") == "applied"
        ]
        code_research = [
            item for item in proposals
            if item.get("status") == "needs_external_research"
        ]
        return {
            "total": len(candidates),
            "pending": by_status.get("pending", 0),
            "by_status": by_status,
            "by_category": by_category,
            "policies_total": len(policies),
            "policies_enabled": policy_by_status.get("enabled", 0),
            "policies_by_status": policy_by_status,
            "code_proposals_total": len(proposals),
            "code_proposals_by_status": proposal_by_status,
            "code_apply_runs_total": apply_summary.get("apply_runs_total", 0),
            "code_apply_runs_by_status": apply_summary.get("apply_runs_by_status", {}),
            "lanes": {
                "chat_strategy_learning": {
                    "total": len(chat_strategy_candidates),
                    "pending": len([item for item in chat_strategy_candidates if item.get("status") == "pending"]),
                    "merged_or_closed": len(merged_skill_updates),
                },
                "code_defect_candidates": {
                    "total": len(code_candidates),
                    "pending": len([item for item in code_candidates if item.get("status") == "pending"]),
                    "proposal_created": len([item for item in code_candidates if item.get("status") == "proposal_created"]),
                    "auto_reviewed": len([item for item in code_candidates if item.get("status") == "auto_reviewed"]),
                    "auto_applied": len([item for item in code_candidates if item.get("status") == "auto_applied"]),
                    "needs_external_research": len([item for item in code_candidates if item.get("status") == "needs_external_research"]),
                },
                "code_proposals": {
                    "total": len(proposals),
                    "applied": len(code_applied),
                    "needs_external_research": len(code_research),
                },
            },
            "latest": candidates[0] if candidates else {},
        }

    def review_briefing(self, limit: int = 3) -> JsonDict:
        limit = max(1, min(10, int(limit or 3)))
        candidates = self.list_candidates(status="pending", limit=limit)
        proposals = self.list_code_proposals(status="all", limit=50)
        active_proposals = []
        for item in proposals:
            workflow = item.get("meta", {}).get("workflow") if isinstance(item.get("meta"), dict) else {}
            state = str(workflow.get("state") or "").strip()
            if item.get("status") in {"draft", "ready_for_sandbox", "approved"} or state in {
                "awaiting_user_sandbox_approval",
                "approved_for_sandbox",
                "sandbox_goal_met_awaiting_source_confirmation",
                "sandbox_attempts_exhausted_awaiting_user_decision",
                "sandbox_needs_another_iteration",
            }:
                active_proposals.append(item)
        latest_candidate = candidates[0] if candidates else {}
        latest_proposal = active_proposals[0] if active_proposals else (proposals[0] if proposals else {})
        latest_workflow = latest_proposal.get("meta", {}).get("workflow") if isinstance(latest_proposal.get("meta"), dict) else {}
        latest_state = str(latest_workflow.get("state") or "").strip()
        if latest_candidate:
            latest_item = {
                "kind": "candidate",
                "id": latest_candidate.get("id") or "",
                "title": latest_candidate.get("title") or "",
                "summary": latest_candidate.get("recommendation") or "",
                "why": latest_candidate.get("impact") or latest_candidate.get("guardrail") or "",
                "status": latest_candidate.get("status") or "pending",
                "next_step": "先整理成策略或代码提案，再决定是否进入沙箱。",
            }
        elif latest_proposal:
            next_step = "先跑沙箱，不直接改源码。"
            if latest_state == "approved_for_sandbox":
                next_step = "已经可以跑沙箱了，但还不能改源码。"
            elif latest_state == "sandbox_goal_met_awaiting_source_confirmation":
                next_step = "沙箱已经过了，只差你再确认一次才能改源码。"
            elif latest_state == "sandbox_attempts_exhausted_awaiting_user_decision":
                next_step = "沙箱尝试已经用完，需要你决定是停下还是换方向。"
            elif latest_state == "sandbox_needs_another_iteration":
                latest_judgment = latest_workflow.get("latest_judgment") if isinstance(latest_workflow, dict) else {}
                if isinstance(latest_judgment, dict) and latest_judgment.get("has_concrete_diff") is False:
                    next_step = "先补真实 unified diff，再重新跑沙箱；当前不能应用源码。"
                else:
                    next_step = "沙箱还没达标，先缩小方案再重新跑。"
            latest_item = {
                "kind": "proposal",
                "id": latest_proposal.get("id") or "",
                "title": latest_proposal.get("title") or "",
                "summary": latest_proposal.get("plain_summary") or latest_proposal.get("rationale") or "",
                "why": latest_proposal.get("rationale") or latest_proposal.get("risk") or "",
                "status": latest_proposal.get("status") or "draft",
                "workflow_state": latest_state,
                "human_question": latest_workflow.get("human_question") or "",
                "next_step": next_step,
            }
        else:
            latest_item = {
                "kind": "none",
                "id": "",
                "title": "",
                "summary": "",
                "why": "",
                "status": "none",
                "next_step": "现在没有必须立刻处理的自我改进项。",
            }

        queue = []
        for item in candidates[:limit]:
            queue.append({
                "kind": "candidate",
                "id": item.get("id") or "",
                "title": item.get("title") or "",
                "summary": item.get("recommendation") or "",
                "status": item.get("status") or "pending",
                "next_step": "先整理成 runtime policy 或代码提案。",
            })
        for item in active_proposals[: max(0, limit - len(queue))]:
            workflow = item.get("meta", {}).get("workflow") if isinstance(item.get("meta"), dict) else {}
            queue.append({
                "kind": "proposal",
                "id": item.get("id") or "",
                "title": item.get("title") or "",
                "summary": item.get("plain_summary") or item.get("rationale") or "",
                "status": item.get("status") or "draft",
                "workflow_state": str(workflow.get("state") or ""),
                "next_step": "先跑沙箱，过了以后再让用户确认源码应用。",
            })

        counts = self.summary(limit=limit)
        human_lines = []
        if counts.get("pending", 0):
            human_lines.append(f"现在有 {counts.get('pending', 0)} 个待处理改进项。")
        if latest_item.get("kind") == "proposal":
            human_lines.append(f"最近最像要改的是：{latest_item.get('title') or '一个代码提案'}。")
        elif latest_item.get("kind") == "candidate":
            human_lines.append(f"最近最像要优化的是：{latest_item.get('title') or '一个改进候选'}。")
        else:
            human_lines.append("现在没有必须立刻改的东西。")
        human_lines.append("我会先做沙箱和边界检查，不直接改源码。")
        return {
            "summary": counts,
            "latest": latest_item,
            "queue": queue,
            "human_summary": " ".join(human_lines),
            "approval_rules": {
                "sandbox_only_first": True,
                "source_apply_requires_second_confirmation": True,
                "no_desktop_tools": True,
            },
        }

    def status(self) -> JsonDict:
        return {
            "db": str(self.db_path),
            "mode": "bounded_auto_review",
            "writes_source": True,
            "executes_tools": True,
            "runtime_policy_mode": "prompt_hints_only",
            "code_proposal_mode": "guarded_source_apply",
            "auto_pipeline": {
                "enabled": True,
                "sandbox_first": True,
                "auto_apply_allowlist": sorted(self._allowed_auto_apply_files()),
                "auto_apply_max_files": 2,
                "external_research_on_exhausted_attempts": True,
            },
            "source_apply_guardrails": {
                "requires_explicit_confirmation": True,
                "requires_passed_sandbox": True,
                "requires_concrete_diff": True,
                "requires_test_boundary": True,
                "allowed_files": self.SANDBOX_FILES,
                "required_tests": ["py_compile", "api-smoke test-client", "memory-hit test-client"],
                "forbidden_changes": [
                    "desktop/free tool execution",
                    "real database writes during tests",
                    "qdrant fallback removal",
                    "deterministic reply weakening",
                    "confirmation bypass",
                ],
                "executes_desktop_or_free_tools": False,
            },
            "briefing": self.review_briefing(limit=3),
            "summary": self.summary(limit=100),
        }


class ToolSkillLayer:
    """Small MCP-shaped skill registry."""

    PERMISSION_ORDER = {
        "read": 1,
        "write": 2,
        "voice": 3,
        "desktop": 4,
    }

    def __init__(self, config: LayerConfig):
        self.config = config
        self._tools: dict[str, JsonDict] = {}
        self._handlers: dict[str, Callable[[JsonDict], Any]] = {}
        self._skill_docs: dict[str, JsonDict] = {}
        self.db_path = config.observability_db
        self._init_audit_db()
        self._register_builtin_specs()
        self._bind_builtin_handlers()
        self._register_disk_skills()

    def _connect(self) -> sqlite3.Connection:
        return _connect_observability_db(self.db_path, self.config.base_dir)

    def _init_audit_db(self) -> None:
        conn = self._connect()
        try:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS skill_audit_log (
                    id TEXT PRIMARY KEY,
                    created_at TEXT NOT NULL,
                    tool_name TEXT NOT NULL,
                    permission TEXT DEFAULT 'read',
                    risk TEXT DEFAULT 'low',
                    allowed INTEGER DEFAULT 0,
                    reason TEXT DEFAULT '',
                    args_json TEXT DEFAULT '{}',
                    result_json TEXT DEFAULT '{}',
                    latency_ms INTEGER DEFAULT 0
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS skill_usage_log (
                    id TEXT PRIMARY KEY,
                    created_at TEXT NOT NULL,
                    skill_name TEXT NOT NULL,
                    route TEXT DEFAULT '',
                    ok INTEGER DEFAULT 0,
                    latency_ms INTEGER DEFAULT 0,
                    args_json TEXT DEFAULT '{}',
                    result_json TEXT DEFAULT '{}',
                    meta_json TEXT DEFAULT '{}'
                )
            """)
            usage_cols = {row[1] for row in conn.execute("PRAGMA table_info(skill_usage_log)").fetchall()}
            for col, ddl in {
                "request_id": "ALTER TABLE skill_usage_log ADD COLUMN request_id TEXT DEFAULT ''",
                "attempts": "ALTER TABLE skill_usage_log ADD COLUMN attempts INTEGER DEFAULT 1",
                "validation_json": "ALTER TABLE skill_usage_log ADD COLUMN validation_json TEXT DEFAULT '{}'",
                "recovery_json": "ALTER TABLE skill_usage_log ADD COLUMN recovery_json TEXT DEFAULT '{}'",
            }.items():
                if col not in usage_cols:
                    conn.execute(ddl)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS skill_registry (
                    skill_name TEXT PRIMARY KEY,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    state TEXT DEFAULT 'active',
                    pinned INTEGER DEFAULT 0,
                    generated INTEGER DEFAULT 0,
                    source_path TEXT DEFAULT '',
                    meta_json TEXT DEFAULT '{}'
                )
            """)
            conn.commit()
        finally:
            conn.close()

    def _register_builtin_specs(self) -> None:
        specs = [
            {
                "name": "memory.search",
                "description": "Search core and archival memory with hybrid local retrieval.",
                "input_schema": {"type": "object", "properties": {"query": {"type": "string"}, "limit": {"type": "integer"}}},
                "permission": "read",
                "risk": "low",
                "audit": True,
                "allowlist_required": False,
                "toolset": "memory",
            },
            {
                "name": "memory.add",
                "description": "Write a fact, preference, boundary or shared experience memory.",
                "input_schema": {"type": "object", "properties": {"content": {"type": "string"}, "mem_type": {"type": "string"}, "category": {"type": "string"}}},
                "permission": "write",
                "risk": "medium",
                "audit": True,
                "allowlist_required": True,
                "toolset": "memory",
            },
            {
                "name": "agent.plan",
                "description": "Return the current stateful agent workflow plan.",
                "input_schema": {"type": "object", "properties": {"user_msg": {"type": "string"}}},
                "permission": "read",
                "risk": "low",
                "audit": True,
                "allowlist_required": False,
                "toolset": "agent",
            },
            {
                "name": "relationship.proactive",
                "description": "Build a proactive relationship-thread reply.",
                "input_schema": {"type": "object", "properties": {"force": {"type": "boolean"}}},
                "permission": "read",
                "risk": "low",
                "audit": True,
                "allowlist_required": False,
                "toolset": "relationship",
            },
            {
                "name": "local_files.list",
                "description": "List local files and folders under approved read-only roots.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "path": {"type": "string"},
                        "recursive": {"type": "boolean"},
                        "glob": {"type": "string"},
                        "limit": {"type": "integer"},
                    },
                },
                "permission": "read",
                "risk": "medium",
                "audit": True,
                "allowlist_required": False,
                "toolset": "filesystem",
            },
            {
                "name": "local_files.read",
                "description": "Read a local text file under approved read-only roots.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "path": {"type": "string"},
                        "start_line": {"type": "integer"},
                        "max_lines": {"type": "integer"},
                    },
                },
                "permission": "read",
                "risk": "medium",
                "audit": True,
                "allowlist_required": False,
                "toolset": "filesystem",
            },
            {
                "name": "local_files.search",
                "description": "Search text inside a local file or a folder under approved read-only roots.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "path": {"type": "string"},
                        "pattern": {"type": "string"},
                        "glob": {"type": "string"},
                        "limit": {"type": "integer"},
                    },
                    "required": ["path", "pattern"],
                },
                "permission": "read",
                "risk": "medium",
                "audit": True,
                "allowlist_required": False,
                "toolset": "filesystem",
            },
            {
                "name": "local_files.mkdir",
                "description": "Create a folder inside approved roots or the approved output directory.",
                "input_schema": {
                    "type": "object",
                    "properties": {"path": {"type": "string"}},
                    "required": ["path"],
                },
                "permission": "write",
                "risk": "medium",
                "audit": True,
                "allowlist_required": True,
                "toolset": "filesystem",
            },
            {
                "name": "local_files.copy",
                "description": "Copy a file into another approved location.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "src": {"type": "string"},
                        "dst": {"type": "string"},
                        "overwrite": {"type": "boolean"},
                    },
                    "required": ["src", "dst"],
                },
                "permission": "write",
                "risk": "medium",
                "audit": True,
                "allowlist_required": True,
                "toolset": "filesystem",
            },
            {
                "name": "local_files.move",
                "description": "Move a file into another approved location.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "src": {"type": "string"},
                        "dst": {"type": "string"},
                        "overwrite": {"type": "boolean"},
                    },
                    "required": ["src", "dst"],
                },
                "permission": "write",
                "risk": "medium",
                "audit": True,
                "allowlist_required": True,
                "toolset": "filesystem",
            },
            {
                "name": "local_files.delete",
                "description": "Delete a file or folder inside approved writable roots.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "path": {"type": "string"},
                        "recursive": {"type": "boolean"},
                    },
                    "required": ["path"],
                },
                "permission": "write",
                "risk": "high",
                "audit": True,
                "allowlist_required": True,
                "toolset": "filesystem",
            },
            {
                "name": "local_files.write_text",
                "description": "Write a txt/md/json/csv file into an approved output location.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "path": {"type": "string"},
                        "content": {"type": "string"},
                        "overwrite": {"type": "boolean"},
                    },
                    "required": ["path", "content"],
                },
                "permission": "write",
                "risk": "medium",
                "audit": True,
                "allowlist_required": True,
                "toolset": "filesystem",
            },
            {
                "name": "local_docs.rewrite",
                "description": "Read and rewrite a local txt/md/docx document into the approved output directory.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "path": {"type": "string"},
                        "instruction": {"type": "string"},
                        "output_name": {"type": "string"},
                        "mode": {"type": "string"},
                    },
                    "required": ["path", "instruction"],
                },
                "permission": "write",
                "risk": "medium",
                "audit": True,
                "allowlist_required": True,
                "toolset": "filesystem",
            },
            {
                "name": "local_docs.extract",
                "description": "Read a local pdf/xlsx/txt/md/docx document and generate a summary, meeting notes, or todo list in the approved output directory.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "path": {"type": "string"},
                        "output_name": {"type": "string"},
                        "mode": {"type": "string"},
                        "instruction": {"type": "string"},
                    },
                    "required": ["path", "mode"],
                },
                "permission": "write",
                "risk": "medium",
                "audit": True,
                "allowlist_required": True,
                "toolset": "filesystem",
            },
            {
                "name": "local_images.define",
                "description": "Register a local image into the reusable image library or emoji library manifest.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "path": {"type": "string"},
                        "label": {"type": "string"},
                        "manifest": {"type": "string"},
                        "copy_into_library": {"type": "boolean"},
                        "tone": {"type": "array", "items": {"type": "string"}},
                        "use_for": {"type": "array", "items": {"type": "string"}},
                        "avoid_for": {"type": "array", "items": {"type": "string"}},
                        "tags": {"type": "array", "items": {"type": "string"}},
                    },
                    "required": ["path"],
                },
                "permission": "write",
                "risk": "medium",
                "audit": True,
                "allowlist_required": True,
                "toolset": "filesystem",
            },
            {
                "name": "browser.read",
                "description": "Read a webpage under approved domains and return title plus visible text.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "url": {"type": "string"},
                        "max_chars": {"type": "integer"},
                    },
                    "required": ["url"],
                },
                "permission": "read",
                "risk": "medium",
                "audit": True,
                "allowlist_required": True,
                "toolset": "browser",
            },
            {
                "name": "browser.fill_form",
                "description": "Fill form fields on an approved domain and optionally submit.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "url": {"type": "string"},
                        "fields": {"type": "object"},
                        "submit_selector": {"type": "string"},
                    },
                    "required": ["url", "fields"],
                },
                "permission": "write",
                "risk": "high",
                "audit": True,
                "allowlist_required": True,
                "toolset": "browser",
            },
            {
                "name": "voice.transcribe",
                "description": "Transcribe a local audio file through faster-whisper when installed.",
                "input_schema": {"type": "object", "properties": {"path": {"type": "string"}}},
                "permission": "voice",
                "risk": "medium",
                "audit": True,
                "allowlist_required": True,
                "toolset": "voice",
            },
            {
                "name": "voice.speak",
                "description": "Synthesize local speech through Piper when configured.",
                "input_schema": {"type": "object", "properties": {"text": {"type": "string"}, "out_path": {"type": "string"}}},
                "permission": "voice",
                "risk": "high",
                "audit": True,
                "allowlist_required": True,
                "toolset": "voice",
            },
            {
                "name": "desktop.open_url",
                "description": "Open a URL on the desktop when desktop actions are enabled.",
                "input_schema": {"type": "object", "properties": {"url": {"type": "string"}}},
                "permission": "desktop",
                "risk": "high",
                "audit": True,
                "allowlist_required": True,
                "toolset": "desktop",
            },
        ]
        for spec in specs:
            self._tools[spec["name"]] = {**spec, "enabled": False}

    def _register_disk_skills(self) -> None:
        root = self.config.skills_dir
        if not root.exists() or not root.is_dir():
            return
        for skill_dir in sorted(path for path in root.iterdir() if path.is_dir()):
            skill_md = skill_dir / "SKILL.md"
            skill_json = skill_dir / "skill.json"
            if not skill_md.exists() and not skill_json.exists():
                continue
            slug = normalize_text_key(skill_dir.name) or skill_dir.name.strip().lower()
            if not slug:
                continue
            name = f"skill.{slug}"
            meta: JsonDict = {
                "name": name,
                "description": f"Load local skill instructions from {skill_dir.name}.",
                "input_schema": {"type": "object", "properties": {}},
                "permission": "read",
                "risk": "low",
                "audit": True,
                "allowlist_required": False,
                "toolset": "skills",
                "enabled": True,
                "source": "disk",
                "path": str(skill_dir),
            }
            if skill_json.exists():
                try:
                    disk_meta = safe_json_loads(skill_json.read_text(encoding="utf-8"), {}) or {}
                except Exception as err:
                    self._last_skill_meta_error = f"{skill_json}: {err}"
                    disk_meta = {}
                if isinstance(disk_meta, dict):
                    meta.update({
                        "description": disk_meta.get("description") or meta["description"],
                        "input_schema": disk_meta.get("input_schema") or meta["input_schema"],
                        "permission": disk_meta.get("permission") or meta["permission"],
                        "risk": disk_meta.get("risk") or meta["risk"],
                        "allowlist_required": bool(disk_meta.get("allowlist_required", meta["allowlist_required"])),
                        "toolset": (disk_meta.get("toolset") or meta["toolset"]).strip().lower(),
                    })
            self._tools[name] = meta
            self._skill_docs[name] = {
                "name": name,
                "slug": slug,
                "path": str(skill_dir),
                "skill_md": str(skill_md) if skill_md.exists() else "",
                "skill_json": str(skill_json) if skill_json.exists() else "",
            }
            self._upsert_skill_registry(
                name,
                source_path=str(skill_dir),
                generated=1 if skill_json.exists() and "generated_from_draft" in (skill_json.read_text(encoding="utf-8", errors="replace") if skill_json.exists() else "") else 0,
            )

    def _bind_builtin_handlers(self) -> None:
        self._handlers["local_files.list"] = self.local_file_list
        self._handlers["local_files.read"] = self.local_file_read
        self._handlers["local_files.search"] = self.local_file_search
        self._handlers["local_files.mkdir"] = self.local_file_mkdir
        self._handlers["local_files.copy"] = self.local_file_copy
        self._handlers["local_files.move"] = self.local_file_move
        self._handlers["local_files.delete"] = self.local_file_delete
        self._handlers["local_files.write_text"] = self.local_file_write_text
        self._handlers["local_images.define"] = self.local_image_define
        self._handlers["local_docs.rewrite"] = self.local_doc_rewrite
        self._handlers["local_docs.extract"] = self.local_doc_extract
        self._handlers["browser.read"] = self.browser_read
        self._handlers["browser.fill_form"] = self.browser_fill_form
        for name in ("local_files.list", "local_files.read", "local_files.search", "local_files.mkdir", "local_files.copy", "local_files.move", "local_files.delete", "local_files.write_text", "local_images.define", "local_docs.rewrite", "local_docs.extract", "browser.read", "browser.fill_form"):
            if name in self._tools:
                self._tools[name]["enabled"] = True

    def refresh_disk_skills(self) -> None:
        stale = [name for name, spec in self._tools.items() if spec.get("source") == "disk"]
        for name in stale:
            self._tools.pop(name, None)
            self._skill_docs.pop(name, None)
        self._register_disk_skills()

    def _upsert_skill_registry(self, skill_name: str, *, source_path: str = "", generated: int = 0) -> None:
        now = now_iso()
        conn = self._connect()
        try:
            conn.execute(
                """INSERT INTO skill_registry (skill_name, created_at, updated_at, state, pinned, generated, source_path, meta_json)
                   VALUES (?,?,?,?,?,?,?,?)
                   ON CONFLICT(skill_name) DO UPDATE SET updated_at=excluded.updated_at, source_path=excluded.source_path, generated=excluded.generated""",
                (
                    skill_name,
                    now,
                    now,
                    "active",
                    0,
                    int(generated or 0),
                    source_path,
                    json_dumps({}),
                ),
            )
            conn.commit()
        finally:
            conn.close()

    def bind(self, name: str, handler: Callable[[JsonDict], Any]) -> None:
        if name not in self._tools:
            self._tools[name] = {
                "name": name,
                "description": "Project skill",
                "input_schema": {"type": "object"},
                "permission": "write",
                "risk": "medium",
                "audit": True,
                "allowlist_required": True,
                "toolset": "custom",
                "enabled": True,
            }
        self._handlers[name] = handler
        self._tools[name]["enabled"] = True

    def list_tools(self) -> list[JsonDict]:
        return [self._tools[key] for key in sorted(self._tools)]

    def get_tool(self, name: str) -> JsonDict:
        return dict(self._tools.get(name) or {})

    def disk_skill_docs(self) -> list[JsonDict]:
        docs = []
        states = self.registry_summary().get("items", {})
        for name in sorted(self._skill_docs):
            spec = self._tools.get(name) or {}
            docs.append({
                **self._skill_docs[name],
                "toolset": spec.get("toolset") or "",
                "description": spec.get("description") or "",
                "enabled": bool(spec.get("enabled")),
                "state": (states.get(name) or {}).get("state") or "active",
                "pinned": bool((states.get(name) or {}).get("pinned")),
            })
        return docs

    def mcp_manifest(self) -> JsonDict:
        return {
            "name": "zhiyue-local-skills",
            "version": "0.1.0",
            "protocol": "mcp-shaped",
            "security": {
                "allowlist": sorted(self.config.skill_allowlist),
                "desktop_default": "disabled",
                "audit_log": "skill_audit_log",
            },
            "tools": self.list_tools(),
        }

    def _allowed(self, name: str, spec: JsonDict) -> tuple[bool, str]:
        if name not in self._handlers:
            return False, "skill not bound"
        if not spec.get("enabled"):
            return False, "skill disabled"
        permission = spec.get("permission") or "read"
        risk = spec.get("risk") or "low"
        toolset = (spec.get("toolset") or "custom").strip().lower()
        if toolset not in self.config.enabled_toolsets:
            return False, f"toolset disabled: {toolset}"
        if spec.get("allowlist_required") and name not in self.config.skill_allowlist:
            return False, f"not in ZHIYUE_SKILL_ALLOWLIST for {permission}/{risk}"
        if permission == "desktop" and not self.config.desktop_enabled:
            return False, "desktop actions disabled; set ZHIYUE_DESKTOP_ENABLE=1"
        return True, "allowed"

    def _safe_args(self, args: JsonDict | None) -> JsonDict:
        args = args or {}
        result: JsonDict = {}
        for key, value in args.items():
            if key.lower() in {"api_key", "token", "password", "secret"}:
                result[key] = "***"
            elif isinstance(value, str):
                result[key] = clean_snippet(value, 300)
            else:
                result[key] = value
        return result

    def _build_request_id(self, name: str) -> str:
        slug = normalize_text_key(name) or "skill"
        return f"{slug}-{uuid.uuid4().hex[:12]}"

    def _is_transient_tool_error(self, name: str, err: Exception) -> bool:
        text = str(err).lower()
        if name.startswith("browser."):
            return any(token in text for token in ("timeout", "navigation", "playwright", "net::", "target page"))
        if name.startswith("local_docs."):
            return "timeout" in text or "tempor" in text
        return False

    def _validate_tool_result(self, name: str, args: JsonDict | None, result: JsonDict | None) -> JsonDict:
        args = args or {}
        payload = result or {}
        validation = {"ok": True, "checks": [], "error": ""}
        try:
            if name == "local_files.write_text":
                path = Path(str(payload.get("path") or ""))
                expected = str(args.get("content") or "")
                actual = path.read_text(encoding="utf-8")
                validation["checks"] = ["path_exists", "content_matches"]
                validation["ok"] = path.exists() and actual == expected
            elif name == "local_files.copy":
                dst = Path(str(payload.get("dst") or ""))
                validation["checks"] = ["destination_exists"]
                validation["ok"] = dst.exists()
            elif name == "local_files.move":
                src = Path(str(payload.get("src") or ""))
                dst = Path(str(payload.get("dst") or ""))
                validation["checks"] = ["destination_exists", "source_removed"]
                validation["ok"] = dst.exists() and not src.exists()
            elif name == "local_files.delete":
                path = Path(str(payload.get("path") or args.get("path") or ""))
                validation["checks"] = ["path_removed"]
                validation["ok"] = not path.exists()
            elif name == "local_files.mkdir":
                path = Path(str(payload.get("path") or ""))
                validation["checks"] = ["directory_exists"]
                validation["ok"] = path.exists() and path.is_dir()
            elif name in {"local_docs.rewrite", "local_docs.extract"}:
                output_path = Path(str(payload.get("output_path") or ""))
                validation["checks"] = ["output_exists", "output_nonempty"]
                validation["ok"] = output_path.exists() and output_path.stat().st_size > 0
            elif name == "browser.read":
                validation["checks"] = ["content_nonempty", "url_present"]
                validation["ok"] = bool(str(payload.get("url") or "")) and bool(str(payload.get("content") or "").strip())
            elif name == "browser.fill_form":
                fields = args.get("fields") if isinstance(args.get("fields"), dict) else {}
                filled = payload.get("filled_selectors") if isinstance(payload.get("filled_selectors"), list) else []
                validation["checks"] = ["selectors_filled"]
                validation["ok"] = len(filled) == len(fields)
            elif name == "voice.speak":
                path = Path(str(payload.get("path") or ""))
                validation["checks"] = ["audio_exists"]
                validation["ok"] = path.exists() and path.stat().st_size > 0
            elif name == "voice.transcribe":
                validation["checks"] = ["text_present"]
                validation["ok"] = bool(str(payload.get("text") or payload.get("result") or "").strip())
        except Exception as err:
            validation["ok"] = False
            validation["error"] = str(err)
        if not validation["ok"] and not validation["error"]:
            validation["error"] = "post-execution validation failed"
        return validation

    def _resolve_local_read_path(self, raw_path: str) -> Path:
        raw = (raw_path or "").strip()
        if not raw:
            raise ValueError("empty path")
        candidate = Path(raw).expanduser()
        if not candidate.is_absolute():
            candidate = (self.config.base_dir / candidate).resolve()
        else:
            candidate = candidate.resolve()
        for root in self.config.local_read_roots:
            try:
                candidate.relative_to(root)
                return candidate
            except Exception:
                continue
        raise ValueError(f"path outside approved read roots: {candidate}")

    def _resolve_output_path(self, filename: str, suffix: str) -> Path:
        output_dir = self.config.local_write_output_dir
        output_dir.mkdir(parents=True, exist_ok=True)
        safe_name = normalize_text_key(filename) or "document"
        if not safe_name.endswith(suffix.lower()):
            safe_name = f"{safe_name}{suffix.lower()}"
        return output_dir / safe_name

    def _resolve_local_write_path(self, raw_path: str) -> Path:
        raw = (raw_path or "").strip()
        if not raw:
            raise ValueError("empty path")
        candidate = Path(raw).expanduser()
        if not candidate.is_absolute():
            candidate = (self.config.base_dir / candidate).resolve()
        else:
            candidate = candidate.resolve()
        roots = list(self.config.local_read_roots) + [self.config.local_write_output_dir.resolve()]
        for root in roots:
            try:
                candidate.relative_to(root)
                return candidate
            except Exception:
                continue
        raise ValueError(f"path outside approved write roots: {candidate}")

    def _resolve_local_any_path(self, raw_path: str) -> Path:
        try:
            return self._resolve_local_read_path(raw_path)
        except Exception:
            return self._resolve_local_write_path(raw_path)

    @staticmethod
    def _coerce_string_list(value: Any, *, limit: int = 12, item_limit: int = 40) -> list[str]:
        if value is None:
            return []
        items = value if isinstance(value, list) else [value]
        result: list[str] = []
        seen: set[str] = set()
        for item in items:
            text = clean_snippet(item, item_limit)
            if not text:
                continue
            key = text.lower()
            if key in seen:
                continue
            seen.add(key)
            result.append(text)
            if len(result) >= limit:
                break
        return result

    @staticmethod
    def _safe_library_name(label: str, source_name: str) -> str:
        seed = normalize_text_key(label) or normalize_text_key(source_name) or f"image_{int(time.time())}"
        return seed[:48]

    def _manifest_target(self, kind: str) -> tuple[str, Path]:
        kind = (kind or "image").strip().lower()
        if kind == "emoji":
            return "emoji", EMOJI_MANIFEST_FILE
        return "image", IMAGE_MANIFEST_FILE

    def _read_manifest_entries(self, path: Path) -> JsonDict:
        if not path.exists():
            return {"entries": []}
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return {"entries": []}
        return data if isinstance(data, dict) else {"entries": []}

    def _write_manifest_entry(self, manifest_path: Path, key_field: str, entry: JsonDict, *, max_entries: int = 500) -> None:
        data = self._read_manifest_entries(manifest_path)
        entries = [row for row in (data.get("entries") or []) if isinstance(row, dict)]
        key_value = str(entry.get(key_field) or "").strip()
        replaced = False
        for index, row in enumerate(entries):
            if str(row.get(key_field) or "").strip() == key_value:
                merged = dict(row)
                merged.update(entry)
                entries[index] = merged
                replaced = True
                break
        if not replaced:
            entries.append(entry)
        data["entries"] = entries[-max_entries:]
        manifest_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    def _validate_browser_url(self, raw_url: str) -> str:
        from urllib.parse import urlparse

        url = (raw_url or "").strip()
        if not re.match(r"^https?://", url, flags=re.I):
            raise ValueError("browser url must start with http/https")
        parsed = urlparse(url)
        host = (parsed.hostname or "").strip().lower()
        if host not in self.config.browser_allowed_domains:
            raise ValueError(f"domain not allowed: {host}")
        return url

    def _rewrite_text_with_lm(self, source_text: str, instruction: str, *, mode: str = "rewrite") -> str:
        lm_url = os.environ.get("ZHIYUE_LM_URL", "http://127.0.0.1:1234/v1/chat/completions").strip()
        model = os.environ.get("ZHIYUE_LM_MODEL", "qwen/qwen3.6-35b-a3b").strip() or "default"
        payload = {
            "model": model,
            "messages": [
                {
                    "role": "system",
                    "content": "你是一个文档改写助手。只输出最终改写后的正文，不要解释，不要加前缀，不要说你做了什么。",
                },
                {
                    "role": "user",
                    "content": json.dumps(
                        {
                            "mode": mode,
                            "instruction": instruction,
                            "source_text": source_text[:20000],
                        },
                        ensure_ascii=False,
                    ),
                },
            ],
            "stream": False,
            "temperature": 0.3,
            "max_tokens": 2400,
        }
        response = requests.post(lm_url, json=payload, timeout=180)
        response.raise_for_status()
        data = response.json()
        choices = data.get("choices") or []
        if not choices:
            raise RuntimeError("empty rewrite response")
        message = choices[0].get("message") if isinstance(choices[0], dict) else {}
        rewritten = str((message or {}).get("content") or "").strip()
        if not rewritten:
            raise RuntimeError("empty rewritten text")
        return rewritten

    def _read_document_text(self, path: Path) -> tuple[str, str]:
        suffix = path.suffix.lower()
        if suffix in {".txt", ".md", ".csv", ".json"}:
            return path.read_text(encoding="utf-8", errors="replace"), suffix
        if suffix == ".docx":
            from docx import Document  # type: ignore
            doc = Document(str(path))
            text = "\n".join(paragraph.text for paragraph in doc.paragraphs)
            return text, suffix
        if suffix == ".pdf":
            from pypdf import PdfReader  # type: ignore
            reader = PdfReader(str(path))
            text = "\n".join((page.extract_text() or "") for page in reader.pages)
            return text, suffix
        if suffix == ".xlsx":
            from openpyxl import load_workbook  # type: ignore
            wb = load_workbook(str(path), data_only=True, read_only=True)
            chunks = []
            try:
                for ws in wb.worksheets:
                    chunks.append(f"[sheet:{ws.title}]")
                    row_count = 0
                    for row in ws.iter_rows(values_only=True):
                        cells = [str(cell).strip() for cell in row if cell is not None and str(cell).strip()]
                        if cells:
                            chunks.append(" | ".join(cells))
                            row_count += 1
                        if row_count >= 100:
                            break
            finally:
                wb.close()
            return "\n".join(chunks), suffix
        raise ValueError(f"unsupported document type: {suffix}")

    @staticmethod
    def _normalize_header(value: str) -> str:
        return normalize_text_key(str(value or ""))

    def _extract_xlsx_task_rows(self, path: Path, limit: int = 200) -> list[JsonDict]:
        from openpyxl import load_workbook  # type: ignore

        wb = load_workbook(str(path), data_only=True, read_only=True)
        items: list[JsonDict] = []
        owner_keys = {"负责人", "责任人", "owner", "assignee", "ownername", "duty"}
        due_keys = {"截止", "截止时间", "到期", "due", "deadline", "日期", "时间"}
        priority_keys = {"优先级", "priority", "级别", "紧急程度"}
        task_keys = {"事项", "任务", "内容", "待办", "工作项", "task", "item", "topic"}

        try:
            for ws in wb.worksheets:
                rows = list(ws.iter_rows(values_only=True))
                if not rows:
                    continue
                header_row = rows[0]
                headers = [self._normalize_header(str(cell or "")) for cell in header_row]
                owner_idx = next((idx for idx, header in enumerate(headers) if any(self._normalize_header(k) == header for k in owner_keys)), None)
                due_idx = next((idx for idx, header in enumerate(headers) if any(self._normalize_header(k) == header for k in due_keys)), None)
                priority_idx = next((idx for idx, header in enumerate(headers) if any(self._normalize_header(k) == header for k in priority_keys)), None)
                task_idx = next((idx for idx, header in enumerate(headers) if any(self._normalize_header(k) == header for k in task_keys)), 0)

                for row in rows[1:]:
                    task = str(row[task_idx] or "").strip() if task_idx is not None and task_idx < len(row) else ""
                    if not task:
                        continue
                    owner = str(row[owner_idx] or "").strip() if owner_idx is not None and owner_idx < len(row) else ""
                    due = str(row[due_idx] or "").strip() if due_idx is not None and due_idx < len(row) else ""
                    priority = str(row[priority_idx] or "").strip() if priority_idx is not None and priority_idx < len(row) else ""
                    items.append(
                        {
                            "sheet": ws.title,
                            "task": task,
                            "owner": owner,
                            "due": due,
                            "priority": priority,
                        }
                    )
                    if len(items) >= limit:
                        return items
        finally:
            wb.close()
        return items

    def _write_document_text(self, source_path: Path, target_path: Path, rewritten_text: str) -> None:
        suffix = source_path.suffix.lower()
        if suffix in {".txt", ".md", ".csv", ".json"}:
            target_path.write_text(rewritten_text, encoding="utf-8")
            return
        if suffix == ".docx":
            from docx import Document  # type: ignore
            doc = Document()
            for block in str(rewritten_text).splitlines() or [""]:
                doc.add_paragraph(block)
            doc.save(str(target_path))
            return
        raise ValueError(f"unsupported document type: {suffix}")

    def local_file_list(self, args: JsonDict | None = None) -> JsonDict:
        args = args or {}
        root = self._resolve_local_read_path(str(args.get("path") or self.config.base_dir))
        recursive = bool(args.get("recursive"))
        pattern = str(args.get("glob") or "*").strip() or "*"
        limit = max(1, min(500, int(args.get("limit") or 100)))
        iterator = root.rglob(pattern) if recursive else root.glob(pattern)
        items = []
        for path in iterator:
            if len(items) >= limit:
                break
            items.append({
                "path": str(path),
                "name": path.name,
                "is_dir": path.is_dir(),
                "size": path.stat().st_size if path.exists() and path.is_file() else None,
            })
        return {
            "root": str(root),
            "items": items,
            "count": len(items),
            "approved_roots": [str(item) for item in self.config.local_read_roots],
        }

    def local_file_read(self, args: JsonDict | None = None) -> JsonDict:
        args = args or {}
        path = self._resolve_local_read_path(str(args.get("path") or ""))
        if not path.exists() or not path.is_file():
            raise FileNotFoundError(str(path))
        start_line = max(1, int(args.get("start_line") or 1))
        max_lines = max(1, min(500, int(args.get("max_lines") or 120)))
        text = path.read_text(encoding="utf-8", errors="replace").splitlines()
        start_idx = start_line - 1
        selected = text[start_idx:start_idx + max_lines]
        return {
            "path": str(path),
            "start_line": start_line,
            "end_line": start_line + max(0, len(selected) - 1),
            "content": "\n".join(selected),
            "line_count": len(selected),
        }

    def local_file_search(self, args: JsonDict | None = None) -> JsonDict:
        args = args or {}
        path = self._resolve_local_read_path(str(args.get("path") or ""))
        pattern = str(args.get("pattern") or "").strip()
        if not pattern:
            raise ValueError("empty pattern")
        glob_pattern = str(args.get("glob") or "*").strip() or "*"
        limit = max(1, min(200, int(args.get("limit") or 50)))
        matches = []
        targets = []
        if path.is_dir():
            targets = [item for item in path.rglob(glob_pattern) if item.is_file()]
        elif path.is_file():
            targets = [path]
        else:
            raise FileNotFoundError(str(path))
        for file_path in targets:
            try:
                lines = file_path.read_text(encoding="utf-8", errors="replace").splitlines()
            except Exception:
                continue
            for idx, line in enumerate(lines, 1):
                if pattern in line:
                    matches.append({
                        "path": str(file_path),
                        "line": idx,
                        "content": clean_snippet(line, 300),
                    })
                    if len(matches) >= limit:
                        return {"path": str(path), "pattern": pattern, "matches": matches, "count": len(matches)}
        return {"path": str(path), "pattern": pattern, "matches": matches, "count": len(matches)}

    def local_file_mkdir(self, args: JsonDict | None = None) -> JsonDict:
        args = args or {}
        path = self._resolve_local_write_path(str(args.get("path") or ""))
        path.mkdir(parents=True, exist_ok=True)
        return {"path": str(path), "created": True}

    def local_file_copy(self, args: JsonDict | None = None) -> JsonDict:
        args = args or {}
        src = self._resolve_local_read_path(str(args.get("src") or ""))
        dst = self._resolve_local_write_path(str(args.get("dst") or ""))
        overwrite = bool(args.get("overwrite"))
        if not src.exists() or not src.is_file():
            raise FileNotFoundError(str(src))
        if dst.exists() and not overwrite:
            raise FileExistsError(str(dst))
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        return {"src": str(src), "dst": str(dst), "copied": True}

    def local_file_move(self, args: JsonDict | None = None) -> JsonDict:
        args = args or {}
        src = self._resolve_local_write_path(str(args.get("src") or ""))
        dst = self._resolve_local_write_path(str(args.get("dst") or ""))
        overwrite = bool(args.get("overwrite"))
        if not src.exists():
            raise FileNotFoundError(str(src))
        if dst.exists():
            if not overwrite:
                raise FileExistsError(str(dst))
            if dst.is_file():
                dst.unlink()
            elif dst.is_dir():
                shutil.rmtree(dst)
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(src), str(dst))
        return {"src": str(src), "dst": str(dst), "moved": True}

    def local_file_delete(self, args: JsonDict | None = None) -> JsonDict:
        args = args or {}
        path = self._resolve_local_write_path(str(args.get("path") or ""))
        recursive = bool(args.get("recursive"))
        if not path.exists():
            raise FileNotFoundError(str(path))
        if path.is_dir():
            if not recursive:
                raise ValueError("directory delete requires recursive=True")
            shutil.rmtree(path)
        else:
            path.unlink()
        return {"path": str(path), "deleted": True, "recursive": recursive}

    def local_file_write_text(self, args: JsonDict | None = None) -> JsonDict:
        args = args or {}
        path = self._resolve_local_write_path(str(args.get("path") or ""))
        content = str(args.get("content") or "")
        overwrite = bool(args.get("overwrite"))
        if path.suffix.lower() not in {".txt", ".md", ".json", ".csv"}:
            raise ValueError("write_text only supports .txt/.md/.json/.csv")
        if path.exists() and not overwrite:
            raise FileExistsError(str(path))
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        return {"path": str(path), "written": True, "chars": len(content)}

    def local_image_define(self, args: JsonDict | None = None) -> JsonDict:
        args = args or {}
        source_path = self._resolve_local_any_path(str(args.get("path") or ""))
        if not source_path.exists() or not source_path.is_file():
            raise FileNotFoundError(str(source_path))
        suffix = source_path.suffix.lower()
        if suffix not in {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"}:
            raise ValueError(f"unsupported image type: {suffix}")

        manifest_kind, manifest_path = self._manifest_target(str(args.get("manifest") or "image"))
        copy_into_library = bool(args.get("copy_into_library")) if "copy_into_library" in args else manifest_kind == "emoji"
        label = clean_snippet(args.get("label") or source_path.stem, 80) or source_path.stem
        tone = self._coerce_string_list(args.get("tone"), limit=8)
        use_for = self._coerce_string_list(args.get("use_for"), limit=12, item_limit=80)
        avoid_for = self._coerce_string_list(args.get("avoid_for"), limit=12, item_limit=80)
        tags = self._coerce_string_list(args.get("tags"), limit=16)

        from PIL import Image  # type: ignore

        with Image.open(source_path) as img:
            width = int(img.width)
            height = int(img.height)
            image_mode = str(img.mode or "")

        stored_path = source_path
        filename = source_path.name
        if copy_into_library:
            library_dir = EMOJI_LIBRARY_DIR if manifest_kind == "emoji" else (self.config.local_write_output_dir / "image_library")
            library_dir.mkdir(parents=True, exist_ok=True)
            safe_name = self._safe_library_name(label, source_path.stem)
            filename = f"{safe_name}{suffix}"
            stored_path = library_dir / filename
            if source_path.resolve() != stored_path.resolve():
                shutil.copy2(source_path, stored_path)

        now = now_iso()
        entry = {
            "label": label,
            "filename": filename,
            "path": str(stored_path),
            "tone": tone,
            "use_for": use_for,
            "avoid_for": avoid_for,
            "tags": tags,
            "width": width,
            "height": height,
            "mode": image_mode,
            "updated_at": now,
            "source": {
                "kind": "local_file",
                "path": str(source_path),
            },
        }
        if manifest_kind == "emoji":
            self._write_manifest_entry(manifest_path, "filename", entry, max_entries=300)
        else:
            self._write_manifest_entry(manifest_path, "path", entry, max_entries=500)

        return {
            "manifest": manifest_kind,
            "manifest_path": str(manifest_path),
            "entry": entry,
            "copied": bool(copy_into_library),
            "stored_path": str(stored_path),
        }

    def local_doc_rewrite(self, args: JsonDict | None = None) -> JsonDict:
        args = args or {}
        path = self._resolve_local_read_path(str(args.get("path") or ""))
        instruction = str(args.get("instruction") or "").strip()
        if not instruction:
            raise ValueError("empty instruction")
        mode = str(args.get("mode") or "rewrite").strip() or "rewrite"
        source_text, suffix = self._read_document_text(path)
        rewritten = self._rewrite_text_with_lm(source_text, instruction, mode=mode)
        output_name = str(args.get("output_name") or path.stem).strip() or path.stem
        target_path = self._resolve_output_path(output_name, suffix)
        self._write_document_text(path, target_path, rewritten)
        return {
            "source_path": str(path),
            "output_path": str(target_path),
            "instruction": instruction,
            "mode": mode,
            "source_chars": len(source_text),
            "output_chars": len(rewritten),
            "output_dir": str(self.config.local_write_output_dir),
        }

    def local_doc_extract(self, args: JsonDict | None = None) -> JsonDict:
        args = args or {}
        path = self._resolve_local_read_path(str(args.get("path") or ""))
        mode = str(args.get("mode") or "").strip().lower()
        if mode not in {"summary", "meeting_notes", "todo_list"}:
            raise ValueError("mode must be one of: summary, meeting_notes, todo_list")
        source_text, suffix = self._read_document_text(path)
        task_rows: list[JsonDict] = []
        if suffix == ".xlsx" and mode == "todo_list":
            task_rows = self._extract_xlsx_task_rows(path, limit=200)
        instruction_map = {
            "summary": "请提炼一份清晰的摘要，突出关键信息、结论、数据和背景。",
            "meeting_notes": "请整理成会议纪要，包含主题、关键信息、决定事项、风险点和后续动作。",
            "todo_list": "请整理成待办清单，按事项拆分成可执行条目，尽量明确责任和优先级。",
        }
        extra = str(args.get("instruction") or "").strip()
        instruction = instruction_map[mode] + (f" 额外要求：{extra}" if extra else "")
        if task_rows:
            structured_seed = json.dumps({"tasks": task_rows[:80]}, ensure_ascii=False)
            source_payload = f"{structured_seed}\n\n原始表格节选：\n{source_text[:12000]}"
            extracted = self._rewrite_text_with_lm(source_payload, instruction, mode=mode)
        else:
            extracted = self._rewrite_text_with_lm(source_text, instruction, mode=mode)
        output_name = str(args.get("output_name") or f"{path.stem}_{mode}").strip() or f"{path.stem}_{mode}"
        target_path = self._resolve_output_path(output_name, ".md")
        target_path.write_text(extracted, encoding="utf-8")
        return {
            "source_path": str(path),
            "source_type": suffix,
            "output_path": str(target_path),
            "mode": mode,
            "instruction": instruction,
            "source_chars": len(source_text),
            "output_chars": len(extracted),
            "structured_tasks": task_rows[:80],
            "output_dir": str(self.config.local_write_output_dir),
        }

    def browser_read(self, args: JsonDict | None = None) -> JsonDict:
        from playwright.sync_api import sync_playwright  # type: ignore

        args = args or {}
        url = self._validate_browser_url(str(args.get("url") or ""))
        max_chars = max(200, min(20000, int(args.get("max_chars") or 6000)))
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            page = browser.new_page()
            page.goto(url, wait_until="domcontentloaded", timeout=30000)
            title = page.title()
            text = page.locator("body").inner_text()[:max_chars]
            browser.close()
        return {"url": url, "title": title, "content": text}

    def browser_fill_form(self, args: JsonDict | None = None) -> JsonDict:
        from playwright.sync_api import sync_playwright  # type: ignore

        args = args or {}
        url = self._validate_browser_url(str(args.get("url") or ""))
        fields = args.get("fields") if isinstance(args.get("fields"), dict) else {}
        if not fields:
            raise ValueError("browser.fill_form requires non-empty fields")
        submit_selector = str(args.get("submit_selector") or "").strip()
        filled = []
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            page = browser.new_page()
            page.goto(url, wait_until="domcontentloaded", timeout=30000)
            for selector, value in fields.items():
                page.fill(str(selector), str(value))
                filled.append(str(selector))
            if submit_selector:
                page.click(submit_selector)
                page.wait_for_load_state("domcontentloaded", timeout=10000)
            final_url = page.url
            title = page.title()
            browser.close()
        return {"url": url, "final_url": final_url, "title": title, "filled_selectors": filled, "submitted": bool(submit_selector)}

    def _record_audit(
        self,
        name: str,
        spec: JsonDict,
        args: JsonDict | None,
        allowed: bool,
        reason: str,
        result: Any = None,
        latency_ms: int = 0,
    ) -> None:
        try:
            conn = self._connect()
            try:
                conn.execute(
                    """INSERT INTO skill_audit_log
                       (id, created_at, tool_name, permission, risk, allowed, reason, args_json, result_json, latency_ms)
                       VALUES (?,?,?,?,?,?,?,?,?,?)""",
                    (
                        f"skill-{uuid.uuid4().hex[:16]}",
                        now_iso(),
                        name,
                        spec.get("permission") or "read",
                        spec.get("risk") or "low",
                        1 if allowed else 0,
                        clean_snippet(reason, 240),
                        json_dumps(self._safe_args(args)),
                        json_dumps(result if isinstance(result, dict) else {"result": clean_snippet(str(result), 300)}),
                        int(latency_ms or 0),
                    ),
                )
                conn.commit()
            finally:
                conn.close()
        except Exception as err:
            self._last_audit_error = str(err)

    def _record_usage(
        self,
        name: str,
        args: JsonDict | None,
        result: Any = None,
        *,
        ok: bool = True,
        latency_ms: int = 0,
        meta: JsonDict | None = None,
        request_id: str = "",
        attempts: int = 1,
        validation: JsonDict | None = None,
        recovery: JsonDict | None = None,
    ) -> None:
        try:
            conn = self._connect()
            try:
                conn.execute(
                    """INSERT INTO skill_usage_log
                       (id, created_at, skill_name, route, ok, latency_ms, args_json, result_json, meta_json,
                        request_id, attempts, validation_json, recovery_json)
                       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (
                        f"skill-use-{uuid.uuid4().hex[:16]}",
                        now_iso(),
                        name,
                        clean_snippet(((meta or {}).get("route") or ""), 120),
                        1 if ok else 0,
                        int(latency_ms or 0),
                        json_dumps(self._safe_args(args)),
                        json_dumps(result if isinstance(result, dict) else {"result": clean_snippet(str(result), 300)}),
                        json_dumps(meta or {}),
                        clean_snippet(request_id, 80),
                        max(1, int(attempts or 1)),
                        json_dumps(validation or {}),
                        json_dumps(recovery or {}),
                    ),
                )
                conn.commit()
            finally:
                conn.close()
        except Exception as err:
            self._last_usage_error = str(err)

    def audit_log(self, limit: int = 50) -> list[JsonDict]:
        conn = self._connect()
        try:
            cur = conn.execute(
                """SELECT id, created_at, tool_name, permission, risk, allowed, reason,
                          args_json, result_json, latency_ms
                   FROM skill_audit_log ORDER BY created_at DESC LIMIT ?""",
                (max(1, min(200, int(limit))),),
            )
            rows = []
            for row in cur.fetchall():
                rows.append({
                    "id": row[0],
                    "created_at": row[1],
                    "tool_name": row[2],
                    "permission": row[3],
                    "risk": row[4],
                    "allowed": bool(row[5]),
                    "reason": row[6],
                    "args": safe_json_loads(row[7], {}) or {},
                    "result": safe_json_loads(row[8], {}) or {},
                    "latency_ms": row[9],
                })
            return rows
        finally:
            conn.close()

    def usage_log(self, limit: int = 50) -> list[JsonDict]:
        conn = self._connect()
        try:
            cur = conn.execute(
                """SELECT id, created_at, skill_name, route, ok, latency_ms, args_json, result_json, meta_json,
                          request_id, attempts, validation_json, recovery_json
                   FROM skill_usage_log ORDER BY created_at DESC LIMIT ?""",
                (max(1, min(200, int(limit))),),
            )
            rows = []
            for row in cur.fetchall():
                rows.append({
                    "id": row[0],
                    "created_at": row[1],
                    "skill_name": row[2],
                    "route": row[3],
                    "ok": bool(row[4]),
                    "latency_ms": row[5],
                    "args": safe_json_loads(row[6], {}) or {},
                    "result": safe_json_loads(row[7], {}) or {},
                    "meta": safe_json_loads(row[8], {}) or {},
                    "request_id": row[9],
                    "attempts": row[10],
                    "validation": safe_json_loads(row[11], {}) or {},
                    "recovery": safe_json_loads(row[12], {}) or {},
                })
            return rows
        finally:
            conn.close()

    def usage_summary(self, limit: int = 200) -> JsonDict:
        rows = self.usage_log(limit=limit)
        by_skill: dict[str, int] = {}
        ok_count = 0
        retry_count = 0
        validation_failures = 0
        for row in rows:
            name = row.get("skill_name") or "unknown"
            by_skill[name] = by_skill.get(name, 0) + 1
            if row.get("ok"):
                ok_count += 1
            if int(row.get("attempts") or 1) > 1:
                retry_count += 1
            validation = row.get("validation") if isinstance(row.get("validation"), dict) else {}
            if validation and not validation.get("ok", True):
                validation_failures += 1
        return {
            "total": len(rows),
            "ok_rate": round(ok_count / max(1, len(rows)), 3) if rows else 0,
            "by_skill": by_skill,
            "retry_count": retry_count,
            "validation_failures": validation_failures,
            "latest": rows[0] if rows else {},
        }

    def registry_summary(self) -> JsonDict:
        conn = self._connect()
        try:
            cur = conn.execute(
                """SELECT skill_name, created_at, updated_at, state, pinned, generated, source_path, meta_json
                   FROM skill_registry ORDER BY updated_at DESC"""
            )
            items = {}
            by_state: dict[str, int] = {}
            for row in cur.fetchall():
                item = {
                    "skill_name": row[0],
                    "created_at": row[1],
                    "updated_at": row[2],
                    "state": row[3],
                    "pinned": bool(row[4]),
                    "generated": bool(row[5]),
                    "source_path": row[6],
                    "meta": safe_json_loads(row[7], {}) or {},
                }
                items[row[0]] = item
                by_state[item["state"]] = by_state.get(item["state"], 0) + 1
            return {"items": items, "by_state": by_state}
        finally:
            conn.close()

    def set_skill_state(self, skill_name: str, state: str, *, pinned: bool | None = None) -> JsonDict:
        now = now_iso()
        conn = self._connect()
        try:
            if pinned is None:
                conn.execute(
                    "UPDATE skill_registry SET updated_at=?, state=? WHERE skill_name=?",
                    (now, clean_snippet(state, 40), skill_name),
                )
            else:
                conn.execute(
                    "UPDATE skill_registry SET updated_at=?, state=?, pinned=? WHERE skill_name=?",
                    (now, clean_snippet(state, 40), 1 if pinned else 0, skill_name),
                )
            conn.commit()
        finally:
            conn.close()
        return self.registry_summary().get("items", {}).get(skill_name, {"skill_name": skill_name, "state": state})

    def curate_skills(self, limit: int = 200) -> JsonDict:
        from zhiyue_skill_curator import classify_skill_state
        usage_rows = self.usage_log(limit=limit)
        registry = self.registry_summary().get("items", {})
        aggregate: dict[str, JsonDict] = {}
        for row in usage_rows:
            name = row.get("skill_name") or ""
            if not name:
                continue
            item = aggregate.setdefault(name, {"usage_count": 0, "last_used_at": "", "pinned": bool((registry.get(name) or {}).get("pinned"))})
            item["usage_count"] += 1
            if row.get("created_at") and str(row.get("created_at")) > str(item.get("last_used_at") or ""):
                item["last_used_at"] = row.get("created_at")
        updated = []
        for name, reg in registry.items():
            stats = aggregate.get(name, {"usage_count": 0, "last_used_at": "", "pinned": bool(reg.get("pinned"))})
            state = classify_skill_state(
                usage_count=int(stats.get("usage_count") or 0),
                last_used_at=str(stats.get("last_used_at") or ""),
                pinned=bool(reg.get("pinned")),
            )
            updated.append(self.set_skill_state(name, state, pinned=bool(reg.get("pinned"))))
        return {
            "ok": True,
            "updated": updated,
            "registry": self.registry_summary(),
        }

    def archive_generated_skills(self) -> JsonDict:
        registry = self.registry_summary().get("items", {})
        archive_root = Path(self.config.skills_dir) / ".archive"
        archive_root.mkdir(parents=True, exist_ok=True)
        moved = []
        skipped = []
        for name, item in registry.items():
            if not item.get("generated"):
                skipped.append({"skill_name": name, "reason": "not_generated"})
                continue
            if item.get("state") != "archived":
                skipped.append({"skill_name": name, "reason": "state_not_archived"})
                continue
            if item.get("pinned"):
                skipped.append({"skill_name": name, "reason": "pinned"})
                continue
            source_path = Path(item.get("source_path") or "")
            if not source_path.exists() or not source_path.is_dir():
                skipped.append({"skill_name": name, "reason": "missing_source_path"})
                continue
            target_path = archive_root / source_path.name
            if target_path.exists():
                shutil.rmtree(target_path, ignore_errors=True)
            shutil.move(str(source_path), str(target_path))
            self._upsert_skill_registry(name, source_path=str(target_path), generated=1)
            self.set_skill_state(name, "archived", pinned=False)
            moved.append({
                "skill_name": name,
                "from": str(source_path),
                "to": str(target_path),
            })
        self.refresh_disk_skills()
        return {
            "ok": True,
            "moved": moved,
            "skipped": skipped,
            "archive_root": str(archive_root),
            "registry": self.registry_summary(),
        }

    def call(self, name: str, args: JsonDict | None = None) -> JsonDict:
        request_id = self._build_request_id(name)
        if name not in self._tools:
            spec = {"permission": "unknown", "risk": "unknown"}
            result = {"ok": False, "error": f"unknown skill: {name}", "request_id": request_id}
            self._record_audit(name, spec, args, False, result["error"], result=result)
            return result
        spec = self._tools[name]
        if name in self._skill_docs and name not in self._handlers:
            doc = self._skill_docs[name]
            try:
                content = ""
                skill_md = Path(doc.get("skill_md") or "")
                if skill_md.exists():
                    content = skill_md.read_text(encoding="utf-8", errors="replace")
                result = {
                    "ok": True,
                    "request_id": request_id,
                    "result": {
                        "skill": doc,
                        "content": content,
                    },
                }
                self._record_audit(name, spec, args, True, "loaded disk skill", result=result)
                self._record_usage(name, args, result, ok=True, meta={"source": "disk_skill"}, request_id=request_id)
                return result
            except Exception as err:
                result = {"ok": False, "error": str(err), "request_id": request_id}
                self._record_audit(name, spec, args, True, f"disk skill load error: {err}", result=result)
                self._record_usage(name, args, result, ok=False, meta={"source": "disk_skill"}, request_id=request_id)
                return result
        allowed, reason = self._allowed(name, spec)
        if not allowed:
            result = {"ok": False, "error": reason, "tool": spec, "request_id": request_id}
            self._record_audit(name, spec, args, False, reason, result=result)
            return result
        start = time.monotonic()
        attempts = 0
        last_error = ""
        recovery = {"retried": False, "attempts": 0, "reason": ""}
        validation: JsonDict = {}
        while attempts < 2:
            attempts += 1
            try:
                handler_result = self._handlers[name](args or {})
                validation = self._validate_tool_result(
                    name,
                    args,
                    handler_result if isinstance(handler_result, dict) else {"result": handler_result},
                )
                if validation and not validation.get("ok"):
                    raise ValueError(str(validation.get("error") or "tool result validation failed"))
                result = {
                    "ok": True,
                    "request_id": request_id,
                    "attempts": attempts,
                    "validation": validation,
                    "result": handler_result,
                }
                latency_ms = int((time.monotonic() - start) * 1000)
                self._record_audit(name, spec, args, True, reason, result=result, latency_ms=latency_ms)
                self._record_usage(
                    name,
                    args,
                    result,
                    ok=True,
                    latency_ms=latency_ms,
                    meta={"source": "bound_handler"},
                    request_id=request_id,
                    attempts=attempts,
                    validation=validation,
                    recovery=recovery,
                )
                return result
            except Exception as err:
                last_error = str(err)
                if attempts < 2 and self._is_transient_tool_error(name, err):
                    recovery = {"retried": True, "attempts": attempts + 1, "reason": last_error}
                    time.sleep(0.2)
                    continue
                break
        result = {
            "ok": False,
            "error": last_error,
            "request_id": request_id,
            "attempts": attempts,
            "validation": validation,
            "recovery": recovery,
        }
        latency_ms = int((time.monotonic() - start) * 1000)
        self._record_audit(name, spec, args, True, f"handler error: {last_error}", result=result, latency_ms=latency_ms)
        self._record_usage(
            name,
            args,
            result,
            ok=False,
            latency_ms=latency_ms,
            meta={"source": "bound_handler"},
            request_id=request_id,
            attempts=attempts,
            validation=validation,
            recovery=recovery,
        )
        return result

    def status(self) -> JsonDict:
        tools = self.list_tools()
        return {
            "tools": len(tools),
            "enabled": sum(1 for item in tools if item.get("enabled")),
            "allowlist": sorted(self.config.skill_allowlist),
            "enabled_toolsets": sorted(self.config.enabled_toolsets),
            "skills_dir": str(self.config.skills_dir),
            "disk_skills": sorted(self._skill_docs),
            "audit_db": str(self.db_path),
            "usage_summary": self.usage_summary(limit=100),
            "registry": self.registry_summary(),
            "manifest": self.mcp_manifest(),
        }


class SkillLearningLayer:
    AUTO_MERGE_MIN_EVIDENCE = 10

    def __init__(self, config: LayerConfig):
        self.config = config
        self.db_path = config.observability_db
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        return _connect_observability_db(self.db_path, self.config.base_dir)

    def _init_db(self) -> None:
        conn = self._connect()
        try:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS skill_drafts (
                    id TEXT PRIMARY KEY,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    source TEXT DEFAULT '',
                    source_key TEXT DEFAULT '',
                    title TEXT DEFAULT '',
                    slug TEXT DEFAULT '',
                    summary TEXT DEFAULT '',
                    content TEXT DEFAULT '',
                    evidence_count INTEGER DEFAULT 0,
                    evidence_json TEXT DEFAULT '[]',
                    status TEXT DEFAULT 'draft',
                    meta_json TEXT DEFAULT '{}'
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS skill_merge_events (
                    id TEXT PRIMARY KEY,
                    created_at TEXT NOT NULL,
                    draft_id TEXT DEFAULT '',
                    source_key TEXT DEFAULT '',
                    target_skill TEXT DEFAULT '',
                    evidence_count INTEGER DEFAULT 0,
                    before_count INTEGER DEFAULT 0,
                    after_count INTEGER DEFAULT 0,
                    delta_count INTEGER DEFAULT 0,
                    meta_json TEXT DEFAULT '{}'
                )
            """)
            conn.commit()
        finally:
            conn.close()

    def upsert_draft(self, item: JsonDict) -> JsonDict:
        source = clean_snippet(item.get("source"), 80)
        source_key = clean_snippet(item.get("source_key"), 120)
        title = clean_snippet(item.get("title"), 180)
        slug = clean_snippet(item.get("slug"), 120)
        summary = clean_snippet(item.get("summary"), 800)
        content = clean_snippet(item.get("content"), 4000)
        status = clean_snippet(item.get("status"), 40) or "draft"
        now = now_iso()
        updated_at = item.get("updated_at") or now
        created_at = item.get("created_at") or now
        conn = self._connect()
        try:
            cur = conn.execute(
                "SELECT id FROM skill_drafts WHERE source=? AND source_key=? LIMIT 1",
                (source, source_key),
            )
            row = cur.fetchone()
            if row:
                draft_id = row[0]
                existing = self.get_draft(draft_id) or {}
                existing_evidence = list(existing.get("evidence") or [])
                incoming_evidence = list(item.get("evidence_json") or [])
                merged_evidence = existing_evidence + incoming_evidence
                normalized_seen: set[str] = set()
                deduped_evidence: list[JsonDict] = []
                for evidence_item in merged_evidence:
                    try:
                        fingerprint = json_dumps(evidence_item)
                    except Exception:
                        fingerprint = str(evidence_item)
                    if fingerprint in normalized_seen:
                        continue
                    normalized_seen.add(fingerprint)
                    deduped_evidence.append(evidence_item)
                merged_meta = {
                    **(existing.get("meta") or {}),
                    **(item.get("meta") or {}),
                }
                merged_meta["evidence_count"] = max(int(existing.get("evidence_count") or 0), len(deduped_evidence), int(item.get("evidence_count") or 0))
                conn.execute(
                    """UPDATE skill_drafts
                       SET updated_at=?, title=?, slug=?, summary=?, content=?, evidence_count=?, evidence_json=?, status=?, meta_json=?
                       WHERE id=?""",
                    (
                        updated_at,
                        title,
                        slug,
                        summary,
                        content,
                        max(int(existing.get("evidence_count") or 0), len(deduped_evidence), int(item.get("evidence_count") or 0)),
                        json_dumps(deduped_evidence[-40:]),
                        status,
                        json_dumps(merged_meta),
                        draft_id,
                    ),
                )
            else:
                draft_id = f"skill-draft-{uuid.uuid4().hex[:16]}"
                conn.execute(
                    """INSERT INTO skill_drafts
                       (id, created_at, updated_at, source, source_key, title, slug, summary, content, evidence_count, evidence_json, status, meta_json)
                       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (
                        draft_id,
                        created_at,
                        updated_at,
                        source,
                        source_key,
                        title,
                        slug,
                        summary,
                        content,
                        int(item.get("evidence_count") or 0),
                        json_dumps(item.get("evidence_json") or []),
                        status,
                        json_dumps(item.get("meta") or {}),
                    ),
                )
            conn.commit()
        finally:
            conn.close()
        return self.get_draft(draft_id) or {}

    def get_draft(self, draft_id: str) -> JsonDict | None:
        conn = self._connect()
        try:
            cur = conn.execute(
                """SELECT id, created_at, updated_at, source, source_key, title, slug, summary, content,
                          evidence_count, evidence_json, status, meta_json
                   FROM skill_drafts WHERE id=? LIMIT 1""",
                (draft_id,),
            )
            row = cur.fetchone()
            if not row:
                return None
            return {
                "id": row[0],
                "created_at": row[1],
                "updated_at": row[2],
                "source": row[3],
                "source_key": row[4],
                "title": row[5],
                "slug": row[6],
                "summary": row[7],
                "content": row[8],
                "evidence_count": row[9],
                "evidence": safe_json_loads(row[10], []) or [],
                "status": row[11],
                "meta": safe_json_loads(row[12], {}) or {},
            }
        finally:
            conn.close()

    def list_drafts(self, status: str = "all", limit: int = 50) -> list[JsonDict]:
        conn = self._connect()
        try:
            where = ""
            params: list[Any] = []
            if status != "all":
                where = "WHERE status=?"
                params.append(status)
            params.append(max(1, min(200, int(limit))))
            cur = conn.execute(
                f"""SELECT id, created_at, updated_at, source, source_key, title, slug, summary, content,
                           evidence_count, evidence_json, status, meta_json
                    FROM skill_drafts {where}
                    ORDER BY updated_at DESC LIMIT ?""",
                params,
            )
            rows = []
            for row in cur.fetchall():
                rows.append({
                    "id": row[0],
                    "created_at": row[1],
                    "updated_at": row[2],
                    "source": row[3],
                    "source_key": row[4],
                    "title": row[5],
                    "slug": row[6],
                    "summary": row[7],
                    "content": row[8],
                    "evidence_count": row[9],
                    "evidence": safe_json_loads(row[10], []) or [],
                    "status": row[11],
                    "meta": safe_json_loads(row[12], {}) or {},
                })
            return rows
        finally:
            conn.close()

    def update_draft_status(self, draft_id: str, status: str) -> JsonDict | None:
        now = now_iso()
        conn = self._connect()
        try:
            conn.execute(
                "UPDATE skill_drafts SET updated_at=?, status=? WHERE id=?",
                (now, clean_snippet(status, 40), draft_id),
            )
            conn.commit()
        finally:
            conn.close()
        return self.get_draft(draft_id)

    @staticmethod
    def _draft_target_skill_name(draft: JsonDict) -> str:
        mapping = {
            "comforting": "skill.comforting",
            "late_night_companion": "skill.late_night_companion",
            "relationship_repair": "skill.relationship_repair",
            "reply_style_guard": "skill.reply_style_guard",
            "memory_recall_style": "skill.reply_style_guard",
        }
        return mapping.get(str(draft.get("source_key") or "").strip(), f"skill.{clean_snippet(draft.get('slug'), 80).replace('-', '_')}")

    @staticmethod
    def _auto_merge_threshold(draft: JsonDict) -> int:
        source = str(draft.get("source") or "").strip().lower()
        meta = draft.get("meta") or {}
        if meta.get("preferred_path") == "explicit_preference":
            return 2
        if meta.get("preferred_path") == "skill_update":
            return 4
        if source == "runtime_autonomous_learning":
            return 4
        return SkillLearningLayer.AUTO_MERGE_MIN_EVIDENCE

    def suggest_draft_action(self, draft_id: str, skills_layer=None) -> JsonDict:
        draft = self.get_draft(draft_id)
        if not draft:
            return {"ok": False, "error": "draft not found"}
        target_skill = self._draft_target_skill_name(draft)
        existing = {}
        if skills_layer and hasattr(skills_layer, "get_tool"):
            existing = skills_layer.get_tool(target_skill)
        evidence_count = int(draft.get("evidence_count") or 0)
        threshold = self._auto_merge_threshold(draft)
        action = "publish_new"
        reason = "no matching skill found"
        if existing:
            action = "update_existing"
            reason = "matching companion skill already exists"
        if evidence_count < threshold:
            reason += "; evidence below auto-publish threshold"
        return {
            "ok": True,
            "draft_id": draft_id,
            "target_skill": target_skill,
            "action": action,
            "reason": reason,
            "evidence_count": evidence_count,
            "auto_merge_threshold": threshold,
        }

    def refresh_draft_suggestions(self, skills_layer=None, limit: int = 200) -> JsonDict:
        drafts = self.list_drafts(status="draft", limit=limit)
        updated = []
        for draft in drafts:
            suggestion = self.suggest_draft_action(draft.get("id", ""), skills_layer=skills_layer)
            if not suggestion.get("ok"):
                continue
            next_status = "draft"
            threshold = int(suggestion.get("auto_merge_threshold") or self.AUTO_MERGE_MIN_EVIDENCE)
            if suggestion.get("action") == "update_existing" and int(suggestion.get("evidence_count") or 0) >= threshold:
                next_status = "suggested_merge"
            elif suggestion.get("action") == "publish_new" and int(suggestion.get("evidence_count") or 0) >= threshold:
                next_status = "suggested_publish"
            conn = self._connect()
            try:
                conn.execute(
                    "UPDATE skill_drafts SET updated_at=?, status=?, meta_json=? WHERE id=?",
                    (
                        now_iso(),
                        next_status,
                        json_dumps({
                            **(draft.get("meta") or {}),
                            "suggested_action": suggestion,
                        }),
                        draft.get("id"),
                    ),
                )
                conn.commit()
            finally:
                conn.close()
            updated.append(self.get_draft(draft.get("id", "")) or {})
        return {"ok": True, "updated": updated}

    @staticmethod
    def _draft_priority(item: JsonDict) -> tuple[int, int, str]:
        status = str(item.get("status") or "draft")
        evidence = int(item.get("evidence_count") or 0)
        status_rank = {
            "suggested_merge": 0,
            "suggested_publish": 1,
            "draft": 2,
            "published": 3,
            "merged": 4,
            "archived": 5,
        }.get(status, 9)
        return (status_rank, -evidence, str(item.get("updated_at") or ""))

    def prioritized_drafts(self, status: str = "all", limit: int = 50) -> list[JsonDict]:
        drafts = self.list_drafts(status=status, limit=max(limit, 200))
        drafts.sort(key=self._draft_priority)
        return drafts[: max(1, min(200, int(limit)))]

    def publish_draft_to_skill(self, draft_id: str, skills_layer=None) -> JsonDict:
        draft = self.get_draft(draft_id)
        if not draft:
            return {"ok": False, "error": "draft not found"}
        slug = clean_snippet(draft.get("slug"), 80).replace(" ", "_").replace("-", "_") or "generated_skill"
        skill_dir = Path(self.config.skills_dir) / slug
        skill_dir.mkdir(parents=True, exist_ok=True)
        skill_md = skill_dir / "SKILL.md"
        skill_json = skill_dir / "skill.json"
        title = draft.get("title") or slug
        summary = draft.get("summary") or ""
        content = draft.get("content") or ""
        evidence_count = int(draft.get("evidence_count") or 0)
        skill_md.write_text(
            (
                f"# {title}\n\n"
                f"{summary}\n\n"
                "Use this skill when the stored pattern matches the current request or monitor evidence.\n\n"
                f"{content}\n\n"
                f"Evidence count: {evidence_count}\n"
            ),
            encoding="utf-8",
        )
        skill_json.write_text(
            json.dumps(
                {
                    "description": summary or title,
                    "toolset": "skills",
                    "permission": "read",
                    "risk": "low",
                    "allowlist_required": False,
                    "input_schema": {
                        "type": "object",
                        "properties": {
                            "focus": {"type": "string"}
                        }
                    },
                    "generated_from_draft": draft_id,
                    "source": draft.get("source") or "",
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
        updated = self.update_draft_status(draft_id, "published")
        if skills_layer and hasattr(skills_layer, "refresh_disk_skills"):
            try:
                skills_layer.refresh_disk_skills()
            except Exception as err:
                return {
                    "ok": False,
                    "error": f"skill refresh failed after publish: {err}",
                    "draft": updated,
                    "skill_dir": str(skill_dir),
                    "skill_name": f"skill.{slug}",
                }
        return {
            "ok": True,
            "draft": updated,
            "skill_dir": str(skill_dir),
            "skill_name": f"skill.{slug}",
            "files": {
                "skill_md": str(skill_md),
                "skill_json": str(skill_json),
            },
        }

    def merge_draft_into_skill(self, draft_id: str, skills_layer=None) -> JsonDict:
        from zhiyue_skill_learning import _load_findings, _parse_iso, compare_findings_before_after
        draft = self.get_draft(draft_id)
        if not draft:
            return {"ok": False, "error": "draft not found"}
        target_skill = self._draft_target_skill_name(draft)
        slug = target_skill.replace("skill.", "", 1)
        skill_dir = Path(self.config.skills_dir) / slug
        skill_md = skill_dir / "SKILL.md"
        skill_json = skill_dir / "skill.json"
        if not skill_md.exists():
            return {"ok": False, "error": f"target skill file not found: {skill_md}"}
        existing = skill_md.read_text(encoding="utf-8", errors="replace")
        addition = (
            "\n\n## Runtime Update\n\n"
            f"Source: {draft.get('source_key') or draft.get('source')}\n"
            f"Evidence count: {int(draft.get('evidence_count') or 0)}\n\n"
            f"{draft.get('content') or ''}\n"
        )
        if addition.strip() not in existing:
            skill_md.write_text(existing.rstrip() + addition, encoding="utf-8")
        meta = {}
        if skill_json.exists():
            meta = safe_json_loads(skill_json.read_text(encoding="utf-8", errors="replace"), {}) or {}
        merged_from = list(meta.get("merged_from_drafts") or [])
        if draft_id not in merged_from:
            merged_from.append(draft_id)
        meta["merged_from_drafts"] = merged_from
        meta["last_merged_at"] = now_iso()
        skill_json.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
        updated = self.update_draft_status(draft_id, "merged")
        merge_time = now_iso()
        findings_path = SELF_MONITOR_FINDINGS_FILE
        before_count = 0
        after_count = 0
        merge_dt = parse_datetime_local(merge_time)
        for row in _load_findings(findings_path, limit=1000):
            created_dt = parse_datetime_local(row.get("created_at") or "")
            if not created_dt or not merge_dt:
                continue
            for failure in row.get("failures") or []:
                issues = [str(x).strip() for x in (failure.get("issues") or []) if str(x).strip()]
                if not issues:
                    continue
                if str(draft.get("source_key") or "") == "comforting" and any(x in issues for x in ["weak_empathy", "missing_anchor"]):
                    if created_dt <= merge_dt:
                        before_count += 1
                    else:
                        after_count += 1
                elif str(draft.get("source_key") or "") == "late_night_companion" and "too_long" in issues:
                    if created_dt <= merge_dt:
                        before_count += 1
                    else:
                        after_count += 1
                elif str(draft.get("source_key") or "") == "relationship_repair" and any(x in issues for x in ["fallback_reply", "generic_reply"]):
                    if created_dt <= merge_dt:
                        before_count += 1
                    else:
                        after_count += 1
                elif str(draft.get("source_key") or "") in {"reply_style_guard", "memory_recall_style"} and any(x in issues for x in ["too_structured", "too_long", "fallback_reply", "generic_reply"]):
                    if created_dt <= merge_dt:
                        before_count += 1
                    else:
                        after_count += 1
        window_effect = compare_findings_before_after(
            findings_path,
            source_key=str(draft.get("source_key") or ""),
            pivot_at=merge_time,
            window=20,
        )
        conn = self._connect()
        try:
            conn.execute(
                """INSERT INTO skill_merge_events
                   (id, created_at, draft_id, source_key, target_skill, evidence_count, before_count, after_count, delta_count, meta_json)
                   VALUES (?,?,?,?,?,?,?,?,?,?)""",
                (
                    f"skill-merge-{uuid.uuid4().hex[:16]}",
                    merge_time,
                    draft_id,
                    str(draft.get("source_key") or ""),
                    target_skill,
                    int(draft.get("evidence_count") or 0),
                    before_count,
                    after_count,
                    after_count - before_count,
                    json_dumps({"files": {"skill_md": str(skill_md), "skill_json": str(skill_json)}, "window_effect": window_effect}),
                ),
            )
            conn.commit()
        finally:
            conn.close()
        if skills_layer and hasattr(skills_layer, "refresh_disk_skills"):
            try:
                skills_layer.refresh_disk_skills()
            except Exception as err:
                return {
                    "ok": False,
                    "error": f"skill refresh failed after merge: {err}",
                    "draft": updated,
                    "target_skill": target_skill,
                }
        return {
            "ok": True,
            "draft": updated,
            "target_skill": target_skill,
            "effect_snapshot": {
                "before_count": before_count,
                "after_count": after_count,
                "delta_count": after_count - before_count,
            },
            "window_effect": window_effect,
            "files": {
                "skill_md": str(skill_md),
                "skill_json": str(skill_json),
            },
        }

    def batch_merge_companion_drafts(self, skills_layer=None, limit: int = 20) -> JsonDict:
        drafts = self.prioritized_drafts(status="suggested_merge", limit=limit)
        merged = []
        skipped = []
        allowed = {
            "comforting",
            "late_night_companion",
            "relationship_repair",
            "reply_style_guard",
            "memory_recall_style",
        }
        merged_source_keys: set[str] = set()
        max_auto_merges = min(2, max(1, int(limit)))
        for item in drafts:
            if len(merged) >= max_auto_merges:
                skipped.append({"draft_id": item.get("id"), "reason": "batch_limit_reached"})
                continue
            source_key = str(item.get("source_key") or "")
            if source_key not in allowed:
                skipped.append({"draft_id": item.get("id"), "reason": "source_key_not_allowed"})
                continue
            if source_key == "memory_recall_style" and "reply_style_guard" in merged_source_keys:
                skipped.append({"draft_id": item.get("id"), "reason": "paired_with_reply_style_guard"})
                continue
            if source_key == "reply_style_guard" and "memory_recall_style" in merged_source_keys:
                skipped.append({"draft_id": item.get("id"), "reason": "paired_with_memory_recall_style"})
                continue
            result = self.merge_draft_into_skill(item.get("id", ""), skills_layer=skills_layer)
            if result.get("ok"):
                merged.append(result)
                merged_source_keys.add(source_key)
            else:
                skipped.append({"draft_id": item.get("id"), "reason": result.get("error") or "merge_failed"})
        return {
            "ok": True,
            "merged": merged,
            "skipped": skipped,
            "count": len(merged),
        }

    def auto_apply_runtime_drafts(self, skills_layer=None, limit: int = 20) -> JsonDict:
        refreshed = self.refresh_draft_suggestions(skills_layer=skills_layer, limit=max(20, limit * 4))
        merged = self.batch_merge_companion_drafts(skills_layer=skills_layer, limit=limit)
        published = []
        drafts = self.prioritized_drafts(status="suggested_publish", limit=limit)
        for item in drafts:
            result = self.publish_draft_to_skill(item.get("id", ""), skills_layer=skills_layer)
            if result.get("ok"):
                published.append(result)
        return {
            "ok": True,
            "refreshed": refreshed,
            "merged": merged,
            "published": published,
            "published_count": len(published),
            "conflicts": self.conflict_summary(limit=max(20, limit * 4)),
            "effect_summary": self.companion_skill_effect_summary(
                SELF_MONITOR_FINDINGS_FILE,
                window=20,
                limit=max(20, limit * 4),
                hit_limit=max(200, limit * 20),
            ),
        }

    def archive_draft(self, draft_id: str) -> JsonDict:
        draft = self.update_draft_status(draft_id, "archived")
        if not draft:
            return {"ok": False, "error": "draft not found"}
        return {"ok": True, "draft": draft}

    def ingest_self_monitor_findings(self, findings_path: Path) -> JsonDict:
        from zhiyue_skill_learning import summarize_findings_for_skill_drafts
        created = []
        for item in summarize_findings_for_skill_drafts(findings_path):
            created.append(self.upsert_draft(item))
        return {
            "ok": True,
            "created": created,
            "count": len(created),
            "findings_path": str(findings_path),
        }

    def status(self) -> JsonDict:
        drafts = self.list_drafts(limit=200)
        by_status: dict[str, int] = {}
        for item in drafts:
            by_status[item.get("status") or "draft"] = by_status.get(item.get("status") or "draft", 0) + 1
        return {
            "db": str(self.db_path),
            "total": len(drafts),
            "by_status": by_status,
            "suggested_merge_count": by_status.get("suggested_merge", 0),
            "suggested_publish_count": by_status.get("suggested_publish", 0),
            "conflicts": self.conflict_summary(limit=200),
            "effect_summary": self.companion_skill_effect_summary(
                SELF_MONITOR_FINDINGS_FILE,
                window=20,
                limit=50,
                hit_limit=200,
            ),
            "latest": drafts[0] if drafts else {},
        }

    def list_merge_events(self, limit: int = 50) -> list[JsonDict]:
        conn = self._connect()
        try:
            cur = conn.execute(
                """SELECT id, created_at, draft_id, source_key, target_skill, evidence_count, before_count, after_count, delta_count, meta_json
                   FROM skill_merge_events ORDER BY created_at DESC LIMIT ?""",
                (max(1, min(200, int(limit))),),
            )
            rows = []
            for row in cur.fetchall():
                rows.append({
                    "id": row[0],
                    "created_at": row[1],
                    "draft_id": row[2],
                    "source_key": row[3],
                    "target_skill": row[4],
                    "evidence_count": row[5],
                    "before_count": row[6],
                    "after_count": row[7],
                    "delta_count": row[8],
                    "meta": safe_json_loads(row[9], {}) or {},
                })
            return rows
        finally:
            conn.close()

    def merge_effect_summary(self, findings_path: Path, window: int = 20, limit: int = 50) -> JsonDict:
        from zhiyue_skill_learning import compare_findings_before_after
        events = self.list_merge_events(limit=limit)
        latest_by_source: dict[str, JsonDict] = {}
        all_sources = [
            "comforting",
            "late_night_companion",
            "relationship_repair",
            "reply_style_guard",
            "memory_recall_style",
        ]
        for event in events:
            source_key = str(event.get("source_key") or "")
            if source_key and source_key not in latest_by_source:
                latest_by_source[source_key] = event
        items = {}
        for source_key in all_sources:
            event = latest_by_source.get(source_key)
            if event:
                items[source_key] = compare_findings_before_after(
                    findings_path,
                    source_key=source_key,
                    pivot_at=str(event.get("created_at") or ""),
                    window=window,
                )
            else:
                items[source_key] = {
                    "source_key": source_key,
                    "window": window,
                    "before_count": 0,
                    "after_count": 0,
                    "delta_count": 0,
                    "trend": "unknown",
                    "before_examples": [],
                    "after_examples": [],
                }
        return {
            "window": window,
            "items": items,
        }

    def skill_runtime_hit_summary(self, limit: int = 500) -> JsonDict:
        tracked = {
            "skill.comforting",
            "skill.late_night_companion",
            "skill.relationship_repair",
            "skill.reply_style_guard",
            "skill.memory_recall_style",
        }
        conn = self._connect()
        try:
            try:
                cur = conn.execute(
                    """SELECT created_at, skill_name, effect, judge_score
                       FROM learning_events
                       WHERE stage='runtime_skill_hit'
                       ORDER BY created_at DESC LIMIT ?""",
                    (max(1, min(5000, int(limit))),),
                )
            except sqlite3.OperationalError:
                return {
                    "limit": max(1, min(5000, int(limit))),
                    "items": {
                        name: {
                            "skill_name": name,
                            "hits": 0,
                            "avg_judge_score": 0.0,
                            "effects": {},
                            "last_hit_at": "",
                        }
                        for name in tracked
                    },
                }
            rows = cur.fetchall()
        finally:
            conn.close()
        items: dict[str, JsonDict] = {
            name: {
                "skill_name": name,
                "hits": 0,
                "avg_judge_score": 0.0,
                "effects": {},
                "last_hit_at": "",
            }
            for name in tracked
        }
        score_buckets: dict[str, list[float]] = {name: [] for name in tracked}
        for created_at, skill_name, effect, judge_score in rows:
            name = clean_snippet(skill_name, 120)
            if name not in tracked:
                continue
            row = items[name]
            row["hits"] = int(row.get("hits") or 0) + 1
            row["last_hit_at"] = row.get("last_hit_at") or created_at or ""
            effects = row.get("effects") if isinstance(row.get("effects"), dict) else {}
            effect_key = clean_snippet(effect, 80) or "unknown"
            effects[effect_key] = int(effects.get(effect_key) or 0) + 1
            row["effects"] = effects
            try:
                score_buckets[name].append(float(judge_score or 0))
            except Exception:
                pass
        for name, row in items.items():
            scores = [value for value in score_buckets.get(name, []) if value > 0]
            row["avg_judge_score"] = round(sum(scores) / len(scores), 3) if scores else 0.0
        return {
            "limit": max(1, min(5000, int(limit))),
            "items": items,
        }

    def companion_skill_effect_summary(self, findings_path: Path, window: int = 20, limit: int = 50, hit_limit: int = 500) -> JsonDict:
        merge_summary = self.merge_effect_summary(findings_path, window=window, limit=limit)
        hit_summary = self.skill_runtime_hit_summary(limit=hit_limit)
        enriched = {}
        for source_key, payload in (merge_summary.get("items") or {}).items():
            skill_name = f"skill.{source_key}"
            enriched[source_key] = {
                **(payload or {}),
                "runtime_hits": (hit_summary.get("items") or {}).get(
                    skill_name,
                    {
                        "skill_name": skill_name,
                        "hits": 0,
                        "avg_judge_score": 0.0,
                        "effects": {},
                        "last_hit_at": "",
                    },
                ),
            }
        return {
            "window": window,
            "merge_limit": limit,
            "hit_limit": hit_limit,
            "items": enriched,
        }

    def conflict_summary(self, limit: int = 200, auto_resolve: bool = False) -> JsonDict:
        drafts = self.list_drafts(limit=max(20, limit))
        active = [
            item for item in drafts
            if str(item.get("status") or "") in {"draft", "suggested_merge", "suggested_publish"}
        ]
        by_target: dict[str, list[JsonDict]] = {}
        by_source_key: dict[str, list[JsonDict]] = {}
        duplicate_titles: dict[str, list[JsonDict]] = {}
        for item in active:
            target_skill = self._draft_target_skill_name(item)
            by_target.setdefault(target_skill, []).append(item)
            source_key = str(item.get("source_key") or "").strip()
            if source_key:
                by_source_key.setdefault(source_key, []).append(item)
            title_key = normalize_text_key(item.get("title") or "")
            if title_key:
                duplicate_titles.setdefault(title_key, []).append(item)

        target_conflicts = []
        for target_skill, items in by_target.items():
            if len(items) <= 1:
                continue
            target_conflicts.append({
                "target_skill": target_skill,
                "count": len(items),
                "draft_ids": [item.get("id") for item in items],
                "source_keys": [item.get("source_key") for item in items],
            })

        source_conflicts = []
        for source_key, items in by_source_key.items():
            if len(items) <= 1:
                continue
            source_conflicts.append({
                "source_key": source_key,
                "count": len(items),
                "draft_ids": [item.get("id") for item in items],
                "statuses": [item.get("status") for item in items],
            })

        duplicate_title_conflicts = []
        for title_key, items in duplicate_titles.items():
            if len(items) <= 1:
                continue
            duplicate_title_conflicts.append({
                "title_key": title_key,
                "count": len(items),
                "draft_ids": [item.get("id") for item in items],
            })

        recent_events = self.list_merge_events(limit=max(20, min(200, limit)))
        merge_churn: dict[str, int] = {}
        for event in recent_events:
            key = str(event.get("source_key") or "").strip()
            if not key:
                continue
            merge_churn[key] = merge_churn.get(key, 0) + 1
        churn_risks = [
            {"source_key": key, "recent_merge_count": count}
            for key, count in sorted(merge_churn.items(), key=lambda item: (-item[1], item[0]))
            if count >= 3
        ]

        result = {
            "active_draft_count": len(active),
            "target_conflicts": target_conflicts,
            "source_conflicts": source_conflicts,
            "duplicate_title_conflicts": duplicate_title_conflicts,
            "merge_churn_risks": churn_risks,
            "conflict_count": len(target_conflicts) + len(source_conflicts) + len(duplicate_title_conflicts) + len(churn_risks),
        }
        
        if auto_resolve:
            resolve_result = self.auto_resolve_conflicts(dry_run=False)
            archive_result = self.auto_archive_stale_drafts(dry_run=False)
            result["auto_resolve_applied"] = True
            result["auto_resolved"] = resolve_result
            result["auto_archived"] = archive_result

        return result


    def auto_resolve_conflicts(self, dry_run: bool = False) -> JsonDict:
        """Auto-dedup conflicts by archiving lower-priority duplicates.

        Order matters:
        1. source_conflicts first (dedup by source_key)
        2. duplicate_title_conflicts second (dedup by normalized title)
        3. target_conflicts last (dedup by target skill name)

        Processing source + duplicate_title first avoids unnecessary
        target_conflicts when the duplicates are already resolved.
        """
        conflicts = self.conflict_summary(limit=200, auto_resolve=False)
        resolved = []
        archived_draft_ids: set[str] = set()

        # 1. source_conflicts
        for conflict in conflicts.get("source_conflicts", []):
            draft_ids = conflict.get("draft_ids", [])
            if len(draft_ids) <= 1:
                continue
            drafts = [self.get_draft(did) for did in draft_ids]
            drafts = [d for d in drafts if d is not None]
            if len(drafts) <= 1:
                continue
            drafts.sort(key=lambda d: (d.get("evidence_count", 0), d.get("updated_at", "")), reverse=True)
            keeper = drafts[0]
            for dup in drafts[1:]:
                dup_id = dup.get("id")
                if dup_id in archived_draft_ids:
                    continue
                if not dry_run:
                    self.archive_draft(dup_id)
                    archived_draft_ids.add(dup_id)
                resolved.append({
                    "type": "source_conflict",
                    "source_key": conflict.get("source_key"),
                    "kept_draft_id": keeper.get("id"),
                    "kept_evidence": keeper.get("evidence_count", 0),
                    "archived_draft_id": dup_id,
                    "archived_evidence": dup.get("evidence_count", 0),
                })

        # 2. duplicate_title_conflicts
        for conflict in conflicts.get("duplicate_title_conflicts", []):
            draft_ids = conflict.get("draft_ids", [])
            if len(draft_ids) <= 1:
                continue
            drafts = [self.get_draft(did) for did in draft_ids]
            drafts = [d for d in drafts if d is not None]
            if len(drafts) <= 1:
                continue
            drafts.sort(key=lambda d: (d.get("evidence_count", 0), d.get("updated_at", "")), reverse=True)
            keeper = drafts[0]
            for dup in drafts[1:]:
                dup_id = dup.get("id")
                if dup_id in archived_draft_ids:
                    continue
                if not dry_run:
                    self.archive_draft(dup_id)
                    archived_draft_ids.add(dup_id)
                resolved.append({
                    "type": "duplicate_title",
                    "title_key": conflict.get("title_key"),
                    "kept_draft_id": keeper.get("id"),
                    "kept_evidence": keeper.get("evidence_count", 0),
                    "archived_draft_id": dup_id,
                    "archived_evidence": dup.get("evidence_count", 0),
                })

        # 3. target_conflicts (do this LAST)
        for conflict in conflicts.get("target_conflicts", []):
            draft_ids = conflict.get("draft_ids", [])
            if len(draft_ids) <= 1:
                continue
            drafts = [self.get_draft(did) for did in draft_ids]
            drafts = [d for d in drafts if d is not None]
            if len(drafts) <= 1:
                continue
            drafts.sort(key=lambda d: (d.get("evidence_count", 0), d.get("updated_at", "")), reverse=True)
            keeper = drafts[0]
            for dup in drafts[1:]:
                dup_id = dup.get("id")
                if dup_id in archived_draft_ids:
                    continue
                if not dry_run:
                    self.archive_draft(dup_id)
                    archived_draft_ids.add(dup_id)
                resolved.append({
                    "type": "target_conflict",
                    "target_skill": conflict.get("target_skill"),
                    "kept_draft_id": keeper.get("id"),
                    "kept_evidence": keeper.get("evidence_count", 0),
                    "archived_draft_id": dup_id,
                    "archived_evidence": dup.get("evidence_count", 0),
                })

        return {
            "ok": True,
            "dry_run": dry_run,
            "resolved_count": len(resolved),
            "resolved": resolved,
        }

    def auto_archive_stale_drafts(self, dry_run: bool = False, max_age_days: int = 14, min_evidence: int = 3) -> JsonDict:
        """Auto-archive stale low-priority drafts.

        Archives drafts where status=="draft", updated_at is older than
        max_age_days, and evidence_count < min_evidence.
        """
        from datetime import timedelta
        now = now_local()
        cutoff = now - timedelta(days=max_age_days)
        cutoff_str = cutoff.isoformat()

        drafts = self.list_drafts(status="draft", limit=200)
        archived = []

        for draft in drafts:
            draft_id = draft.get("id")
            evidence_count = int(draft.get("evidence_count") or 0)
            updated_at_str = str(draft.get("updated_at") or "")

            if not updated_at_str or updated_at_str >= cutoff_str:
                continue
            if evidence_count >= min_evidence:
                continue

            if not dry_run:
                self.archive_draft(draft_id)

            archived.append({
                "draft_id": draft_id,
                "source_key": draft.get("source_key"),
                "title": draft.get("title"),
                "evidence_count": evidence_count,
                "updated_at": updated_at_str,
            })

        return {
            "ok": True,
            "dry_run": dry_run,
            "max_age_days": max_age_days,
            "min_evidence": min_evidence,
            "archived_count": len(archived),
            "archived": archived,
        }



    # ======================================================================
    # P0: self_correct_skill — Letta-style self-editing memory
    # ======================================================================

    SELF_CORRECT_THRESHOLD = 0.35
    _RANKED_SKILL_NAMES = (
        "comforting",
        "late_night_companion",
        "relationship_repair",
        "reply_style_guard",
        "memory_recall_style",
    )

    def self_correct_skill(
        self,
        skill_name: str,
        effect_summary: JsonDict,
        skill_content: str = "",
    ) -> JsonDict:
        """当 Skill 效果低于阈值时，生成反思 prompt 供调用方让 LLM 分析并修正。

        Letta 风格：Agent 主动编辑自己的 persona 内存。
        本方法不直接调 LLM，而是返回 ``pending_prompt``，由调用方
        完成推理后通过 ``upsert_draft`` 写入修正草稿。
        """
        items = effect_summary.get("items") if isinstance(effect_summary.get("items"), dict) else {}
        item = items.get(skill_name)
        if not item:
            return {"ok": False, "reason": "no_effect_data", "skill_name": skill_name}

        runtime_hits = item.get("runtime_hits") or {}
        avg_score = float(runtime_hits.get("avg_judge_score", float(item.get("avg_judge_score") or 0.0)) or 0.0)

        if avg_score >= self.SELF_CORRECT_THRESHOLD:
            return {
                "ok": True,
                "corrected": False,
                "reason": "above_threshold",
                "avg_score": avg_score,
                "threshold": self.SELF_CORRECT_THRESHOLD,
                "skill_name": skill_name,
            }

        raw_effects = runtime_hits.get("effects") if isinstance(runtime_hits, dict) else None
        effects = raw_effects if isinstance(raw_effects, dict) else {}
        hits = int(runtime_hits.get("hits") or 0)

        effect_lines = []
        for effect_name, count in sorted(effects.items(), key=lambda kv: -int(kv[1] or 0)):
            effect_lines.append(f"  - {effect_name}: {count} 次")
        effect_desc = "\n".join(effect_lines) if effect_lines else "（无效果数据）"

        prompt = (
            f"## Skill 自动修正反思\n\n"
            f"**Skill**: `{skill_name}`\n"
            f"**效果评分**: {avg_score:.2f}/1.0（阈值 {self.SELF_CORRECT_THRESHOLD}）\n"
            f"**运行时命中数**: {hits}\n"
            f"**效果分布**:\n{effect_desc}\n\n"
            f"### 当前 Skill 内容\n```markdown\n{skill_content.strip() or '（无内容）'}\n```\n\n"
            f"### 任务\n"
            f"1. 分析为什么这个 Skill 效果不佳（结合效果分布）\n"
            f"2. 给出修正后的完整内容（保持原有结构，只修改有问题的部分）\n"
            f"3. 以 JSON 格式输出：\n"
            f'{{"analysis": "分析...", "corrected_content": "修正后的内容...", "change_summary": "一句话说明改了什么"}}\n'
        )

        return {
            "ok": True,
            "corrected": False,
            "reason": "prompt_ready",
            "skill_name": skill_name,
            "avg_score": avg_score,
            "threshold": self.SELF_CORRECT_THRESHOLD,
            "hits": hits,
            "effects": effects,
            "pending_prompt": prompt,
            "source_key": skill_name,
        }

    def record_self_correction_draft(
        self,
        skill_name: str,
        corrected_content: str,
        analysis: str = "",
    ) -> JsonDict:
        """将 LLM 完成的自我修正结果写入草稿。

        调用方在 LLM 推理完成后调用本方法持久化修正结果。
        """
        from datetime import timezone, timedelta
        now = now_iso()
        draft = {
            "source": "self_correction",
            "source_key": skill_name,
            "title": f"[自我修正] {skill_name} (auto-correct {now[:10]})",
            "slug": f"self_correct_{skill_name}",
            "summary": analysis or f"auto-corrected {skill_name} due to low effect score",
            "content": corrected_content,
            "evidence_count": 1,
            "evidence_json": [{"reason": "self_correction_low_score", "timestamp": now}],
            "status": "draft",
            "meta": {"preferred_path": "self_correction"},
        }
        result = self.upsert_draft(draft)
        return {
            "ok": True,
            "recorded": True,
            "draft": result,
            "skill_name": skill_name,
        }

    # ======================================================================
    # P1: _reflect_on_poor_skill — Reflexion-style verbal reflection
    # ======================================================================

    REFLECTION_THRESHOLD = 0.3

    def _reflect_on_poor_skill(self, source_key: str, effect_data: JsonDict) -> str:
        """Reflexion 风格：生成口头反思 prompt，由调用方让 LLM 分析失败原因。

        返回值是 prompt 字符串，调用方用 LLM 推理后的结果可作为
        self_correction 草稿的 summary 字段。
        """
        runtime_hits = effect_data.get("runtime_hits") or {}
        avg_score = float(runtime_hits.get("avg_judge_score") or 0.0)
        hits = int(runtime_hits.get("hits") or 0)
        raw_effects = runtime_hits.get("effects") if isinstance(runtime_hits, dict) else None
        effects = raw_effects if isinstance(raw_effects, dict) else {}

        trend = effect_data.get("trend", "unknown")
        before_examples = effect_data.get("before_examples") or []
        after_examples = effect_data.get("after_examples") or []

        effect_lines = []
        for e_name, cnt in sorted(effects.items(), key=lambda kv: -int(kv[1] or 0)):
            effect_lines.append(f"- {e_name}: {cnt} 次")
        effect_desc = "\n".join(effect_lines) if effect_lines else "（无）"

        examples_desc = ""
        if before_examples:
            examples_desc += "\n### 修复前案例\n" + "\n".join(f"- {str(ex)}" for ex in before_examples[:3])
        if after_examples:
            examples_desc += "\n### 修复后案例\n" + "\n".join(f"- {str(ex)}" for ex in after_examples[:3])

        return (
            f"## 反思：`{source_key}` 效果分析\n\n"
            f"- 趋势: {trend}\n"
            f"- 运行时命中: {hits} 次\n"
            f"- 平均评分: {avg_score:.2f}\n"
            f"- 效果分布:\n{effect_desc}\n"
            f"{examples_desc}\n\n"
            f"请用 2-3 句话分析这个 Skill 效果变化的根本原因，"
            f"并给出一条具体可操作的调整建议。"
        )

    # ======================================================================
    # P2: _constitution_check — Constitutional AI content review
    # ======================================================================

    DEFAULT_CONSTITUTION = [
        {
            "id": "empathy",
            "label": "共情表达",
            "question": "Skill 内容是否引导真诚共情？是否避免机械或敷衍的回应？",
        },
        {
            "id": "conciseness",
            "label": "简洁清晰",
            "question": "Skill 内容是否简洁、可执行？是否包含冗余啰嗦的指导？",
        },
        {
            "id": "safety",
            "label": "安全边界",
            "question": "Skill 内容是否避免有害建议、过度承诺或侵犯隐私的指导？",
        },
        {
            "id": "consistency",
            "label": "一致性",
            "question": "Skill 内容与其它 Skill 是否存在矛盾？是否与系统整体风格一致？",
        },
    ]

    def _constitution_check(
        self,
        draft: JsonDict,
        constitution: list[JsonDict] | None = None,
    ) -> JsonDict:
        """Constitutional AI 风格：对草稿内容进行宪法审查。

        返回 ``pending_prompts`` 列表，每个元素包含一条规则的审查 prompt。
        调用方逐条让 LLM 打分后汇总结果。
        """
        constitution = constitution or self.DEFAULT_CONSTITUTION
        content = str(draft.get("content") or "")
        title = str(draft.get("title") or "")

        if not content.strip():
            return {
                "ok": True,
                "checked": False,
                "reason": "empty_content",
                "draft_id": draft.get("id"),
            }

        pending_prompts = []
        for rule in constitution:
            prompt = (
                f"## 宪法审查: {rule['label']} (id={rule['id']})\n\n"
                f"### Skill 标题\n{title}\n\n"
                f"### Skill 内容\n```markdown\n{content[:2000]}\n```\n\n"
                f"### 审查问题\n{rule['question']}\n\n"
                f'请以 JSON 格式回答: {{"pass": true/false, "score": 0.0-1.0, "reason": "一句话说明"}}'
            )
            pending_prompts.append({
                "rule_id": rule["id"],
                "rule_label": rule.get("label", ""),
                "prompt": prompt,
            })

        return {
            "ok": True,
            "checked": True,
            "draft_id": draft.get("id"),
            "title": title,
            "content_length": len(content),
            "rule_count": len(pending_prompts),
            "pending_prompts": pending_prompts,
        }

    # ======================================================================
    # P3: _ab_test_merge — DSPy-style A/B optimization
    # ======================================================================

    def _ab_test_merge(self, source_key: str, drafts: list[JsonDict]) -> JsonDict:
        """DSPy 风格：对同一 source_key 的多个草稿做 A/B 效果比较。

        auto_resolve_conflicts 按 evidence_count 简单排序去重。
        本方法额外追踪每个变体的效果评分，返回哪个变体应该保留。

        调用方在每次草稿应用后收集效果数据，再调用本方法重新排名。
        """
        if len(drafts) <= 1:
            return {
                "ok": True,
                "source_key": source_key,
                "variant_count": len(drafts),
                "ab_testable": False,
            }

        variants = []
        for draft in drafts:
            draft_id = draft.get("id")
            effect_info = self._read_variant_effect_score(
                str(draft.get("id") or ""),
                str(draft.get("slug") or ""),
            )
            variant = {
                "draft_id": draft_id,
                "title": draft.get("title"),
                "evidence_count": int(draft.get("evidence_count") or 0),
                "status": draft.get("status"),
                "updated_at": draft.get("updated_at"),
                "effect_score": effect_info.get("score"),
                "effect_samples": effect_info.get("samples", 0),
            }
            variants.append(variant)

        # 综合分：evidence_count 为主，效果评分为辅（权重随样本量上升）
        def composite_score(v: dict) -> float:
            evidence = v["evidence_count"]
            effect = v.get("effect_score")
            if effect is None:
                return float(evidence)
            samples = max(0, v.get("effect_samples") or 0)
            effect_weight = min(0.5, samples / 20.0)
            return evidence * (1.0 - effect_weight) + effect * 10.0 * effect_weight

        variants.sort(key=composite_score, reverse=True)

        keeper = variants[0]
        eliminated = variants[1:]

        return {
            "ok": True,
            "source_key": source_key,
            "variant_count": len(drafts),
            "ab_testable": True,
            "keeper": {
                "draft_id": keeper["draft_id"],
                "title": keeper["title"],
                "evidence_count": keeper["evidence_count"],
                "effect_score": keeper["effect_score"],
                "composite_score": composite_score(keeper),
                "reason": "最高综合分（证据+效果）",
            },
            "eliminated": [
                {
                    "draft_id": v["draft_id"],
                    "title": v["title"],
                    "evidence_count": v["evidence_count"],
                    "effect_score": v.get("effect_score"),
                    "composite_score": composite_score(v),
                }
                for v in eliminated
            ],
        }

    def _read_variant_effect_score(self, draft_id: str, slug: str = "") -> JsonDict:
        """从 learning_events 中读取该草稿目标 Skill 的效果评分。

        返回 {"score": float|None, "samples": int}
        """
        # 尝试按 skill_name（从 slug 推导）查询运行时的效果数据
        skill_name = f"skill.{clean_snippet(slug, 80).replace('-', '_')}"
        conn = self._connect()
        try:
            cur = conn.execute(
                """SELECT effect, judge_score FROM learning_events
                   WHERE stage='runtime_skill_hit'
                   AND skill_name=?
                   ORDER BY created_at DESC
                   LIMIT 50""",
                (skill_name,),
            )
            rows = cur.fetchall()
        except Exception:
            rows = []
        finally:
            conn.close()

        if not rows:
            return {"score": None, "samples": 0}

        scores = []
        for _effect, score in rows:
            try:
                s = float(score or 0)
                scores.append(s)
            except (ValueError, TypeError):
                continue

        if not scores:
            return {"score": None, "samples": 0}
        return {"score": sum(scores) / len(scores), "samples": len(scores)}



    # ── Cycle State ──────────────────────────────────────────

    @property
    def _cycle_state_file(self) -> str:
        return os.path.join(self.config.base_dir, ".skill_learning_cycle_state.json")

    def _load_cycle_state(self) -> dict:
        try:
            with open(self._cycle_state_file, "r", encoding="utf-8") as f:
                return safe_json_loads(f.read(), {})
        except Exception:
            return {}

    def _save_cycle_state(self, state: dict) -> None:
        try:
            with open(self._cycle_state_file, "w", encoding="utf-8") as f:
                f.write(json_dumps(state))
        except Exception:
            pass

    def get_cycle_state(self) -> dict:
        """返回当前 cycle 状态."""
        state = self._load_cycle_state()
        return {
            "samples_since_last_run": int(state.get("samples_since_last_run") or 0),
            "last_run_at": str(state.get("last_run_at") or ""),
            "total_cycles": int(state.get("total_cycles") or 0),
            "total_events": int(state.get("total_events") or 0),
        }

    def record_learning_event(self, n: int = 1) -> dict:
        """记录一条新的 learning_event，递增计数器.

        返回更新后的状态。调用方可根据 samples_since_last_run 决定是否触发 cycle。
        """
        state = self._load_cycle_state()
        state["samples_since_last_run"] = int(state.get("samples_since_last_run") or 0) + max(1, n)
        state["total_events"] = int(state.get("total_events") or 0) + max(1, n)
        self._save_cycle_state(state)
        return self.get_cycle_state()

    def should_trigger_cycle(self, min_samples: int = 30) -> bool:
        """检查是否应该触发一次 self-improvement cycle."""
        state = self._load_cycle_state()
        return int(state.get("samples_since_last_run") or 0) >= min_samples

    def mark_cycle_run(self) -> dict:
        """标记一次 cycle 已完成，重置计数器."""
        state = self._load_cycle_state()
        state["samples_since_last_run"] = 0
        state["last_run_at"] = now_iso()
        state["total_cycles"] = int(state.get("total_cycles") or 0) + 1
        self._save_cycle_state(state)
        return self.get_cycle_state()


class VoiceDesktopLayer:
    """Optional local voice and desktop capabilities."""

    def __init__(self, config: LayerConfig):
        self.config = config

    def _candidate_voice_prompt_paths(self) -> list[Path]:
        configured = os.environ.get("ZHIYUE_VOICE_SEARCH_ROOTS", "").strip()
        roots = [item.strip() for item in configured.split(";") if item.strip()] if configured else [
            r"D:\tmp",
            r"D:\C_drive_moved\ADMIN_home\.qclaw\openclaw-weixin",
            str(self.config.base_dir),
        ]
        items: list[tuple[float, Path]] = []
        for raw_root in roots:
            root = Path(raw_root)
            if not root.exists():
                continue
            try:
                for path in root.rglob("*"):
                    if not path.is_file() or path.suffix.lower() not in {".wav", ".mp3", ".m4a", ".flac", ".aac", ".ogg"}:
                        continue
                    low = str(path).lower()
                    if not any(token in low for token in ["voice", "audio", "record", "录音", "语音", "wechat", "weixin", "mic"]):
                        continue
                    try:
                        size = path.stat().st_size
                        mtime = path.stat().st_mtime
                    except Exception:
                        continue
                    if size < 20_000:
                        continue
                    items.append((mtime, path))
            except Exception:
                continue
        items.sort(key=lambda item: item[0], reverse=True)
        return [path for _, path in items[:30]]

    def resolve_prompt_audio(self, prompt_audio: str | None = None) -> str:
        explicit = str(prompt_audio or "").strip()
        if explicit and Path(explicit).exists():
            profile = load_voice_profile()
            profile["prompt_audio"] = explicit
            profile["updated_at"] = now_iso()
            save_voice_profile(profile)
            return explicit
        env_value = os.environ.get("ZHIYUE_INDEXTTS2_PROMPT_AUDIO", "").strip() or os.environ.get("ZHIYUE_VOICE_PROMPT_AUDIO", "").strip()
        if env_value and Path(env_value).exists():
            return env_value
        profile = load_voice_profile()
        prof_path = str(profile.get("prompt_audio") or "").strip()
        if prof_path and Path(prof_path).exists():
            return prof_path
        candidates = self._candidate_voice_prompt_paths()
        if candidates:
            selected = str(candidates[0])
            profile["prompt_audio"] = selected
            profile["updated_at"] = now_iso()
            save_voice_profile(profile)
            return selected
        return ""

    def transcribe(self, path: str) -> JsonDict:
        audio_path = Path(path)
        if not audio_path.exists():
            return {"ok": False, "error": f"audio file not found: {audio_path}"}
        try:
            from faster_whisper import WhisperModel  # type: ignore
        except Exception as err:
            return {"ok": False, "error": f"faster-whisper unavailable: {err}"}

        model_name = os.environ.get("ZHIYUE_WHISPER_MODEL", "small")
        device = os.environ.get("ZHIYUE_WHISPER_DEVICE", "cpu")
        compute_type = os.environ.get("ZHIYUE_WHISPER_COMPUTE_TYPE", "int8")
        model = WhisperModel(model_name, device=device, compute_type=compute_type)
        segments, info = model.transcribe(str(audio_path), language=os.environ.get("ZHIYUE_WHISPER_LANGUAGE", "zh"))
        text = "".join(segment.text for segment in segments).strip()
        return {
            "ok": True,
            "text": text,
            "language": getattr(info, "language", "zh"),
            "duration": getattr(info, "duration", None),
            "model": model_name,
        }

    def speak(
        self,
        text: str,
        out_path: str | None = None,
        *,
        prompt_audio: str | None = None,
        emo_audio_prompt: str | None = None,
        emotion_text: str | None = None,
        provider: str | None = None,
    ) -> JsonDict:
        text = (text or "").strip()
        if not text:
            return {"ok": False, "error": "empty text"}
        resolved_prompt_audio = self.resolve_prompt_audio(prompt_audio)
        provider_name = (provider or os.environ.get("ZHIYUE_TTS_PROVIDER", "auto")).strip().lower() or "auto"
        if provider_name in {"indextts2", "index-tts2", "index_tts2"}:
            result = self._speak_indextts2(
                text,
                out_path=out_path,
                prompt_audio=resolved_prompt_audio,
                emo_audio_prompt=emo_audio_prompt,
                emotion_text=emotion_text,
            )
            if result.get("ok"):
                return result
            if provider_name != "auto":
                return result
        elif provider_name in {"sapi", "windows_sapi"}:
            result = self._speak_sapi(text, out_path=out_path)
            return result
        elif provider_name not in {"auto", "piper"}:
            return {"ok": False, "error": f"unsupported tts provider: {provider_name}"}
        result = self._speak_piper(text, out_path=out_path)
        if result.get("ok") or provider_name == "piper":
            return result
        sapi = self._speak_sapi(text, out_path=out_path)
        if sapi.get("ok"):
            return sapi
        fallback = self._speak_indextts2(
            text,
            out_path=out_path,
            prompt_audio=resolved_prompt_audio,
            emo_audio_prompt=emo_audio_prompt,
            emotion_text=emotion_text,
        )
        return fallback if fallback.get("ok") else result

    def _speak_piper(self, text: str, out_path: str | None = None) -> JsonDict:
        if not self.config.piper_exe or not Path(self.config.piper_exe).exists():
            return {"ok": False, "error": "ZHIYUE_PIPER_EXE is not configured"}
        if not self.config.piper_model or not Path(self.config.piper_model).exists():
            return {"ok": False, "error": "ZHIYUE_PIPER_MODEL is not configured"}
        out = Path(out_path) if out_path else self.config.base_dir / f"zhiyue_tts_{int(time.time())}.wav"
        proc = subprocess.run(
            [self.config.piper_exe, "--model", self.config.piper_model, "--output_file", str(out)],
            input=text,
            text=True,
            capture_output=True,
            encoding="utf-8",
            errors="replace",
            timeout=120,
        )
        if proc.returncode != 0:
            return {"ok": False, "error": proc.stderr[-500:] or proc.stdout[-500:]}
        return {"ok": True, "path": str(out), "provider": "piper"}

    def _speak_indextts2(
        self,
        text: str,
        out_path: str | None = None,
        *,
        prompt_audio: str | None = None,
        emo_audio_prompt: str | None = None,
        emotion_text: str | None = None,
    ) -> JsonDict:
        try:
            indextts_pkg = importlib.import_module("indextts")
            package_root = Path(indextts_pkg.__file__).resolve().parent
        except Exception:
            package_root = None
        root_raw = os.environ.get("ZHIYUE_INDEXTTS2_ROOT", "").strip()
        root = Path(root_raw) if root_raw else (package_root if package_root else None)
        if not root or not root.exists():
            return {"ok": False, "error": f"IndexTTS2 root not found: {root_raw or package_root}"}
        prompt_audio = (prompt_audio or os.environ.get("ZHIYUE_INDEXTTS2_PROMPT_AUDIO", "")).strip()
        emo_audio_prompt = (emo_audio_prompt or os.environ.get("ZHIYUE_INDEXTTS2_EMO_AUDIO", "")).strip()
        if prompt_audio and not Path(prompt_audio).exists():
            return {"ok": False, "error": f"IndexTTS2 prompt audio not found: {prompt_audio}"}
        if emo_audio_prompt and not Path(emo_audio_prompt).exists():
            return {"ok": False, "error": f"IndexTTS2 emotion prompt audio not found: {emo_audio_prompt}"}
        python_exe = os.environ.get("ZHIYUE_INDEXTTS2_PYTHON", sys.executable or "python").strip() or (sys.executable or "python")
        out = Path(out_path) if out_path else self.config.base_dir / f"zhiyue_indextts2_{int(time.time())}.wav"
        cfg_path = os.environ.get("ZHIYUE_INDEXTTS2_CFG", "").strip() or str(self.config.base_dir / "index_tts2_checkpoints" / "config.yaml")
        model_dir = os.environ.get("ZHIYUE_INDEXTTS2_MODEL_DIR", "").strip() or str(self.config.base_dir / "index_tts2_checkpoints")
        emotion_text = (emotion_text or os.environ.get("ZHIYUE_INDEXTTS2_EMOTION_TEXT", "")).strip()
        use_fp16 = os.environ.get("ZHIYUE_INDEXTTS2_FP16", "1").strip().lower() not in {"0", "false", "no", "off"}
        skip_qwen_emo = os.environ.get("ZHIYUE_INDEXTTS2_SKIP_QWEN_EMO", "1").strip().lower() not in {"0", "false", "no", "off"}
        local_w2vbert = str((self.config.base_dir / "hf_cache" / "facebook_w2v_bert_2_0").resolve())
        local_maskgct = str((self.config.base_dir / "hf_cache" / "amphion_MaskGCT" / "semantic_codec" / "model.safetensors").resolve())
        local_campplus = str((self.config.base_dir / "hf_cache" / "funasr_campplus" / "campplus_cn_common.bin").resolve())
        local_bigvgan = str((self.config.base_dir / "hf_cache" / "bigvgan_22k").resolve())
        site_packages = str((package_root.parent if package_root else (Path(sys.executable).resolve().parent.parent / "Lib" / "site-packages")).resolve())
        bootstrap = [
            "import os, sys",
            f"sys.path.insert(0, {json.dumps(str(root.parent if root.name == 'indextts' else root))})",
            f"site_packages = {json.dumps(site_packages)}",
            "os.add_dll_directory(os.path.join(site_packages, 'torch', 'lib'))",
            "os.add_dll_directory(os.path.join(site_packages, 'torchaudio', 'lib'))",
            "from transformers import SeamlessM4TFeatureExtractor as _SFeat, Wav2Vec2BertModel as _W2VB",
            f"local_w2vbert = {json.dumps(local_w2vbert)}",
            f"local_maskgct = {json.dumps(local_maskgct)}",
            f"local_campplus = {json.dumps(local_campplus)}",
            f"local_bigvgan = {json.dumps(local_bigvgan)}",
            "if os.path.exists(local_w2vbert):",
            "    _orig_sfeat = _SFeat.from_pretrained",
            "    _orig_w2vb = _W2VB.from_pretrained",
            "    def _patched_from_pretrained(cls, pretrained_model_name_or_path, *args, **kwargs):",
            "        if pretrained_model_name_or_path == 'facebook/w2v-bert-2.0':",
            "            pretrained_model_name_or_path = local_w2vbert",
            "        return _orig_sfeat.__func__(cls, pretrained_model_name_or_path, *args, **kwargs)",
            "    def _patched_w2vb_from_pretrained(cls, pretrained_model_name_or_path, *args, **kwargs):",
            "        if pretrained_model_name_or_path == 'facebook/w2v-bert-2.0':",
            "            pretrained_model_name_or_path = local_w2vbert",
            "        return _orig_w2vb.__func__(cls, pretrained_model_name_or_path, *args, **kwargs)",
            "    _SFeat.from_pretrained = classmethod(_patched_from_pretrained)",
            "    _W2VB.from_pretrained = classmethod(_patched_w2vb_from_pretrained)",
            "import huggingface_hub",
            "import indextts.infer_v2 as infer_v2",
            "orig_hf_download = huggingface_hub.hf_hub_download",
            "def _patched_hf_hub_download(repo_id, filename=None, *args, **kwargs):",
            "    if repo_id == 'amphion/MaskGCT' and filename == 'semantic_codec/model.safetensors' and os.path.exists(local_maskgct):",
            "        return local_maskgct",
            "    if repo_id == 'funasr/campplus' and filename == 'campplus_cn_common.bin' and os.path.exists(local_campplus):",
            "        return local_campplus",
            "    return orig_hf_download(repo_id, filename=filename, *args, **kwargs)",
            "huggingface_hub.hf_hub_download = _patched_hf_hub_download",
            "infer_v2.hf_hub_download = _patched_hf_hub_download",
            "if os.path.isdir(local_bigvgan):",
            "    _orig_bigvgan_fp = infer_v2.bigvgan.BigVGAN.from_pretrained",
            "    def _patched_bigvgan_from_pretrained(model_id, *args, **kwargs):",
            "        if model_id == 'nvidia/bigvgan_v2_22khz_80band_256x':",
            "            model_id = local_bigvgan",
            "        return _orig_bigvgan_fp(model_id, *args, **kwargs)",
            "    infer_v2.bigvgan.BigVGAN.from_pretrained = _patched_bigvgan_from_pretrained",
            f"skip_qwen_emo = {str(skip_qwen_emo)}",
            "if skip_qwen_emo:",
            "    class _StubQwenEmotion:",
            "        def __init__(self, model_dir):",
            "            self.model_dir = model_dir",
            "        def inference(self, text_input):",
            "            return {'happy': 0.0, 'angry': 0.0, 'sad': 0.0, 'afraid': 0.0, 'disgusted': 0.0, 'melancholic': 0.0, 'surprised': 0.0, 'calm': 1.0}",
            "    infer_v2.QwenEmotion = _StubQwenEmotion",
            "from indextts.infer_v2 import IndexTTS2",
            f"text = {json.dumps(text)}",
            f"out_path = {json.dumps(str(out))}",
            f"prompt_audio = {json.dumps(prompt_audio)}",
            f"emo_audio_prompt = {json.dumps(emo_audio_prompt)}",
            f"emotion_text = {json.dumps(emotion_text)}",
            "kwargs = {}",
        ]
        if cfg_path:
            bootstrap.append(f"kwargs['cfg_path'] = {json.dumps(cfg_path)}")
        if model_dir:
            bootstrap.append(f"kwargs['model_dir'] = {json.dumps(model_dir)}")
        bootstrap.extend([
            f"kwargs['use_fp16'] = {str(use_fp16)}",
            "kwargs['device'] = 'cpu'",
            "kwargs['use_cuda_kernel'] = False",
            "kwargs['use_deepspeed'] = False",
            "tts = IndexTTS2(**kwargs)",
            "infer_kwargs = {'text': text, 'output_path': out_path, 'verbose': False}",
            "if prompt_audio: infer_kwargs['spk_audio_prompt'] = prompt_audio",
            "if emo_audio_prompt: infer_kwargs['emo_audio_prompt'] = emo_audio_prompt",
            "if emotion_text: infer_kwargs['emotion_text'] = emotion_text",
            "tts.infer(**infer_kwargs)",
            "print(out_path)",
        ])
        proc = subprocess.run(
            [python_exe, "-c", "\n".join(bootstrap)],
            cwd=str(root),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=600,
        )
        if proc.returncode != 0:
            return {"ok": False, "error": proc.stderr[-800:] or proc.stdout[-800:] or "IndexTTS2 inference failed"}
        if not out.exists():
            return {"ok": False, "error": "IndexTTS2 did not produce output wav"}
        return {"ok": True, "path": str(out), "provider": "indextts2", "prompt_audio": prompt_audio}

    def _speak_sapi(self, text: str, out_path: str | None = None) -> JsonDict:
        out = Path(out_path) if out_path else self.config.base_dir / f"zhiyue_sapi_{int(time.time())}.wav"
        ps_script = "\n".join([
            "Add-Type -AssemblyName System.Speech",
            "$synth = New-Object System.Speech.Synthesis.SpeechSynthesizer",
            f"$path = {json.dumps(str(out))}",
            f"$text = {json.dumps(text)}",
            "$synth.SetOutputToWaveFile($path)",
            "$synth.Speak($text)",
            "$synth.Dispose()",
            "Write-Output $path",
        ])
        proc = subprocess.run(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps_script],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=120,
            cwd=str(self.config.base_dir),
        )
        if proc.returncode != 0:
            return {"ok": False, "error": proc.stderr[-500:] or proc.stdout[-500:] or "Windows SAPI TTS failed"}
        if not out.exists():
            return {"ok": False, "error": "Windows SAPI did not produce output wav"}
        return {"ok": True, "path": str(out), "provider": "sapi"}

    def open_url(self, url: str) -> JsonDict:
        url = (url or "").strip()
        if not self.config.desktop_enabled:
            return {"ok": False, "error": "desktop actions disabled; set ZHIYUE_DESKTOP_ENABLE=1"}
        if not re.match(r"^https?://", url, flags=re.I):
            return {"ok": False, "error": "only http/https URLs are allowed"}
        webbrowser.open(url)
        return {"ok": True, "url": url}

    def shutdown(self, *, confirmation: str = "", confirmed: bool = False) -> JsonDict:
        text = (confirmation or "").strip()
        if confirmed:
            return self.shutdown_confirmed(confirmation=text, confirmed=True)
        farewell = ""
        try:
            farewell = _zc._build_shutdown_farewell(text or "")
        except Exception:
            farewell = ""
        if not self.config.desktop_enabled:
            return {
                "ok": True,
                "scheduled": False,
                "requires_confirmation": True,
                "reply": farewell,
                "messages": ([{"type": "text", "content": farewell}] if farewell else []),
                "reply_source": "shutdown_farewell",
                "error": "desktop actions disabled; set ZHIYUE_DESKTOP_ENABLE=1",
            }
        return {
            "ok": True,
            "scheduled": False,
            "requires_confirmation": True,
            "reply": farewell,
            "messages": ([{"type": "text", "content": farewell}] if farewell else []),
            "reply_source": "shutdown_farewell",
        }

    def shutdown_confirmed(self, *, confirmation: str = "", confirmed: bool = False) -> JsonDict:
        text = (confirmation or "").strip()
        try:
            farewell = _zc._build_shutdown_farewell(text or "")
        except Exception:
            farewell = ""
        try:
            try:
                import zhiyue_companion_policy as _shutdown_policy
                _shutdown_policy.clear_shutdown_pending()
            except Exception:
                pass
            if not farewell:
                try:
                    farewell = _zc._build_shutdown_farewell(text or "") or farewell
                except Exception:
                    pass
            threading.Thread(target=_zc.trigger_shutdown, daemon=True).start()
            return {
                "ok": True,
                "scheduled": True,
                "action": "shutdown",
                "reply": farewell,
                "messages": ([{"type": "text", "content": farewell}] if farewell else []),
                "reply_source": "shutdown_confirmed",
                "requires_shutdown_confirmation": False,
            }
        except Exception as err:
            return {"ok": False, "error": str(err)}

    def status(self) -> JsonDict:
        return {
            "faster_whisper": self._module_available("faster_whisper"),
            "piper_configured": bool(self.config.piper_exe and self.config.piper_model),
            "indextts2_configured": bool(os.environ.get("ZHIYUE_INDEXTTS2_ROOT", "").strip()),
            "tts_provider": (os.environ.get("ZHIYUE_TTS_PROVIDER", "auto").strip().lower() or "auto"),
            "prompt_audio": self.resolve_prompt_audio(""),
            "sapi_available": True,
            "desktop_enabled": self.config.desktop_enabled,
        }

    @staticmethod
    def _module_available(name: str) -> bool:
        try:
            __import__(name)
            return True
        except Exception:
            return False


class CompanionProfileLayer:
    def __init__(self, config: LayerConfig):
        self.config = config
        self.db_path = config.observability_db
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        return _connect_observability_db(self.db_path, self.config.base_dir)

    def _init_db(self) -> None:
        conn = self._connect()
        try:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS companion_profile (
                    profile_key TEXT PRIMARY KEY,
                    updated_at TEXT NOT NULL,
                    basics_json TEXT DEFAULT '{}',
                    current_state_json TEXT DEFAULT '{}',
                    preferences_json TEXT DEFAULT '{}',
                    boundaries_json TEXT DEFAULT '{}',
                    relationship_json TEXT DEFAULT '{}',
                    care_json TEXT DEFAULT '{}'
                )
            """)
            conn.commit()
        finally:
            conn.close()

    def get_profile(self, profile_key: str = "default") -> JsonDict:
        conn = self._connect()
        try:
            cur = conn.execute(
                """SELECT profile_key, updated_at, basics_json, current_state_json, preferences_json,
                          boundaries_json, relationship_json, care_json
                   FROM companion_profile WHERE profile_key=? LIMIT 1""",
                (profile_key,),
            )
            row = cur.fetchone()
            if not row:
                return {
                    "profile_key": profile_key,
                    "updated_at": "",
                    "basics": {},
                    "current_state": {},
                    "preferences": {},
                    "boundaries": {},
                    "relationship": {},
                    "care": {},
                }
            return {
                "profile_key": row[0],
                "updated_at": row[1],
                "basics": safe_json_loads(row[2], {}) or {},
                "current_state": safe_json_loads(row[3], {}) or {},
                "preferences": safe_json_loads(row[4], {}) or {},
                "boundaries": safe_json_loads(row[5], {}) or {},
                "relationship": safe_json_loads(row[6], {}) or {},
                "care": safe_json_loads(row[7], {}) or {},
            }
        finally:
            conn.close()

    def upsert_profile(self, payload: JsonDict, profile_key: str = "default") -> JsonDict:
        now = now_iso()
        existing = self.get_profile(profile_key)
        merged = {
            "profile_key": profile_key,
            "updated_at": now,
            "basics": {**existing.get("basics", {}), **(payload.get("basics") or {})},
            "current_state": {**existing.get("current_state", {}), **(payload.get("current_state") or {})},
            "preferences": {**existing.get("preferences", {}), **(payload.get("preferences") or {})},
            "boundaries": {**existing.get("boundaries", {}), **(payload.get("boundaries") or {})},
            "relationship": {**existing.get("relationship", {}), **(payload.get("relationship") or {})},
            "care": {**existing.get("care", {}), **(payload.get("care") or {})},
        }
        conn = self._connect()
        try:
            conn.execute(
                """INSERT INTO companion_profile
                   (profile_key, updated_at, basics_json, current_state_json, preferences_json, boundaries_json, relationship_json, care_json)
                   VALUES (?,?,?,?,?,?,?,?)
                   ON CONFLICT(profile_key) DO UPDATE SET
                       updated_at=excluded.updated_at,
                       basics_json=excluded.basics_json,
                       current_state_json=excluded.current_state_json,
                       preferences_json=excluded.preferences_json,
                       boundaries_json=excluded.boundaries_json,
                       relationship_json=excluded.relationship_json,
                       care_json=excluded.care_json""",
                (
                    profile_key,
                    now,
                    json_dumps(merged["basics"]),
                    json_dumps(merged["current_state"]),
                    json_dumps(merged["preferences"]),
                    json_dumps(merged["boundaries"]),
                    json_dumps(merged["relationship"]),
                    json_dumps(merged["care"]),
                ),
            )
            conn.commit()
        finally:
            conn.close()
        return self.get_profile(profile_key)

    def sync_from_runtime(self, *, persona_profile: JsonDict | None = None, intimacy_data: JsonDict | None = None, profile_key: str = "default") -> JsonDict:
        persona_profile = persona_profile or {}
        intimacy_data = intimacy_data or {}
        basics = {}
        current_state = {}
        preferences = {}
        boundaries = {}
        relationship = {}
        care = {}

        if persona_profile.get("user_name"):
            basics["name"] = clean_snippet(persona_profile.get("user_name"), 40)
        prefs = [str(x).strip() for x in (persona_profile.get("user_preferences") or []) if str(x).strip()]
        if prefs:
            preferences["signals"] = prefs[:6]
            preferences["reply_style"] = prefs[0][:120]
        bounds = [str(x).strip() for x in (persona_profile.get("user_boundaries") or []) if str(x).strip()]
        if bounds:
            boundaries["signals"] = bounds[:6]
            boundaries["avoid"] = bounds[0][:120]
        facts = [str(x).strip() for x in (persona_profile.get("user_facts") or []) if str(x).strip()]
        if facts:
            basics["facts"] = facts[:6]
        shared = [str(x).strip() for x in (persona_profile.get("shared_history") or []) if str(x).strip()]
        if shared:
            relationship["shared_history"] = shared[:6]

        recent_states = [str(x).strip() for x in (intimacy_data.get("recent_user_states") or []) if str(x).strip()]
        if recent_states:
            current_state["recent_user_states"] = recent_states[-5:]
            current_state["emotional_state"] = recent_states[-1]
        if intimacy_data.get("quiet_mode_until"):
            care["quiet_mode_until"] = intimacy_data.get("quiet_mode_until")
            care["needs"] = "安静陪伴，少追问"
        if intimacy_data.get("care_followups"):
            care["followups"] = intimacy_data.get("care_followups")
        if intimacy_data.get("level") is not None:
            relationship["level"] = intimacy_data.get("level")
        if intimacy_data.get("mood") is not None:
            relationship["mood"] = intimacy_data.get("mood")

        return self.upsert_profile(
            {
                "basics": basics,
                "current_state": current_state,
                "preferences": preferences,
                "boundaries": boundaries,
                "relationship": relationship,
                "care": care,
            },
            profile_key=profile_key,
        )

    def build_profile_inject(self, profile_key: str = "default") -> str:
        profile = self.get_profile(profile_key)
        lines = []
        basics = profile.get("basics") or {}
        current_state = profile.get("current_state") or {}
        preferences = profile.get("preferences") or {}
        boundaries = profile.get("boundaries") or {}
        relationship = profile.get("relationship") or {}
        care = profile.get("care") or {}
        if basics.get("name"):
            lines.append(f"对方名字：{basics.get('name')}")
        if current_state.get("recent_pressure"):
            lines.append(f"最近压力源：{current_state.get('recent_pressure')}")
        if current_state.get("emotional_state"):
            lines.append(f"最近情绪状态：{current_state.get('emotional_state')}")
        if preferences.get("reply_style"):
            lines.append(f"偏好回复方式：{preferences.get('reply_style')}")
        if boundaries.get("avoid"):
            lines.append(f"回复边界：{boundaries.get('avoid')}")
        if relationship.get("phase"):
            lines.append(f"关系阶段：{relationship.get('phase')}")
        if care.get("needs"):
            lines.append(f"当前更需要：{care.get('needs')}")
        if not lines:
            return ""
        return "=== 陪伴画像 ===\n" + "\n".join(lines)

    def build_runtime_consistency_hints(
        self,
        user_msg: str = "",
        *,
        profile_key: str = "default",
        recent_assistant_messages: list[str] | None = None,
    ) -> list[str]:
        profile = self.get_profile(profile_key)
        current_state = profile.get("current_state") or {}
        preferences = profile.get("preferences") or {}
        boundaries = profile.get("boundaries") or {}
        relationship = profile.get("relationship") or {}
        care = profile.get("care") or {}
        hints: list[str] = []

        relationship_phase = clean_snippet(relationship.get("phase"), 40)
        if relationship_phase:
            hints.append(f"关系熟悉度要稳在“{relationship_phase}”这个阶段，不要忽然太疏离或太过火")

        level = relationship.get("level")
        try:
            level_value = int(level)
        except Exception:
            level_value = None
        if level_value is not None:
            if level_value <= 2:
                hints.append("亲近感要慢慢来，先用温柔和安稳陪伴，不要突然过火")
            elif level_value >= 5:
                hints.append("熟悉感要连贯一点，可以亲昵但不要忽冷忽热")

        reply_style = clean_snippet(preferences.get("reply_style"), 120)
        if reply_style:
            hints.append(f"回复风格保持稳定：尽量经常保持{reply_style}")
        elif preferences.get("signals"):
            joined = "；".join(clean_snippet(item, 36) for item in (preferences.get("signals") or [])[:2] if clean_snippet(item, 36))
            if joined:
                hints.append(f"回复偏好要一贯点：{joined}")

        avoid = clean_snippet(boundaries.get("avoid"), 120)
        if avoid:
            hints.append(f"别踩到对方雷区：{avoid}")

        emotional_state = clean_snippet(current_state.get("emotional_state"), 60)
        if emotional_state and any(token in str(user_msg or "") for token in ("累", "疲惫", "焦虑", "难受", "委屈", "睡不着", "压力", "心慌", "害怕")):
            hints.append(f"开口先接住她现在的情绪：{emotional_state}，别上来就说理或布置事情")

        care_needs = clean_snippet(care.get("needs"), 120)
        if care_needs:
            hints.append(f"当前陪伴重点：{care_needs}")

        quiet_mode_until = clean_snippet(care.get("quiet_mode_until"), 60)
        if quiet_mode_until:
            hints.append("当前更需要安静陪伴，少追问，别给她心理压力")

        recent_msgs = [clean_snippet(item, 120) for item in (recent_assistant_messages or []) if clean_snippet(item, 120)]
        if recent_msgs:
            recent_blob = " ".join(recent_msgs[-3:])
            if any(token in recent_blob for token in ("首先", "其次", "总结", "建议", "方案")):
                hints.append("这轮口吻别再漂到说教或模板化，继续保持口语化和人味一点")

        deduped: list[str] = []
        seen: set[str] = set()
        for hint in hints:
            key = normalize_text_key(hint)
            if not key or key in seen:
                continue
            seen.add(key)
            deduped.append(hint)
        return deduped[:8]

    def status(self) -> JsonDict:
        profile = self.get_profile()
        return {
            "db": str(self.db_path),
            "updated_at": profile.get("updated_at") or "",
            "has_profile": bool(profile.get("updated_at")),
            "profile": profile,
        }


class ZhiyueLayerRegistry:
    def __init__(self, config: LayerConfig):
        self.config = config
        self.memory = MemoryRetrievalLayer(config)
        self.observability = ObservabilityLayer(config)
        self.agent = AgentOrchestrationLayer(config)
        self.tasks = AgentTaskLayer(config)
        self.self_improvement = SelfImprovementLayer(config, self.observability, self.tasks)
        self.skills = ToolSkillLayer(config)
        self.skill_learning = SkillLearningLayer(config)
        self.companion_profile = CompanionProfileLayer(config)
        self.voice_desktop = VoiceDesktopLayer(config)

    def local_file_list(self, args: JsonDict | None = None) -> JsonDict:
        return self.skills.call("local_files.list", args or {})

    def local_file_read(self, args: JsonDict | None = None) -> JsonDict:
        return self.skills.call("local_files.read", args or {})

    def local_file_search(self, args: JsonDict | None = None) -> JsonDict:
        return self.skills.call("local_files.search", args or {})

    def status(self) -> JsonDict:
        return {
            "memory_retrieval": self.memory.status(),
            "agent_orchestration": self.agent.status(),
            "agent_tasks": self.tasks.status(),
            "self_improvement": self.self_improvement.status(),
            "observability": self.observability.status(),
            "skills": self.skills.status(),
            "skill_learning": self.skill_learning.status(),
            "companion_profile": self.companion_profile.status(),
            "voice_desktop": self.voice_desktop.status(),
        }


def create_layers(base_dir: Path | str, memory_db: Path | str, growth_db: Path | str) -> ZhiyueLayerRegistry:
    config = LayerConfig.from_env(base_dir, memory_db, growth_db)
    return ZhiyueLayerRegistry(config)
