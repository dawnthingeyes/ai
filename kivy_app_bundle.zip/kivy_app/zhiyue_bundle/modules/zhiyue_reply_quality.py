# -*- coding: utf-8 -*-
from __future__ import annotations

import re
import inspect
import zhiyue_human_like as human_like

MAX_HUMAN_REWRITE_ROUNDS = 2
MAX_HUMAN_REWRITE_NO_IMPROVE = 1


def _build_bucket_rewrite_hints(user_msg, evaluation):
    hints = []
    question_type = str((evaluation or {}).get("question_type") or human_like.classify_question_type(user_msg))
    user_attitude = str((evaluation or {}).get("user_attitude") or human_like.classify_user_attitude(user_msg))
    if question_type == "planning_probe":
        hints.append("human_like_rewrite: for planning questions, answer the currently knowable part first. Do not reply only with 'give me more scope'.")
        hints.append("human_like_rewrite: if details are missing, first state the most likely priority or current known arrangement in one short line, then ask one tiny follow-up only if needed.")
    if question_type == "emotion_support" or user_attitude == "vulnerable":
        hints.append("human_like_rewrite: for emotional support, first hold the feeling in the opening words, then give one light companion move or one gentle pinpoint question.")
        hints.append("human_like_rewrite: avoid empty listening-only lines like '我在听' or '你继续说' unless they are attached to concrete emotional holding.")
    return hints


def _rewrite_still_bad(question_type, evaluation):
    issues = set((evaluation or {}).get("issues") or [])
    if "unanswered_question" in issues:
        return True
    if question_type == "planning_probe" and any(issue in issues for issue in ("avoidant_attitude", "weak_anchor")):
        return True
    if question_type == "emotion_support" and any(issue in issues for issue in ("emotion_not_held", "cold_attitude", "avoidant_attitude")):
        return True
    return False


def reply_lacks_topic_anchor(user_msg, reply, *, topic_anchor_rules):
    msg = (user_msg or "").strip().lower()
    text = (reply or "").strip().lower()
    if not msg or not text:
        return False
    matched_topic = False
    for triggers, anchors in topic_anchor_rules:
        if any(trigger in msg for trigger in triggers):
            matched_topic = True
            if any(anchor in text for anchor in anchors):
                return False
    return matched_topic


def build_service_unavailable_payload(
    user_msg="",
    *,
    channel,
    route,
    last_lm_error,
):
    import random
    persona_phrases = [
        "乖我现在在忙，过会回你",
        "抱歉，我暂时连接不上，稍后回复您",
        "等等，我这边有点问题，过会再试",
        "我现在有点忙，稍后回来找你",
        "稍等，我处理完这个就回来",
        "我现在不在，过会回复你",
    ]
    fallback_reply = random.choice(persona_phrases)
    payload = {
        "reply": fallback_reply,
        "messages": [],
        "error": True,
        "error_code": "lm_unavailable",
        "error_message": last_lm_error or "language model unavailable",
        "reply_source": "service_unavailable",
        "used_fallback": False,
        "reply_repaired": False,
        "judge": {
            "passed": False,
            "score": 0,
            "issues": ["lm_unavailable"],
            "reason": last_lm_error or "language model unavailable",
            "revision_advice": "",
            "needs_rewrite": False,
            "reply_kind": "meaningless",
        },
        "feedback_classification": {
            "label": "neutral",
            "needs_action": False,
            "problem_report": False,
            "approval": False,
            "rejection": False,
            "reason": last_lm_error or "language model unavailable",
        },
    }
    return payload


def _call_run_lm_judge_loop_compat(
    run_lm_judge_loop,
    user_msg,
    history,
    *,
    seed_reply="",
    route_hint="lm",
    rule_hints=None,
    user_directives=None,
    allow_persistent_directives=True,
):
    kwargs = {
        "seed_reply": seed_reply,
        "route_hint": route_hint,
    }
    if rule_hints is not None:
        kwargs["rule_hints"] = rule_hints
    try:
        params = inspect.signature(run_lm_judge_loop).parameters
        if "user_directives" in params:
            kwargs["user_directives"] = user_directives
        if "allow_persistent_directives" in params:
            kwargs["allow_persistent_directives"] = allow_persistent_directives
    except (TypeError, ValueError):
        params = None
    try:
        return run_lm_judge_loop(user_msg, history, **kwargs)
    except TypeError as err:
        if "unexpected keyword argument" not in str(err):
            raise

    # 兼容旧测试桩和旧调用签名。
    legacy_kwargs = {
        "seed_reply": seed_reply,
        "route_hint": route_hint,
    }
    if rule_hints is not None:
        legacy_kwargs["rule_hints"] = rule_hints
    try:
        return run_lm_judge_loop(user_msg, history, **legacy_kwargs)
    except TypeError as err:
        msg = str(err)
        if "unexpected keyword argument" not in msg:
            raise
        legacy_kwargs.pop("rule_hints", None)
        return run_lm_judge_loop(user_msg, history, **legacy_kwargs)


def enforce_model_reply_quality(
    result,
    user_msg,
    *,
    channel,
    history,
    run_lm_judge_loop,
    clean_reply,
    build_display_messages,
    build_service_unavailable_payload_fn,
    recover_specific_reply_fn=None,
    extra_rewrite_hints_fn=None,
    self_diagnose_fn=None,
    user_directives=None,
    allow_persistent_directives=True,
):
    if not isinstance(result, dict) or result.get("coalesced_skip"):
        return result
    _ = (history, recover_specific_reply_fn, extra_rewrite_hints_fn, self_diagnose_fn, user_directives, allow_persistent_directives)
    raw_reply = str(result.get("reply") or "")
    raw_eval = human_like.evaluate_human_likeness(
        user_msg,
        raw_reply,
        route=str(result.get("reply_source") or result.get("rule_reply") or "seed"),
    )
    if not raw_reply.strip():
        payload = build_service_unavailable_payload_fn(
            user_msg,
            channel=channel,
            route=((result.get("agent_run") or {}).get("route") or {}).get("name") or result.get("rule_reply") or "empty_reply",
        )
        payload["reply_quality"] = {"passed": False, "action": "rejected_empty"}
        return payload

    if callable(recover_specific_reply_fn):
        try:
            recovered = recover_specific_reply_fn(user_msg)
        except Exception:
            recovered = ""
        if isinstance(recovered, str) and recovered.strip():
            result["recover_specific_reply"] = recovered.strip()
            raw_eval = human_like.evaluate_human_likeness(
                user_msg,
                raw_reply,
                route=str(result.get("reply_source") or result.get("rule_reply") or "seed"),
            )

    route_hint = ((result.get("agent_run") or {}).get("route") or {}).get("name") or result.get("rule_reply") or result.get("reply_source") or "lm"
    pipeline = _call_run_lm_judge_loop_compat(
        run_lm_judge_loop,
        user_msg,
        history,
        seed_reply=raw_reply,
        route_hint=route_hint,
        user_directives=user_directives,
        allow_persistent_directives=allow_persistent_directives,
    )
    judge = pipeline.get("judge") or {}
    result["reply"] = raw_reply
    try:
        result["messages"] = build_display_messages(user_msg, raw_reply, allow_followup=False, media_actions=result.get("media_actions"))
    except TypeError:
        result["messages"] = build_display_messages(user_msg, raw_reply, allow_followup=False)
    result["judge"] = judge
    result["judge_trace"] = pipeline.get("judge_trace") or []
    result["reply_repaired"] = bool(pipeline.get("reply_repaired"))
    result["used_fallback"] = False
    result["reply_source"] = pipeline.get("reply_source") or "lm_judge_loop"
    result["human_likeness"] = raw_eval
    result["reply_quality"] = {
        "passed": bool(judge.get("passed")),
        "score": judge.get("score"),
        "issues": judge.get("issues") or [],
        "action": "record_only",
    }
    result["self_correction"] = {
        "applied": False,
        "reason": "",
        "before": {},
        "after": {},
        "rounds": 0,
    }
    return result
