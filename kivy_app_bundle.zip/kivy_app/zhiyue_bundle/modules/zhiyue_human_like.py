# -*- coding: utf-8 -*-
from __future__ import annotations

import re
from typing import Any

from zhiyue_semantic_routing import score_overlap  # canonical impl, was duplicated locally


_EXPLANATION_MARKERS = (
    "首先", "其次", "最后", "本质上", "核心是", "原因是", "意味着", "总结一下",
    "从整体上", "结构上", "逻辑上", "步骤", "方案",
)
_CONTROL_MARKERS = (
    "你可以", "建议你", "可以考虑", "我建议", "执行", "调用", "工具", "接口",
    "系统", "模型", "路由", "能力", "协议", "配置",
)
_TOOL_EXPOSURE_MARKERS = (
    "文件", "网页", "表单", "导出", "payload", "json", "trace", "run_id",
)
_AI_DISCLOSURE_MARKERS = (
    "作为AI",
    "作为一个AI",
    "我是AI",
    "我只是AI",
    "语言模型",
    "大语言模型",
    "ChatGPT",
    "OpenAI",
)
_LIST_RE = re.compile(r"(^|\n)\s*(?:[-*]|[0-9]+\.)\s+")
_GENERIC_REPLY_MARKERS = (
    "我在听", "你继续说", "你说", "我在", "慢慢说", "我听着",
)
_QUESTION_MARKERS = (
    "？", "?", "吗", "是不是", "什么", "为啥", "为什么", "怎么", "哪", "什么时候", "会不会", "还是",
)
_ANSWER_PROTOTYPES = {
    "persona_food": ["你喜欢甜的还是辣的", "能吃辣吗", "爱吃甜的吗"],
    "persona_profile": ["哪里人", "在哪读书", "学什么", "生日什么时候"],
    "future_plan": ["明天最重要的事", "明天干啥", "后天要做什么"],
    "identity_probe": ["你是不是ai", "你是不是机器人", "你是不是张致悦"],
}
_ANSWER_TOKENS = {
    "persona_food": ["甜", "辣"],
    "persona_profile": ["兰州", "河南", "中医", "6月14", "六月十四"],
    "future_plan": ["明天", "安排", "范围", "行测", "申论", "笔试"],
    "identity_probe": ["张致悦", "ai", "机器人"],
}
_EMOTION_SUPPORT_MARKERS = ("焦虑", "难受", "委屈", "崩溃", "烦", "累", "害怕", "不舒服", "好想哭", "心慌", "压力")
_WARM_MARKERS = ("抱抱", "别怕", "别急", "我在", "跟我说", "慢慢说", "先歇", "陪你", "我陪你", "先抱抱", "没事")
_COLD_MARKERS = ("自己想", "你自己", "随便", "不知道", "不清楚", "关我", "行吧", "哦", "那就这样")
_PRESSURE_MARKERS = ("必须", "赶紧", "立刻", "马上", "先去", "现在就", "最好", "应该", "得", "务必")
_AVOIDANT_MARKERS = ("你继续说", "再给我一句范围", "你自己看", "回头再说", "懒得", "不想说")
_PLANNING_MARKERS = ("明天", "后天", "安排", "计划", "最重要", "几点", "什么时候", "要做什么")
_RELATION_MARKERS = ("想我", "陪我", "别走", "是不是不喜欢我", "吃醋", "想你")
_USER_SOFT_MARKERS = ("有点", "好像", "想", "可以吗", "陪我", "帮我", "我现在", "我有点")
_USER_HARD_MARKERS = ("必须", "立刻", "马上", "给我", "别废话", "赶紧", "现在就")


def _looks_like_planning_prompt(msg: str) -> bool:
    return any(marker in msg for marker in _PLANNING_MARKERS) or score_overlap(msg, _ANSWER_PROTOTYPES["future_plan"]) >= 0.26


def _looks_like_emotion_prompt(msg: str) -> bool:
    return any(marker in msg for marker in _EMOTION_SUPPORT_MARKERS)


def _clean_text(text: str) -> str:
    return re.sub(r"\s+", " ", str(text or "")).strip()


def _message_terms(user_msg: str) -> list[str]:
    raw = re.findall(r"[\u4e00-\u9fff]{2,}|[a-zA-Z0-9_]{3,}", str(user_msg or ""))
    seen = set()
    result = []
    for item in raw:
        key = item.lower()
        if key in seen:
            continue
        seen.add(key)
        result.append(item)
        if len(result) >= 8:
            break
    return result


def classify_question_type(user_msg: str) -> str:
    msg = str(user_msg or "").strip().lower()
    if not msg:
        return "open_chat"
    if score_overlap(msg, _ANSWER_PROTOTYPES["identity_probe"]) >= 0.26:
        return "identity_probe"
    if score_overlap(msg, _ANSWER_PROTOTYPES["persona_food"]) >= 0.26:
        return "preference_probe"
    if score_overlap(msg, _ANSWER_PROTOTYPES["persona_profile"]) >= 0.26:
        return "persona_fact_probe"
    if score_overlap(msg, _ANSWER_PROTOTYPES["future_plan"]) >= 0.26:
        return "planning_probe"
    if _looks_like_emotion_prompt(msg):
        return "emotion_support"
    if _looks_like_planning_prompt(msg):
        return "planning_probe"
    if any(marker in msg for marker in _RELATION_MARKERS):
        return "relationship_probe"
    if any(marker in msg for marker in ("喜欢", "偏爱", "甜", "辣", "爱吃", "口味")):
        return "preference_probe"
    if any(marker in msg for marker in _QUESTION_MARKERS):
        return "direct_question"
    return "open_chat"


def classify_user_attitude(user_msg: str) -> str:
    msg = str(user_msg or "").strip()
    if not msg:
        return "neutral"
    if _looks_like_emotion_prompt(msg):
        return "vulnerable"
    hard_hits = sum(1 for marker in _USER_HARD_MARKERS if marker in msg)
    soft_hits = sum(1 for marker in _USER_SOFT_MARKERS if marker in msg)
    if hard_hits >= 1:
        return "urgent"
    if soft_hits >= 1:
        return "soft"
    if any(marker in msg for marker in _QUESTION_MARKERS):
        return "probing"
    return "neutral"


def compress_state_bucket(state_context: str | None) -> str:
    parts = [part.strip() for part in str(state_context or "").split("|") if part.strip()]
    if not parts:
        return "neutral"
    keep: list[str] = []
    for part in parts:
        keep.append(part)
        if part.startswith("stage:") or len(keep) >= 3:
            break
    return "|".join(keep[:3]) if keep else "neutral"


def evaluation_has_bad_signal(evaluation: dict[str, Any]) -> bool:
    if not isinstance(evaluation, dict):
        return False
    if evaluation.get("needs_rewrite") or evaluation.get("issues"):
        return True
    dimensions = evaluation.get("dimensions") if isinstance(evaluation.get("dimensions"), dict) else {}
    for value in dimensions.values():
        try:
            score = float(value or 0)
        except Exception:
            continue
        if score < 7.0 or score > 9.8:
            return True
    return False


def evaluate_human_likeness(user_msg: str, reply: str, *, route: str = "") -> dict[str, Any]:
    raw_user_msg = str(user_msg or "")
    text = _clean_text(reply)
    route_name = str(route or "").lower()
    question_type = classify_question_type(raw_user_msg)
    user_attitude = classify_user_attitude(raw_user_msg)
    looks_planning = _looks_like_planning_prompt(raw_user_msg)
    looks_emotion = _looks_like_emotion_prompt(raw_user_msg)
    issues: list[str] = []
    score = 10.0

    if not text:
        return {
            "score": 0.0,
            "issues": ["empty_reply"],
            "needs_rewrite": True,
            "question_type": question_type,
            "user_attitude": user_attitude,
            "attitude": "empty",
            "issue_buckets": ["empty_reply"],
            "dimensions": {
                "naturalness": 0.0,
                "specificity": 0.0,
                "warmth": 0.0,
                "emotional_attunement": 0.0,
                "attitude_fit": 0.0,
            },
        }

    sentence_count = max(1, len([x for x in re.split(r"[。！？?!]", text) if x.strip()]))
    if len(text) > 88:
        issues.append("long_monologue")
        score -= 2.0
    if sentence_count >= 4 and len(text) > 52:
        issues.append("over_explained")
        score -= 1.4
    if _LIST_RE.search(text):
        issues.append("list_tone")
        score -= 1.6

    explanation_hits = sum(1 for marker in _EXPLANATION_MARKERS if marker in text)
    if explanation_hits >= 2:
        issues.append("explanation_heavy")
        score -= min(2.2, explanation_hits * 0.7)

    control_hits = sum(1 for marker in _CONTROL_MARKERS if marker in text)
    if control_hits >= 1 and "technical" not in route_name and "review" not in route_name:
        issues.append("control_heavy")
        score -= min(2.0, control_hits * 0.8)

    tool_hits = sum(1 for marker in _TOOL_EXPOSURE_MARKERS if marker in text)
    if tool_hits >= 2 and "technical" not in route_name and "review" not in route_name:
        issues.append("tool_exposure")
        score -= 1.6

    # Human-likeness killer: unsolicited "I'm an AI model" disclosure in normal companionship chat.
    if any(marker in text for marker in _AI_DISCLOSURE_MARKERS) and "technical" not in route_name and "review" not in route_name:
        issues.append("ai_disclaimer")
        score -= 3.2

    terms = _message_terms(raw_user_msg)
    anchor_ok = any(term in text for term in terms[:3]) if terms else False
    for name, protos in _ANSWER_PROTOTYPES.items():
        if score_overlap(raw_user_msg, protos) >= 0.26 and any(token in text for token in _ANSWER_TOKENS.get(name, [])):
            anchor_ok = True
            break
    if terms and not anchor_ok:
        issues.append("weak_anchor")
        score -= 0.6

    is_question = any(marker in raw_user_msg for marker in _QUESTION_MARKERS)
    generic_reply = any(marker in text for marker in _GENERIC_REPLY_MARKERS)
    if is_question and generic_reply:
        issues.append("unanswered_question")
        score -= 2.4
    if looks_planning and any(marker in text for marker in _AVOIDANT_MARKERS):
        if "avoidant_attitude" not in issues:
            issues.append("avoidant_attitude")
        score -= 1.3
    if looks_emotion and generic_reply:
        if "emotion_not_held" not in issues:
            issues.append("emotion_not_held")
        score -= 1.6

    if len(text) > 36 and sentence_count <= 1:
        issues.append("single_block_reply")
        score -= 0.8

    warmth_hits = sum(1 for marker in _WARM_MARKERS if marker in text)
    cold_hits = sum(1 for marker in _COLD_MARKERS if marker in text)
    pressure_hits = sum(1 for marker in _PRESSURE_MARKERS if marker in text)
    avoidant_hits = sum(1 for marker in _AVOIDANT_MARKERS if marker in text)

    specificity_score = 10.0
    if "weak_anchor" in issues:
        specificity_score -= 2.2
    if "unanswered_question" in issues:
        specificity_score -= 3.0
    if generic_reply and len(text) <= 18:
        specificity_score -= 1.4
    if question_type in {"planning_probe", "preference_probe", "persona_fact_probe", "identity_probe", "direct_question"} and len(text) <= 8:
        specificity_score -= 1.0

    warmth_score = 6.8 + min(2.0, warmth_hits * 0.8) - min(3.0, cold_hits * 1.1)
    if "control_heavy" in issues:
        warmth_score -= 1.2
    if user_attitude in {"vulnerable", "soft"} and generic_reply:
        warmth_score -= 0.8

    emotional_attunement = 7.0 + min(2.0, warmth_hits * 0.6)
    if question_type == "emotion_support" or user_attitude == "vulnerable" or looks_emotion:
        if not any(marker in text for marker in _EMOTION_SUPPORT_MARKERS) and warmth_hits == 0:
            emotional_attunement -= 3.2
        if generic_reply:
            emotional_attunement -= 1.3
    else:
        emotional_attunement -= max(0.0, avoidant_hits * 0.4)

    naturalness = 10.0
    if "long_monologue" in issues:
        naturalness -= 2.0
    if "over_explained" in issues:
        naturalness -= 1.4
    if "list_tone" in issues:
        naturalness -= 1.0
    if "tool_exposure" in issues:
        naturalness -= 1.8
    if "single_block_reply" in issues:
        naturalness -= 0.8

    attitude_fit = 8.4 + min(1.0, warmth_hits * 0.3) - min(3.2, pressure_hits * 0.9) - min(2.4, avoidant_hits * 0.8)
    if "control_heavy" in issues:
        attitude_fit -= 1.6
    if user_attitude in {"vulnerable", "soft"} and pressure_hits >= 1:
        attitude_fit -= 1.1
    if question_type in {"planning_probe", "preference_probe", "persona_fact_probe", "identity_probe"} and generic_reply:
        attitude_fit -= 1.0
    if looks_planning and any(marker in text for marker in _AVOIDANT_MARKERS):
        attitude_fit -= 1.2

    if warmth_score < 4.8:
        issues.append("cold_attitude")
        score -= 1.2
    if attitude_fit < 5.2:
        issues.append("misaligned_attitude")
        score -= 1.4
    if pressure_hits >= 2 or ("control_heavy" in issues and user_attitude in {"vulnerable", "soft"}):
        if "pushy_attitude" not in issues:
            issues.append("pushy_attitude")
        score -= 1.1
    if avoidant_hits >= 1 and (question_type in {"planning_probe", "emotion_support", "direct_question"} or looks_planning or looks_emotion):
        issues.append("avoidant_attitude")
        score -= 1.0
    if emotional_attunement < 4.8 and (question_type == "emotion_support" or user_attitude == "vulnerable" or looks_emotion):
        issues.append("emotion_not_held")
        score -= 1.5

    attitude = "balanced"
    if "pushy_attitude" in issues or "control_heavy" in issues:
        attitude = "pushy"
    elif "avoidant_attitude" in issues:
        attitude = "avoidant"
    elif "cold_attitude" in issues:
        attitude = "cold"
    elif warmth_hits >= 1:
        attitude = "warm"

    dimensions = {
        "naturalness": round(max(0.0, min(10.0, naturalness)), 2),
        "specificity": round(max(0.0, min(10.0, specificity_score)), 2),
        "warmth": round(max(0.0, min(10.0, warmth_score)), 2),
        "emotional_attunement": round(max(0.0, min(10.0, emotional_attunement)), 2),
        "attitude_fit": round(max(0.0, min(10.0, attitude_fit)), 2),
    }
    issue_buckets = sorted(set(issues))

    needs_rewrite = score < 7.2 or any(
        flag in issues
        for flag in (
            "control_heavy",
            "tool_exposure",
            "long_monologue",
            "unanswered_question",
            "avoidant_attitude",
            "cold_attitude",
            "misaligned_attitude",
            "emotion_not_held",
            "ai_disclaimer",
        )
    )
    return {
        "score": round(max(0.0, score), 2),
        "issues": issues,
        "needs_rewrite": needs_rewrite,
        "question_type": question_type,
        "user_attitude": user_attitude,
        "attitude": attitude,
        "issue_buckets": issue_buckets,
        "dimensions": dimensions,
        "sentence_count": sentence_count,
        "chars": len(text),
    }


def requires_answer_fidelity(user_msg: str) -> bool:
    msg = str(user_msg or "")
    if any(marker in msg for marker in _QUESTION_MARKERS):
        return True
    for protos in _ANSWER_PROTOTYPES.values():
        if score_overlap(msg, protos) >= 0.26:
            return True
    return False


def build_human_like_rewrite_hints(user_msg: str, reply: str, evaluation: dict[str, Any]) -> list[str]:
    hints = [
        "human_like_rewrite: lower control feel; reply like a real close partner, not a system or assistant.",
        "human_like_rewrite: keep it in 2-4 short chat bubbles, each short and natural, avoid one long paragraph.",
        "human_like_rewrite: reduce explanation, summary, method talk, and explicit capability exposure.",
        "human_like_rewrite: prioritize emotional contact and natural continuity before task framing.",
        "human_like_rewrite: preserve natural chat features: catchphrases, slight repetition, sentence breaks, ellipsis (...), rhetorical questions, and small emotion words (哼/切/唔/好啦). Do NOT over-polish these away.",
    ]
    issues = set(evaluation.get("issues") or [])
    if "control_heavy" in issues or "tool_exposure" in issues:
        hints.append("human_like_rewrite: hide tool/process words; do not mention system, route, files, payload, protocol, or execution unless the user explicitly asks.")
    if "ai_disclaimer" in issues:
        hints.append("human_like_rewrite: do not mention being an AI/model/system; stay in-character as a real person and keep it natural.")
    if "long_monologue" in issues or "over_explained" in issues:
        hints.append("human_like_rewrite: shorten aggressively; do not explain everything, leave natural omission.")
    if "weak_anchor" in issues:
        hints.append("human_like_rewrite: softly anchor to one concrete word or feeling from the user message.")
    if "unanswered_question" in issues:
        hints.append("human_like_rewrite: answer the user's concrete question directly first; do not dissolve it into a generic listening reply.")
    if "cold_attitude" in issues or "emotion_not_held" in issues:
        hints.append("human_like_rewrite: keep the attitude warmer and more companion-like; don't sound cold, detached, or perfunctory.")
    if "pushy_attitude" in issues or "misaligned_attitude" in issues:
        hints.append("human_like_rewrite: lower pressure and preaching; do not command, lecture, or manage the user too hard.")
    if "avoidant_attitude" in issues:
        hints.append("human_like_rewrite: don't dodge with vague scope questions unless absolutely necessary; give the best concrete answer you can first.")
    return hints


def _split_pieces(reply: str) -> list[str]:
    text = _clean_text(reply)
    if not text:
        return []
    pieces: list[str] = []
    for block in re.split(r"\s*---+\s*", text):
        block = block.strip()
        if not block:
            continue
        parts = [part.strip() for part in re.split(r"(?<=[。！？?!~])", block) if part.strip()]
        if not parts:
            parts = [block]
        pieces.extend(parts)
    return pieces


def split_human_like_bubbles(reply: str, *, max_bubbles: int = 4, target_chars: int = 18, hard_max: int = 30) -> list[str]:
    text = _clean_text(reply)
    if "---" in text:
        forced = [part.strip() for part in re.split(r"\s*---+\s*", text) if part.strip()]
        return forced[:max_bubbles]
    pieces = _split_pieces(reply)
    if not pieces:
        return []
    bubbles: list[str] = []
    current = ""
    for piece in pieces:
        piece = piece.strip()
        if not piece:
            continue
        if not current:
            current = piece
            continue
        projected = current + piece
        if len(projected) <= target_chars:
            current = projected
            continue
        bubbles.append(current)
        current = piece
    if current:
        bubbles.append(current)

    compressed: list[str] = []
    for bubble in bubbles:
        if len(bubble) <= hard_max:
            compressed.append(bubble)
            continue
        parts = [x.strip() for x in re.split(r"[，,]", bubble) if x.strip()]
        if len(parts) <= 1:
            compressed.append(bubble[:hard_max].rstrip())
            remainder = bubble[hard_max:].strip()
            if remainder:
                compressed.append(remainder)
            continue
        carry = ""
        for part in parts:
            if not carry:
                carry = part
            elif len(carry) + len(part) + 1 <= hard_max:
                carry = carry + "，" + part
            else:
                compressed.append(carry)
                carry = part
        if carry:
            compressed.append(carry)
    return compressed[:max_bubbles]


def humanize_office_reply(user_msg: str, reply: str) -> str:
    text = _clean_text(reply)
    if not text:
        return ""
    replacements = [
        ("我已经", "我"),
        ("我先", "我"),
        ("结果在", "在"),
        ("整理好了", "弄好了"),
        ("先帮你", "我帮你"),
        ("你要我再", "要我再"),
        ("我可以直接接着来", "我接着来"),
        ("我已经把", "我把"),
    ]
    for src, dst in replacements:
        text = text.replace(src, dst)
    text = re.sub(r"\s+", " ", text).strip()
    bubbles = split_human_like_bubbles(text, max_bubbles=4, target_chars=20, hard_max=40)
    if not bubbles:
        return text
    return "---".join(bubbles[:4])
