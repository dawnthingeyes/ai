# -*- coding: utf-8 -*-
"""
Lightweight self-monitor for Zhiyue.

Runs isolated evals on a schedule and records findings/proposals only.
It never edits source files, never touches real DBs, and never calls desktop tools.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
import sqlite3 as _sql
from datetime import datetime
from pathlib import Path

from zhiyue_runtime_health import (
    model_service_ready,
    runtime_health_snapshot,
    wait_for_runtime_services,
)
from zhiyue_monitor_reporting import append_proposal, archive_stale_pending_proposals, collect_eval_failures
from zhiyue_project_paths import (
    BASE_DIR,
    INTIMACY_FILE,
    OBSERVABILITY_DB,
    SELF_MONITOR_FINDINGS_FILE as FINDINGS_FILE,
    SELF_MONITOR_LOG_FILE as LOG_FILE,
    SELF_MONITOR_PROPOSAL_ARCHIVE_FILE as PROPOSAL_ARCHIVE_FILE,
    SELF_MONITOR_PROPOSAL_FILE as PROPOSAL_FILE,
    SELF_MONITOR_STATE_FILE as STATE_FILE,
)
import zhiyue_growth_reviewer as growth_reviewer
import zhiyue_prompt_assets as prompt_assets


LOG_MAX_BYTES = max(1024, int(os.environ.get("ZHIYUE_SELF_MONITOR_LOG_MAX_KB", "512"))) * 1024
LOG_BACKUP_COUNT = max(1, int(os.environ.get("ZHIYUE_SELF_MONITOR_LOG_BACKUPS", "3")))
QUICK_DIALOG_RESULT_FILE = BASE_DIR / "evals" / "zhiyue_quick_dialog_result.json"
QUICK_DIALOG_SCRIPT = BASE_DIR / "zhiyue_quick_dialog_eval.py"
RANDOM_DAILY_RESULT_FILE = BASE_DIR / "evals" / "zhiyue_random_daily_10_result.json"
RANDOM_DAILY_SCRIPT = BASE_DIR / "zhiyue_random_daily_eval.py"
CODE_REVIEW_MATRIX_SCRIPT = BASE_DIR / "test_service_code_review.py"
INTERVAL_SECONDS = max(300, int(os.environ.get("ZHIYUE_SELF_MONITOR_INTERVAL", "420")))
FAIL_THRESHOLD = max(1, int(os.environ.get("ZHIYUE_SELF_MONITOR_FAIL_THRESHOLD", "2")))
MEMORY_HIT_EVERY_CYCLES = max(1, int(os.environ.get("ZHIYUE_SELF_MONITOR_MEMORY_HIT_EVERY", "4")))
API_SMOKE_EVERY_CYCLES = max(1, int(os.environ.get("ZHIYUE_SELF_MONITOR_API_SMOKE_EVERY", "4")))
DEFAULT_EVAL_EVERY_CYCLES = max(1, int(os.environ.get("ZHIYUE_SELF_MONITOR_DEFAULT_EVERY", "6")))
RANDOM_DAILY_ENABLED = os.environ.get("ZHIYUE_SELF_MONITOR_RANDOM_DAILY", "1").strip().lower() not in {"0", "false", "no", "off"}
RANDOM_DAILY_EVERY_CYCLES = max(1, int(os.environ.get("ZHIYUE_SELF_MONITOR_RANDOM_DAILY_EVERY", "1")))
RANDOM_DAILY_IDLE_MINUTES = max(1, int(os.environ.get("ZHIYUE_SELF_MONITOR_RANDOM_DAILY_IDLE_MINUTES", "20")))
STARTUP_RANDOM_DAILY_DELAY_MINUTES = max(1, int(os.environ.get("ZHIYUE_SELF_MONITOR_STARTUP_RANDOM_DAILY_DELAY_MINUTES", "30")))
AUTO_PROPOSAL_MIN_FAILURES = max(1, int(os.environ.get("ZHIYUE_SELF_MONITOR_AUTO_PROPOSAL_MIN_FAILURES", "5")))
MONITOR_BASELINE_VERSION = os.environ.get("ZHIYUE_MONITOR_BASELINE_VERSION", "2026-05-11-model-judge-v2").strip() or "2026-05-11-model-judge-v2"
PYTHON = sys.executable or "python"
REQUIRE_LIVE_SERVICES = os.environ.get("ZHIYUE_SELF_MONITOR_REQUIRE_LIVE_SERVICES", "0").strip().lower() in {"1", "true", "yes", "on"}
DB_CLEANUP_TTL_DAYS = max(1, int(os.environ.get("ZHIYUE_DB_CLEANUP_TTL_DAYS", "30")))
DB_CLEANUP_EVERY_CYCLES = max(1, int(os.environ.get("ZHIYUE_DB_CLEANUP_EVERY_CYCLES", "200")))
GROWTH_REVIEW_MIN_DAYS = max(1, int(os.environ.get("ZHIYUE_SELF_MONITOR_GROWTH_REVIEW_MIN_DAYS", "7")))
PROMPT_PATCH_AUTO_APPLY = os.environ.get("ZHIYUE_SELF_MONITOR_PROMPT_PATCH_AUTO_APPLY", "1").strip().lower() not in {"0", "false", "no", "off"}


def log(message: str) -> None:
    line = f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {message}"
    try:
        if LOG_FILE.exists() and LOG_FILE.stat().st_size > LOG_MAX_BYTES:
            for i in range(LOG_BACKUP_COUNT - 1, 0, -1):
                old = LOG_FILE.with_name(f"zhiyue_self_monitor.{i}.log")
                new = LOG_FILE.with_name(f"zhiyue_self_monitor.{i + 1}.log")
                if old.exists():
                    old.replace(new)
            LOG_FILE.rename(LOG_FILE.with_name("zhiyue_self_monitor.1.log"))
        LOG_FILE.open("a", encoding="utf-8").write(line + "\n")
    except Exception:
        pass


def load_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def write_json(path: Path, data) -> None:
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def append_finding(item: dict) -> None:
    try:
        with FINDINGS_FILE.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(item, ensure_ascii=False, sort_keys=True) + "\n")
    except Exception:
        pass


def run_command(name: str, cmd: list[str], timeout: int) -> dict:
    env = os.environ.copy()
    env.setdefault("PYTHONIOENCODING", "utf-8")
    started = time.time()
    try:
        proc = subprocess.run(
            cmd,
            cwd=str(BASE_DIR),
            env=env,
            text=True,
            encoding="utf-8",
            errors="replace",
            capture_output=True,
            timeout=timeout,
        )
        return {
            "mode": name,
            "ok": proc.returncode == 0,
            "returncode": proc.returncode,
            "latency_ms": int((time.time() - started) * 1000),
            "stdout": proc.stdout[-4000:],
            "stderr": proc.stderr[-4000:],
        }
    except subprocess.TimeoutExpired as err:
        return {
            "mode": name,
            "ok": False,
            "returncode": -1,
            "latency_ms": int((time.time() - started) * 1000),
            "stdout": (err.stdout or "")[-4000:] if isinstance(err.stdout, str) else "",
            "stderr": f"timeout after {timeout}s",
        }
    except Exception as err:
        return {
            "mode": name,
            "ok": False,
            "returncode": -1,
            "latency_ms": int((time.time() - started) * 1000),
            "stdout": "",
            "stderr": str(err),
        }


def run_eval(mode: str) -> dict:
    cmd = [
        PYTHON,
        str(BASE_DIR / "zhiyue_eval.py"),
        "--mode",
        mode,
        "--transport",
        "http",
    ]
    return run_command(mode, cmd, timeout=420)


def run_quick_dialog_eval() -> dict:
    return run_command("quick-dialog", [PYTHON, str(QUICK_DIALOG_SCRIPT), "--transport", "http"], timeout=180)


def run_default_eval() -> dict:
    cmd = [
        PYTHON,
        str(BASE_DIR / "zhiyue_eval.py"),
        "--transport",
        "http",
    ]
    return run_command("default", cmd, timeout=420)


def run_random_daily_eval() -> dict:
    return run_command(
        "random-daily-5",
        [PYTHON, str(RANDOM_DAILY_SCRIPT), "--rounds", "5", "--output", str(RANDOM_DAILY_RESULT_FILE)],
        timeout=7200,
    )


def run_code_review_matrix_eval() -> dict:
    return run_command(
        "code-review-matrix",
        [PYTHON, str(CODE_REVIEW_MATRIX_SCRIPT), "--transport", "http"],
        timeout=420,
    )


def run_growth_review_cycle() -> dict:
    eval_summary = {}
    try:
        quick = load_json(QUICK_DIALOG_RESULT_FILE, {})
        eval_summary = {
            "review_window": "7d",
            "quick_dialog_pass_rate": quick.get("pass_rate"),
            "quick_dialog_failed": quick.get("failed"),
        }
    except Exception:
        eval_summary = {"review_window": "7d"}
    try:
        review = growth_reviewer.review_growth_assets(
            eval_summary=eval_summary,
            bad_reply_samples=collect_bad_reply_samples(),
        )
        applied = False
        if PROMPT_PATCH_AUTO_APPLY:
            patch_result = growth_reviewer.apply_review_patch(review)
            applied = bool(patch_result.get("ok"))
        review["applied"] = applied
        review["patched_assets"] = bool(applied)
        return {"ok": True, "review": review}
    except Exception as err:
        return {"ok": False, "error": str(err)}


def monitor_runtime_ready(runtime_state: dict) -> bool:
    if REQUIRE_LIVE_SERVICES:
        return bool(runtime_state["lm"] and runtime_state["gateway"] and runtime_state["backend"])
    return bool(runtime_state["lm"])


def result_file_for(mode: str) -> Path:
    if mode == "quick-dialog":
        return QUICK_DIALOG_RESULT_FILE
    if mode == "human-chat":
        return BASE_DIR / "evals" / "zhiyue_human_chat_result.json"
    if mode == "api-smoke":
        return BASE_DIR / "evals" / "zhiyue_api_smoke_result.json"
    if mode == "memory-hit":
        return BASE_DIR / "evals" / "zhiyue_memory_hit_result.json"
    if mode == "random-daily-5":
        return RANDOM_DAILY_RESULT_FILE
    if mode == "code-review-matrix":
        return BASE_DIR / "evals" / "zhiyue_code_review_matrix_result.json"
    return BASE_DIR / "evals" / "zhiyue_eval_result.json"


def collect_bad_reply_samples(limit: int = 6) -> list[dict]:
    samples: list[dict] = []
    for mode in ("quick-dialog", "default", "memory-hit", "api-smoke", "code-review-matrix", "random-daily-5"):
        samples.extend(
            collect_eval_failures(
                mode,
                load_json=load_json,
                result_file_for=result_file_for,
            )
        )
        if len(samples) >= limit:
            break
    return samples[:limit]


def _parse_iso(value: str) -> datetime | None:
    try:
        return datetime.fromisoformat(str(value))
    except Exception:
        return None


def idle_minutes() -> float | None:
    data = load_json(INTIMACY_FILE, {})
    last = _parse_iso(data.get("last_user_time") or data.get("last_chat") or "")
    if not last:
        return None
    return max(0.0, (datetime.now() - last).total_seconds() / 60.0)


def should_run_random_daily(state: dict) -> bool:
    if not RANDOM_DAILY_ENABLED or not RANDOM_DAILY_SCRIPT.exists():
        return False
    if not model_service_ready():
        log("random-daily skipped model_service_unavailable")
        return False
    cycles = int(state.get("cycles", 0))
    if cycles % RANDOM_DAILY_EVERY_CYCLES != 0:
        return False
    started_at = _parse_iso(state.get("started_at") or "")
    if started_at and not state.get("last_random_daily_at"):
        since_started = max(0.0, (datetime.now() - started_at).total_seconds() / 60.0)
        if since_started < STARTUP_RANDOM_DAILY_DELAY_MINUTES:
            log(f"random-daily skipped startup_delay elapsed_minutes={since_started:.1f} required={STARTUP_RANDOM_DAILY_DELAY_MINUTES}")
            return False
    idle = idle_minutes()
    if idle is not None and idle < RANDOM_DAILY_IDLE_MINUTES:
        log(f"random-daily skipped active_user idle_minutes={idle:.1f} required={RANDOM_DAILY_IDLE_MINUTES}")
        return False
    return True


def should_run_growth_review(state: dict) -> bool:
    last = load_json(STATE_FILE, {}).get("last_growth_review_at") if state is None else state.get("last_growth_review_at")
    if not last:
        return True
    try:
        last_dt = datetime.fromisoformat(str(last))
    except Exception:
        return True
    elapsed_days = max(0.0, (datetime.now() - last_dt).total_seconds() / 86400.0)
    return elapsed_days >= GROWTH_REVIEW_MIN_DAYS


def run_db_maintenance(state: dict) -> dict:
    """Periodic cleanup of observability DB: delete old records, VACUUM."""
    if not OBSERVABILITY_DB.exists():
        return {"ok": True, "reason": "db_not_found"}
    cutoff = (datetime.now() - __import__("datetime").timedelta(days=DB_CLEANUP_TTL_DAYS)).isoformat()
    maintenance_cycles = int(state.get("db_maintenance_cycles", 0))
    try:
        conn = _sql.connect(str(OBSERVABILITY_DB))
        cur = conn.cursor()
        deleted = {}
        for table in ("traces", "agent_runs", "agent_actions", "agent_tasks", "skill_audit_log"):
            try:
                cur.execute(
                    f"DELETE FROM [{table}] WHERE created_at < ?",
                    (cutoff,),
                )
                deleted[table] = cur.rowcount
            except _sql.OperationalError:
                pass
        conn.commit()
        # 归档过期的自改进候选（不删除，只标记 archived）
        cur.execute(
            "UPDATE self_improvement_candidates SET status='archived', archived_at=? WHERE status IN ('pending','approved') AND created_at < ?",
            (datetime.now().isoformat(), cutoff),
        )
        archived_candidates = cur.rowcount
        conn.commit()
        total_deleted = sum(deleted.values())
        do_vacuum = total_deleted > 0 or maintenance_cycles % 5 == 0
        if do_vacuum:
            cur.execute("VACUUM")
            conn.commit()
        conn.close()
        state["db_maintenance_cycles"] = maintenance_cycles + 1
        result = {"ok": True, "deleted": deleted, "total_deleted": total_deleted, "cutoff": cutoff, "vacuum": do_vacuum}
        log(f"db_maintenance {json.dumps(result, ensure_ascii=False)}")
        return result
    except Exception as e:
        log(f"db_maintenance failed: {e}")
        return {"ok": False, "error": str(e)}


def run_once(state: dict) -> dict:
    cycles = int(state.get("cycles", 0))
    runtime_state = runtime_health_snapshot()
    state["model_service_ready"] = runtime_state["lm"]
    state["gateway_ready"] = runtime_state["gateway"]
    state["backend_ready"] = runtime_state["backend"]
    if not monitor_runtime_ready(runtime_state):
        state["cycles"] = cycles + 1
        state["last_run_at"] = datetime.now().isoformat()
        state["last_results"] = []
        state["last_skip_reason"] = "runtime_service_unavailable"
        log(
            "monitor skipped runtime_service_unavailable "
            + json.dumps(
                {
                    "lm": state["model_service_ready"],
                    "gateway": state["gateway_ready"],
                    "backend": state["backend_ready"],
                },
                ensure_ascii=False,
            )
        )
        write_json(STATE_FILE, state)
        return state
    evals = [run_quick_dialog_eval()]
    if cycles % DB_CLEANUP_EVERY_CYCLES == 0:
        run_db_maintenance(state)
    if cycles % 2 == 0 and CODE_REVIEW_MATRIX_SCRIPT.exists():
        evals.append(run_code_review_matrix_eval())
    if should_run_growth_review(state):
        review_result = run_growth_review_cycle()
        log("growth_review: " + json.dumps(review_result, ensure_ascii=False))
        state["last_growth_review_at"] = datetime.now().isoformat()
        prompt_snapshot = prompt_assets.load_growth_asset_bundle()
        state["last_prompt_patch_at"] = datetime.now().isoformat()
        state["prompt_asset_digest"] = {
            "system_len": len(prompt_snapshot.get("system_template") or ""),
            "state_len": len(prompt_snapshot.get("state_renderer") or ""),
            "memory_budget_keys": sorted(list((prompt_snapshot.get("memory_budget") or {}).keys())),
        }
    if cycles % DEFAULT_EVAL_EVERY_CYCLES == 0:
        evals.append(run_default_eval())
    if cycles % MEMORY_HIT_EVERY_CYCLES == 0:
        evals.append(run_eval("memory-hit"))
    if cycles % API_SMOKE_EVERY_CYCLES == 0:
        evals.append(run_eval("api-smoke"))
    if should_run_random_daily(state):
        evals.append(run_random_daily_eval())
    if any(item.get("mode") == "random-daily-5" for item in evals):
        state["last_random_daily_at"] = datetime.now().isoformat()
    failed = [item for item in evals if not item["ok"]]
    state["cycles"] = cycles + 1
    state["last_run_at"] = datetime.now().isoformat()
    state["last_results"] = [
        {k: item[k] for k in ("mode", "ok", "returncode", "latency_ms")}
        for item in evals
    ]
    state["consecutive_failures"] = int(state.get("consecutive_failures", 0))
    if failed:
        state["consecutive_failures"] += 1
        log("eval failed " + json.dumps(state["last_results"], ensure_ascii=False))
    else:
        state["consecutive_failures"] = 0
        log("eval ok " + json.dumps(state["last_results"], ensure_ascii=False))

    if state["consecutive_failures"] >= FAIL_THRESHOLD:
        append_proposal(
            state=state,
            evals=evals,
            auto_proposal_min_failures=AUTO_PROPOSAL_MIN_FAILURES,
            proposal_file=PROPOSAL_FILE,
            findings_file=FINDINGS_FILE,
            baseline_version=MONITOR_BASELINE_VERSION,
            load_json=load_json,
            write_json=write_json,
            append_finding=append_finding,
            log=log,
            result_file_for=result_file_for,
        )
    write_json(STATE_FILE, state)
    return state


def main() -> int:
    log(f"self monitor started interval={INTERVAL_SECONDS}s threshold={FAIL_THRESHOLD}")
    archive_stale_pending_proposals(
        proposal_file=PROPOSAL_FILE,
        archive_file=PROPOSAL_ARCHIVE_FILE,
        baseline_version=MONITOR_BASELINE_VERSION,
        load_json=load_json,
        write_json=write_json,
        log=log,
    )
    state = load_json(STATE_FILE, {})
    if not state.get("started_at"):
        state["started_at"] = datetime.now().isoformat()
    ready = wait_for_runtime_services(timeout_seconds=120) if REQUIRE_LIVE_SERVICES else model_service_ready()
    log(f"self monitor runtime ready={ready}")
    runtime_state = runtime_health_snapshot()
    state["model_service_ready"] = runtime_state["lm"]
    state["gateway_ready"] = runtime_state["gateway"]
    state["backend_ready"] = runtime_state["backend"]
    state["last_runtime_check_at"] = datetime.now().isoformat()
    if ready:
        state["last_skip_reason"] = ""
    write_json(STATE_FILE, state)
    while True:
        try:
            state = run_once(state)
        except Exception as err:
            state["consecutive_failures"] = int(state.get("consecutive_failures", 0)) + 1
            state["last_error"] = str(err)
            write_json(STATE_FILE, state)
            log(f"monitor error: {err}")
        time.sleep(INTERVAL_SECONDS)


if __name__ == "__main__":
    raise SystemExit(main())
