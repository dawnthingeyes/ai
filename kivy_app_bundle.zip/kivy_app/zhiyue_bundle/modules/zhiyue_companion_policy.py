# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import os
import random
import re
import time
from datetime import datetime
from pathlib import Path
from typing import Any
import requests
from zhiyue_project_paths import BASE_DIR, SHUTDOWN_STATE_FILE
import zhiyue_human_like as human_like
from zhiyue_semantic_routing import match_intent
from zhiyue_llm_provider import post_chat_completion as _provider_post_chat_completion


def _pick_variant(seed_text: str, options: list[str]) -> str:
    if not options:
        return ""
    seed = sum(ord(ch) for ch in str(seed_text or ""))
    return options[seed % len(options)]


_SHUTDOWN_PENDING_TTL_SECONDS = max(120, int(os.environ.get("ZHIYUE_SHUTDOWN_PENDING_TTL_SECONDS", "900")))
_LOW_STATE_PROTOTYPES = {
    "low_state": [
        "我好累",
        "我现在好累",
        "我很难受",
        "我现在很难受",
        "我有点崩溃",
        "我现在有点崩溃",
        "我好焦虑",
        "我现在好焦虑",
        "我现在很焦虑",
        "我撑不住了",
        "我好委屈",
    ],
}
_IDENTITY_PROTOTYPES = {
    "identity_probe": [
        "你是不是AI",
        "你是不是机器人",
        "你到底是不是机器人",
        "你到底是不是AI",
        "你是不是张致悦",
        "你别装了",
    ],
}
def _load_shutdown_state() -> dict[str, Any]:
    if not SHUTDOWN_STATE_FILE.exists():
        return {}
    try:
        data = json.loads(SHUTDOWN_STATE_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def _save_shutdown_state(state: dict[str, Any]) -> None:
    try:
        SHUTDOWN_STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
        SHUTDOWN_STATE_FILE.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        return


def _shutdown_state_is_active(state: dict[str, Any] | None = None) -> bool:
    state = state if isinstance(state, dict) else _load_shutdown_state()
    if not state:
        return False
    if not bool(state.get("pending")):
        return False
    expires_at = state.get("expires_at")
    if not expires_at:
        clear_shutdown_pending()
        return False
    try:
        if float(expires_at) <= time.time():
            clear_shutdown_pending()
            return False
    except Exception:
        clear_shutdown_pending()
        return False
    return True


def _shutdown_state_is_expired(state: dict[str, Any] | None = None) -> bool:
    state = state if isinstance(state, dict) else _load_shutdown_state()
    if not state:
        return True
    expires_at = state.get("expires_at")
    if not expires_at:
        return True
    try:
        return float(expires_at) <= time.time()
    except Exception:
        return True


def get_shutdown_pending_state() -> dict[str, Any]:
    state = _load_shutdown_state()
    if not _shutdown_state_is_active(state):
        return {}
    return state


def mark_shutdown_pending(user_msg: str, *, reply: str = "", source: str = "request") -> dict[str, Any]:
    now = time.time()
    state = {
        "pending": True,
        "user_msg": str(user_msg or "").strip(),
        "reply": str(reply or "").strip(),
        "source": str(source or "request").strip() or "request",
        "created_at": datetime.now().isoformat(),
        "updated_at": datetime.now().isoformat(),
        "created_ts": now,
        "updated_ts": now,
        "expires_at": now + _SHUTDOWN_PENDING_TTL_SECONDS,
    }
    _save_shutdown_state(state)
    return state


def clear_shutdown_pending() -> None:
    try:
        if SHUTDOWN_STATE_FILE.exists():
            SHUTDOWN_STATE_FILE.unlink()
    except Exception:
        _save_shutdown_state({})


def is_shutdown_pending() -> bool:
    return _shutdown_state_is_active()


def _build_safe_direct_reply(user_directives=None) -> str:
    return ""


def _contains_directive_forbidden_text(text: str, user_directives=None) -> bool:
    reply = str(text or "").strip()
    if not reply:
        return False
    normalized_reply = re.sub(r"\s+", "", reply)
    for directive in user_directives or []:
        if not isinstance(directive, dict):
            continue
        action = str(directive.get("action") or "").strip()
        if not action:
            continue
        action_key = re.sub(r"\s+", "", action)
        if not action_key:
            continue
        fragments = set()
        if len(action_key) <= 3:
            fragments.add(action_key)
        for size in (2, 3):
            if len(action_key) < size:
                continue
            for idx in range(0, len(action_key) - size + 1):
                frag = action_key[idx:idx + size]
                if frag.strip():
                    fragments.add(frag)
        if any(frag in normalized_reply for frag in fragments):
            return True
    return False


def _lm_classify_bool(*, system_prompt: str, user_msg: str, history: list[dict[str, Any]] | None = None, extra: dict[str, Any] | None = None, timeout: int = 4) -> bool:
    payload: dict[str, Any] = {"user_msg": str(user_msg or "").strip(), "recent_history": list(history or [])}
    if extra:
        payload.update(extra)
    try:
        result = _call_lm_json(system_prompt=system_prompt, user_payload=payload, timeout=timeout)
    except Exception:
        return False
    matched = bool(result.get("matched"))
    try:
        confidence = float(result.get("confidence") or 0.0)
    except Exception:
        confidence = 0.0
    return matched and confidence >= 0.5


def should_ack_reply_quality_feedback(user_msg: str, *, history: list[dict[str, Any]] | None = None) -> bool:
    return _lm_classify_bool(
        system_prompt=(
            "你是对话意图分析器。判断用户当前是否在反馈上一句回复的质量、自然度或接话方式。"
            "结合最近上下文理解，不要做关键词匹配。只输出 JSON：{\"matched\": boolean, \"confidence\": number, \"reason\": string}。"
        ),
        user_msg=user_msg,
        history=history,
    )


def build_reply_quality_feedback_ack(*, user_directives=None) -> str:
    _ = user_directives
    return random.choice([
        "嗯，我记下了---我会改",
        "知道了---这次我收着点",
        "行，我听懂了---我改",
    ])


def should_short_circuit_low_state(user_msg: str, *, history: list[dict[str, Any]] | None = None) -> bool:
    if _lm_classify_bool(
        system_prompt=(
            "你是对话意图分析器。判断用户当前是否处于明显低落、疲惫、崩溃、委屈或需要安慰的状态。"
            "结合最近上下文理解，不要做关键词匹配。只输出 JSON：{\"matched\": boolean, \"confidence\": number, \"reason\": string}。"
        ),
        user_msg=user_msg,
        history=history,
    ):
        return True
    matched, score = match_intent(user_msg, _LOW_STATE_PROTOTYPES, threshold=0.28)
    return bool(matched and score >= 0.28)


def build_low_state_direct_reply(*, user_directives=None) -> str:
    _ = user_directives
    return random.choice([
        "先抱抱你---别硬撑",
        "我在---先缓一下",
        "别急---慢慢说",
    ])


def should_identity_probe(user_msg: str, *, history: list[dict[str, Any]] | None = None) -> bool:
    if _lm_classify_bool(
        system_prompt=(
            "你是对话意图分析器。判断用户当前是否在质疑身份、询问是否是AI、机器人、冒充者，或要求确认人格身份。"
            "结合最近上下文理解，不要做关键词匹配。只输出 JSON：{\"matched\": boolean, \"confidence\": number, \"reason\": string}。"
        ),
        user_msg=user_msg,
        history=history,
    ):
        return True
    matched, score = match_intent(user_msg, _IDENTITY_PROTOTYPES, threshold=0.26)
    return bool(matched and score >= 0.26)


def build_identity_probe_reply(*, user_directives=None) -> str:
    _ = user_directives
    return random.choice([
        "不是啊---你又开始试我？",
        "不是---少套我话",
        "不是啊---你怎么又问这个",
    ])


def _classify_shutdown_intent_semantically(
    user_msg: str,
    *,
    history: list[dict[str, Any]] | None = None,
    shutdown_state: dict[str, Any] | None = None,
    intent: str = "request",
) -> bool:
    msg = str(user_msg or "").strip()
    if not msg:
        return False
    extra: dict[str, Any] = {}
    if isinstance(shutdown_state, dict) and shutdown_state:
        extra["shutdown_state"] = {
            "pending": bool(shutdown_state.get("pending")),
            "source": str(shutdown_state.get("source") or ""),
            "reply": str(shutdown_state.get("reply") or ""),
            "created_at": str(shutdown_state.get("created_at") or ""),
            "updated_at": str(shutdown_state.get("updated_at") or ""),
        }
    return _detect_shutdown_intent(
        msg,
        history=history,
        mode="confirmation" if intent == "confirmation" else "request",
        extra=extra or None,
    )


def should_shutdown_request(user_msg: str, *, history: list[dict[str, Any]] | None = None) -> bool:
    msg = str(user_msg or "").strip()
    if not msg:
        return False
    return _classify_shutdown_intent_semantically(msg, history=history, intent="request")


def should_shutdown_confirmation(user_msg: str, *, history: list[dict[str, Any]] | None = None, shutdown_state: dict[str, Any] | None = None) -> bool:
    msg = str(user_msg or "").strip()
    if not msg:
        return False
    if _classify_shutdown_intent_semantically(msg, history=history, shutdown_state=shutdown_state, intent="request"):
        return False
    state = shutdown_state if isinstance(shutdown_state, dict) else {}
    if not state:
        try:
            state = get_shutdown_pending_state()
        except Exception:
            state = {}
    if not _shutdown_state_is_active(state):
        return False
    return _classify_shutdown_intent_semantically(
        msg,
        history=history,
        shutdown_state=state,
        intent="confirmation",
    )


def _call_lm_json(*, system_prompt: str, user_payload: dict[str, Any], timeout: int = 30) -> dict[str, Any]:
    response = _provider_post_chat_completion(
        "main",
        {
            "model": os.environ.get("ZHIYUE_LM_MODEL", "qwen/qwen3.6-35b-a3b").strip() or "default",
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": json.dumps(user_payload, ensure_ascii=False)},
            ],
            "stream": False,
            "temperature": 0.1,
            "max_tokens": 120,
            "think_disabled": True,
        },
        timeout=timeout,
    )
    response.raise_for_status()
    data = response.json()
    choices = data.get("choices") or []
    message = choices[0].get("message") if choices and isinstance(choices[0], dict) else {}
    raw = str((message or {}).get("content") or "").strip()
    raw = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw, flags=re.I | re.M).strip()
    return json.loads(raw) if raw else {}


def _detect_shutdown_intent(
    user_msg: str,
    *,
    history: list[dict[str, Any]] | None = None,
    mode: str = "request",
    extra: dict[str, Any] | None = None,
) -> bool:
    msg = str(user_msg or "").strip()
    if not msg:
        return False
    recent_history = []
    for item in list(history or [])[-8:]:
        if not isinstance(item, dict):
            continue
        role = str(item.get("role") or "").strip().lower()
        content = str(item.get("content") or "").strip()
        if role in {"user", "assistant"} and content:
            recent_history.append({"role": role, "content": content})
    last_user_msg = ""
    last_assistant_msg = ""
    previous_user_msg = ""
    previous_assistant_msg = ""
    user_turns = 0
    assistant_turns = 0
    for item in recent_history:
        if item["role"] == "user":
            user_turns += 1
            previous_user_msg = last_user_msg
            last_user_msg = item["content"]
        elif item["role"] == "assistant":
            assistant_turns += 1
            previous_assistant_msg = last_assistant_msg
            last_assistant_msg = item["content"]
    if mode == "confirmation":
        system_prompt = (
            "你是对话意图分析器。任务是判断当前消息是否表示用户同意继续执行上一轮已经开始的关机流程。"
            "只根据当前消息和最近对话的语义判断，不要依赖固定词表。"
            "如果当前消息是在上一轮关机收尾之后表达同意、继续收尾、允许执行或自然结束当前流程，则 matched=true。"
            "如果只是普通问候、闲聊、话题切换或没有延续上一轮关机收尾，则 matched=false。"
            "只输出 JSON：{\"matched\": boolean, \"confidence\": number, \"reason\": string}。"
        )
    else:
        system_prompt = (
            "你是对话意图分析器。任务是判断当前消息是否在请求关机、关闭电脑、停止本程序或让本机执行电源关闭。"
            "只根据当前消息和最近对话的语义判断，不要依赖固定词表，不要被字面词本身误导。"
            "如果只是普通聊天、闲聊、寒暄、陈述句或与关机无关的结束语，则 matched=false。"
            "只输出 JSON：{\"matched\": boolean, \"confidence\": number, \"reason\": string}。"
        )
    payload = {
        "mode": mode,
        "user_msg": msg,
        "recent_history": recent_history,
        "context": {
            "last_user_msg": last_user_msg,
            "last_assistant_msg": last_assistant_msg,
            "previous_user_msg": previous_user_msg,
            "previous_assistant_msg": previous_assistant_msg,
            "user_turns": user_turns,
            "assistant_turns": assistant_turns,
        },
    }
    if extra:
        payload.update(extra)
    try:
        result = _call_lm_json(system_prompt=system_prompt, user_payload=payload, timeout=12)
    except Exception:
        return False
    matched = bool(result.get("matched"))
    try:
        confidence = float(result.get("confidence") or 0.0)
    except Exception:
        confidence = 0.0
    return matched and confidence >= 0.5


def _trim_history(history: list[dict[str, Any]], limit: int = 50) -> list[dict[str, Any]]:
    return history[-limit:] if len(history) > limit else history


def record_simple_rule_turn(
    *,
    user_msg: str,
    reply: str,
    rule_name: str,
    chat_history: list[dict[str, Any]],
    intimacy,
    build_display_messages,
    clean_reply,
    exp: int = 1,
    energy_delta: int = -1,
    allow_followup: bool = False,
    user_directives=None,
) -> dict[str, Any]:
    candidate = clean_reply(reply)
    if _contains_directive_forbidden_text(candidate, user_directives):
        return None
    compact_candidate = re.sub(r"\s+", "", candidate).strip("，。,.!?！？-")
    if not candidate or len(compact_candidate) < 2:
        return None
    human_eval = human_like.evaluate_human_likeness(user_msg, candidate, route=rule_name)
    chat_history.append({"role": "user", "content": user_msg})
    chat_history.append({"role": "assistant", "content": candidate})
    chat_history[:] = _trim_history(chat_history, limit=50)
    intimacy.data["last_user_time"] = datetime.now().isoformat()
    intimacy.data["last_user_message"] = user_msg[:120]
    intimacy.data["last_assistant_message"] = candidate[:120]
    intimacy.save()
    intimacy.add_exp(exp)
    intimacy.update_energy(energy_delta)
    return {
        "reply": candidate,
        "messages": build_display_messages(user_msg, candidate, allow_followup=allow_followup),
        "error": False,
        "rule_reply": rule_name,
        "reply_source": "rule_hint",
        "used_fallback": False,
        "reply_repaired": False,
        "human_likeness": human_eval,
        "self_correction": {"applied": False, "reason": "", "before": {}, "after": {}},
        "coalesced_skip": True,
        "level": intimacy.data["level"],
        "stage": intimacy.get_stage(),
    }
