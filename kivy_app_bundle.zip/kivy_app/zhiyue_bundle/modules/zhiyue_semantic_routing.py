# -*- coding: utf-8 -*-
from __future__ import annotations

import re


_STOPWORDS = {
    "我", "你", "他", "她", "它", "我们", "你们", "他们", "这个", "那个", "这些", "那些",
    "一下", "一点", "有点", "什么", "怎么", "为什么", "是不是", "可以", "还是", "然后",
}


def normalize_text(text: str | None) -> str:
    return re.sub(r"\s+", "", str(text or "").strip().lower())


def extract_terms(text: str | None, *, limit: int = 12) -> list[str]:
    raw = normalize_text(text)
    if not raw:
        return []
    terms: list[str] = []
    seen = set()
    for token in re.findall(r"[a-z0-9]{2,}|[\u4e00-\u9fff]{2,}", raw):
        if token in _STOPWORDS or token in seen:
            continue
        seen.add(token)
        terms.append(token)
        if len(terms) >= limit:
            return terms
    return terms


def score_overlap(text: str | None, prototypes: list[str]) -> float:
    terms = extract_terms(text)
    if not terms:
        return 0.0
    best = 0.0
    for proto in prototypes:
        proto_terms = extract_terms(proto)
        if not proto_terms:
            continue
        hits = sum(1 for term in terms if term in proto_terms)
        if hits:
            best = max(best, hits / max(1.0, len(proto_terms)))
        joined = normalize_text(proto)
        raw = normalize_text(text)
        if raw and joined and (joined in raw or raw in joined):
            best = max(best, 0.95)
    return round(best, 3)


def match_intent(text: str | None, prototype_map: dict[str, list[str]], *, threshold: float = 0.34) -> tuple[str, float]:
    best_name = ""
    best_score = 0.0
    for name, protos in prototype_map.items():
        score = score_overlap(text, protos)
        if score > best_score:
            best_name = name
            best_score = score
    if best_score < threshold:
        return "", best_score
    return best_name, best_score
