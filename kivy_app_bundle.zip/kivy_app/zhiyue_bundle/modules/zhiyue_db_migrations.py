# -*- coding: utf-8 -*-
"""数据库 schema 迁移（从 zhiyue_connected.py 拆分）"""
import sqlite3
import logging
from pathlib import Path

_dbg = logging.getLogger("zhiyue")
BASE_DIR = Path(__file__).resolve().parent


def init_memory_db(db_path: str) -> None:
    """初始化记忆数据库（memories + events 表）"""
    conn = sqlite3.connect(db_path, check_same_thread=False)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            content TEXT NOT NULL,
            category TEXT DEFAULT 'general',
            importance INTEGER DEFAULT 1,
            summary TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            last_recall TEXT NOT NULL,
            recall_count INTEGER DEFAULT 0,
            mem_type TEXT DEFAULT 'fact',
            source TEXT DEFAULT 'chat',
            status TEXT DEFAULT 'active',
            confidence REAL DEFAULT 1,
            last_verified TEXT,
            verified_count INTEGER DEFAULT 0,
            scope TEXT DEFAULT 'chat',
            allow_chat_inject INTEGER DEFAULT 1,
            expires_at TEXT
        )
    """)
    memory_cols = {row[1] for row in conn.execute("PRAGMA table_info(memories)").fetchall()}
    for col in ["mem_type", "summary", "recall_count", "source", "status",
                "confidence", "last_verified", "verified_count", "scope",
                "allow_chat_inject", "expires_at", "valid_from", "valid_until"]:
        if col not in memory_cols:
            col_type = "TEXT DEFAULT ''"
            conn.execute(f"ALTER TABLE memories ADD COLUMN {col} {col_type}")
    # FTS5 index for BM25 keyword search
    try:
        conn.execute("""
            CREATE VIRTUAL TABLE IF NOT EXISTS memory_fts5 USING fts5(
                content, summary, category, mem_type,
                content='memories', content_rowid='id'
            )
        """)
        conn.executescript("""
            CREATE TRIGGER IF NOT EXISTS m5i AFTER INSERT ON memories BEGIN
                INSERT INTO memory_fts5(rowid, content, summary, category, mem_type)
                VALUES (new.id, new.content, new.summary, new.category, new.mem_type);
            END;
            CREATE TRIGGER IF NOT EXISTS m5d AFTER DELETE ON memories BEGIN
                INSERT INTO memory_fts5(memory_fts5, rowid, content, summary, category, mem_type)
                VALUES ('delete', old.id, old.content, old.summary, old.category, old.mem_type);
            END;
            CREATE TRIGGER IF NOT EXISTS m5u AFTER UPDATE ON memories BEGIN
                INSERT INTO memory_fts5(memory_fts5, rowid, content, summary, category, mem_type)
                VALUES ('delete', old.id, old.content, old.summary, old.category, old.mem_type);
                INSERT INTO memory_fts5(rowid, content, summary, category, mem_type)
                VALUES (new.id, new.content, new.summary, new.category, new.mem_type);
            END;
        """)
        conn.execute("INSERT INTO memory_fts5(memory_fts5) VALUES('rebuild')")
    except Exception:
        pass
    conn.execute(
        """
        UPDATE memories
        SET scope='technical', allow_chat_inject=0
        WHERE lower(coalesce(source, '')) LIKE '%test%'
           OR lower(coalesce(source, '')) LIKE '%stress%'
           OR lower(coalesce(source, '')) LIKE '%smoke%'
           OR lower(coalesce(source, '')) LIKE '%sandbox%'
           OR lower(coalesce(source, '')) LIKE '%monitor%'
        """
    )
    conn.execute(
        """
        UPDATE memories
        SET expires_at=COALESCE(expires_at, datetime(created_at, '+180 days'))
        WHERE allow_chat_inject=1
          AND expires_at IS NULL
          AND coalesce(confidence, 0) < 2.5
        """
    )
    conn.execute("""
        CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            date TEXT,
            created_at TEXT NOT NULL,
            notified INTEGER DEFAULT 0
        )
    """)
    conn.commit()
    conn.close()


def init_growth_db(db_path: str) -> None:
    """初始化成长数据库（good_replies / learning_notes / relationship_threads / life_events 表）"""
    conn = sqlite3.connect(db_path, check_same_thread=False)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS good_replies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_msg TEXT NOT NULL,
            ai_reply TEXT NOT NULL,
            score REAL DEFAULT 0,
            source TEXT DEFAULT 'ai_eval',
            created_at TEXT NOT NULL
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS learning_notes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            note_type TEXT NOT NULL,
            content TEXT NOT NULL,
            evidence TEXT DEFAULT '',
            confidence INTEGER DEFAULT 1,
            active INTEGER DEFAULT 1,
            created_at TEXT NOT NULL,
            scope TEXT DEFAULT 'chat',
            allow_chat_inject INTEGER DEFAULT 1,
            expires_at TEXT
        )
    """)
    growth_cols = {row[1] for row in conn.execute("PRAGMA table_info(learning_notes)").fetchall()}
    for col in ["scope", "allow_chat_inject", "expires_at"]:
        if col not in growth_cols:
            conn.execute(f"ALTER TABLE learning_notes ADD COLUMN {col} TEXT DEFAULT ''")
    conn.execute(
        """
        UPDATE learning_notes
        SET scope='technical', allow_chat_inject=0
        WHERE note_type IN ('代码审查', '自我改进', '技术问题', 'runtime_policy', 'proposal')
           OR content LIKE '%代码%' OR content LIKE '%源码%' OR content LIKE '%sandbox%'
           OR content LIKE '%proposal%' OR evidence LIKE '%代码%' OR evidence LIKE '%源码%'
           OR evidence LIKE '%sandbox%' OR evidence LIKE '%proposal%'
        """
    )
    conn.execute(
        """
        UPDATE learning_notes
        SET expires_at=COALESCE(expires_at, datetime(created_at, '+45 days'))
        WHERE allow_chat_inject=1 AND expires_at IS NULL AND coalesce(confidence, 0) < 3
        """
    )
    conn.execute("""
        CREATE TABLE IF NOT EXISTS relationship_threads (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            thread_type TEXT NOT NULL,
            title TEXT DEFAULT '',
            content TEXT NOT NULL,
            evidence TEXT DEFAULT '',
            status TEXT DEFAULT 'active',
            heat INTEGER DEFAULT 1,
            last_touched TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS life_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            event_type TEXT DEFAULT 'general',
            status TEXT DEFAULT 'active',
            due_time TEXT,
            entities_json TEXT DEFAULT '[]',
            last_mentioned_at TEXT NOT NULL,
            next_followup_at TEXT,
            evidence TEXT DEFAULT '',
            importance INTEGER DEFAULT 3,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
    """)
    life_event_cols = {row[1] for row in conn.execute("PRAGMA table_info(life_events)").fetchall()}
    for col, ddl in {
        "event_type": "ALTER TABLE life_events ADD COLUMN event_type TEXT DEFAULT 'general'",
        "status": "ALTER TABLE life_events ADD COLUMN status TEXT DEFAULT 'active'",
        "due_time": "ALTER TABLE life_events ADD COLUMN due_time TEXT",
        "entities_json": "ALTER TABLE life_events ADD COLUMN entities_json TEXT DEFAULT '[]'",
        "last_mentioned_at": "ALTER TABLE life_events ADD COLUMN last_mentioned_at TEXT",
        "next_followup_at": "ALTER TABLE life_events ADD COLUMN next_followup_at TEXT",
        "evidence": "ALTER TABLE life_events ADD COLUMN evidence TEXT DEFAULT ''",
        "importance": "ALTER TABLE life_events ADD COLUMN importance INTEGER DEFAULT 3",
        "created_at": "ALTER TABLE life_events ADD COLUMN created_at TEXT",
        "updated_at": "ALTER TABLE life_events ADD COLUMN updated_at TEXT",
    }.items():
        if col not in life_event_cols:
            conn.execute(ddl)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_life_events_status_due ON life_events(status, due_time)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_life_events_type_touch ON life_events(event_type, last_mentioned_at)")
    thread_cols = {row[1] for row in conn.execute("PRAGMA table_info(relationship_threads)").fetchall()}
    for col, ddl in {
        "thread_type": "ALTER TABLE relationship_threads ADD COLUMN thread_type TEXT NOT NULL DEFAULT 'memory'",
        "title": "ALTER TABLE relationship_threads ADD COLUMN title TEXT DEFAULT ''",
        "content": "ALTER TABLE relationship_threads ADD COLUMN content TEXT NOT NULL DEFAULT ''",
        "evidence": "ALTER TABLE relationship_threads ADD COLUMN evidence TEXT DEFAULT ''",
        "status": "ALTER TABLE relationship_threads ADD COLUMN status TEXT DEFAULT 'active'",
        "heat": "ALTER TABLE relationship_threads ADD COLUMN heat INTEGER DEFAULT 1",
        "last_touched": "ALTER TABLE relationship_threads ADD COLUMN last_touched TEXT",
        "created_at": "ALTER TABLE relationship_threads ADD COLUMN created_at TEXT",
    }.items():
        if col not in thread_cols:
            conn.execute(ddl)
    conn.commit()
    conn.close()


def init_all_dbs(memory_db: str, growth_db: str) -> None:
    """执行全部数据库迁移"""
    init_memory_db(memory_db)
    init_growth_db(growth_db)


def init_observability_db(db_path: str) -> None:
    """Initialize observability tables for diagnostics, tooling, and self-improvement."""
    conn = sqlite3.connect(db_path, check_same_thread=False)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS skill_audit_log (
            id TEXT PRIMARY KEY,
            created_at TEXT NOT NULL,
            tool_name TEXT NOT NULL,
            permission TEXT DEFAULT 'read',
            risk TEXT DEFAULT 'low',
            allowed INTEGER DEFAULT 0,
            reason TEXT DEFAULT '',
            args_json TEXT DEFAULT '{}',
            result_json TEXT DEFAULT '{}',
            latency_ms INTEGER DEFAULT 0
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS skill_usage_log (
            id TEXT PRIMARY KEY,
            created_at TEXT NOT NULL,
            skill_name TEXT NOT NULL,
            route TEXT DEFAULT '',
            ok INTEGER DEFAULT 0,
            latency_ms INTEGER DEFAULT 0,
            args_json TEXT DEFAULT '{}',
            result_json TEXT DEFAULT '{}',
            meta_json TEXT DEFAULT '{}'
        )
    """)
    usage_cols = {row[1] for row in conn.execute("PRAGMA table_info(skill_usage_log)").fetchall()}
    for col, ddl in {
        "request_id": "ALTER TABLE skill_usage_log ADD COLUMN request_id TEXT DEFAULT ''",
        "attempts": "ALTER TABLE skill_usage_log ADD COLUMN attempts INTEGER DEFAULT 1",
        "validation_json": "ALTER TABLE skill_usage_log ADD COLUMN validation_json TEXT DEFAULT '{}'",
        "recovery_json": "ALTER TABLE skill_usage_log ADD COLUMN recovery_json TEXT DEFAULT '{}'",
    }.items():
        if col not in usage_cols:
            conn.execute(ddl)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS skill_registry (
            skill_name TEXT PRIMARY KEY,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            state TEXT DEFAULT 'active',
            pinned INTEGER DEFAULT 0,
            generated INTEGER DEFAULT 0,
            source_path TEXT DEFAULT '',
            meta_json TEXT DEFAULT '{}'
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS skill_drafts (
            id TEXT PRIMARY KEY,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            source TEXT DEFAULT '',
            source_key TEXT DEFAULT '',
            title TEXT DEFAULT '',
            slug TEXT DEFAULT '',
            summary TEXT DEFAULT '',
            content TEXT DEFAULT '',
            evidence_count INTEGER DEFAULT 0,
            evidence_json TEXT DEFAULT '[]',
            status TEXT DEFAULT 'draft',
            meta_json TEXT DEFAULT '{}'
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS skill_merge_events (
            id TEXT PRIMARY KEY,
            created_at TEXT NOT NULL,
            draft_id TEXT DEFAULT '',
            source_key TEXT DEFAULT '',
            target_skill TEXT DEFAULT '',
            evidence_count INTEGER DEFAULT 0,
            before_count INTEGER DEFAULT 0,
            after_count INTEGER DEFAULT 0,
            delta_count INTEGER DEFAULT 0,
            meta_json TEXT DEFAULT '{}'
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS self_improvement_candidates (
            id TEXT PRIMARY KEY,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            status TEXT DEFAULT 'pending',
            source TEXT DEFAULT '',
            category TEXT DEFAULT '',
            title TEXT NOT NULL,
            recommendation TEXT DEFAULT '',
            evidence_json TEXT DEFAULT '[]',
            impact TEXT DEFAULT '',
            risk TEXT DEFAULT 'low',
            rollback TEXT DEFAULT '',
            guardrail TEXT DEFAULT '',
            fingerprint TEXT UNIQUE,
            meta_json TEXT DEFAULT '{}'
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS runtime_policies (
            id TEXT PRIMARY KEY,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            status TEXT DEFAULT 'draft',
            candidate_id TEXT DEFAULT '',
            policy_type TEXT NOT NULL,
            title TEXT NOT NULL,
            instruction TEXT DEFAULT '',
            params_json TEXT DEFAULT '{}',
            priority INTEGER DEFAULT 3,
            risk TEXT DEFAULT 'low',
            evidence_json TEXT DEFAULT '[]',
            rollback TEXT DEFAULT '',
            guardrail TEXT DEFAULT '',
            fingerprint TEXT UNIQUE,
            meta_json TEXT DEFAULT '{}'
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS code_change_proposals (
            id TEXT PRIMARY KEY,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            status TEXT DEFAULT 'draft',
            source_type TEXT DEFAULT '',
            source_id TEXT DEFAULT '',
            title TEXT NOT NULL,
            plain_summary TEXT DEFAULT '',
            target_files_json TEXT DEFAULT '[]',
            diff_text TEXT DEFAULT '',
            rationale TEXT DEFAULT '',
            risk TEXT DEFAULT 'low',
            rollback TEXT DEFAULT '',
            test_commands_json TEXT DEFAULT '[]',
            authorization_text TEXT DEFAULT '',
            authorized_at TEXT,
            fingerprint TEXT UNIQUE,
            meta_json TEXT DEFAULT '{}'
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS code_sandbox_runs (
            id TEXT PRIMARY KEY,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            proposal_id TEXT NOT NULL,
            status TEXT DEFAULT 'running',
            workspace_path TEXT DEFAULT '',
            workspace_kept INTEGER DEFAULT 0,
            applied_patch INTEGER DEFAULT 0,
            test_commands_json TEXT DEFAULT '[]',
            result_json TEXT DEFAULT '{}',
            stdout_tail TEXT DEFAULT '',
            stderr_tail TEXT DEFAULT '',
            error TEXT DEFAULT '',
            duration_ms INTEGER DEFAULT 0,
            meta_json TEXT DEFAULT '{}'
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS code_apply_runs (
            id TEXT PRIMARY KEY,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            proposal_id TEXT NOT NULL,
            sandbox_run_id TEXT DEFAULT '',
            status TEXT DEFAULT 'rejected',
            changed_files_json TEXT DEFAULT '[]',
            confirmation_text TEXT DEFAULT '',
            result_json TEXT DEFAULT '{}',
            error TEXT DEFAULT '',
            meta_json TEXT DEFAULT '{}'
        )
    """)
    conn.execute("""
        CREATE VIEW IF NOT EXISTS code_proposals AS
        SELECT
            id,
            created_at,
            updated_at,
            status,
            source_type,
            source_id,
            title,
            plain_summary,
            target_files_json,
            diff_text,
            rationale,
            risk,
            rollback,
            test_commands_json,
            authorization_text,
            authorized_at,
            fingerprint,
            meta_json
        FROM code_change_proposals
    """)
    conn.commit()
    conn.close()


def init_all_dbs(memory_db: str, growth_db: str, observability_db: str | None = None) -> None:
    """Initialize all primary project databases."""
    init_memory_db(memory_db)
    init_growth_db(growth_db)
    if observability_db:
        init_observability_db(observability_db)
