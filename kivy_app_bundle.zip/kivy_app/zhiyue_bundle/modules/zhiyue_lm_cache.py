# -*- coding: utf-8 -*-
from __future__ import annotations

import hashlib
import json
import re
import sqlite3
import threading
import time
from pathlib import Path
from typing import Any

from zhiyue_project_paths import REPLY_CACHE_DB
from zhiyue_semantic_routing import extract_terms, normalize_text

try:
    import zhiyue_human_like as human_like
except Exception:  # pragma: no cover - best effort fallback
    human_like = None


_CACHE_LOCK = threading.Lock()
_CACHE_INITIALIZED = False
_EXACT_CACHE_TTL_SECONDS = max(300, int((__import__("os").environ.get("ZHIYUE_REPLY_CACHE_TTL", "1800"))))
_SEMANTIC_CACHE_TTL_SECONDS = max(300, int((__import__("os").environ.get("ZHIYUE_REPLY_SEMANTIC_TTL", "900"))))
_SAFE_SEMANTIC_TYPES = {"greeting", "presence", "identity_probe", "open_chat", "direct_question", "preference_probe", "relationship_probe"}
_TIME_SENSITIVE_MARKERS = (
    "今天", "明天", "后天", "昨晚", "现在", "最新", "刚刚", "刚才", "实时", "天气", "价格", "几点", "周几",
    "本周", "这周", "今天晚上", "明早", "明晚",
)
_TECHNICAL_MARKERS = (
    "prompt", "提示词", "系统", "模型", "token", "cache", "缓存", "代码", "接口", "json", "api", "数据库",
    "源码", "bug", "报错", "调试", "训练", "推理",
)


def _now() -> float:
    return time.time()


def _json_dumps(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _normalize_text(value: str | None) -> str:
    return re.sub(r"\s+", " ", str(value or "").strip().lower())


def _char_ngrams(text: str, size: int = 2) -> set[str]:
    compact = re.sub(r"\s+", "", _normalize_text(text))
    if len(compact) < size:
        return {compact} if compact else set()
    return {compact[idx:idx + size] for idx in range(0, len(compact) - size + 1)}


def _question_type(user_msg: str) -> str:
    if human_like and hasattr(human_like, "classify_question_type"):
        try:
            return str(human_like.classify_question_type(user_msg) or "open_chat")
        except Exception:
            return "open_chat"
    return "open_chat"


def _is_semantic_safe(user_msg: str, question_type: str) -> bool:
    msg = _normalize_text(user_msg)
    if not msg or len(msg) > 220:
        return False
    if question_type not in _SAFE_SEMANTIC_TYPES:
        return False
    if any(marker in msg for marker in _TIME_SENSITIVE_MARKERS):
        return False
    if any(marker in msg for marker in _TECHNICAL_MARKERS):
        return False
    if "http://" in msg or "https://" in msg or re.search(r"[A-Za-z]:[/\\\\]", msg):
        return False
    if "```" in msg:
        return False
    return True


def _canonical_messages(messages: list[dict[str, Any]] | None) -> list[dict[str, str]]:
    result = []
    for item in messages or []:
        if not isinstance(item, dict):
            continue
        role = str(item.get("role") or "").strip().lower()
        content = re.sub(r"\s+", " ", str(item.get("content") or "")).strip()
        if not role or not content:
            continue
        result.append({"role": role, "content": content})
    return result


def _system_digest(messages: list[dict[str, Any]] | None) -> str:
    system_msgs = [item for item in _canonical_messages(messages) if item["role"] == "system"]
    raw = _json_dumps(system_msgs[:3])
    return hashlib.sha256(raw.encode("utf-8", errors="ignore")).hexdigest()


def _history_digest(normalized_history: list[dict[str, Any]] | None) -> str:
    history = []
    for item in (normalized_history or [])[-6:]:
        if not isinstance(item, dict):
            continue
        history.append({
            "role": str(item.get("role") or "").strip().lower(),
            "content": re.sub(r"\s+", " ", str(item.get("content") or "")).strip()[:180],
        })
    raw = _json_dumps(history)
    return hashlib.sha256(raw.encode("utf-8", errors="ignore")).hexdigest()


def _request_digest(messages: list[dict[str, Any]] | None, *, model: str, max_tokens: int, temperature: float, top_p: float, think_disabled: bool) -> str:
    payload = {
        "messages": _canonical_messages(messages),
        "model": str(model or ""),
        "max_tokens": int(max_tokens or 0),
        "temperature": round(float(temperature or 0.0), 3),
        "top_p": round(float(top_p or 0.0), 3),
        "think_disabled": bool(think_disabled),
    }
    raw = _json_dumps(payload)
    return hashlib.sha256(raw.encode("utf-8", errors="ignore")).hexdigest()


def _semantic_bucket(*, messages: list[dict[str, Any]] | None, normalized_history: list[dict[str, Any]] | None, model: str, max_tokens: int, temperature: float, top_p: float, question_type: str) -> str:
    payload = {
        "system_digest": _system_digest(messages),
        "history_digest": _history_digest(normalized_history),
        "model": str(model or ""),
        "max_tokens": int(max_tokens or 0),
        "temperature": round(float(temperature or 0.0), 3),
        "top_p": round(float(top_p or 0.0), 3),
        "question_type": str(question_type or "open_chat"),
    }
    return hashlib.sha256(_json_dumps(payload).encode("utf-8", errors="ignore")).hexdigest()


def _semantic_similarity(a: str, b: str, question_type: str) -> float:
    left = _normalize_text(a)
    right = _normalize_text(b)
    if not left or not right:
        return 0.0
    if left == right:
        return 1.0
    if question_type in {"greeting", "presence", "identity_probe"}:
        return 0.92

    left_terms = set(extract_terms(left, limit=10))
    right_terms = set(extract_terms(right, limit=10))
    if not left_terms or not right_terms:
        left_terms = _char_ngrams(left)
        right_terms = _char_ngrams(right)
    if not left_terms or not right_terms:
        return 0.0
    overlap = len(left_terms & right_terms)
    union = len(left_terms | right_terms)
    score = overlap / max(1, union)
    if score == 0.0 and question_type in {"open_chat", "direct_question"}:
        score = overlap / max(1, max(len(left_terms), len(right_terms)))
    return round(float(score), 3)


def _semantic_threshold(user_msg: str, question_type: str) -> float:
    if question_type in {"greeting", "presence", "identity_probe"}:
        return 0.55
    if len(_normalize_text(user_msg)) <= 8:
        return 0.8
    return 0.7


def _connect() -> sqlite3.Connection:
    conn = sqlite3.connect(str(REPLY_CACHE_DB), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA busy_timeout=3000")
    return conn


def _init_schema() -> None:
    global _CACHE_INITIALIZED
    if _CACHE_INITIALIZED:
        return
    with _CACHE_LOCK:
        if _CACHE_INITIALIZED:
            return
        conn = _connect()
        try:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS lm_reply_cache (
                    exact_digest TEXT PRIMARY KEY,
                    semantic_bucket TEXT NOT NULL,
                    question_type TEXT NOT NULL,
                    user_msg TEXT NOT NULL,
                    user_norm TEXT NOT NULL,
                    system_digest TEXT NOT NULL,
                    history_digest TEXT NOT NULL,
                    model TEXT NOT NULL,
                    max_tokens INTEGER NOT NULL,
                    temperature REAL NOT NULL,
                    top_p REAL NOT NULL,
                    think_disabled INTEGER NOT NULL,
                    reply TEXT NOT NULL,
                    reply_source TEXT DEFAULT '',
                    created_at REAL NOT NULL,
                    updated_at REAL NOT NULL,
                    expires_at REAL NOT NULL,
                    hit_count INTEGER NOT NULL DEFAULT 0,
                    last_hit_at REAL DEFAULT 0,
                    meta_json TEXT DEFAULT '{}'
                )
                """
            )
            conn.execute("CREATE INDEX IF NOT EXISTS idx_lm_reply_cache_bucket ON lm_reply_cache(semantic_bucket, updated_at DESC)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_lm_reply_cache_expire ON lm_reply_cache(expires_at)")
            conn.commit()
        finally:
            conn.close()
        _CACHE_INITIALIZED = True


def clear_cache() -> None:
    _init_schema()
    with _CACHE_LOCK:
        conn = _connect()
        try:
            conn.execute("DELETE FROM lm_reply_cache")
            conn.commit()
        finally:
            conn.close()


def cache_stats() -> dict[str, Any]:
    _init_schema()
    conn = _connect()
    try:
        now = _now()
        row = conn.execute(
            """
            SELECT COUNT(*) AS total,
                   SUM(CASE WHEN expires_at > ? THEN 1 ELSE 0 END) AS live,
                   SUM(hit_count) AS hits
            FROM lm_reply_cache
            """,
            (now,),
        ).fetchone()
        return {
            "total": int(row["total"] or 0),
            "live": int(row["live"] or 0),
            "hits": int(row["hits"] or 0),
        }
    finally:
        conn.close()


def lookup_completion(
    *,
    messages: list[dict[str, Any]] | None,
    user_msg: str,
    normalized_history: list[dict[str, Any]] | None,
    model: str,
    max_tokens: int,
    temperature: float,
    top_p: float,
    think_disabled: bool,
) -> str | None:
    _init_schema()
    request_digest = _request_digest(
        messages,
        model=model,
        max_tokens=max_tokens,
        temperature=temperature,
        top_p=top_p,
        think_disabled=think_disabled,
    )
    now = _now()
    conn = _connect()
    try:
        row = conn.execute("SELECT * FROM lm_reply_cache WHERE exact_digest=? LIMIT 1", (request_digest,)).fetchone()
        if row and float(row["expires_at"] or 0) > now:
            conn.execute(
                "UPDATE lm_reply_cache SET hit_count=hit_count+1, last_hit_at=?, updated_at=? WHERE exact_digest=?",
                (now, now, request_digest),
            )
            conn.commit()
            return str(row["reply"] or "")

        qtype = _question_type(user_msg)
        if not _is_semantic_safe(user_msg, qtype):
            return None

        bucket = _semantic_bucket(
            messages=messages,
            normalized_history=normalized_history,
            model=model,
            max_tokens=max_tokens,
            temperature=temperature,
            top_p=top_p,
            question_type=qtype,
        )
        candidates = conn.execute(
            """
            SELECT * FROM lm_reply_cache
            WHERE semantic_bucket=? AND expires_at>?
            ORDER BY last_hit_at DESC, hit_count DESC, updated_at DESC
            LIMIT 40
            """,
            (bucket, now),
        ).fetchall()
        threshold = _semantic_threshold(user_msg, qtype)
        for candidate in candidates:
            score = _semantic_similarity(user_msg, str(candidate["user_msg"] or ""), qtype)
            if score >= threshold:
                conn.execute(
                    "UPDATE lm_reply_cache SET hit_count=hit_count+1, last_hit_at=?, updated_at=? WHERE exact_digest=?",
                    (now, now, candidate["exact_digest"]),
                )
                conn.commit()
                return str(candidate["reply"] or "")
        return None
    finally:
        conn.close()


def store_completion(
    *,
    messages: list[dict[str, Any]] | None,
    user_msg: str,
    normalized_history: list[dict[str, Any]] | None,
    model: str,
    max_tokens: int,
    temperature: float,
    top_p: float,
    think_disabled: bool,
    reply: str,
    reply_source: str = "",
    meta: dict[str, Any] | None = None,
) -> None:
    reply_text = str(reply or "").strip()
    if not reply_text:
        return
    _init_schema()
    now = _now()
    qtype = _question_type(user_msg)
    semantic_safe = _is_semantic_safe(user_msg, qtype)
    request_digest = _request_digest(
        messages,
        model=model,
        max_tokens=max_tokens,
        temperature=temperature,
        top_p=top_p,
        think_disabled=think_disabled,
    )
    bucket = _semantic_bucket(
        messages=messages,
        normalized_history=normalized_history,
        model=model,
        max_tokens=max_tokens,
        temperature=temperature,
        top_p=top_p,
        question_type=qtype,
    ) if semantic_safe else ""
    conn = _connect()
    try:
        conn.execute(
            """
            INSERT INTO lm_reply_cache (
                exact_digest, semantic_bucket, question_type, user_msg, user_norm,
                system_digest, history_digest, model, max_tokens, temperature, top_p, think_disabled,
                reply, reply_source, created_at, updated_at, expires_at, hit_count, last_hit_at, meta_json
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(exact_digest) DO UPDATE SET
                semantic_bucket=excluded.semantic_bucket,
                question_type=excluded.question_type,
                user_msg=excluded.user_msg,
                user_norm=excluded.user_norm,
                system_digest=excluded.system_digest,
                history_digest=excluded.history_digest,
                model=excluded.model,
                max_tokens=excluded.max_tokens,
                temperature=excluded.temperature,
                top_p=excluded.top_p,
                think_disabled=excluded.think_disabled,
                reply=excluded.reply,
                reply_source=excluded.reply_source,
                updated_at=excluded.updated_at,
                expires_at=excluded.expires_at,
                meta_json=excluded.meta_json
            """,
            (
                request_digest,
                bucket,
                qtype,
                str(user_msg or "")[:240],
                normalize_text(user_msg)[:240],
                _system_digest(messages),
                _history_digest(normalized_history),
                str(model or ""),
                int(max_tokens or 0),
                float(temperature or 0.0),
                float(top_p or 0.0),
                1 if think_disabled else 0,
                reply_text[:4000],
                str(reply_source or "")[:80],
                now,
                now,
                now + (_SEMANTIC_CACHE_TTL_SECONDS if semantic_safe else _EXACT_CACHE_TTL_SECONDS),
                0,
                0.0,
                _json_dumps(meta or {}),
            ),
        )
        conn.execute(
            "DELETE FROM lm_reply_cache WHERE expires_at <= ?",
            (now,),
        )
        conn.commit()
    finally:
        conn.close()

