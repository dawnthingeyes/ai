# -*- coding: utf-8 -*-
"""
张致悦 AI - 认知画像系统
记录角色内心对用户的认知、印象和期待，随对话动态更新
"""
import os, sqlite3, json, random, re
from datetime import datetime
from pathlib import Path
from zhiyue_project_paths import BASE_DIR, COGNITIVE_DB as PROJECT_COGNITIVE_DB

COGNITIVE_DB = os.environ.get("ZHIYUE_COGNITIVE_DB", str(PROJECT_COGNITIVE_DB))

def _init_cognitive_db():
    conn = sqlite3.connect(COGNITIVE_DB, check_same_thread=False)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS cognitive_model (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            dimension TEXT NOT NULL,       -- personality / warmth / reliability / expectations / unmet / attitude
            observation TEXT NOT NULL,     -- 角色的观察结论
            evidence TEXT DEFAULT '',      -- 支撑证据（原始对话摘录）
            confidence INTEGER DEFAULT 1, -- 置信度 1-3
            updated_at TEXT NOT NULL,
            UNIQUE(dimension)
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS attitude_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            dimension TEXT NOT NULL,
            attitude TEXT NOT NULL,
            trigger TEXT DEFAULT '',
            created_at TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()

_init_cognitive_db()

class CognitiveModel:
    """
    角色对用户的认知画像
    维度：personality / warmth / reliability / expectations / unmet_need / attitude
    """
    def __init__(self):
        self.conn = sqlite3.connect(COGNITIVE_DB, check_same_thread=False)

    def _now(self):
        return datetime.now().isoformat()

    # -------- 读取 --------
    def get_model(self):
        """获取当前认知画像（所有维度）"""
        cur = self.conn.execute(
            "SELECT dimension, observation, confidence FROM cognitive_model ORDER BY id"
        )
        return {row[0]: {"observation": row[1], "confidence": row[2]} for row in cur.fetchall()}

    def get_dimension(self, dim):
        cur = self.conn.execute(
            "SELECT observation FROM cognitive_model WHERE dimension = ?", (dim,)
        )
        row = cur.fetchone()
        return row[0] if row else None

    # -------- 更新 --------
    def update(self, dimension, observation, evidence='', confidence=None):
        """
        更新某个维度的认知。
        如果新认知与现有一致，置信度+1（上限3）；否则重置为1。
        """
        existing = self.get_dimension(dimension)
        if existing == observation:
            # 一致，加强置信
            if confidence is None:
                cur = self.conn.execute(
                    "SELECT confidence FROM cognitive_model WHERE dimension = ?", (dimension,)
                )
                row = cur.fetchone()
                new_conf = min(3, (row[0] if row else 1) + 1)
            else:
                new_conf = confidence
            self.conn.execute(
                "UPDATE cognitive_model SET confidence=?, updated_at=? WHERE dimension=?",
                (new_conf, self._now(), dimension)
            )
        else:
            # 新认知
            new_conf = confidence or 1
            self.conn.execute(
                "INSERT OR REPLACE INTO cognitive_model (dimension, observation, evidence, confidence, updated_at) VALUES (?,?,?,?,?)",
                (dimension, observation, evidence[:200] if evidence else '', new_conf, self._now())
            )
        self.conn.commit()

    def log_attitude(self, dimension, attitude, trigger=''):
        """记录态度变化日志"""
        self.conn.execute(
            "INSERT INTO attitude_log (dimension, attitude, trigger, created_at) VALUES (?,?,?,?)",
            (dimension, attitude, trigger[:100], self._now())
        )
        self.conn.commit()

    # -------- 推断分析（NLG辅助） --------
    def infer_from_message(self, user_msg, ai_reply, intimacy_level):
        """
        根据用户消息和AI回复，提取并更新认知画像。
        在每次对话后调用（抽样而非每次全量）。
        """
        # 随机抽样，避免每次都跑（10%概率 + 新维度首次）
        if random.random() > 0.1:
            return

        updated_dims = []
        um = user_msg.strip()

        # ----- personality：推断用户性格特征 -----
        personality_signals = [
            # (关键词模式, 推断结论, 置信度加成)
            (['哈哈哈','好开心','太棒了','好呀好呀','哈哈哈哈哈'], '乐观开朗', 1),
            (['烦','讨厌','滚','不想理你','算了'], '容易烦躁', 1),
            (['应该','我觉得','其实'], '理性克制', 1),
            (['想你','喜欢','爱你','想见你'], '情感直接', 1),
            (['你咋','为啥','怎么回事','为什么'], '好奇心强', 1),
            (['没事','随便','都行','没关系'], '随和随意', 1),
            (['累','困','不想动','好疲惫'], '近期疲惫', 1),
            (['忙','加班','作业','考试'], '近期压力大', 1),
        ]
        for patterns, conclusion, conf in personality_signals:
            if any(p in um for p in patterns):
                self.update('personality', conclusion, evidence=um, confidence=conf)
                updated_dims.append(('personality', conclusion))
                break

        # ----- warmth：用户对角色的情感温度 -----
        warm_signals = [
            (['想你','喜欢','爱你','宝贝','老婆','心肝'], '表达爱意', 1),
            (['在干嘛','吃了吗','睡了吗','还好吗'], '日常关心', 1),
            (['辛苦了','累不累','休息一下'], '体贴关怀', 2),
            (['哈哈','嘿嘿','好'], '轻松愉快', 1),
            (['嗯','行','好'], '敷衍冷淡', -1),
            (['忙','没空','下次吧'], '疏离忙碌', -1),
        ]
        for patterns, conclusion, conf in warm_signals:
            if any(p in um for p in patterns):
                self.update('warmth', conclusion, evidence=um, confidence=conf)
                updated_dims.append(('warmth', conclusion))
                break

        # ----- reliability：角色对用户可靠度的判断 -----
        if '晚安' in um and intimacy_level >= 5:
            self.update('reliability', '记得道晚安', evidence=um, confidence=1)
            updated_dims.append(('reliability', '记得道晚安'))

        # ----- unmet_need：角色的未满足需求（推断） -----
        unmet_hints = [
            (intimacy_level >= 5 and any(w in um for w in ['忙','没空','下次']), '希望对方多陪伴', 1),
            (ai_reply and any(w in ai_reply for w in ['你都不理我','好无聊','没人聊天']), '渴望被关注', 1),
        ]
        for condition, conclusion, conf in unmet_hints:
            if condition:
                self.update('unmet_need', conclusion, confidence=conf)
                updated_dims.append(('unmet_need', conclusion))

        if updated_dims:
            print(f"[认知更新] {updated_dims}")

    # -------- 生成认知画像描述（用于Prompt注入） --------
    def get_prompt_inject(self):
        """生成一段认知画像文本，插入Prompt"""
        model = self.get_model()
        if not model:
            return ""

        lines = []
        lines.append("\n=== 我对你的印象 ===")

        if 'personality' in model:
            m = model['personality']
            lines.append(f"我觉得你是：{m['observation']}")

        if 'warmth' in model:
            m = model['warmth']
            conf_mark = '★' * m['confidence']
            lines.append(f"你最近对我：{m['observation']} {conf_mark}")

        if 'reliability' in model:
            lines.append(f"关于你：{model['reliability']['observation']}")

        if 'unmet_need' in model and model['unmet_need']['confidence'] >= 2:
            lines.append(f"我心里的小遗憾：{model['unmet_need']['observation']}")

        return "\n".join(lines)


# 全局单例
cognitive = CognitiveModel()
