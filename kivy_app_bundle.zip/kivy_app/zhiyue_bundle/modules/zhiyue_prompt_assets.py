# -*- coding: utf-8 -*-
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from zhiyue_pure_chat_config import PROMPT_ASSET_DIR

# NOTE:
# The project should ship with a clean, non-biased initial archive:
# - no pre-filled persona
# - no pre-filled memories
# - no personal names/relationships baked into prompt assets
#
# Users can later customize via the UI and the backend will persist assets into app-private storage.


_DEFAULT_SYSTEM_TEMPLATE = """\
只做陪伴式聊天，不要像客服/助理/说明书。
不提系统、模型、协议、工具、流程；除非用户明确问到。
优先接住情绪和具体点，再继续内容；少解释、少总结、少列清单。
尽量用 2-4 句短句，口语自然，允许停顿与一点点不完美。
如果信息不够：先给一个最自然的回应，再问 1 个最关键的追问。
"""


_DEFAULT_STATE_RENDERER = """\
场景: {scene}
情绪(mood): {mood} | 精力: {energy}/100 | 主动: {initiative} | 亲近拉力: {closeness_pull}/100
语气偏向: {tone_bias} | 声线: {voice_mode}
最近关注: {recent_focus}
边界压力: {boundary_pressure}
只把这些当作语气底色，不要逐项复述。
"""


_DEFAULT_MEMORY_BUDGET = {
    # Keep budgets small by default to save tokens.
    "persona_chars": 220,
    "companion_chars": 240,
    "core_memory_chars": 100,
    "relevant_memory_chars": 100,
    "state_chars": 100,
    "boundary_chars": 70,
}


# Clean default: ship with an empty profile.
_DEFAULT_COMPANION_PROFILE: dict[str, Any] = {}


_DEFAULT_GROWTH_NOTES = """\
成长只做小步迭代，不改骨架。
每次只改 1-2 个点，优先改口吻：更自然、更贴近、更少解释。
记忆只补高频事实/边界/少量共同经历，不要写“人设说明书”。
"""


def _read_text(path: Path, default: str = "") -> str:
    try:
        if path.exists():
            return path.read_text(encoding="utf-8").strip()
    except Exception:
        pass
    return default


def _read_json(path: Path, default: Any) -> Any:
    try:
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        pass
    return default


def _write_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text((content or "").strip() + "\n", encoding="utf-8")


def _write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def ensure_growth_asset_files() -> dict[str, Any]:
    defaults = {
        "chat_system_template.txt": _DEFAULT_SYSTEM_TEMPLATE,
        "state_renderer_template.txt": _DEFAULT_STATE_RENDERER,
        "persona_growth_notes.txt": _DEFAULT_GROWTH_NOTES,
    }
    created: dict[str, Any] = {}
    for name, content in defaults.items():
        path = PROMPT_ASSET_DIR / name
        if not path.exists():
            _write_text(path, content)
            created[name] = True

    budget_path = PROMPT_ASSET_DIR / "memory_budget.json"
    if not budget_path.exists():
        _write_json(budget_path, dict(_DEFAULT_MEMORY_BUDGET))
        created["memory_budget.json"] = True

    companion_profile_path = PROMPT_ASSET_DIR / "companion_profile.json"
    if not companion_profile_path.exists():
        _write_json(companion_profile_path, dict(_DEFAULT_COMPANION_PROFILE))
        created["companion_profile.json"] = True

    return created


def load_chat_system_template() -> str:
    return _read_text(PROMPT_ASSET_DIR / "chat_system_template.txt", _DEFAULT_SYSTEM_TEMPLATE)


def load_state_renderer_template() -> str:
    return _read_text(PROMPT_ASSET_DIR / "state_renderer_template.txt", _DEFAULT_STATE_RENDERER)


def load_persona_growth_notes() -> str:
    return _read_text(PROMPT_ASSET_DIR / "persona_growth_notes.txt", _DEFAULT_GROWTH_NOTES)


def load_companion_profile() -> dict[str, Any]:
    profile = _read_json(PROMPT_ASSET_DIR / "companion_profile.json", dict(_DEFAULT_COMPANION_PROFILE))
    if not isinstance(profile, dict):
        return dict(_DEFAULT_COMPANION_PROFILE)
    # Merge with clean default (currently empty) for forward-compat keys.
    result = dict(_DEFAULT_COMPANION_PROFILE)
    result.update(profile)
    return result


def load_memory_budget() -> dict[str, int]:
    budget = _read_json(PROMPT_ASSET_DIR / "memory_budget.json", dict(_DEFAULT_MEMORY_BUDGET))
    if not isinstance(budget, dict):
        return dict(_DEFAULT_MEMORY_BUDGET)
    result: dict[str, int] = {}
    for key, default in _DEFAULT_MEMORY_BUDGET.items():
        try:
            result[key] = max(0, int(budget.get(key, default)))
        except Exception:
            result[key] = default
    return result


def load_growth_asset_bundle() -> dict[str, Any]:
    return {
        "system_template": load_chat_system_template(),
        "state_renderer": load_state_renderer_template(),
        "memory_budget": load_memory_budget(),
        "persona_growth_notes": load_persona_growth_notes(),
        "companion_profile": load_companion_profile(),
    }


def update_growth_assets(
    *,
    system_template: str | None = None,
    state_renderer: str | None = None,
    memory_budget: dict[str, int] | None = None,
    persona_growth_notes: str | None = None,
    companion_profile: dict[str, Any] | None = None,
) -> dict[str, Any]:
    updated: dict[str, Any] = {}
    if system_template is not None:
        _write_text(PROMPT_ASSET_DIR / "chat_system_template.txt", system_template)
        updated["system_template"] = load_chat_system_template()
    if state_renderer is not None:
        _write_text(PROMPT_ASSET_DIR / "state_renderer_template.txt", state_renderer)
        updated["state_renderer"] = load_state_renderer_template()
    if persona_growth_notes is not None:
        _write_text(PROMPT_ASSET_DIR / "persona_growth_notes.txt", persona_growth_notes)
        updated["persona_growth_notes"] = load_persona_growth_notes()
    if memory_budget is not None:
        clean_budget: dict[str, int] = {}
        for key, default in _DEFAULT_MEMORY_BUDGET.items():
            try:
                clean_budget[key] = max(0, int((memory_budget or {}).get(key, default)))
            except Exception:
                clean_budget[key] = default
        _write_json(PROMPT_ASSET_DIR / "memory_budget.json", clean_budget)
        updated["memory_budget"] = load_memory_budget()
    if companion_profile is not None:
        clean_profile = dict(_DEFAULT_COMPANION_PROFILE)
        if isinstance(companion_profile, dict):
            clean_profile.update(companion_profile)
        _write_json(PROMPT_ASSET_DIR / "companion_profile.json", clean_profile)
        updated["companion_profile"] = load_companion_profile()
    return updated or load_growth_asset_bundle()

