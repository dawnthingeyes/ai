# -*- coding: utf-8 -*-
from __future__ import annotations

from datetime import datetime
import os
import time
from zoneinfo import ZoneInfo


CHAT_DIRECTIVE_SCOPES = {"chat", "global", ""}
CHAT_MEMORY_BLOCKED_SOURCE_MARKERS = ("test", "stress", "smoke", "sandbox", "monitor")
CHAT_NOTE_BLOCKED_TYPES = {"代码审查", "自我改进", "技术问题", "runtime_policy", "proposal"}
TIMEZONE_NAME = os.environ.get("ZHIYUE_TIMEZONE", "Asia/Shanghai").strip() or "Asia/Shanghai"
try:
    APP_TIMEZONE = ZoneInfo(TIMEZONE_NAME)
except Exception:
    APP_TIMEZONE = ZoneInfo("Asia/Shanghai")


def now_local():
    return datetime.now(APP_TIMEZONE)


def parse_iso_dt_soft(value):
    try:
        dt = datetime.fromisoformat(str(value or ""))
        if dt.tzinfo is None:
            return dt.replace(tzinfo=APP_TIMEZONE)
        return dt.astimezone(APP_TIMEZONE)
    except Exception:
        return None


def source_allows_chat_inject(source):
    value = str(source or "").strip().lower()
    if not value:
        return True
    return not any(marker in value for marker in CHAT_MEMORY_BLOCKED_SOURCE_MARKERS)


def directive_allows_chat(directive):
    if not isinstance(directive, dict):
        return False
    scope = str(directive.get("scope") or "chat").strip().lower()
    source = str(directive.get("source") or "").strip().lower()
    return scope in CHAT_DIRECTIVE_SCOPES and source_allows_chat_inject(source)


def memory_allows_chat_inject(item):
    if not isinstance(item, dict):
        return False
    if int(item.get("allow_chat_inject", 1) or 0) != 1:
        return False
    if str(item.get("scope") or "chat").strip().lower() not in {"chat", "global", ""}:
        return False
    expires_dt = parse_iso_dt_soft(item.get("expires_at"))
    if expires_dt and expires_dt <= now_local():
        return False
    if not source_allows_chat_inject(item.get("source")):
        return False
    created_dt = parse_iso_dt_soft(item.get("created_at"))
    if created_dt:
        age_days = max(0.0, (now_local() - created_dt).total_seconds() / 86400.0)
        if age_days > 180 and float(item.get("confidence") or 0) < 2.5:
            return False
    return True


def learning_note_allows_chat_inject(note_type, content, confidence, created_at):
    note_type_text = str(note_type or "").strip().lower()
    if note_type_text in {value.lower() for value in CHAT_NOTE_BLOCKED_TYPES}:
        return False
    content_text = str(content or "").lower()
    if any(marker in content_text for marker in ("代码", "源码", "规则", "接口", "proposal", "sandbox")):
        return False
    created_dt = parse_iso_dt_soft(created_at)
    if created_dt:
        age_days = max(0.0, (now_local() - created_dt).total_seconds() / 86400.0)
        if age_days > 45 and float(confidence or 0) < 3:
            return False
    return True


def infer_chat_state_meta(*, source="", category="", mem_type="", note_type=""):
    source_text = str(source or "").strip().lower()
    category_text = str(category or "").strip().lower()
    note_type_text = str(note_type or "").strip().lower()
    blocked = (
        not source_allows_chat_inject(source_text)
        or note_type_text in {value.lower() for value in CHAT_NOTE_BLOCKED_TYPES}
        or any(token in category_text for token in ("代码", "技术", "proposal", "sandbox"))
        or any(token in note_type_text for token in ("代码", "技术", "proposal", "sandbox"))
    )
    scope = "technical" if blocked else "chat"
    return {
        "scope": scope,
        "allow_chat_inject": 0 if blocked else 1,
        "expires_at": None,
    }


def prune_expired_state(*, force, intimacy, memory_conn, growth_conn, load_user_directives, save_user_directives, log_runtime_exception):
    now = now_local()
    now_iso = now.isoformat()
    prune_key = now.strftime("%Y-%m-%dT%H")
    if not force and intimacy.data.get("last_state_prune_hour") == prune_key:
        return {"memories": 0, "learning_notes": 0, "user_directives": 0}

    pruned_memories = 0
    pruned_notes = 0
    pruned_directives = 0

    try:
        cur = memory_conn.execute(
            """
            UPDATE memories
            SET status='archived', last_recall=?
            WHERE status='active'
              AND expires_at IS NOT NULL
              AND expires_at != ''
              AND expires_at <= ?
            """,
            (now_iso, now_iso),
        )
        memory_conn.commit()
        pruned_memories = int(getattr(cur, "rowcount", 0) or 0)
    except Exception as err:
        log_runtime_exception("prune_expired_state.memories", err)

    try:
        cur = growth_conn.execute(
            """
            UPDATE learning_notes
            SET active=0
            WHERE active=1
              AND expires_at IS NOT NULL
              AND expires_at != ''
              AND expires_at <= ?
            """,
            (now_iso,),
        )
        growth_conn.commit()
        pruned_notes = int(getattr(cur, "rowcount", 0) or 0)
    except Exception as err:
        log_runtime_exception("prune_expired_state.learning_notes", err)

    try:
        directives = load_user_directives(for_chat=False)
        kept = [item for item in directives if item.get("expire_until", 0) > time.time()]
        pruned_directives = max(0, len(directives) - len(kept))
        if pruned_directives:
            save_user_directives(kept)
    except Exception as err:
        log_runtime_exception("prune_expired_state.user_directives", err)

    intimacy.data["last_state_prune_hour"] = prune_key
    intimacy.save()
    return {
        "memories": pruned_memories,
        "learning_notes": pruned_notes,
        "user_directives": pruned_directives,
    }


def get_state_hygiene_summary(*, intimacy, memory_conn, growth_conn, load_user_directives, log_runtime_exception):
    now_iso = now_local().isoformat()
    try:
        memory_row = memory_conn.execute(
            """
            SELECT
                COUNT(*),
                SUM(CASE WHEN scope='technical' OR allow_chat_inject=0 THEN 1 ELSE 0 END),
                SUM(CASE WHEN expires_at IS NOT NULL AND expires_at != '' THEN 1 ELSE 0 END),
                SUM(CASE WHEN expires_at IS NOT NULL AND expires_at != '' AND expires_at <= ? THEN 1 ELSE 0 END)
            FROM memories
            WHERE status='active'
            """,
            (now_iso,),
        ).fetchone() or (0, 0, 0, 0)
    except Exception as err:
        log_runtime_exception("state_hygiene.memories", err)
        memory_row = (0, 0, 0, 0)

    try:
        note_row = growth_conn.execute(
            """
            SELECT
                COUNT(*),
                SUM(CASE WHEN scope='technical' OR allow_chat_inject=0 THEN 1 ELSE 0 END),
                SUM(CASE WHEN expires_at IS NOT NULL AND expires_at != '' THEN 1 ELSE 0 END),
                SUM(CASE WHEN expires_at IS NOT NULL AND expires_at != '' AND expires_at <= ? THEN 1 ELSE 0 END)
            FROM learning_notes
            WHERE active=1
            """,
            (now_iso,),
        ).fetchone() or (0, 0, 0, 0)
    except Exception as err:
        log_runtime_exception("state_hygiene.learning_notes", err)
        note_row = (0, 0, 0, 0)

    directives_all = load_user_directives(for_chat=False)
    directives_chat = load_user_directives(for_chat=True)
    return {
        "last_state_prune_hour": intimacy.data.get("last_state_prune_hour"),
        "memories": {
            "active_total": int(memory_row[0] or 0),
            "technical_or_blocked": int(memory_row[1] or 0),
            "ttl_tagged": int(memory_row[2] or 0),
            "expired_still_active": int(memory_row[3] or 0),
        },
        "learning_notes": {
            "active_total": int(note_row[0] or 0),
            "technical_or_blocked": int(note_row[1] or 0),
            "ttl_tagged": int(note_row[2] or 0),
            "expired_still_active": int(note_row[3] or 0),
        },
        "user_directives": {
            "all_active": len(directives_all),
            "chat_visible": len(directives_chat),
            "hidden_from_chat": max(0, len(directives_all) - len(directives_chat)),
        },
    }


def state_hygiene_reply(user_msg, summary):
    msg = (user_msg or "").strip()
    if not msg:
        return None
    triggers = [
        "状态治理", "状态注入", "状态清理", "查看状态", "看看状态",
        "记忆注入", "学习笔记注入", "过期状态", "状态卫生", "state hygiene",
    ]
    if not any(trigger in msg for trigger in triggers):
        return None
    return (
        f"现在能直接看状态治理了。记忆活跃 {summary['memories']['active_total']} 条，"
        f"其中技术/已屏蔽 {summary['memories']['technical_or_blocked']} 条；"
        f"学习笔记活跃 {summary['learning_notes']['active_total']} 条，"
        f"其中技术/已屏蔽 {summary['learning_notes']['technical_or_blocked']} 条；"
        f"用户指令当前 {summary['user_directives']['all_active']} 条，聊天可见 {summary['user_directives']['chat_visible']} 条。"
        "你要详细看，查 /api/state_hygiene 就行。"
    )
