# -*- coding: utf-8 -*-
from __future__ import annotations

from datetime import datetime, timedelta


def classify_skill_state(*, usage_count: int, last_used_at: str = "", pinned: bool = False) -> str:
    if pinned:
        return "pinned"
    if usage_count <= 0:
        return "stale"
    try:
        last = datetime.fromisoformat(str(last_used_at))
    except Exception:
        last = None
    if not last:
        return "active" if usage_count > 0 else "stale"
    age_days = max(0.0, (datetime.now() - last).total_seconds() / 86400.0)
    if age_days >= 60 and usage_count < 3:
        return "archived"
    if age_days >= 30:
        return "stale"
    return "active"
