# -*- coding: utf-8 -*-
from __future__ import annotations

from typing import Any
import zhiyue_human_like as human_like


def _emotion_anchor(user_msg: str) -> str:
    msg = user_msg or ""
    if any(term in msg for term in ["\u7d2f", "\u56f0", "\u7126\u8651", "\u5d29", "\u96be\u53d7", "\u5934\u75bc", "\u9ebb\u4e86"]):
        return "\u6211\u5148\u5e2e\u4f60\u6361\u4e00\u4e0b\uff0c\u4f60\u522b\u6025\u3002"
    if any(term in msg for term in ["\u8d76", "\u6765\u4e0d\u53ca", "\u6025", "\u9a6c\u4e0a", "\u7acb\u523b"]):
        return "\u884c\uff0c\u6211\u5148\u6293\u91cd\u70b9\u3002"
    return "\u6211\u770b\u8fc7\u4e86\uff0c\u7ed9\u4f60\u538b\u77ed\u8bf4\u3002"


def close_office_reply(user_msg: str, reply: str) -> str:
    return human_like.humanize_office_reply(user_msg, (reply or "").strip())


def render_office_result(user_msg: str, execution: dict[str, Any]) -> str:
    kind = str(execution.get("kind") or "")
    payload = execution.get("payload") if isinstance(execution.get("payload"), dict) else {}
    anchor = _emotion_anchor(user_msg)

    if kind == "browser_read":
        title = payload.get("title") or "\u8fd9\u4e2a\u7f51\u9875"
        preview = str(payload.get("content_preview") or "").strip()
        prefix = "\u6211\u987a\u7740\u521a\u624d\u90a3\u4e2a\u7f51\u9875\u7ee7\u7eed\u770b\u4e86\u4e0b\u3002 " if payload.get("from_recent_context") else ""
        if preview:
            return close_office_reply(user_msg, f"{anchor} {prefix}\u6211\u5148\u770b\u4e86\u4e0b\u300a{title}\u300b\uff0c\u524d\u9762\u4e3b\u8981\u662f\uff1a{preview}")
        return close_office_reply(user_msg, f"{anchor} {prefix}\u6211\u5148\u770b\u4e86\u4e0b\u300a{title}\u300b\uff0c\u4f60\u8981\u7684\u8bdd\u6211\u7ee7\u7eed\u7ed9\u4f60\u538b\u6210\u6458\u8981\u3002")

    if kind == "browser_fill_ready":
        return close_office_reply(user_msg, f"{anchor} \u8fd9\u4e2a\u8868\u6211\u80fd\u5e2e\u4f60\u586b\uff0c\u4f46\u4f60\u628a\u8981\u586b\u7684\u5b57\u6bb5\u53d1\u6211\uff0c\u6211\u6309\u9879\u66ff\u4f60\u586b\u3002")

    if kind == "local_read":
        name = payload.get("file_name") or "\u8fd9\u4e2a\u6587\u4ef6"
        preview = str(payload.get("content_preview") or "").strip()
        prefix = "\u6211\u987a\u7740\u521a\u624d\u90a3\u4e2a\u6587\u4ef6\u7ee7\u7eed\u63a5\u4e0a\u4e86\u3002 " if payload.get("from_recent_context") else ""
        if preview:
            return close_office_reply(user_msg, f"{anchor} {prefix}\u6211\u627e\u5230\u300a{name}\u300b\u4e86\uff0c\u524d\u9762\u5927\u6982\u662f\uff1a{preview}")
        return close_office_reply(user_msg, f"{anchor} {prefix}\u6211\u627e\u5230\u300a{name}\u300b\u4e86\u3002")

    if kind == "local_rewrite":
        name = payload.get("file_name") or "\u8fd9\u4e2a\u6587\u4ef6"
        output_path = payload.get("output_path") or ""
        instruction = str(payload.get("instruction") or "").strip()
        if instruction:
            return close_office_reply(user_msg, f"{anchor} \u6211\u987a\u7740\u521a\u624d\u90a3\u4e2a\u6587\u4ef6\u7ee7\u7eed\u6539\u4e86\u4e00\u7248\u300a{name}\u300b\uff0c\u8fd9\u6b21\u6309\u201c{instruction}\u201d\u6536\u4e86\uff0c\u7ed3\u679c\u5728 `{output_path}`\u3002")
        return close_office_reply(user_msg, f"{anchor} \u6211\u987a\u7740\u521a\u624d\u90a3\u4e2a\u6587\u4ef6\u7ee7\u7eed\u6539\u4e86\u4e00\u7248\u300a{name}\u300b\uff0c\u7ed3\u679c\u5728 `{output_path}`\u3002")

    if kind == "local_delete":
        name = payload.get("file_name") or "\u8fd9\u4e2a\u6587\u4ef6"
        return close_office_reply(user_msg, f"{anchor} \u6211\u5df2\u7ecf\u628a\u300a{name}\u300b\u5220\u6389\u4e86\uff0c\u540e\u9762\u5982\u679c\u4f60\u8981\u6211\u6362\u4e2a\u7248\u672c\u91cd\u505a\uff0c\u6211\u53ef\u4ee5\u76f4\u63a5\u63a5\u7740\u6765\u3002")

    if kind == "local_quiz":
        items = payload.get("selected_items") or []
        opening = str(payload.get("opening_line") or "").strip()
        if items:
            first = items[0] if isinstance(items[0], dict) else {}
            topic = str(first.get("topic") or "").strip()
            question = str(first.get("question") or "").strip()
            lead = opening or "\u6211\u5148\u6311\u4e86\u51e0\u9053\u66f4\u5bb9\u6613\u5361\u4f4f\u4f60\u7684\u3002"
            if topic and question:
                return close_office_reply(user_msg, f"{anchor} {lead} \u5148\u6765\u7b2c\u4e00\u9053\uff0c\u504f\u201c{topic}\u201d\uff1a{question}")
        return close_office_reply(user_msg, f"{anchor} \u6211\u5148\u6311\u4e86\u51e0\u9053\u504f\u96be\u7684\uff0c\u6211\u4eec\u76f4\u63a5\u4e00\u9053\u4e00\u9053\u6765\u3002\u4f60\u51c6\u5907\u597d\u4e86\u6211\u5c31\u5148\u51fa\u7b2c\u4e00\u9898\u3002")

    if kind == "local_extract_direct":
        lead = str(payload.get("lead") or "").strip()
        body = str(payload.get("body") or "").strip()
        bullets = payload.get("bullets") or []
        parts = [part for part in [lead, body] if part]
        bullet_text = "\uff1b".join(str(item).strip() for item in bullets if str(item).strip())
        if bullet_text:
            parts.append(bullet_text)
        if parts:
            return close_office_reply(user_msg, f"{anchor} {' '.join(parts)}")
        return close_office_reply(user_msg, f"{anchor} \u6211\u5148\u628a\u7ed3\u679c\u76f4\u63a5\u7ed9\u4f60\u6536\u51fa\u6765\u4e86\u3002")

    if kind == "local_extract":
        name = payload.get("file_name") or "\u8fd9\u4e2a\u6587\u4ef6"
        output_path = payload.get("output_path") or ""
        extract_mode = str(payload.get("mode") or "summary")
        tasks = payload.get("structured_tasks") or []
        if extract_mode == "todo_list" and tasks:
            preview = "\uff1b".join(
                f"{item.get('task')} / {item.get('owner') or '\u672a\u6807\u8d1f\u8d23\u4eba'} / {item.get('due') or '\u672a\u6807\u622a\u6b62'}"
                for item in tasks[:3]
                if isinstance(item, dict)
            )
            return close_office_reply(user_msg, f"{anchor} \u6211\u5df2\u7ecf\u4ece\u300a{name}\u300b\u91cc\u62c6\u51fa\u51e0\u6761\u5173\u952e\u9879\u4e86\uff0c\u524d\u51e0\u6761\u662f\uff1a{preview}\u3002\u6574\u7406\u7a3f\u6211\u4e5f\u653e\u5230 `{output_path}` \u4e86\u3002")
        if extract_mode == "meeting_notes":
            return close_office_reply(user_msg, f"{anchor} \u6211\u628a\u300a{name}\u300b\u6574\u7406\u6210\u7eaa\u8981\u4e86\uff0c\u51b3\u5b9a\u4e8b\u9879\u548c\u540e\u7eed\u52a8\u4f5c\u90fd\u6536\u8fdb\u53bb\u4e86\uff0c\u7a3f\u5b50\u5728 `{output_path}`\u3002")
        return close_office_reply(user_msg, f"{anchor} \u6211\u628a\u300a{name}\u300b\u5148\u6574\u7406\u597d\u4e86\uff0c\u7ed3\u679c\u5728 `{output_path}`\u3002\u4f60\u8981\u6211\u518d\u538b\u77ed\u4e00\u70b9\u4e5f\u884c\u3002")

    if kind == "not_found":
        return close_office_reply(user_msg, "\u6211\u53bb\u770b\u4e86\u4f60\u8bf4\u7684\u8303\u56f4\uff0c\u4f46\u8fd8\u6ca1\u6293\u5230\u6700\u50cf\u7684\u90a3\u4efd\u6750\u6599\u3002\u4f60\u8981\u662f\u613f\u610f\uff0c\u6211\u53ef\u4ee5\u7ee7\u7eed\u7f29\u5c0f\u8303\u56f4\u627e\uff0c\u6216\u8005\u4f60\u76f4\u63a5\u628a\u6587\u4ef6\u540d\u544a\u8bc9\u6211\u3002")

    if kind == "need_instruction":
        name = payload.get("file_name") or "\u8fd9\u4e2a\u6587\u4ef6"
        return close_office_reply(user_msg, f"{anchor} \u6211\u80fd\u63a5\u7740\u6539\u300a{name}\u300b\uff0c\u4f46\u4f60\u5f97\u518d\u7ed9\u6211\u4e00\u53e5\u660e\u786e\u65b9\u5411\uff0c\u6bd4\u5982\u66f4\u6b63\u5f0f\u4e00\u70b9\u3001\u538b\u77ed\u4e00\u70b9\uff0c\u6216\u8005\u6539\u6210\u4f1a\u8bae\u7eaa\u8981\u3002")

    if kind == "failed":
        detail = str(payload.get("error") or "\u5904\u7406\u5931\u8d25").strip()
        return close_office_reply(user_msg, f"\u6211\u521a\u8bd5\u4e86\u4e0b\uff0c\u8fd9\u4e00\u6b65\u6ca1\u8dd1\u901a\uff1a{detail}")

    return close_office_reply(user_msg, f"{anchor} \u6211\u5148\u5e2e\u4f60\u5904\u7406\u4e86\u4e00\u4e0b\u3002")
