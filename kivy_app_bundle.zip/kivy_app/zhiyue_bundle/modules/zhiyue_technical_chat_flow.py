# -*- coding: utf-8 -*-
from __future__ import annotations

import hashlib
import random
import re


def self_improvement_brief_reply(
    user_msg,
    *,
    layers,
    classify_user_feedback_with_model,
    clean_reply,
):
    msg = user_msg or ""
    meta_terms = [
        "改代码", "修改源码", "你想改什么", "要改什么", "修改方案",
        "自主优化", "自我改进", "自我优化", "沙箱", "权限",
        "你能改吗", "你能处理吗", "怎么优化", "怎么修", "怎么改", "修一下", "改一下代码",
        "回答有问题", "回复有问题", "回答很有问题", "回复很有问题",
        "像模板", "不像人", "驴唇不对马嘴", "偏题", "跑偏", "乱码", "外语",
        "裁判", "压力测试", "bug", "BUG", "日志", "监控",
        "记忆成长", "自主测试", "自主对话", "提案", "源码",
    ]
    context_terms = ["哪一步", "到哪一步", "进度", "想改什么", "要改什么", "通俗"]
    meta_hit = any(k in msg for k in meta_terms)
    asks = meta_hit or any(k in msg for k in context_terms)
    feedback = classify_user_feedback_with_model(msg) if meta_hit else {
        "label": "neutral",
        "needs_action": False,
        "problem_report": False,
        "approval": False,
        "rejection": False,
        "reason": "meta terms not detected",
    }
    asks = asks or (meta_hit and (bool(feedback.get("problem_report")) or str(feedback.get("label") or "") == "request_change"))
    if not asks:
        return None
    if not layers or not hasattr(layers, "self_improvement"):
        return "我现在还看不到自我改进层，所以不会乱改源码"
    try:
        briefing = layers.self_improvement.review_briefing(limit=3)
    except Exception:
        return "自检简报读取失败，先不动源码"
    latest = briefing.get("latest") if isinstance(briefing, dict) else {}
    latest = latest if isinstance(latest, dict) else {}
    if latest.get("kind") == "none":
        if any(k in msg for k in ["哪一步", "到哪一步", "进度"]):
            return "现在没有必须立刻改的东西，我会继续攒问题，够了再问你"
        if any(k in msg for k in ["想改什么", "通俗", "要改什么"]):
            return "现在还不用立刻动源码，我先把问题归一归"
        if any(k in msg for k in ["沙箱", "权限", "允许"]):
            return "收到，真有方案也先跑沙箱，不直接改源码"
        return random.choice([
            "现在没有必须立刻改的东西，我会继续攒问题，够了再问你",
            "现在还不用立刻动源码，我先把问题归一归",
            "目前没有需要立刻改的东西，我先继续收集问题",
        ])
    title = clean_reply(str(latest.get("title") or "一个小改进"))[:90]
    summary = clean_reply(str(latest.get("summary") or latest.get("why") or "让回复和记忆更稳"))[:120]
    next_step = clean_reply(str(latest.get("next_step") or "先跑沙箱，不直接改源码"))[:100]
    if latest.get("kind") == "proposal":
        if latest.get("workflow_state") == "sandbox_goal_met_awaiting_source_confirmation":
            return random.choice([
                f"沙箱这步过了，但源码还不动，要改的是：{title}。你确认后我才继续",
                f"沙箱已过，现在就等你说是否回到源码：{title}。",
            ])
        return random.choice([
            f"我现在最想先处理：{title}，原因是：{summary}。{next_step}你同意的话，先说“同意先跑沙箱”",
            f"目前最想先改的是：{title}，主要原因是：{summary}。{next_step}",
        ])
    return random.choice([
        f"我现在撞到的主要问题是：{title}。我会先把它整理成小方案，不会有一点问题就改源码",
        f"现在最想先处理的是：{title}。我会先把问题拆开再动",
    ])


def code_fix_chat_reply(
    user_msg,
    *,
    scan_and_accumulate_issues,
    get_pending_summary,
    format_pending_for_user,
    approve_fixes,
    generate_fix_diff_for_approved,
    format_proposals_for_user,
    execute_approved_fixes,
    reject_fixes,
    layers,
    tool_source_dir,
    clean_reply,
):
    msg = (user_msg or "").strip()
    if not msg:
        return None

    def _match(patterns, text):
        for p in patterns:
            if isinstance(p, tuple) and re.search(p[0], text):
                return True
            if isinstance(p, str) and p in text:
                return True
        return False

    if _match([
        "生成.*方案", "看看待修复", "攒了多少问题", "有哪些问题", "问题列表",
        "代码问题", "扫一下问题", "扫描问题", "攒了几个", "攒了几个问题",
        "有多少问题", "检查问题", "看看问题", "待修", "自查", "自检结果",
    ], msg):
        try:
            summary = get_pending_summary()
            if summary["total_pending"] == 0:
                scan_and_accumulate_issues(tool_source_dir)
            return format_pending_for_user()
        except Exception as err:
            return f"查看待修复出了点问题：{str(err)[:80]}"

    # ── 用户要求直接执行修复（不只是看方案，而是动手改）
    if _match([
        "修吧", "那就修", "可以修", "同意修", "改吧", "那就改",
        "开始修代码", "修代码", "改代码", "动手", "动手修",
        "你去试试", "你去修", "你修吧", "你改吧",
        "干好了叫我", "好了叫我", "修完叫我",
        "直接修", "直接改", "直接动手",
        "别光说不练", "别光说不做", "别只说不动",
        "赶紧修", "赶紧改", "快点修", "快点改",
        "执行修复", "执行修改", "开始执行",
        "批准修复", "批准所有", "全批准",
        "应用修改", "应用方案", "应用修复",
        (r"能.*处理",), (r"能.*修.*吗",), (r"能.*改.*吗",),
        (r"处理.*吧",), (r"处理一下",),
    ], msg):
        try:
            scan_and_accumulate_issues(tool_source_dir)
            result = approve_fixes()
            if result["approved"] == 0:
                return "没有待批准的问题诶。先让我扫一遍？你可以说“看看待修复”"
            # 先生成方案
            proposals = generate_fix_diff_for_approved(tool_source_dir)
            if not proposals:
                return "批准了，但暂时没法自动生成 diff……这些问题需要你手动改，或者让我逐个细看。"
            # 直接执行修复
            exec_result = execute_approved_fixes(tool_source_dir)
            executed = exec_result.get("executed", 0)
            skipped = exec_result.get("skipped", 0)
            errors = exec_result.get("errors", [])
            backup = exec_result.get("backup_path", "")
            if executed > 0 and not errors:
                reply = f"搞定了，改了 {executed} 处"
                if skipped > 0:
                    reply += f"，还有 {skipped} 处得你亲自看（风险高的我没敢自动动）"
                reply += "。备份在 " + backup.split("\\")[-1] if backup else ""
                reply += "。得重启才能生效哦。"
                return reply
            elif executed > 0 and errors:
                reply = f"改了 {executed} 处，但"
                for e in errors[:2]:
                    reply += f"：{e}。"
                reply += "备份在 " + backup.split("\\")[-1] if backup else ""
                return reply
            else:
                # 全部被跳过——说明没有能自动修的项
                if skipped > 0:
                    # 看看都是什么类型的
                    auto_count = sum(1 for p in proposals if p.get('diff_text') and not p['diff_text'].startswith('#') and p.get('category') == 'bare_except')
                    if auto_count == 0:
                        return f"现在攒的 {skipped} 个问题都没法自动改（比如备份文件整理这种），得手动或者我帮你逐个看。要不你先说‘看看方案’我给你列出来？"
                return f"没能改成……{exec_result.get('message', '出了点问题')}。你看看要不要手动搞？"
        except Exception as err:
            return f"执行修复出了问题：{str(err)[:80]}"

    # ── 用户要求看方案/进沙盒（先看后做）
    if _match([
        "确认进沙箱", "进沙箱", "跑沙箱", "先进沙箱", "先跑沙箱",
        (r"生成.*方案",), (r"给.*方案",), (r"测试.*方案",), (r"验证.*方案",),
        "看看方案", "给个方案", "出个方案", "看看怎么改",
    ], msg):
        try:
            scan_and_accumulate_issues(tool_source_dir)
            result = approve_fixes()
            if result["approved"] == 0:
                return "没有待批准的问题。先让我扫一遍？你可以说“看看待修复”"
            proposals = generate_fix_diff_for_approved(tool_source_dir)
            if not proposals:
                return "批准了，但暂时没法自动生成 diff。这些问题需要你手动改，或者让我逐个细看。"
            return format_proposals_for_user(proposals)
        except Exception as err:
            return f"生成方案出了问题：{str(err)[:80]}"

    if _match([
        "确认应用", "正式改", "改到源码", "应用源码",
        "确认应用源码", "正式应用", "就这样改", "按这个改",
    ], msg):
        try:
            if not layers or not hasattr(layers, "self_improvement"):
                return "自我改进层不可用，没法应用源码修改。"
            proposals = layers.self_improvement.list_code_proposals(status="approved", limit=5)
            if not proposals:
                proposals = layers.self_improvement.list_code_proposals(status="ready_for_sandbox", limit=5)
            if not proposals:
                return "没有已批准的代码提案。先说“确认进沙箱”开始流程。"
            for proposal in proposals:
                meta = proposal.get("meta") or {}
                if meta.get("latest_sandbox_status") == "passed":
                    try:
                        layers.self_improvement.apply_code_proposal_to_source(proposal.get("id"), confirmation_text=msg)
                        title = clean_reply(str(proposal.get("title") or "提案"))[:60]
                        return f"已应用到源码：{title}。需要重启才能生效。"
                    except Exception as err:
                        return f"应用失败：{str(err)[:120]}"
            return "还没有通过沙箱的提案。先说“进沙箱”跑一遍。"
        except Exception as err:
            return f"应用流程出了问题：{str(err)[:80]}"

    cancel_specific = _match([
        "不要修复", "取消修复", "不用修", "先不修",
        "算了不修", "先别修", "别改了", "不用改", "先不改",
    ], msg)
    cancel_broad = _match(["取消", "不要了", "算了", "先放着", "先不开"], msg)
    has_fix_context = any(k in msg for k in ["修", "改", "沙箱", "方案", "问题", "fix", "pending"])
    if cancel_specific or (cancel_broad and has_fix_context):
        try:
            items = get_pending_summary().get("items", [])
            ids = [i["id"] for i in items if i.get("status") == "pending"]
            if ids:
                reject_fixes(ids)
                return f"已取消 {len(ids)} 个待修复问题。"
            return "没有待取消的。"
        except Exception:
            return None
    return None


def maybe_record_user_reported_reply_issue(
    user_msg,
    *,
    layers,
    clean_reply,
):
    msg = user_msg or ""
    reports_reply_issue = any(k in msg for k in [
        "回答有问题", "回复有问题", "回答很有问题", "回复很有问题",
        "回答不对", "回复不对", "不像人", "像模板", "模板味",
        "驴唇不对马嘴", "乱回", "没接住", "说得怪", "说的怪",
    ])
    asks_fix = any(k in msg for k in [
        "怎么修", "怎么改", "改一下", "修一下", "改代码", "改一下代码", "优化一下",
    ])
    if not (reports_reply_issue and asks_fix):
        return None
    if not layers or not hasattr(layers, "self_improvement"):
        return "我看到了，但现在自我改进层不可用，我先不动源码"
    evidence = [{
        "id": f"user-report-{hashlib.sha1(msg.encode('utf-8', errors='ignore')).hexdigest()[:12]}",
        "user_msg": clean_reply(msg)[:220],
        "reported_issue": "reply quality",
    }]
    try:
        candidate = layers.self_improvement.record_candidate(
            source="user.report",
            category="reply_quality.user_reported",
            title="Fix user-reported unnatural or off-topic replies",
            recommendation=(
                "Add focused daily-chat regression cases and tighten reply repair fallbacks "
                "for user-reported unnatural or off-topic replies."
            ),
            evidence=evidence,
            impact="User explicitly reported reply quality regression in chat.",
            risk="low",
            meta={"from_chat": True, "reported_by_user": True},
        )
    except Exception:
        candidate = {}
    title = clean_reply(str(candidate.get("title") or "回复质量问题"))[:80] if isinstance(candidate, dict) else "回复质量问题"
    return (
        f"这次我记成要修的点了：{title}。"
        "我会先补对话测试和小补丁，先跑沙箱；"
        "没过测试不动正式源码。"
        "你要我继续的话，说“可以”就行。"
    )


def self_improvement_chat_approval_reply(
    user_msg,
    *,
    layers,
    classify_user_feedback_with_model,
    clean_reply,
):
    msg = user_msg or ""
    feedback = classify_user_feedback_with_model(msg)
    explicit_sandbox_approval = any(k in msg for k in [
        "同意先跑沙箱", "授权先跑沙箱", "批准先跑沙箱", "可以先跑沙箱", "允许先跑沙箱",
    ])
    approval_like = bool(feedback.get("approval")) and len(msg.strip()) <= 12
    mentions_improvement = any(k in msg for k in ["沙箱", "提案", "改代码", "修改源码", "优化", "修复", "源码"])
    approves_sandbox = explicit_sandbox_approval or (approval_like and mentions_improvement)
    if not approves_sandbox:
        return None
    if any(k in msg for k in ["应用到源码", "直接改源码", "正式改源码"]):
        return "这句涉及源码应用，我不在普通聊天里直接改源码，必须先有通过的沙箱结果"
    if not layers or not hasattr(layers, "self_improvement"):
        return "现在自我改进层不可用，我不会贸然记授权"
    try:
        proposals = layers.self_improvement.list_code_proposals(status="draft", limit=5)
        if not proposals:
            proposals = layers.self_improvement.list_code_proposals(status="ready_for_sandbox", limit=5)
        if not proposals:
            recent = layers.self_improvement.list_code_proposals(status="all", limit=20)
            proposals = [
                item for item in recent
                if str(item.get("status") or "") in {"draft", "ready_for_sandbox", "approved"}
            ][:5]
        proposal = proposals[0] if proposals else {}
        if not proposal:
            if not explicit_sandbox_approval:
                return None
            return "现在没有等你批的代码提案，所以不记这次授权"
        updated = layers.self_improvement.authorize_code_proposal(proposal.get("id") or "", msg)
        title = clean_reply(str(updated.get("title") or "这个提案"))[:90]
        return f"收到，我只把“{title}”标成允许跑沙箱，源码还没动"
    except Exception as err:
        return f"这次授权没记上：{clean_reply(str(err))[:80]}"
