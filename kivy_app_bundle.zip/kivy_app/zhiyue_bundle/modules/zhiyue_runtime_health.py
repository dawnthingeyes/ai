# -*- coding: utf-8 -*-
from __future__ import annotations

import os
import time
from datetime import datetime
from pathlib import Path
from urllib.error import URLError
from urllib.request import urlopen

from zhiyue_project_paths import SELF_MONITOR_STATE_FILE


LM_HEALTH_URL = os.environ.get("ZHIYUE_SELF_MONITOR_LM_HEALTH_URL", "http://127.0.0.1:1234/v1/models").strip()
GATEWAY_HEALTH_URL = os.environ.get("ZHIYUE_SELF_MONITOR_GATEWAY_HEALTH_URL", "http://127.0.0.1:8899/v1").strip()
BACKEND_HEALTH_URL = os.environ.get("ZHIYUE_SELF_MONITOR_BACKEND_HEALTH_URL", "http://127.0.0.1:8898/api/health").strip()


def http_service_ready(url: str) -> bool:
    if not url:
        return True
    try:
        with urlopen(url, timeout=3) as resp:
            code = int(getattr(resp, "status", 200) or 200)
            return 200 <= code < 300
    except (URLError, OSError, ValueError):
        return False


def model_service_ready() -> bool:
    return http_service_ready(LM_HEALTH_URL)


def runtime_health_snapshot() -> dict:
    return {
        "lm": model_service_ready(),
        "gateway": http_service_ready(GATEWAY_HEALTH_URL),
        "backend": http_service_ready(BACKEND_HEALTH_URL),
    }


def self_monitor_snapshot(
    state_file: str | Path = SELF_MONITOR_STATE_FILE,
    *,
    stale_after_seconds: int = 1800,
) -> dict:
    path = Path(state_file)
    snapshot = {
        "state_file": str(path),
        "exists": path.exists(),
        "last_run_at": "",
        "last_error": "",
        "cycles": 0,
        "stale": True,
        "age_seconds": None,
    }
    if not path.exists():
        return snapshot
    try:
        import json

        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception as err:
        snapshot["last_error"] = str(err)
        return snapshot
    snapshot["cycles"] = int(data.get("cycles") or 0)
    snapshot["last_run_at"] = str(data.get("last_run_at") or "")
    snapshot["last_error"] = str(data.get("last_error") or "")
    if not snapshot["last_run_at"]:
        return snapshot
    try:
        dt = datetime.fromisoformat(snapshot["last_run_at"])
    except Exception:
        snapshot["last_error"] = snapshot["last_error"] or "invalid last_run_at"
        return snapshot
    age_seconds = max(0.0, time.time() - dt.timestamp())
    snapshot["age_seconds"] = round(age_seconds, 1)
    snapshot["stale"] = age_seconds > max(60, stale_after_seconds)
    return snapshot


def runtime_services_ready() -> bool:
    status = runtime_health_snapshot()
    return status["lm"] and status["gateway"] and status["backend"]


def wait_for_runtime_services(timeout_seconds: int = 120) -> bool:
    deadline = time.time() + max(5, timeout_seconds)
    while time.time() < deadline:
        if runtime_services_ready():
            return True
        time.sleep(2)
    return runtime_services_ready()
