from __future__ import annotations

import hashlib
import json
import os
import random
import re
import threading
import time
import xml.etree.ElementTree as ET
from collections import Counter
from datetime import datetime
from html import unescape
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse
from zoneinfo import ZoneInfo

import requests

from zhiyue_project_paths import DATA_DIR


def _env_flag(name: str, default: bool = False) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return default
    return raw.strip().lower() not in {"0", "false", "no", "off"}


TIMEZONE_NAME = os.environ.get("ZHIYUE_TIMEZONE", "Asia/Shanghai").strip() or "Asia/Shanghai"
try:
    APP_TIMEZONE = ZoneInfo(TIMEZONE_NAME)
except Exception:
    APP_TIMEZONE = ZoneInfo("Asia/Shanghai")
    TIMEZONE_NAME = "Asia/Shanghai"

EXTERNAL_AWARENESS_ENABLED = _env_flag("ZHIYUE_EXTERNAL_AWARENESS_ENABLE", True)
WEATHER_CITY = os.environ.get("ZHIYUE_WEATHER_CITY", "").strip()
DEFAULT_LOCATION_LABEL = os.environ.get("ZHIYUE_LOCATION_LABEL", "").strip()
CACHE_SECONDS = max(300, int(os.environ.get("ZHIYUE_EXTERNAL_AWARENESS_CACHE_SECONDS", "1800")))
HTTP_TIMEOUT = max(2.0, float(os.environ.get("ZHIYUE_EXTERNAL_AWARENESS_TIMEOUT_SECONDS", "7")))
RSS_LIMIT = max(1, int(os.environ.get("ZHIYUE_EXTERNAL_AWARENESS_RSS_LIMIT", "4")))
RSS_SOURCES_FILE = DATA_DIR / "external_awareness" / "rss_sources.json"
SOURCE_HEALTH_FILE = DATA_DIR / "external_awareness" / "rss_source_health.json"
_CACHE_FILE = DATA_DIR / "external_awareness" / "cache.json"
_CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
_CACHE_LOCK = threading.Lock()
_CACHE: dict[str, Any] = {}

_DEFAULT_RSS_SOURCES: list[dict[str, str]] = [
    {"name": "E! News", "url": "https://eol-feeds.eonline.com/rssfeed/us/top_stories", "category": "celebrity"},
    {"name": "Us Celebrity", "url": "https://www.usmagazine.com/category/celebrity-news/feed/", "category": "celebrity"},
    {"name": "Us Entertainment", "url": "https://www.usmagazine.com/category/entertainment/feed/", "category": "entertainment"},
    {"name": "Us Lifestyle", "url": "https://www.usmagazine.com/category/lifestyle/feed/", "category": "lifestyle"},
]

_BOOK_POOL = [
    {"title": "《非暴力沟通》", "tags": {"conflict", "tired", "relationship"}, "reason": "适合最近想把话说软一点的时候。"},
    {"title": "《蛤蟆先生去看心理医生》", "tags": {"low", "anxious", "relationship"}, "reason": "适合心里乱、想被稳稳接住的时候。"},
    {"title": "《把时间当作朋友》", "tags": {"plan", "busy", "focus"}, "reason": "适合最近总觉得时间不够用的时候。"},
    {"title": "《深度工作》", "tags": {"focus", "plan", "busy"}, "reason": "适合想把生活拉回正轨的时候。"},
    {"title": "《被讨厌的勇气》", "tags": {"boundary", "growth", "relationship"}, "reason": "适合练习更直接一点的时候。"},
    {"title": "《也许你该找个人聊聊》", "tags": {"low", "anxious"}, "reason": "适合情绪起伏比较大的时候。"},
    {"title": "《山茶文具店》", "tags": {"warm", "share", "relationship"}, "reason": "适合想保留一点温柔感的时候。"},
    {"title": "《活着》", "tags": {"low", "growth"}, "reason": "适合想安静下来、把心收一收的时候。"},
    {"title": "《小狗钱钱》", "tags": {"plan", "busy", "growth"}, "reason": "适合想做一点轻量生活规划的时候。"},
    {"title": "《反脆弱》", "tags": {"growth", "busy"}, "reason": "适合想把波动变成力量的时候。"},
    {"title": "《你当像鸟飞往你的山》", "tags": {"growth", "warm"}, "reason": "适合想把自己往前推一点的时候。"},
    {"title": "《小王子》", "tags": {"warm", "relationship", "share"}, "reason": "适合想说点轻轻的心事的时候。"},
]


def get_current_local_time(now: datetime | None = None) -> datetime:
    if now is None:
        return datetime.now(APP_TIMEZONE)
    if now.tzinfo is None:
        return now.replace(tzinfo=APP_TIMEZONE)
    return now.astimezone(APP_TIMEZONE)


def _normalize_text(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "").strip())


def _compact(value: str, limit: int) -> str:
    value = _normalize_text(value)
    if len(value) <= limit:
        return value
    return value[: max(0, limit - 1)] + "…"


def _stable_seed(*parts: Any) -> int:
    raw = "||".join(_normalize_text(part) for part in parts)
    return int(hashlib.sha256(raw.encode("utf-8", errors="ignore")).hexdigest()[:8], 16)


def _read_json(path: Path, default: Any) -> Any:
    try:
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        pass
    return default


def _write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def _load_cache() -> dict[str, Any]:
    global _CACHE
    if _CACHE:
        return dict(_CACHE)
    data = _read_json(_CACHE_FILE, {})
    if isinstance(data, dict):
        _CACHE = dict(data)
        return dict(data)
    return {}


def _save_cache(cache: dict[str, Any]) -> None:
    global _CACHE
    _CACHE = dict(cache)
    try:
        _write_json(_CACHE_FILE, cache)
    except Exception:
        pass


def _load_health() -> dict[str, Any]:
    health = _read_json(SOURCE_HEALTH_FILE, {})
    return health if isinstance(health, dict) else {}


def _save_health(health: dict[str, Any]) -> None:
    try:
        _write_json(SOURCE_HEALTH_FILE, health)
    except Exception:
        pass


def _source_health_key(source: dict[str, str]) -> str:
    return _normalize_text(source.get("name") or source.get("url")).lower()


def _source_is_cooling(source: dict[str, str], health: dict[str, Any]) -> bool:
    info = health.get(_source_health_key(source))
    if not isinstance(info, dict):
        return False
    until = float(info.get("cooldown_until") or 0)
    return time.time() < until


def _mark_source_health(source: dict[str, str], *, success: bool, health: dict[str, Any]) -> None:
    key = _source_health_key(source)
    info = health.get(key) if isinstance(health.get(key), dict) else {}
    failures = int(info.get("failures") or 0)
    if success:
        health[key] = {
            "failures": 0,
            "last_ok_at": time.time(),
            "cooldown_until": 0,
        }
        return
    failures += 1
    cooldown = 0
    if failures >= 3:
        cooldown = time.time() + min(6 * 3600, 15 * 60 * (2 ** max(0, failures - 3)))
    health[key] = {
        "failures": failures,
        "last_failed_at": time.time(),
        "cooldown_until": cooldown,
    }


def _weather_code_to_cn(code: int) -> str:
    mapping = {
        0: "晴",
        1: "多云",
        2: "少云",
        3: "阴",
        45: "雾",
        48: "雾凇",
        51: "小毛毛雨",
        53: "小雨",
        55: "中雨",
        61: "小雨",
        63: "中雨",
        65: "大雨",
        71: "小雪",
        73: "中雪",
        75: "大雪",
        80: "阵雨",
        81: "较强阵雨",
        82: "强阵雨",
        95: "雷暴",
        96: "雷暴伴小冰雹",
        99: "雷暴伴大冰雹",
    }
    return mapping.get(int(code), f"天气码{code}")


def _http_get(url: str, *, params: dict[str, Any] | None = None, timeout: float | None = None) -> requests.Response:
    return requests.get(
        url,
        params=params,
        timeout=timeout or HTTP_TIMEOUT,
        headers={"User-Agent": "Mozilla/5.0 (zhiyue-external-awareness)"},
    )


def _fetch_json(url: str, *, params: dict[str, Any] | None = None, timeout: float | None = None) -> dict[str, Any]:
    resp = _http_get(url, params=params, timeout=timeout)
    resp.raise_for_status()
    data = resp.json()
    return data if isinstance(data, dict) else {}


def _extract_query_bucket(user_msg: str) -> str:
    msg = _normalize_text(user_msg)
    if any(token in msg for token in ("书", "读", "阅读", "推荐", "书单")):
        return "book"
    if any(token in msg for token in ("八卦", "明星", "娱乐", "热搜", "瓜", "恋情", "分手", "绯闻", "狗血")):
        return "social"
    if any(token in msg for token in ("新鲜", "最新", "最近", "热点", "新闻", "冲浪", "发生了什么")):
        return "news"
    if any(token in msg for token in ("计划", "安排", "生活", "作息", "周末", "规划")):
        return "life"
    return "daily"


def _normalize_ddg_url(url: str) -> str:
    parsed = urlparse(url)
    if parsed.netloc.endswith("duckduckgo.com") and parsed.path.startswith("/l/"):
        query = parse_qs(parsed.query)
        uddg = (query.get("uddg") or [""])[0]
        if uddg:
            return uddg
    return url


def _strip_html(text: str) -> str:
    text = re.sub(r"<[^>]+>", "", text or "")
    return unescape(_normalize_text(text))


def _parse_rss_entries(xml_text: str, source_name: str, source_url: str, category: str) -> list[dict[str, Any]]:
    try:
        root = ET.fromstring(xml_text)
    except Exception:
        return []

    ns = {
        "atom": "http://www.w3.org/2005/Atom",
        "content": "http://purl.org/rss/1.0/modules/content/",
        "dc": "http://purl.org/dc/elements/1.1/",
        "media": "http://search.yahoo.com/mrss/",
    }
    items: list[dict[str, Any]] = []

    def _text(node: ET.Element | None, path: str) -> str:
        if node is None:
            return ""
        found = node.find(path, ns)
        return _strip_html(found.text if found is not None and found.text else "")

    if root.tag.endswith("feed"):
        for entry in root.findall("atom:entry", ns):
            title = _text(entry, "atom:title")
            link = ""
            for link_node in entry.findall("atom:link", ns):
                href = link_node.attrib.get("href")
                if href:
                    link = _normalize_ddg_url(href)
                    break
            summary = _text(entry, "atom:summary") or _text(entry, "atom:content")
            published = _text(entry, "atom:updated") or _text(entry, "atom:published")
            items.append(
                {
                    "title": title,
                    "url": link,
                    "snippet": summary,
                    "published_at": published,
                    "source": source_name,
                    "source_url": source_url,
                    "category": category,
                }
            )
    else:
        channel = root.find("channel")
        if channel is None:
            return []
        for item in channel.findall("item"):
            title = _text(item, "title")
            link = _text(item, "link")
            summary = _text(item, "description")
            published = _text(item, "pubDate") or _text(item, "{http://purl.org/dc/elements/1.1/}date")
            items.append(
                {
                    "title": title,
                    "url": _normalize_ddg_url(link),
                    "snippet": summary,
                    "published_at": published,
                    "source": source_name,
                    "source_url": source_url,
                    "category": category,
                }
            )
    return [item for item in items if item.get("title")]


def _load_rss_sources() -> list[dict[str, str]]:
    sources = _read_json(RSS_SOURCES_FILE, None)
    if isinstance(sources, list) and sources:
        cleaned = []
        for item in sources:
            if not isinstance(item, dict):
                continue
            url = _normalize_text(item.get("url"))
            name = _normalize_text(item.get("name")) or url
            if not url:
                continue
            cleaned.append(
                {
                    "name": name,
                    "url": url,
                    "category": _normalize_text(item.get("category")) or "news",
                }
            )
        if cleaned:
            return cleaned
    _write_json(RSS_SOURCES_FILE, _DEFAULT_RSS_SOURCES)
    return list(_DEFAULT_RSS_SOURCES)


def _fetch_rss_feed(source: dict[str, str]) -> list[dict[str, Any]]:
    try:
        resp = _http_get(source["url"], timeout=HTTP_TIMEOUT)
        resp.raise_for_status()
        return _parse_rss_entries(resp.text or "", source["name"], source["url"], source.get("category") or "news")
    except Exception:
        return []


def _score_rss_item(item: dict[str, Any], user_msg: str, role: str) -> float:
    title = _normalize_text(item.get("title"))
    snippet = _normalize_text(item.get("snippet"))
    category = _normalize_text(item.get("category"))
    msg = _normalize_text(user_msg)
    score = 0.0
    text = f"{title} {snippet}"
    if role == "main":
        score += 0.2
    if category in {"celebrity", "entertainment", "lifestyle"}:
        score += 0.9
    elif category == "news":
        score += 0.4
    elif category == "tech":
        score += 0.1
    if any(token in msg for token in ("八卦", "明星", "娱乐", "热搜", "瓜", "恋情", "分手", "绯闻", "狗血")):
        if category in {"celebrity", "entertainment", "lifestyle"}:
            score += 1.8
        if any(token in text for token in ("恋情", "离婚", "分手", "同框", "约会", "塌房", "官宣", "八卦", "狗血", "绯闻")):
            score += 1.2
    if any(token in msg for token in ("书", "读", "阅读", "推荐", "书单")) and category == "book":
        score += 3.0
    if any(token in msg for token in ("新鲜", "最新", "最近", "热点", "新闻", "冲浪", "发生了什么")) and category in {"news", "tech"}:
        score += 3.0
    if any(token in msg for token in ("计划", "安排", "生活", "周末", "作息")) and category in {"life", "news"}:
        score += 1.5
    if any(token in text for token in ("AI", "模型", "科技", "开发", "代码", "编程")):
        score += 0.05
    if item.get("published_at"):
        score += 0.3
    score += min(len(title), 80) / 120.0
    return score


def _dedupe_items(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen = set()
    deduped = []
    for item in items:
        key = (_normalize_text(item.get("title")).lower(), _normalize_text(item.get("url")).lower())
        if key in seen:
            continue
        seen.add(key)
        deduped.append(item)
    return deduped


def fetch_subscription_digest(
    user_msg: str = "",
    *,
    role: str = "state",
    limit: int = RSS_LIMIT,
    force_refresh: bool = False,
) -> dict[str, Any]:
    role = "main" if str(role or "").strip().lower() == "main" else "state"
    bucket = _extract_query_bucket(user_msg)
    cache_key = hashlib.sha256(
        f"rss|{role}|{bucket}|{datetime.now(APP_TIMEZONE).date().isoformat()}".encode("utf-8", errors="ignore")
    ).hexdigest()
    now = time.time()
    cache = _load_cache()
    entry = cache.get(cache_key)
    if not force_refresh and isinstance(entry, dict):
        updated_at = float(entry.get("updated_at") or 0)
        if now - updated_at < CACHE_SECONDS:
            return dict(entry)

    sources = _load_rss_sources()
    health = _load_health()
    all_items: list[dict[str, Any]] = []
    source_state: dict[str, str] = {}
    for source in sources:
        if _source_is_cooling(source, health):
            source_state[source["name"]] = "cooldown"
            continue
        items = _fetch_rss_feed(source)
        success = bool(items)
        _mark_source_health(source, success=success, health=health)
        source_state[source["name"]] = "ok" if success else "fallback"
        all_items.extend(items)
    _save_health(health)

    all_items = _dedupe_items(all_items)
    scored = sorted(
        all_items,
        key=lambda item: _score_rss_item(item, user_msg, role),
        reverse=True,
    )
    selected = scored[: max(1, limit)]
    if not selected:
        selected = []

    digest = {
        "enabled": bool(EXTERNAL_AWARENESS_ENABLED),
        "role": role,
        "bucket": bucket,
        "updated_at": now,
        "sources": source_state,
        "items": selected,
        "ok": bool(selected),
        "summary": "",
    }
    digest["summary"] = "; ".join(
        _compact(f"{item.get('title')}（{item.get('source')}）", 60) for item in selected[:3]
    )
    if not digest["summary"]:
        digest["summary"] = "未抓到可用订阅内容"

    cache[cache_key] = dict(digest)
    _save_cache(cache)
    return digest


def _search_query_for_role(user_msg: str, role: str) -> str:
    msg = _normalize_text(user_msg)
    if not msg:
        return "today news"
    if role == "main":
        return f"{msg[:12]} fresh news"
    return f"{msg[:12]} news"


def _search_web(query: str, max_results: int = 3) -> list[dict[str, str]]:
    try:
        resp = _http_get("https://duckduckgo.com/html/", params={"q": query}, timeout=HTTP_TIMEOUT)
        resp.raise_for_status()
        html = resp.text or ""
    except Exception:
        return []

    title_matches = list(re.finditer(r'<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>(.*?)</a>', html, re.S))
    snippet_matches = list(re.finditer(r'class="result__snippet"[^>]*>(.*?)</', html, re.S))
    results: list[dict[str, str]] = []
    for idx, match in enumerate(title_matches[:max_results]):
        url = _normalize_ddg_url(match.group(1))
        title = _strip_html(match.group(2))
        snippet = _strip_html(snippet_matches[idx].group(1)) if idx < len(snippet_matches) else ""
        if title:
            results.append({"title": title, "url": url, "snippet": snippet})
    return results


def _fetch_weather_snapshot() -> dict[str, Any]:
    city_name = _normalize_text(WEATHER_CITY)
    if not city_name:
        return {"ok": False, "error": "weather city not configured"}
    cache_key = hashlib.sha256(f"weather|{city_name}".encode("utf-8", errors="ignore")).hexdigest()
    now = time.time()
    cache = _load_cache()
    entry = cache.get(cache_key)
    if isinstance(entry, dict):
        updated_at = float(entry.get("updated_at") or 0)
        if now - updated_at < max(CACHE_SECONDS, 900):
            return dict(entry)

    try:
        geo = _fetch_json(
            "https://geocoding-api.open-meteo.com/v1/search",
            params={"name": city_name, "count": 1, "language": "zh", "format": "json"},
        )
        results = geo.get("results") or []
        if not results:
            payload = {"ok": False, "error": f"city not found: {city_name}", "city": city_name, "updated_at": now}
            cache[cache_key] = dict(payload)
            _save_cache(cache)
            return payload
        top = results[0] if isinstance(results[0], dict) else {}
        latitude = top.get("latitude")
        longitude = top.get("longitude")
        weather = _fetch_json(
            "https://api.open-meteo.com/v1/forecast",
            params={
                "latitude": latitude,
                "longitude": longitude,
                "current": "temperature_2m,weather_code,wind_speed_10m,relative_humidity_2m",
                "timezone": TIMEZONE_NAME,
            },
        )
        current = weather.get("current") or {}
        temp = current.get("temperature_2m")
        code = current.get("weather_code")
        wind = current.get("wind_speed_10m")
        humidity = current.get("relative_humidity_2m")
        summary = "，".join(
            part
            for part in [
                f"{_normalize_text(top.get('name') or city_name)} {temp}°C" if temp is not None else _normalize_text(top.get("name") or city_name),
                _weather_code_to_cn(int(code)) if code is not None else "",
                f"风{wind}m/s" if wind is not None else "",
                f"湿度{humidity}%" if humidity is not None else "",
            ]
            if part
        )
        payload = {
            "ok": True,
            "city": _normalize_text(top.get("name") or city_name),
            "country": _normalize_text(top.get("country") or ""),
            "latitude": latitude,
            "longitude": longitude,
            "summary": summary,
            "temperature": temp,
            "weather_code": code,
            "weather_text": _weather_code_to_cn(int(code)) if code is not None else "",
            "wind_speed": wind,
            "humidity": humidity,
            "updated_at": now,
        }
        cache[cache_key] = dict(payload)
        _save_cache(cache)
        return payload
    except Exception as err:
        payload = {"ok": False, "error": str(err), "city": city_name, "updated_at": now}
        cache[cache_key] = dict(payload)
        _save_cache(cache)
        return payload


def _pick_book(user_msg: str, role: str, weather_text: str = "") -> dict[str, str]:
    msg = _normalize_text(user_msg)
    tags: set[str] = set()
    if any(token in msg for token in ("累", "疲惫", "难受", "焦虑", "压力")):
        tags.update({"low", "anxious"})
    if any(token in msg for token in ("吵架", "别扭", "边界", "生气", "吃醋")):
        tags.update({"relationship", "boundary"})
    if any(token in msg for token in ("计划", "安排", "效率", "拖延", "工作", "忙")):
        tags.update({"plan", "busy", "focus"})
    if any(token in msg for token in ("成长", "改变", "更好", "重启")):
        tags.update({"growth"})
    if any(token in msg for token in ("温柔", "治愈", "陪伴", "想你")):
        tags.update({"warm", "share", "relationship"})
    if weather_text and any(token in weather_text for token in ("雨", "雪", "冷")):
        tags.add("warm")
    if not tags:
        tags.add("share" if role == "main" else "growth")

    candidates = [item for item in _BOOK_POOL if item["tags"] & tags]
    if not candidates:
        candidates = list(_BOOK_POOL)
    rng = random.Random(_stable_seed(msg, role, weather_text, datetime.now(APP_TIMEZONE).date().isoformat()))
    chosen = candidates[rng.randrange(len(candidates))]
    return {
        "title": chosen["title"],
        "reason": chosen["reason"],
        "tags": ",".join(sorted(chosen["tags"])),
    }


def _build_life_hint(time_info: dict[str, Any], weather: dict[str, Any], digest: dict[str, Any], book: dict[str, Any]) -> str:
    pieces = []
    if weather.get("ok"):
        weather_text = str(weather.get("weather_text") or "")
        temp = weather.get("temperature")
        if temp is not None:
            pieces.append(f"出门前先看天气，当前约{temp}°C，{weather_text}。")
        else:
            pieces.append(f"今天的天气偏{weather_text}，安排别太满。")
    else:
        pieces.append("今天先按本地时间和状态来安排，外部天气没拿到就别硬猜。")
    if digest.get("items"):
        first = digest["items"][0]
        pieces.append(f"可分享的事：{_compact(first.get('title') or '', 60)}。")
    if book.get("title"):
        pieces.append(f"如果要推荐书，可顺手说{book.get('title')}。")
    if time_info.get("daypart") in {"evening", "late"}:
        pieces.append("晚上适合收尾、复盘、少做重决定。")
    return " ".join(pieces)


def _build_summary(payload: dict[str, Any], *, role: str) -> str:
    time_info = payload.get("time") or {}
    weather = payload.get("weather") or {}
    digest = payload.get("subscription_digest") or {}
    book = payload.get("book_pick") or {}
    parts = []
    if time_info:
        parts.append(f"{time_info.get('date_display') or ''}{time_info.get('daypart_display') or ''}".strip())
    if weather and weather.get("ok"):
        parts.append(f"天气{_compact(weather.get('summary') or '', 36)}")
    if digest and digest.get("summary"):
        parts.append(f"外部内容{_compact(digest.get('summary') or '', 48)}")
    if book and book.get("title"):
        parts.append(f"书单{book.get('title')}")
    if role == "state" and payload.get("life_hint"):
        parts.append(_compact(payload.get("life_hint") or "", 40))
    return "；".join(part for part in parts if part)


def _cache_key(role: str, bucket: str, city: str) -> str:
    day = datetime.now(APP_TIMEZONE).strftime("%Y-%m-%d")
    return hashlib.sha256(f"context|{role}|{bucket}|{day}|{city}".encode("utf-8", errors="ignore")).hexdigest()


def build_external_awareness_context(
    user_msg: str = "",
    *,
    role: str = "state",
    city: str | None = None,
    location_label: str | None = None,
    force_refresh: bool = False,
) -> dict[str, Any]:
    role = "main" if str(role or "").strip().lower() == "main" else "state"
    city_name = _normalize_text(city or WEATHER_CITY)
    bucket = _extract_query_bucket(user_msg)
    cache_key = _cache_key(role, bucket, city_name)
    now = time.time()
    cache = _load_cache()
    entry = cache.get(cache_key)
    if not force_refresh and isinstance(entry, dict):
        updated_at = float(entry.get("updated_at") or 0)
        if now - updated_at < CACHE_SECONDS:
            return dict(entry)

    current = get_current_local_time()
    daypart = "凌晨" if current.hour < 6 else "上午" if current.hour < 12 else "下午" if current.hour < 18 else "晚上"
    time_info = {
        "iso": current.isoformat(),
        "date": current.date().isoformat(),
        "date_display": current.strftime("%Y年%m月%d日"),
        "weekday": ["星期一", "星期二", "星期三", "星期四", "星期五", "星期六", "星期日"][current.weekday()],
        "daypart": "late" if current.hour >= 23 or current.hour < 6 else "morning" if current.hour < 12 else "afternoon" if current.hour < 18 else "evening",
        "daypart_display": daypart,
    }

    weather = _fetch_weather_snapshot()
    if location_label:
        weather["location_label"] = _normalize_text(location_label)
    subscription_digest = fetch_subscription_digest(user_msg, role=role, force_refresh=force_refresh)
    if not subscription_digest.get("items"):
        fallback_query = _search_query_for_role(user_msg, role)
        fallback_results = _search_web(fallback_query, max_results=3)
        if fallback_results:
            subscription_digest["items"] = [
                {
                    "title": item.get("title") or "",
                    "url": item.get("url") or "",
                    "snippet": item.get("snippet") or "",
                    "source": "web",
                    "category": "web",
                }
                for item in fallback_results
            ]
            subscription_digest["summary"] = "; ".join(_compact(item["title"], 60) for item in subscription_digest["items"][:3])
            subscription_digest["source_state"] = "web_fallback"
        else:
            subscription_digest["source_state"] = "fallback"
    else:
        subscription_digest["source_state"] = "rss"

    book_pick = _pick_book(user_msg, role, str(weather.get("weather_text") or ""))
    life_hint = _build_life_hint(time_info, weather, subscription_digest, book_pick)
    payload = {
        "enabled": bool(EXTERNAL_AWARENESS_ENABLED),
        "role": role,
        "bucket": bucket,
        "generated_at": current.isoformat(),
        "updated_at": now,
        "time": time_info,
        "weather": weather,
        "subscription_digest": subscription_digest,
        "fresh_topic": (subscription_digest.get("items") or [{}])[0] if subscription_digest.get("items") else {},
        "book_pick": book_pick,
        "life_hint": life_hint,
        "summary": "",
        "prompt_hint": "",
        "source_status": {
            "weather": "ok" if weather.get("ok") else "fallback",
            "rss": subscription_digest.get("source_state") or ("rss" if subscription_digest.get("items") else "fallback"),
        },
    }
    payload["summary"] = _build_summary(payload, role=role)
    if role == "main":
        fresh = payload["subscription_digest"].get("items") or []
        first_title = _compact((fresh[0].get("title") if fresh else "") or "", 60)
        payload["prompt_hint"] = _compact(
            f"外部感知：{payload['summary']}。可以自然提一句外部内容：{first_title}。书单优先说{book_pick.get('title') or ''}。", 240
        )
    else:
        payload["prompt_hint"] = _compact(f"外部感知：{payload['summary']}。{life_hint}", 420)

    cache[cache_key] = dict(payload)
    _save_cache(cache)
    return payload


def render_external_awareness_inject(payload: dict[str, Any] | None, *, role: str = "state", max_chars: int | None = None) -> str:
    if not isinstance(payload, dict) or not payload.get("enabled", True):
        return ""
    role = "main" if str(role or "").strip().lower() == "main" else "state"
    limit = max_chars or (220 if role == "main" else 420)
    parts: list[str] = []
    time_info = payload.get("time") or {}
    weather = payload.get("weather") or {}
    digest = payload.get("subscription_digest") or {}
    book = payload.get("book_pick") or {}
    if time_info:
        parts.append(f"时间：{time_info.get('date_display') or ''} {time_info.get('weekday') or ''} {time_info.get('daypart_display') or ''}")
    if weather and weather.get("ok"):
        location = _normalize_text(weather.get("location_label") or weather.get("city") or DEFAULT_LOCATION_LABEL or "")
        weather_line = _compact(str(weather.get("summary") or ""), 60)
        parts.append(f"天气：{location + ' ' if location else ''}{weather_line}")
    if digest and digest.get("items"):
        top = digest["items"][:3]
        news_text = "；".join(
            _compact(f"{item.get('title') or ''}（{item.get('source') or ''}）", 72)
            for item in top
        )
        parts.append(f"外部内容：{news_text}")
    if book and book.get("title"):
        parts.append(f"书：{book.get('title')}（{_compact(book.get('reason') or '', 48)}）")
    if role == "state" and payload.get("life_hint"):
        parts.append(f"生活建议：{_compact(payload.get('life_hint') or '', 96)}")
    text = "\n".join(f"- {part}" for part in parts if part)
    return _compact(text, limit)
