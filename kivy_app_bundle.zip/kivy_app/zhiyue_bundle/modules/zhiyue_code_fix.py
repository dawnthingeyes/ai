# -*- coding: utf-8 -*-
"""
Zhiyue 自我修复闭环模块。

流程:
1. 积累问题(代码审查 + 运行时自检),攒够5-10个或用户主动触发
2. 生成修改方案(具体 diff),展示给用户
3. 用户确认后进入沙盒执行
4. 沙盒通过后,再等用户二次确认,才替换源码
5. 自动重启加载新代码

安全红线:
- 永远不在沙盒外直接修改源码
- 每一步都需要用户确认
- 沙盒失败则废弃方案,不污染源码
"""
from __future__ import annotations

import json
import os
import re
import time
import uuid
from datetime import datetime
from pathlib import Path

from zhiyue_technical_review import (
    _find_except_locations,
    _find_large_functions,
    _find_duplicate_patterns,
    normalize_technical_text,
)

BASE_DIR = Path(__file__).resolve().parent
PENDING_FIXES_FILE = BASE_DIR / "zhiyue_pending_fixes.json"
FIX_HISTORY_FILE = BASE_DIR / "zhiyue_fix_history.jsonl"

# 积累阈值:问题数量达到此值后自动提醒用户
AUTO_NOTIFY_THRESHOLD = 5
MAX_PENDING = 20

# 代码变更通知文件: proactive 通道会读取并推送给用户
CODE_CHANGE_ALERTS_FILE = BASE_DIR / "zhiyue_code_change_alerts.json"

# LM Studio 配置(用于沙盒重试时自动修复 diff)
LM_URL = os.environ.get("ZHIYUE_LM_URL", "http://127.0.0.1:1234/v1/chat/completions")
LM_MODEL = os.environ.get("ZHIYUE_LM_MODEL", "")
from zhiyue_llm_provider import post_chat_completion as _provider_post_chat_completion

# 沙盒重试配置
SANDBOX_RETRY_MAX = 5
SANDBOX_RETRY_REPORT = BASE_DIR / "zhiyue_sandbox_retry_report.json"


def _issue_key(item: dict) -> str:
    return "|".join([
        str(item.get("category", "")),
        str(item.get("title", "")),
        str(item.get("location", "")),
    ])


def _ensure_pending_integrity(items: list[dict]) -> list[dict]:
    fixed = []
    seen_ids = set()
    for index, item in enumerate(items):
        row = dict(item)
        issue_key = _issue_key(row)
        meta = row.get("meta") if isinstance(row.get("meta"), dict) else {}
        meta.setdefault("issue_key", issue_key)
        row["meta"] = meta
        row_id = str(row.get("id") or "").strip()
        if not row_id or row_id in seen_ids:
            row_id = f"fix-{uuid.uuid4().hex[:16]}-{index}"
            row["id"] = row_id
        seen_ids.add(row_id)
        fixed.append(row)
    return fixed


def _load_pending() -> list[dict]:
    try:
        data = json.loads(PENDING_FIXES_FILE.read_text(encoding="utf-8"))
        if not isinstance(data, list):
            return []
        fixed = _ensure_pending_integrity(data)
        if fixed != data:
            _save_pending(fixed)
        return fixed
    except Exception:
        return []


def _save_pending(items: list[dict]) -> None:
    PENDING_FIXES_FILE.write_text(
        json.dumps(items[-MAX_PENDING:], ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def _append_history(item: dict) -> None:
    try:
        with FIX_HISTORY_FILE.open("a", encoding="utf-8") as f:
            f.write(json.dumps(item, ensure_ascii=False) + "\n")
    except Exception:
        pass


def _now_iso() -> str:
    return datetime.now().isoformat()


def _parse_structured_fix(suggested_fix: str) -> tuple[str, int, str, list[str]] | None:
    """
    尝试从 suggested_fix 中解析结构化修复指令。
    支持格式:
        FILE:filename.py|LINE:42|NEW:new line content
    或:
        FILE:filename.py
        LINE:42
        NEW:new content
    返回 (target_file, line_num, new_content, test_commands) 或 None
    """
    if not suggested_fix:
        return None
    text = suggested_fix.strip()
    target_file = ""
    line_num = 0
    new_content = ""
    test_commands: list[str] = []
    n_lines = 1

    # 格式1: 单行 | 分隔
    if "|" in text:
        parts = text.split("|")
        for p in parts:
            p = p.strip()
            if p.upper().startswith("FILE:"):
                target_file = p[5:].strip()
            elif p.upper().startswith("LINE:"):
                try:
                    line_num = int(p[5:].strip())
                except ValueError:
                    return None
            elif p.upper().startswith("NEW:"):
                new_content = p[4:].strip()
            elif p.upper().startswith("NLINE:"):
                try:
                    n_lines = int(p[6:].strip())
                except ValueError:
                    pass
            elif p.upper().startswith("TEST:"):
                test_commands.append(p[5:].strip())

    # 格式2: 多行解析
    elif "\n" in text or text.upper().startswith("FILE:"):
        for line in text.splitlines():
            line = line.strip()
            if line.upper().startswith("FILE:"):
                target_file = line[5:].strip()
            elif line.upper().startswith("LINE:"):
                try:
                    line_num = int(line[5:].strip())
                except ValueError:
                    return None
            elif line.upper().startswith("NEW:"):
                new_content = line[4:].strip()
            elif line.upper().startswith("NLINE:"):
                try:
                    n_lines = int(line[6:].strip())
                except ValueError:
                    pass
            elif line.upper().startswith("TEST:"):
                test_commands.append(line[5:].strip())

    if target_file and line_num > 0 and new_content:
        return (target_file, line_num, new_content, test_commands)
    return None


def _build_structured_diff(item: dict, parsed: tuple[str, int, str, list[str]], source_dir: Path) -> dict:
    """
    根据结构化解析结果,生成完整的 diff 提案。
    parsed = (target_file, line_num, new_content, test_commands)
    """
    target_file, line_num, new_content, test_commands = parsed
    target_path = source_dir / target_file
    diff_text = ""
    if target_path.exists():
        try:
            t_lines = target_path.read_text(encoding="utf-8", errors="replace").splitlines()
            if line_num <= len(t_lines):
                old_line = t_lines[line_num - 1].rstrip()
                diff_text = f"--- a/{target_file}\n+++ b/{target_file}\n@@ -{line_num},1 +{line_num},1 @@\n-{old_line}\n+{new_content}"
        except Exception:
            pass
    return {
        "fix_id": item["id"],
        "title": item["title"],
        "category": item.get("category", ""),
        "target_file": target_file,
        "diff_text": diff_text,
        "test_commands": test_commands,
        "auto_generated": True,
    }


def _apply_diff_to_lines(lines: list[str], target_file: Path, diff_text: str) -> tuple[list[str], int, list[str]]:
    """
    将 unified diff 应用到行数组上(不写文件)。
    返回 (修改后的行数组, 成功修改行数, 错误列表)。
    兼容 bare_except 单行替换和 runtime 多行替换格式。
    """
    modified_lines = list(lines)
    applied = 0
    errors = []

    try:
        line_num = 0
        old_line = ""
        new_line = ""
        for dline in diff_text.split("\n"):
            if dline.startswith("@@"):
                m = re.search(r"@@ -(\d+)", dline)
                if m:
                    line_num = int(m.group(1))
            elif dline.startswith("-") and not dline.startswith("---"):
                old_line = dline[1:]
            elif dline.startswith("+") and not dline.startswith("+++"):
                new_line = dline[1:]

        if line_num <= 0 or line_num > len(modified_lines):
            errors.append(f"行号{line_num}越界(总行数{len(modified_lines)})")
            return modified_lines, 0, errors

        current_line = modified_lines[line_num - 1].rstrip()
        if current_line != old_line.rstrip():
            errors.append(f"第{line_num}行内容不匹配: 期望[{old_line.rstrip()[:60]}] 实际[{current_line[:60]}]")
            return modified_lines, 0, errors

        modified_lines[line_num - 1] = new_line
        applied = 1

    except Exception as e:
        errors.append(f"diff解析异常: {e}")

    return modified_lines, applied, errors


def _sandbox_test(target_file: Path, diff_text: str, test_commands: list[str]) -> tuple[bool, str]:
    """
    沙盒测试: 在临时副本上应用 diff,运行测试命令,通过后才允许写正式文件。
    返回 (是否通过, 错误信息)。

    测试流程:
    1. 将目标文件复制到临时位置
    2. 对临时副本应用 diff
    3. 运行 py_compile 语法检查
    4. 运行额外的 test_commands
    5. 清理临时文件并返回结果
    """
    import tempfile, subprocess as _sp

    tmp_path = None
    try:
        # 1. 创建临时副本
        tmp_fd, tmp_name = tempfile.mkstemp(suffix=".py", prefix="_sandbox_")
        tmp_path = Path(tmp_name)
        import os as _os
        _os.close(tmp_fd)
        import shutil as _shutil
        _shutil.copy2(str(target_file), str(tmp_path))

        # 2. 读入并应用 diff
        t_text = tmp_path.read_text(encoding="utf-8", errors="replace")
        t_lines = t_text.splitlines()
        mod_lines, applied, parse_errors = _apply_diff_to_lines(t_lines, tmp_path, diff_text)
        if parse_errors:
            return False, f"diff应用失败: {'; '.join(parse_errors)}"

        # 3. 写回临时文件
        tmp_path.write_text("\n".join(mod_lines), encoding="utf-8")

        # 4. 语法检查
        try:
            import py_compile
            py_compile.compile(str(tmp_path), doraise=True)
        except py_compile.PyCompileError as e:
            return False, f"语法检查失败: {str(e)[:300]}"

        # 5. 运行额外测试命令
        for cmd in test_commands:
            if not cmd or not cmd.strip():
                continue
            # 替换文件路径为临时文件路径
            cmd_adjusted = cmd.replace(str(target_file), str(tmp_path))
            try:
                result = _sp.run(
                    cmd_adjusted, shell=True,
                    capture_output=True, text=True,
                    timeout=30, cwd=str(target_file.parent),
                )
                if result.returncode != 0:
                    err_detail = result.stderr[:400] or result.stdout[:400]
                    return False, f"测试失败 [{cmd[:60]}]: {err_detail}"
            except _sp.TimeoutExpired:
                return False, f"测试超时(30s): {cmd[:60]}"
            except Exception as e:
                return False, f"测试异常: {cmd[:60]}: {e}"

        return True, ""

    except Exception as e:
        return False, f"沙盒环境异常: {e}"

    finally:
        if tmp_path and tmp_path.exists():
            try:
                tmp_path.unlink()
            except Exception:
                pass


def _record_code_change_notification(summary: str, *, file_changed: str = "", change_type: str = "", details: dict | None = None) -> None:
    """
    记录代码变更通知。proactive 通道会读取并推送给用户。
    """
    notif = {
        "time": _now_iso(),
        "summary": summary,
        "file_changed": file_changed,
        "change_type": change_type,
        "details": details or {},
        "delivered": False,
    }
    existing = []
    if CODE_CHANGE_ALERTS_FILE.exists():
        try:
            existing = json.loads(CODE_CHANGE_ALERTS_FILE.read_text(encoding="utf-8"))
        except Exception:
            pass
    existing.append(notif)
    # 只保留最近20条
    if len(existing) > 20:
        existing = existing[-20:]
    CODE_CHANGE_ALERTS_FILE.write_text(json.dumps(existing, ensure_ascii=False, indent=2), encoding="utf-8")


# 问题白名单：已确认可接受的类型不再报警
ISSUE_WHITELIST_KEYWORDS = [
    "延迟", "latency", "响应太慢", "回复慢", "回复时间", "超时",
]


def add_pending_fix(
    *,
    source: str,
    category: str,
    title: str,
    description: str,
    location: str = "",
    severity: str = "medium",
    suggested_fix: str = "",
    meta: dict | None = None,
) -> dict:
    """添加一个问题到待修复队列。白名单中的问题会被静默跳过。"""
    # 白名单过滤
    for keyword in ISSUE_WHITELIST_KEYWORDS:
        if keyword in title or keyword in description:
            return None
    items = _load_pending()
    # 去重:相同标题+位置的不重复添加
    issue_key = "|".join([category, title, location])
    for item in items:
        item_meta = item.get("meta") if isinstance(item.get("meta"), dict) else {}
        existing_key = item_meta.get("issue_key") or _issue_key(item)
        if existing_key == issue_key:
            return item
    fix = {
        "id": f"fix-{uuid.uuid4().hex[:16]}-{len(items)}",
        "source": source,
        "category": category,
        "title": title,
        "description": description,
        "location": location,
        "severity": severity,
        "suggested_fix": suggested_fix,
        "status": "pending",
        "created_at": _now_iso(),
        "meta": {**(meta or {}), "issue_key": issue_key},
    }
    items.append(fix)
    _save_pending(items)
    return fix


def scan_and_accumulate_issues(source_dir: str | Path = "") -> list[dict]:
    """
    扫描源码,将发现的问题加入待修复队列。
    返回本次新增的问题列表。
    """
    source_dir = Path(source_dir).resolve() if source_dir else BASE_DIR
    main_file = source_dir / "zhiyue_connected.py"
    if not main_file.exists():
        return []

    try:
        text = main_file.read_text(encoding="utf-8", errors="replace")
        lines = text.splitlines()
    except Exception:
        return []

    new_issues = []

    # 1. 裸 except 检测
    except_locs = _find_except_locations(text, lines)
    for ex in except_locs:
        # 只报告吞异常的(body里有pass或print或为空)
        body = ex.get("body_preview", "")
        if "pass" in body or not body.strip() or body.strip().startswith("print("):
            fix = add_pending_fix(
                source="code_scan",
                category="bare_except",
                title=f"第{ex['line']}行裸except吞异常",
                description=f"try从第{ex['try_start']}行开始,except Exception在第{ex['line']}行,异常被吞掉(body: {body[:60]})",
                location=f"zhiyue_connected.py:{ex['line']}",
                severity="high",
                suggested_fix="改成具体异常类型(ValueError/KeyError/ConnectionError等),加上logging",
            )
            if fix:
                new_issues.append(fix)

    # 2. 超大函数(已禁用:用户确认不算问题)
    # large_funcs = _find_large_functions(text, lines, threshold=500)
    # for func in large_funcs[:5]:
    #     fix = add_pending_fix(
    #         source="code_scan",
    #         category="large_function",
    #         title=f"`{func['name']}` 函数{func['lines']}行过长",
    #         description=f"函数从第{func['start']}行到第{func['end']}行,{func['lines']}行,建议拆分",
    #         location=f"zhiyue_connected.py:{func['start']}",
    #         severity="medium",
    #         suggested_fix=f"把 `{func['name']}` 拆成2-3个子函数,用辅助类管理状态",
    #     )

    # 3. 备份文件
    backup_files = sorted(source_dir.glob("zhiyue_connected_backup_*.py"))
    if backup_files:
        fix = add_pending_fix(
            source="code_scan",
            category="backup_clutter",
            title=f"主目录有{len(backup_files)}个备份文件",
            description="备份文件干扰代码检索和人工判断",
            location="D:/chat/",
            severity="low",
            suggested_fix="挪到 backups/ 子目录",
        )
        if fix:
            new_issues.append(fix)

    # 4. 重复代码模式
    dup_patterns = _find_duplicate_patterns(text, lines)
    for p in dup_patterns:
        if p["type"] == "judge_call_duplicated":
            fix = add_pending_fix(
                source="code_scan",
                category="code_duplication",
                title=f"judge调用分散{p['count']}处",
                description="评分逻辑应该统一收敛",
                location=f"zhiyue_connected.py:{p['sample_lines'][0] if p.get('sample_lines') else '?'}",
                severity="medium",
                suggested_fix="统一评分入口,去掉散落的重复调用",
            )
            if fix:
                new_issues.append(fix)
        elif p["type"] == "clean_reply_duplicated":
            fix = add_pending_fix(
                source="code_scan",
                category="code_duplication",
                title=f"clean_reply调用{p['count']}处散落",
                description="回复清洗逻辑分散",
                location=f"zhiyue_connected.py:{p['sample_lines'][0] if p.get('sample_lines') else '?'}",
                severity="medium",
                suggested_fix="抽成装饰器或统一入口",
            )
            if fix:
                new_issues.append(fix)

    # 5. DB健康检查：检测过期的 agent_tasks 和自改进候选
    obs_db = source_dir / "zhiyue_observability.db"
    if obs_db.exists():
        try:
            import sqlite3 as _sql
            conn = _sql.connect(str(obs_db))
            stale_tasks = conn.execute(
                "SELECT COUNT(*) FROM agent_tasks WHERE status NOT IN ('done','archived','rejected') AND julianday('now') - julianday(created_at) > 1"
            ).fetchone()[0]
            stale_candidates = conn.execute(
                "SELECT COUNT(*) FROM self_improvement_candidates WHERE status IN ('pending','approved') AND julianday('now') - julianday(created_at) > 7"
            ).fetchone()[0]
            conn.close()
            if stale_tasks > 0:
                fix = add_pending_fix(
                    source="db_scan",
                    category="db_cleanup",
                    title=f"发现{stale_tasks}个过期agent_tasks无人清理",
                    description=f"agent_tasks表中{stale_tasks}条记录超过1天未完成",
                    location="observability.db:agent_tasks",
                    severity="medium",
                    suggested_fix=f"DELETE FROM agent_tasks WHERE status NOT IN ('done','archived','rejected') AND julianday('now') - julianday(created_at) > 1",
                )
                if fix:
                    new_issues.append(fix)
            if stale_candidates > 0:
                fix = add_pending_fix(
                    source="db_scan",
                    category="db_cleanup",
                    title=f"发现{stale_candidates}个积压的自改进候选",
                    description=f"self_improvement_candidates表中{stale_candidates}条pending/approved记录超过7天未处理",
                    location="observability.db:self_improvement_candidates",
                    severity="medium",
                    suggested_fix=f"UPDATE self_improvement_candidates SET status='archived' WHERE status IN ('pending','approved') AND julianday('now') - julianday(created_at) > 7",
                )
                if fix:
                    new_issues.append(fix)
        except Exception:
            pass

    return new_issues


def add_runtime_issue(
    *,
    title: str,
    description: str,
    location: str = "",
    severity: str = "medium",
    suggested_fix: str = "",
    evidence: dict | None = None,
) -> dict:
    """从运行时自检/监控中添加问题。"""
    return add_pending_fix(
        source="runtime",
        category="runtime_issue",
        title=title,
        description=description,
        location=location,
        severity=severity,
        suggested_fix=suggested_fix,
        meta=evidence or {},
    )


def get_pending_summary() -> dict:
    """获取待修复问题的摘要。"""
    items = _load_pending()
    pending = [i for i in items if i.get("status") == "pending"]
    approved = [i for i in items if i.get("status") == "approved"]
    by_severity = {"high": [], "medium": [], "low": []}
    for item in pending:
        sev = item.get("severity", "medium")
        if sev in by_severity:
            by_severity[sev].append(item)
    return {
        "total_pending": len(pending),
        "total_approved": len(approved),
        "should_notify": len(pending) >= AUTO_NOTIFY_THRESHOLD,
        "by_severity": {
            k: [{"title": i["title"], "location": i.get("location", "")} for i in v]
            for k, v in by_severity.items()
        },
        "items": pending,
    }


def format_pending_for_user() -> str:
    """生成给用户看的待修复问题列表,紧凑格式。"""
    summary = get_pending_summary()
    items = summary["items"]
    if not items:
        return "目前没有待修复的问题。"

    # 按类别分组
    by_cat: dict[str, list[dict]] = {}
    for item in items:
        cat = item.get("category", "other")
        by_cat.setdefault(cat, []).append(item)

    cat_names = {
        "bare_except": "裸except吞异常",
        "large_function": "超大函数",
        "backup_clutter": "备份文件杂乱",
        "code_duplication": "重复代码",
        "runtime_issue": "运行时问题",
        "other": "其他",
    }

    lines = [f"攒了 {len(items)} 个问题:"]
    for cat, cat_items in by_cat.items():
        cat_name = cat_names.get(cat, cat)
        lines.append(f"\n【{cat_name}】{len(cat_items)}个")
        for item in cat_items:
            lines.append(f"• {item['title']}")

    if summary["should_notify"]:
        lines.append(f"\n攒够{AUTO_NOTIFY_THRESHOLD}个了，说\"修吧\"我直接动手，说\"看看方案\"我先给你看改啥。")

    return "\n".join(lines)


def approve_fixes(fix_ids: list[str] | None = None) -> dict:
    """用户批准指定问题(或全部pending)进入修改方案生成阶段。"""
    items = _load_pending()
    if fix_ids is None:
        # 批准所有 pending
        target_ids = {i["id"] for i in items if i.get("status") == "pending"}
    else:
        target_ids = set(fix_ids)

    approved_count = 0
    for item in items:
        if item["id"] in target_ids and item.get("status") == "pending":
            item["status"] = "approved"
            item["approved_at"] = _now_iso()
            approved_count += 1

    _save_pending(items)
    return {"approved": approved_count, "total_approved": sum(1 for i in items if i.get("status") == "approved")}


def reject_fixes(fix_ids: list[str]) -> dict:
    """用户拒绝指定问题。"""
    items = _load_pending()
    rejected = 0
    for item in items:
        if item["id"] in fix_ids:
            item["status"] = "rejected"
            item["rejected_at"] = _now_iso()
            rejected += 1
    _save_pending(items)
    return {"rejected": rejected}


def clear_fixed() -> int:
    """清除已标记为 fixed 的问题。"""
    items = _load_pending()
    remaining = [i for i in items if i.get("status") not in ("fixed", "rejected")]
    removed = len(items) - len(remaining)
    _save_pending(remaining)
    return removed


def mark_fixed(fix_ids: list[str]) -> int:
    """标记问题为已修复。"""
    items = _load_pending()
    count = 0
    for item in items:
        if item["id"] in fix_ids:
            item["status"] = "fixed"
            item["fixed_at"] = _now_iso()
            count += 1
            _append_history(item)
    _save_pending(items)
    return count


def generate_fix_diff_for_approved(source_dir: str | Path = "") -> list[dict]:
    """
    为所有 approved 状态的问题生成具体的修改方案。
    返回方案列表,每个包含:fix_id, target_file, diff_text, test_commands。
    这个函数只生成方案,不执行任何修改。
    """
    source_dir = Path(source_dir).resolve() if source_dir else BASE_DIR
    main_file = source_dir / "zhiyue_connected.py"
    items = _load_pending()
    approved = [i for i in items if i.get("status") == "approved"]

    if not approved:
        return []

    if not main_file.exists():
        return []

    try:
        text = main_file.read_text(encoding="utf-8", errors="replace")
        lines = text.splitlines()
    except Exception:
        return []

    proposals = []
    for item in approved:
        category = item.get("category", "")
        location = item.get("location", "")
        diff_text = ""
        test_commands = []

        # 解析行号
        line_num = 0
        loc_match = re.search(r":(\d+)", location)
        if loc_match:
            line_num = int(loc_match.group(1))

        if category == "bare_except" and line_num > 0 and line_num <= len(lines):
            # 生成把 except Exception 替换成具体类型的 diff
            old_line = lines[line_num - 1]
            indent = len(old_line) - len(old_line.lstrip())
            indent_str = " " * indent
            # 根据 try 块内容推断可能的具体异常类型
            try_start = 1
            for j in range(line_num - 2, max(line_num - 30, -1), -1):
                if re.match(r'^\s*try\s*:', lines[j]):
                    try_start = j + 1
                    break
            try_body = "\n".join(lines[try_start:line_num - 1])
            # 简单推断异常类型
            specific_exceptions = []
            if any(k in try_body for k in ["requests.", "httpx.", "urllib", "aiohttp"]):
                specific_exceptions.extend(["ConnectionError", "TimeoutError"])
            if any(k in try_body for k in ["json.loads", "json.dumps", ".json()"]):
                specific_exceptions.append("json.JSONDecodeError")
            if any(k in try_body for k in ["KeyError", "dict", "get(", ".get("]):
                specific_exceptions.append("KeyError")
            if any(k in try_body for k in ["ValueError", "int(", "float("]):
                specific_exceptions.append("ValueError")
            if any(k in try_body for k in ["open(", "read", "write", "Path"]):
                specific_exceptions.append("OSError")
            if any(k in try_body for k in ["import", "__import__"]):
                specific_exceptions.append("ImportError")

            if not specific_exceptions:
                specific_exceptions = ["RuntimeError", "ValueError"]

            exc_str = "(" + " | ".join(specific_exceptions) + ") as e"
            new_line = f"{indent_str}except {exc_str}:"

            diff_text = f"--- a/zhiyue_connected.py\n+++ b/zhiyue_connected.py\n@@ -{line_num},1 +{line_num},1 @@\n-{old_line.rstrip()}\n+{new_line}"
            test_commands = [f"python -c \"import py_compile; py_compile.compile('zhiyue_connected.py', doraise=True)\""]

        elif category == "large_function" and line_num > 0:
            # 大函数暂不自动生成拆分diff(风险太高),只给出建议
            diff_text = f"# 大函数拆分需要人工确认具体方案\n# {item['title']}\n# 建议: {item.get('suggested_fix', '')}\n# 此 diff 需要人工补充"
            test_commands = []

        elif category == "backup_clutter":
            # 备份文件移动
            backup_files = sorted(source_dir.glob("zhiyue_connected_backup_*.py"))
            if backup_files:
                move_commands = []
                for bf in backup_files:
                    move_commands.append(f"move \"{bf.name}\" backups/")
                diff_text = f"# 移动备份文件到 backups/ 目录\n# 文件: {', '.join(bf.name for bf in backup_files)}"
                test_commands = move_commands

        elif category == "code_duplication":
            # 重复代码暂不自动生成diff
            diff_text = f"# 代码去重需要人工确认\n# {item['title']}\n# 建议: {item.get('suggested_fix', '')}"
            test_commands = []

        elif category == "db_cleanup":
            # 生成可执行的清理 SQL（通过 execute_approved_fixes 直接在 DB 上运行）
            meta = item.get("meta", {}) if isinstance(item.get("meta"), dict) else {}
            suggested = item.get("suggested_fix", "")
            if suggested and any(k in suggested.upper() for k in ["DELETE", "UPDATE", "INSERT", "VACUUM", "DROP"]):
                diff_text = f"SQL_OBSDB: {suggested}"
                test_commands = []
            else:
                # 默认清理：归档过期候选 + 删除僵死任务
                diff_text = f"SQL_OBSDB: DELETE FROM agent_tasks WHERE status NOT IN ('done','archived'); UPDATE self_improvement_candidates SET status='archived' WHERE status IN ('pending','approved') AND julianday('now') - julianday(created_at) > 7"
                test_commands = []
        elif category == "reply_quality":
            # 回复质量类问题：优先尝试结构化修复,否则生成注释型 diff
            parsed = _parse_structured_fix(item.get("suggested_fix", ""))
            if parsed:
                proposals.append(_build_structured_diff(item, parsed, source_dir))
                continue
            diff_text = f"# REPLY_QUALITY: {item['title']}\n# {item.get('suggested_fix','')}\n# 使用结构化格式可自动修复: FILE:文件名|LINE:行号|NEW:新内容"
            test_commands = []
        else:
            # 通用处理器(含 runtime_issue): 优先结构化解析,再试 suggested_fix,最后注释
            parsed = _parse_structured_fix(item.get("suggested_fix", ""))
            if parsed:
                proposals.append(_build_structured_diff(item, parsed, source_dir))
                continue
            suggested = item.get("suggested_fix", "")
            if suggested and not suggested.startswith("#") and "FILE:" not in suggested:
                diff_text = suggested
            else:
                diff_text = f"# {item['title']}\n# {item.get('description', '')}\n# 使用结构化格式可自动修复: FILE:文件名|LINE:行号|NEW:新内容"
            test_commands = []

        if diff_text:
            proposals.append({
                "fix_id": item["id"],
                "title": item["title"],
                "category": category,
                "target_file": "zhiyue_connected.py",
                "diff_text": diff_text,
                "test_commands": test_commands,
                "auto_generated": True,
            })

    return proposals


def _call_lm_for_diff_fix(target_file: Path, diff_text: str, error_message: str, category: str, title: str) -> str | None:
    """Ask LM to fix a failed diff based on the sandbox error"""
    import requests
    prompt = f"""You are a code repair assistant. A code diff failed sandbox testing.

## Target file: {target_file}
## Category: {category}
## Title: {title}

## Failed diff:
```
{diff_text}
```

## Sandbox error:
{error_message}

Please fix the diff so it will pass. Output ONLY the corrected unified diff. Do NOT output any explanation or markdown code fences — just the raw diff."""
    try:
        body = {
            "model": LM_MODEL,
            "messages": [
                {"role": "system", "content": "You are a code repair bot. Output ONLY the corrected unified diff, no markdown, no explanation."},
                {"role": "user", "content": prompt},
            ],
            "stream": False,
            "temperature": 0.0,
            "max_tokens": 2048,
        }
        resp = _provider_post_chat_completion("review", body, timeout=60)
        resp.raise_for_status()
        data = resp.json()
        choices = data.get("choices", [])
        if choices and isinstance(choices[0], dict):
            msg = choices[0].get("message", {})
            content = msg.get("content", "").strip()
            if content:
                # Strip markdown code fences if present
                if content.startswith("```"):
                    lines = content.split("\n")
                    if lines[0].startswith("```"):
                        lines = lines[1:]
                    if lines and lines[-1].startswith("```"):
                        lines = lines[:-1]
                    content = "\n".join(lines).strip()
                return content
        return None
    except Exception:
        return None


def _retry_sandbox_fix(
    target_file: Path,
    diff_text: str,
    test_commands: list[str],
    category: str,
    title: str,
) -> dict:
    """
    Retry sandbox up to SANDBOX_RETRY_MAX times.
    On failure, ask LM to correct the diff and retry.
    Returns: {"success": True/False, "final_diff": str, "attempts": int, "errors": [str]}
    """
    current_diff = diff_text
    error_log: list[str] = []

    for attempt in range(1, SANDBOX_RETRY_MAX + 1):
        ok, err = _sandbox_test(target_file, current_diff, test_commands)
        if ok:
            return {
                "success": True,
                "final_diff": current_diff,
                "attempts": attempt,
                "errors": error_log,
            }

        error_log.append(f"Attempt {attempt}: {err[:200]}")

        if attempt >= SANDBOX_RETRY_MAX:
            break

        fixed = _call_lm_for_diff_fix(target_file, current_diff, err, category, title)
        if not fixed:
            error_log.append(f"Attempt {attempt}: LM did not return a corrected diff")
            break

        # Validate the LM output looks like a diff
        if not any(line.startswith(("---", "+++", "@@")) for line in fixed.split("\n")[:5]):
            error_log.append(f"Attempt {attempt}: LM output was not a valid diff")
            break

        current_diff = fixed

    return {
        "success": False,
        "final_diff": diff_text,
        "attempts": SANDBOX_RETRY_MAX,
        "errors": error_log,
    }


def _write_sandbox_retry_report(reports: list[dict]) -> None:
    """Write failed sandbox retry reports for user review"""
    try:
        existing: list[dict] = []
        if SANDBOX_RETRY_REPORT.exists():
            existing = json.loads(SANDBOX_RETRY_REPORT.read_text(encoding="utf-8"))
        for r in reports:
            r["reported_at"] = _now_iso()
            existing.append(r)
        SANDBOX_RETRY_REPORT.write_text(
            json.dumps(existing[-20:], ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    except Exception:
        pass


def execute_approved_fixes(source_dir: str | Path = "") -> dict:
    """
    真正执行已批准的修复:备份→应用diff→语法检查→标记完成。
    只处理有完整 diff_text(非注释型)的 bare_except 类问题。
    """
    source_dir = Path(source_dir).resolve() if source_dir else BASE_DIR
    main_file = source_dir / "zhiyue_connected.py"
    items = _load_pending()
    approved = [i for i in items if i.get("status") == "approved"]

    if not approved:
        return {"executed": 0, "skipped": 0, "errors": [], "message": "没有已批准的修复可执行"}

    # ── 改动前：抓取当前 eval 基线 ──
    pre_fix_baseline = None
    try:
        import zhiyue_eval as _ze
        pre_fix_baseline = _ze.load_latest_eval_result()
    except Exception:
        pass

    if not main_file.exists():
        return {"executed": 0, "skipped": len(approved), "errors": ["主文件不存在"], "message": "找不到 zhiyue_connected.py"}

    # 1. 备份
    backup_path = source_dir / f"zhiyue_connected_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.py"
    try:
        import shutil
        shutil.copy2(str(main_file), str(backup_path))
    except Exception as e:
        return {"executed": 0, "skipped": len(approved), "errors": [f"备份失败: {e}"], "message": "备份失败,不执行修复"}

    # 2. 读取源文件
    try:
        text = main_file.read_text(encoding="utf-8", errors="replace")
        lines = text.splitlines()
    except Exception as e:
        return {"executed": 0, "skipped": len(approved), "errors": [f"读文件失败: {e}"], "message": "读源文件出错"}

    # 3. 生成 diff 并逐个应用
    proposals = generate_fix_diff_for_approved(source_dir)
    executed = 0
    skipped = 0
    errors = []
    applied_ids = []
    modified_files: dict[str, list[str]] = {}  # {filename: lines} 用于写回非主文件
    changed_files_summary: list[str] = []        # 用于通知用户

    for prop in proposals:
        fix_id = prop.get("fix_id", "")
        category = prop.get("category", "")
        diff_text = prop.get("diff_text", "")

        # backup_clutter: 移动备份文件到 backups/ 目录(不需要diff)
        if category == "backup_clutter":
            import shutil as _shutil
            backups_dir = source_dir / "backups"
            backups_dir.mkdir(exist_ok=True)
            backup_files = sorted(source_dir.glob("zhiyue_connected_backup_*.py"))
            moved = 0
            for bf in backup_files:
                try:
                    _shutil.move(str(bf), str(backups_dir / bf.name))
                    moved += 1
                except Exception:
                    pass
            if moved > 0:
                executed += 1
                applied_ids.append(fix_id)
            else:
                skipped += 1
            continue

        # db_cleanup: 直接在 observability.db 上执行清理 SQL
        if diff_text.startswith("SQL_OBSDB:"):
            sql = diff_text[len("SQL_OBSDB:"):].strip()
            import sqlite3 as _sql3
            try:
                obs_db = _sql3.connect(str(source_dir / "zhiyue_observability.db"))
                obs_db.execute(sql)
                obs_db.commit()
                obs_db.close()
                executed += 1
                applied_ids.append(fix_id)
            except Exception as _e_sql:
                errors.append(f"{prop.get('title', fix_id)}: SQL执行失败: {_e_sql}")
                skipped += 1
            continue

        # 跳过注释型 diff(需要人工补充的)
        if diff_text.startswith("#") or not diff_text.strip():
            skipped += 1
            continue

        # 确定目标文件(支持多文件修改)
        target_filename = prop.get("target_file", "zhiyue_connected.py")
        target_path = source_dir / target_filename
        if not target_path.exists():
            errors.append(f"{prop.get('title', fix_id)}: 目标文件{target_filename}不存在")
            skipped += 1
            continue

        # 读目标文件(如果不是主文件)
        target_lines = lines if target_filename == "zhiyue_connected.py" else target_path.read_text(encoding="utf-8", errors="replace").splitlines()

        # ▸ 沙盒测试(含重试): 失败时请LM修正diff,最多重试5次
        test_commands = prop.get("test_commands", [])
        retry_result = _retry_sandbox_fix(target_path, diff_text, test_commands, category, prop.get('title', fix_id))
        if not retry_result["success"]:
            _write_sandbox_retry_report([{
                "category": category,
                "title": prop.get('title', fix_id),
                "target_file": str(target_path),
                "attempts": retry_result["attempts"],
                "errors": retry_result["errors"],
            }])
            errors.append(f"{prop.get('title', fix_id)}: 沙盒重试{retry_result['attempts']}次均失败,已生成报告")
            skipped += 1
            continue
        diff_text = retry_result["final_diff"]

        # 解析 diff 并应用到目标文件行数组
        try:
            mod_lines, applied_count, apply_errors = _apply_diff_to_lines(target_lines, target_path, diff_text)
            if apply_errors:
                errors.append(f"{prop.get('title', fix_id)}: {'; '.join(apply_errors)}")
                skipped += 1
                continue

            # 应用：更新行数组
            if target_filename == "zhiyue_connected.py":
                lines = mod_lines
            else:
                modified_files[target_filename] = mod_lines
            changed_files_summary.append(f"{target_filename}: {prop.get('title', fix_id)}")

            applied_ids.append(fix_id)
            executed += 1

        except Exception as e:
            errors.append(f"{prop.get('title', fix_id)}: {e}")
            skipped += 1

    # 4. 写回文件(主文件 + 其他被修改的文件)
    all_written = True
    if executed > 0:
        # 写回主文件
        try:
            main_file.write_text("\n".join(lines), encoding="utf-8")
        except Exception as e:
            try:
                shutil.copy2(str(backup_path), str(main_file))
            except Exception:
                pass
            return {"executed": 0, "skipped": len(approved), "errors": [f"写入失败已回滚: {e}"], "message": "写入源文件失败,已从备份恢复"}

        # 写回其他被修改的文件(沙盒已验证通过)
        for fname, flines in modified_files.items():
            fpath = source_dir / fname
            try:
                fpath.write_text("\n".join(flines), encoding="utf-8")
            except Exception as e:
                errors.append(f"写入{fname}失败: {e}")
                all_written = False

        # 5. 语法检查(所有修改过的文件)
        files_to_check = [main_file] + [source_dir / f for f in modified_files]
        try:
            import py_compile
            for fpath_to_check in files_to_check:
                py_compile.compile(str(fpath_to_check), doraise=True)
        except py_compile.PyCompileError as e:
            try:
                shutil.copy2(str(backup_path), str(main_file))
            except Exception:
                pass
            return {"executed": 0, "skipped": len(approved), "errors": [f"语法检查失败已回滚: {e}"], "message": "改完语法不对,已从备份恢复,没动源码"}

        # 6. 记录代码变更通知(proactive通道推送)
        if changed_files_summary:
            _record_code_change_notification(
                summary=f"自动修复了 {executed} 处代码问题",
                file_changed=", ".join(set(f.split(":")[0] for f in changed_files_summary)),
                change_type="auto_fix",
                details={"files": changed_files_summary, "skipped": skipped, "errors": errors},
            )

    # 7. 标记已修复
    for item in items:
        if item["id"] in applied_ids:
            item["status"] = "fixed"
            item["fixed_at"] = _now_iso()
            item["meta"] = item.get("meta", {})
            item["meta"]["backup_path"] = str(backup_path)
            _append_history(item)
    _save_pending([i for i in items if i.get("status") not in ("fixed", "rejected")])

    msg_parts = []
    if executed:
        msg_parts.append(f"已修复 {executed} 处")
    if skipped:
        msg_parts.append(f"跳过 {skipped} 处(需人工确认)")
    if errors:
        msg_parts.append(f"失败 {len(errors)} 处")

    # ── 改动后：后台验证 eval ──
    verify_pid = None
    if executed > 0 and pre_fix_baseline:
        verify_pid = _spawn_verify_eval(pre_fix_baseline, source_dir)

    return {
        "executed": executed,
        "skipped": skipped,
        "errors": errors,
        "backup_path": str(backup_path),
        "message": ",".join(msg_parts) if msg_parts else "无操作",
        "verify_eval_pid": verify_pid,
    }


def _spawn_verify_eval(pre_fix_baseline: dict, source_dir: Path) -> str | None:
    """
    在 execute_approved_fixes 完成后，后台 spawn 验证 eval。
    对比改动前后的各维度分数，生成 delta 报告。
    """
    import sys as _sys, subprocess as _sp, json as _json

    baseline_file = source_dir / "data" / "_pre_fix_baseline.json"
    baseline_file.parent.mkdir(parents=True, exist_ok=True)
    baseline_file.write_text(
        _json.dumps(pre_fix_baseline, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    verify_script = source_dir / "data" / "_verify_eval_runner.py"
    verify_script.write_text(
        f'''# -*- coding: utf-8 -*-
import sys, json, os
os.environ.setdefault("PYTHONIOENCODING", "utf-8")
os.environ.setdefault("DEEPEVAL_PER_ATTEMPT_TIMEOUT_SECONDS", "300")

sys.path.insert(0, r"{source_dir}")
import zhiyue_eval
from pathlib import Path

pre = json.loads(Path(r"{baseline_file}").read_text(encoding="utf-8"))

test_file = Path(r"{source_dir / 'data' / 'eval_test_10cases.json'}")
if not test_file.exists():
    print("[verify] 无测试用例文件")
    sys.exit(0)

cases = zhiyue_eval.build_test_cases_from_file(str(test_file), max_cases=10)
if not cases:
    print("[verify] 无测试用例")
    sys.exit(0)

post = zhiyue_eval.run_evaluation(cases)
if "error" in post:
    print(f"[verify] eval failed: {{post['error']}}")
    sys.exit(1)

pre_overall = pre.get("overall", 0)
post_overall = post.get("overall", 0)
delta = post_overall - pre_overall
trend = "📈" if delta > 0.01 else "📉" if delta < -0.01 else "➡"
print(f"\\n{{'='*50}}")
print(f"[verify] {{trend}} 综合: {{pre_overall:.2f}} → {{post_overall:.2f}}  Δ={{delta:+.2f}}")
print(f"{{'='*50}}")

report = {{
    "timestamp": post.get("timestamp", ""),
    "baseline_overall": pre_overall,
    "after_overall": post_overall,
    "delta": round(delta, 2),
    "per_dimension": {{}},
}}

for dim_name, post_stats in post.get("metrics", {{}}).items():
    pre_stats = {{}}
    for pn, ps in pre.get("metrics", {{}}).items():
        if pn.startswith(dim_name) or dim_name.startswith(pn):
            pre_stats = ps
            break
    pre_mean = pre_stats.get("mean", 0)
    post_mean = post_stats.get("mean", 0)
    dim_delta = post_mean - pre_mean
    arrow = "↑" if dim_delta > 0.01 else "↓" if dim_delta < -0.01 else "→"
    print(f"[verify]   {{dim_name:35s}}: {{pre_mean:.2f}} → {{post_mean:.2f}} {{arrow}}{{abs(dim_delta):.2f}}")
    report["per_dimension"][dim_name] = {{
        "before": pre_mean,
        "after": post_mean,
        "delta": round(dim_delta, 2),
    }}

report_path = Path(r"{source_dir / 'data' / 'eval' / 'fix_verify_report.json'}")
report_path.parent.mkdir(parents=True, exist_ok=True)
report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
print(f"\\n[verify] Report saved: {{report_path}}")

# run_evaluation() 已通过 _save_eval_result() 保存 hash，此处无需重复
''',
        encoding="utf-8",
    )

    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"
    try:
        proc = _sp.Popen(
            [_sys.executable, str(verify_script)],
            env=env,
            stdout=_sp.DEVNULL,
            stderr=_sp.DEVNULL,
        )
        return str(proc.pid)
    except Exception as e:
        import logging
        logging.getLogger("zhiyue_code_fix").error(f"spawn verify eval failed: {e}")
        return None


def format_proposals_for_user(proposals: list[dict]) -> str:
    """生成给用户看的修改方案,带人设口吻。"""
    if not proposals:
        return "没有待执行的修改方案。"

    # 分出能自动修的和需要人工的
    auto_items = [p for p in proposals if p.get('diff_text') and not p['diff_text'].startswith('#')]
    manual_items = [p for p in proposals if p.get('diff_text', '').startswith('#') or not p.get('diff_text')]

    lines = ["我整理了一下,能自动修的:", ""]
    for i, p in enumerate(auto_items, 1):
        lines.append(f"{i}. {p['title']}")
        if p.get('diff_text') and not p['diff_text'].startswith('#'):
            for dl in p['diff_text'].split('\n')[:6]:
                if dl.startswith('-') and not dl.startswith('---'):
                    lines.append(f"   去掉: {dl[1:][:70]}")
                elif dl.startswith('+') and not dl.startswith('+++'):
                    lines.append(f"   换成: {dl[1:][:70]}")
        lines.append("")

    if manual_items:
        lines.append("得你亲自看的:")
        for p in manual_items:
            lines.append(f"• {p['title']}")
        lines.append("")

    lines.append("说'修吧'我直接动手改，说'进沙箱'我先跑一遍验证。")
    return "\n".join(lines)


def auto_fix_safe(source_dir: str = "") -> dict:
    """全自动安全修复：发现 → 批准 → 生成方案 → 执行。处理所有类别的代码问题。"""
    source_path = str(Path(source_dir).resolve()) if source_dir else str(BASE_DIR)
    new_issues = scan_and_accumulate_issues(source_path)
    pending = _load_pending()
    pending_count = len([i for i in pending if i.get("status") in ("pending", "approved")])
    if not new_issues and pending_count == 0:
        return {"ok": True, "action": "skip", "reason": "no issues found"}
    approved = approve_fixes()
    if not approved.get("approved"):
        return {"ok": True, "action": "skip", "reason": "nothing to approve"}
    result = execute_approved_fixes(source_path)
    clear_fixed()
    return {"ok": True, "action": "auto_fixed", "new_issues": len(new_issues), "pending_before": pending_count, "approved": approved.get("approved",0), "executed": result.get("executed",0), "skipped": result.get("skipped",0), "errors": result.get("errors",[]), "message": result.get("message","")}


def trigger_auto_fix(source_dir: str = "", *, issue_title: str = "", issue_desc: str = "", issue_category: str = "runtime_issue") -> dict:
    """直接触发自修复：用户反馈或系统检测到问题时调用。
    
    如果提供了 issue_title，会先注册该问题再执行修复。
    """
    if issue_title:
        add_pending_fix(
            source="user_report" if not issue_category.startswith("runtime") else "runtime",
            category=issue_category,
            title=issue_title,
            description=issue_desc or issue_title,
            location="",
            severity="high",
        )
    return auto_fix_safe(source_dir)
