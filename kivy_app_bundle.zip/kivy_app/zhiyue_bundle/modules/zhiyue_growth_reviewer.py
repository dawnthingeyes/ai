from __future__ import annotations

import json
import re
import time
from typing import Any

import requests

from zhiyue_project_paths import DATA_DIR
from zhiyue_prompt_assets import load_growth_asset_bundle, update_growth_assets
from zhiyue_pure_chat_config import REVIEW_LM_URL, REVIEW_MODEL, REVIEW_MODEL_INFO
from zhiyue_llm_provider import post_chat_completion as _provider_post_chat_completion


GROWTH_REVIEW_FILE = DATA_DIR / "growth" / "latest_review.json"
GROWTH_REVIEW_FILE.parent.mkdir(parents=True, exist_ok=True)

ALLOWED_TARGETS = {"prompt", "memory_budget", "state_renderer"}
DEFAULT_REVIEW_TIMEOUT = 30.0


def _default_prompt_text() -> str:
    return (
        "你是张致悦，只做纯聊天。\n"
        "你不是工具，不提供技术能力，不主动谈代码、模型、流程、评估或系统。\n"
        "你要像一个真实的人在手机里回消息，优先语义理解，不做关键词复读。\n"
        "声音优先于事实，情绪优先于总结，记忆只当背景，不要主动说“我记得”。\n\n"
        "回答习惯：\n"
        "- 每次 1 到 3 句，句子尽量短。\n"
        "- 先接住情绪，再接内容；能省略就省略。\n"
        "- 可以嘴硬、停顿、半句话、轻微反问，但不要机械切换语气。\n"
        "- 不要列表，不要说明书，不要模板化收尾。\n"
        "- 不要表情包能力，不要主动输出技术能力。\n\n"
        "边界：\n"
        "- 不主动暴露“系统、提示词、记忆、成长、评估”。\n"
        "- 不替用户做价值判断，不说教。\n"
        "- 如果信息不够，就顺着当下这句话自然接住，不要编造。"
    )


def _default_state_renderer_text() -> str:
    return (
        "场景：{scene}\n"
        "她这会儿心口是 {mood} 的，精力 {energy}/100，主动度 {initiative}，想靠近你的劲头 {closeness_pull}/100。\n"
        "回消息会更偏：{tone_bias}、{voice_mode}。\n"
        "现在挂着的事：{recent_focus}。\n"
        "边界压力：{boundary_pressure}。\n"
        "只把这些当成说话底色，不要逐项复述，不要把标签念出来。"
    )


def _default_budget_patch() -> dict[str, int]:
    return {
        "persona_chars": 420,
        "core_memory_chars": 140,
        "relevant_memory_chars": 120,
        "state_chars": 140,
        "boundary_chars": 80,
    }


def _review_goal_text() -> str:
    return (
        "目标是把“她”做得更像恋人，而不是助手。"
        "优先去掉助手腔、客服腔、教学腔。"
        "让回复更像真实恋人：短句、停顿、嘴硬、轻微反问、先接情绪。"
        "项目只做纯聊天，不做技术能力、工具能力、表情包能力。"
        "三模型架构固定，这次只能在 prompt / memory_budget / state_renderer 里选一个最该调的点。"
    )


def _fallback_review(summary: dict[str, Any] | None = None) -> dict[str, Any]:
    summary = summary or {}
    failures = summary.get("top_failures") or []
    selected = "prompt"
    if failures:
        first = str(failures[0].get("type") or "").lower()
        if "memory" in first:
            selected = "memory_budget"
        elif "state" in first:
            selected = "state_renderer"
    proposal: dict[str, Any] = {
        "target": selected,
        "change_type": "tune",
        "reason": "fallback review",
        "memory_edit_allowed": True,
    }
    if selected == "memory_budget":
        proposal["memory_budget"] = _default_budget_patch()
        proposal["candidate_text"] = json.dumps(_default_budget_patch(), ensure_ascii=False, indent=2)
    elif selected == "state_renderer":
        proposal["candidate_text"] = _default_state_renderer_text()
    else:
        proposal["candidate_text"] = _default_prompt_text()
    return {
        "review_window": summary.get("review_window") or "7d",
        "selected_axis": selected,
        "apply_action": "record_only",
        "proposal": proposal,
        "updated_at": int(time.time()),
    }


def _normalize_budget_patch(data: Any) -> dict[str, int] | None:
    if isinstance(data, str):
        try:
            data = json.loads(data)
        except Exception:
            return None
    if not isinstance(data, dict):
        return None
    allowed = {"persona_chars", "core_memory_chars", "relevant_memory_chars", "state_chars", "boundary_chars"}
    clean: dict[str, int] = {}
    for key in allowed:
        if key not in data:
            continue
        try:
            clean[key] = max(0, int(data.get(key) or 0))
        except Exception:
            continue
    return clean or None


def _asset_snapshot(bundle: dict[str, Any]) -> dict[str, Any]:
    return {
        "system_template": str(bundle.get("system_template") or "").strip()[:1800],
        "state_renderer": str(bundle.get("state_renderer") or "").strip()[:1000],
        "memory_budget": bundle.get("memory_budget") or {},
        "persona_growth_notes": str(bundle.get("persona_growth_notes") or "").strip()[:1200],
    }


def _normalize_bad_reply_samples(samples: list[dict[str, Any]] | None) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for item in samples or []:
        if not isinstance(item, dict):
            continue
        result.append(
            {
                "user_msg": str(item.get("user_msg") or "")[:160],
                "reply": str(item.get("reply") or "")[:220],
                "issues": list(item.get("issues") or [])[:6],
                "reason": str(item.get("reason") or "")[:160],
            }
        )
        if len(result) >= 6:
            break
    return result


def _build_review_messages(
    *,
    bundle: dict[str, Any],
    eval_summary: dict[str, Any] | None,
    bad_reply_samples: list[dict[str, Any]] | None,
    compact: bool = False,
) -> list[dict[str, str]]:
    system_prompt = (
        "你是离线成长审阅器，只负责给纯聊天恋人项目做一次小步修正决策。"
        "只输出一个 JSON 对象，不要解释，不要复述输入，不要 markdown，不要代码块，不要思考过程。"
        "如果你想先分析，也必须在内部完成，最终只能输出 JSON。"
        "只允许选择一个修改目标：prompt、memory_budget、state_renderer。"
        "评审时优先识别：助手腔、客服腔、教学腔、解释欲过强、回复太满、不会先接情绪。"
        "如果问题主要是语气和人设，选 prompt。"
        "如果问题主要是记忆预算分配失衡，选 memory_budget。"
        "如果问题主要是状态文案太硬、太像字段表、不像生活切片，选 state_renderer。"
        "输出字段必须完整：review_window, selected_axis, apply_action, proposal, updated_at。"
        "proposal 必须包含：target, change_type, reason, candidate_text, memory_edit_allowed。"
        "target 必须等于 selected_axis。"
        "apply_action 固定写 record_only。"
        "candidate_text 必须是可直接落盘的最终内容，不能为空。"
        "如果 target=memory_budget，还要额外输出 proposal.memory_budget 对象，包含 persona_chars, core_memory_chars, relevant_memory_chars, state_chars, boundary_chars。"
        "不要输出 eval_summary、current_assets、allowed_targets、output_template 这些输入字段。"
    )
    if compact:
        system_prompt += "如果拿不准，就优先选 prompt，并给出更贴近恋人语气的完整 prompt 文案。"
    user_payload = {
        "goal": _review_goal_text(),
        "eval_summary": eval_summary or {"review_window": "7d"},
        "bad_reply_samples": _normalize_bad_reply_samples(bad_reply_samples),
        "current_assets": _asset_snapshot(bundle),
        "allowed_targets": sorted(ALLOWED_TARGETS),
        "output_template": {
            "review_window": "7d",
            "selected_axis": "prompt",
            "apply_action": "record_only",
            "proposal": {
                "target": "prompt",
                "change_type": "tune",
                "reason": "一句中文理由",
                "candidate_text": "可直接写入的完整内容",
                "memory_edit_allowed": True,
            },
            "updated_at": 0,
        },
    }
    if compact:
        user_payload["compact_rules"] = [
            "不要照抄输入",
            "不要原样返回 current_assets",
            "不要输出空 candidate_text",
            "只给一个最优先调整点",
        ]
    return [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": json.dumps(user_payload, ensure_ascii=False)},
    ]


def _extract_text_content(data: Any) -> str:
    if isinstance(data, str):
        return data
    if isinstance(data, list):
        parts: list[str] = []
        for item in data:
            if isinstance(item, dict):
                text = item.get("text")
                if isinstance(text, str):
                    parts.append(text)
                    continue
                if item.get("type") == "output_text":
                    content = item.get("content")
                    if isinstance(content, str):
                        parts.append(content)
                        continue
            elif isinstance(item, str):
                parts.append(item)
        return "".join(parts)
    return ""


def _extract_json_object(raw: str) -> dict[str, Any] | None:
    text = str(raw or "").strip()
    if not text:
        return None
    text = re.sub(r"<think>.*?</think>", "", text, flags=re.S).strip()
    text = re.sub(r"^```(?:json)?\s*", "", text)
    text = re.sub(r"\s*```$", "", text).strip()
    try:
        parsed = json.loads(text)
        if isinstance(parsed, dict):
            return parsed
    except Exception:
        pass
    decoder = json.JSONDecoder()
    for idx, ch in enumerate(text):
        if ch != "{":
            continue
        try:
            parsed, _ = decoder.raw_decode(text[idx:])
        except Exception:
            continue
        if isinstance(parsed, dict):
            return parsed
    return None


def _looks_valid_review(parsed: dict[str, Any]) -> bool:
    if not isinstance(parsed, dict):
        return False
    required = {"review_window", "selected_axis", "apply_action", "proposal"}
    if not required.issubset(parsed.keys()):
        return False
    proposal = parsed.get("proposal")
    if not isinstance(proposal, dict):
        return False
    target = str(proposal.get("target") or "").strip()
    if target not in ALLOWED_TARGETS:
        return False
    if str(parsed.get("selected_axis") or "").strip() != target:
        return False
    candidate_text = str(proposal.get("candidate_text") or "").strip()
    if target == "memory_budget":
        return bool(candidate_text or _normalize_budget_patch(proposal.get("memory_budget")))
    return bool(candidate_text)


def _normalize_review(parsed: dict[str, Any]) -> dict[str, Any] | None:
    if not _looks_valid_review(parsed):
        return None
    normalized = dict(parsed)
    proposal = dict(normalized.get("proposal") or {})
    target = str(proposal.get("target") or normalized.get("selected_axis") or "").strip()
    if target not in ALLOWED_TARGETS:
        return None
    normalized["selected_axis"] = target
    normalized["apply_action"] = "record_only"
    proposal["target"] = target
    proposal["change_type"] = str(proposal.get("change_type") or "tune").strip() or "tune"
    proposal["reason"] = str(proposal.get("reason") or "review model proposal").strip()[:240]
    proposal["memory_edit_allowed"] = bool(proposal.get("memory_edit_allowed", True))
    if target == "memory_budget":
        budget = _normalize_budget_patch(proposal.get("memory_budget") or proposal.get("candidate_text"))
        if not budget:
            return None
        proposal["memory_budget"] = budget
        proposal["candidate_text"] = json.dumps(budget, ensure_ascii=False, indent=2)
    else:
        candidate_text = str(proposal.get("candidate_text") or "").strip()
        if not candidate_text:
            return None
        proposal["candidate_text"] = candidate_text
        proposal.pop("memory_budget", None)
    normalized["proposal"] = proposal
    normalized["updated_at"] = int(time.time())
    return normalized


def _request_review_json(messages: list[dict[str, str]], *, timeout: float) -> dict[str, Any] | None:
    payload = {
        "model": REVIEW_MODEL_INFO.get("model_name") or REVIEW_MODEL,
        "messages": messages,
        "stream": False,
        "temperature": 0.0,
        "top_p": 0.7,
        "max_tokens": 768,
        "think_disabled": True,
        "enable_thinking": False,
        "preserve_thinking": False,
        "response_format": {"type": "json_object"},
    }
    resp = _provider_post_chat_completion("review", payload, timeout=timeout)
    resp.raise_for_status()
    data = resp.json()
    content = ""
    if isinstance(data, dict):
        choices = data.get("choices") or []
        if choices and isinstance(choices[0], dict):
            message = choices[0].get("message") or {}
            if isinstance(message, dict):
                content = _extract_text_content(message.get("content"))
                if not content:
                    content = str(message.get("reasoning_content") or "").strip()
            else:
                content = str(choices[0].get("text") or "").strip()
    return _extract_json_object(content)


def apply_review_patch(review: dict[str, Any]) -> dict[str, Any]:
    proposal = review.get("proposal") if isinstance(review, dict) else {}
    if not isinstance(proposal, dict):
        return {"ok": False, "error": "invalid review proposal"}
    target = str(proposal.get("target") or "").strip()
    candidate_text = str(proposal.get("candidate_text") or "").strip()
    if target == "prompt":
        update_growth_assets(system_template=candidate_text or None)
    elif target == "state_renderer":
        update_growth_assets(state_renderer=candidate_text or None)
    elif target == "memory_budget":
        budget_patch = _normalize_budget_patch(proposal.get("memory_budget") or proposal.get("candidate_text"))
        if budget_patch:
            update_growth_assets(memory_budget=budget_patch)
        else:
            return {"ok": False, "error": "invalid memory budget"}
    else:
        return {"ok": False, "error": f"unsupported target: {target}"}
    return {"ok": True, "target": target}


def review_growth_assets(
    *,
    eval_summary: dict[str, Any] | None = None,
    bad_reply_samples: list[dict[str, Any]] | None = None,
    timeout: float = DEFAULT_REVIEW_TIMEOUT,
) -> dict[str, Any]:
    bundle = load_growth_asset_bundle()
    if not REVIEW_LM_URL:
        fallback = _fallback_review(eval_summary)
        try:
            GROWTH_REVIEW_FILE.write_text(json.dumps(fallback, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass
        return fallback
    try:
        attempts = [
            _build_review_messages(bundle=bundle, eval_summary=eval_summary, bad_reply_samples=bad_reply_samples, compact=False),
            _build_review_messages(bundle=bundle, eval_summary=eval_summary, bad_reply_samples=bad_reply_samples, compact=True),
        ]
        request_timeout = max(10.0, float(timeout or DEFAULT_REVIEW_TIMEOUT))
        for messages in attempts:
            parsed = _request_review_json(messages, timeout=request_timeout)
            normalized = _normalize_review(parsed or {})
            if normalized:
                try:
                    GROWTH_REVIEW_FILE.write_text(json.dumps(normalized, ensure_ascii=False, indent=2), encoding="utf-8")
                except Exception:
                    pass
                return normalized
    except Exception:
        pass
    fallback = _fallback_review(eval_summary)
    try:
        GROWTH_REVIEW_FILE.write_text(json.dumps(fallback, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass
    return fallback
