from __future__ import annotations

import json
import re
import threading
import time
from datetime import datetime
from typing import Any

import requests

from zhiyue_pure_chat_config import STATE_LM_URL, STATE_MODEL, STATE_MODEL_INFO
from zhiyue_prompt_assets import load_state_renderer_template
from zhiyue_project_paths import DATA_DIR
from zhiyue_llm_provider import post_chat_completion as _provider_post_chat_completion


STATE_CACHE_FILE = DATA_DIR / "state" / "compiled_state.json"
STATE_CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
_STATE_LOCK = threading.Lock()
_STATE_CACHE: dict[str, Any] = {}
_VALID_MOODS = {
    "neutral",
    "soft",
    "low",
    "warm",
    "happy",
    "angry",
    "shy",
    "jealous",
    "tired",
    "sleepy",
    "calm",
    "mixed",
    "quiet",
    "anxious",
}
_DEFAULT_SCENES = {"在家", "空闲", "待机", "默认", "无事"}
_DEFAULT_FOCI = {"先缓一会儿", "在家", "休息一下", "没什么", "无事"}
_PLACEHOLDER_VALUES = {"?", "??", "???", "……", "...", "无", "暂无", "未知", "默认", "待定", "没什么", "无事"}
_FOCUS_ALIASES = {
    "累": "想先歇会儿",
    "疲惫": "想先歇会儿",
    "睡不着": "脑子还醒着",
    "难受": "想被安静陪着",
    "焦虑": "脑子有点乱",
    "想你": "等你回我",
    "饿": "想吃点热的",
}


class _SafeFormatDict(dict):
    def __missing__(self, key: str) -> str:
        return ""


def _local_hour() -> int:
    return datetime.now().astimezone().hour


def _default_scene_by_hour(hour: int | None = None) -> str:
    hour = _local_hour() if hour is None else int(hour)
    if 0 <= hour <= 5:
        return "还没睡"
    if 6 <= hour <= 10:
        return "刚醒没多久"
    if 11 <= hour <= 13:
        return "在弄吃的"
    if 14 <= hour <= 18:
        return "白天琐事里"
    if 19 <= hour <= 22:
        return "窝着回消息"
    return "准备休息"


def _default_focus_by_hour(hour: int | None = None) -> str:
    hour = _local_hour() if hour is None else int(hour)
    if 0 <= hour <= 5:
        return "还不太想睡"
    if 6 <= hour <= 10:
        return "人刚醒过来"
    if 11 <= hour <= 13:
        return "想吃点热的"
    if 14 <= hour <= 18:
        return "先把手头弄完"
    if 19 <= hour <= 22:
        return "想松一口气"
    return "想慢慢安静下来"


def _is_placeholderish(value: Any) -> bool:
    text = str(value or "").strip()
    if not text:
        return True
    compact = re.sub(r"\s+", "", text)
    if compact in _PLACEHOLDER_VALUES:
        return True
    if re.fullmatch(r"[?？!！,，.。~～、…\-_=+/\\|]+", compact):
        return True
    return False


def _clean_recent_states(values: Any) -> list[str]:
    result: list[str] = []
    for item in values or []:
        text = _coerce_text(item, "", limit=16)
        if not text or _is_placeholderish(text):
            continue
        result.append(text)
    return result[-5:]


def _clean_scene(value: Any, default: str | None = None) -> str:
    fallback = default or _default_scene_by_hour()
    text = _coerce_text(value, fallback, limit=16)
    if _is_placeholderish(text) or text in _DEFAULT_SCENES or len(text) < 2:
        return fallback
    return text


def _clean_recent_focus(value: Any, default: str | None = None) -> str:
    fallback = default or _default_focus_by_hour()
    text = _coerce_text(value, fallback, limit=28)
    if _is_placeholderish(text):
        return fallback
    if text in _DEFAULT_FOCI:
        return fallback
    return _FOCUS_ALIASES.get(text, text)


def _load_cache() -> dict[str, Any]:
    global _STATE_CACHE
    if _STATE_CACHE:
        return dict(_STATE_CACHE)
    try:
        if STATE_CACHE_FILE.exists():
            data = json.loads(STATE_CACHE_FILE.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                _STATE_CACHE = dict(data)
                return dict(data)
    except Exception:
        pass
    return {}


def _save_cache(state: dict[str, Any]) -> None:
    global _STATE_CACHE
    clean = state if isinstance(state, dict) else {}
    _STATE_CACHE = dict(clean)
    try:
        STATE_CACHE_FILE.write_text(json.dumps(clean, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    except Exception:
        pass


def _coerce_text(value: Any, default: str = "", *, limit: int = 32) -> str:
    text = str(value if value is not None else default).strip()
    text = re.sub(r"\s+", " ", text)
    return text[:limit]


def _coerce_int(value: Any, default: int, *, minimum: int | None = None, maximum: int | None = None) -> int:
    try:
        number = int(value)
    except Exception:
        number = int(default)
    if minimum is not None:
        number = max(minimum, number)
    if maximum is not None:
        number = min(maximum, number)
    return number


def _normalize_choice(value: Any, default: str, *, aliases: dict[str, str], limit: int = 24) -> str:
    raw = str(value if value is not None else default).strip()
    lowered = raw.lower()
    for needle, replacement in aliases.items():
        if needle in lowered:
            return replacement
    return _coerce_text(raw or default, default, limit=limit)


def _looks_valid_state(parsed: dict[str, Any]) -> bool:
    if not isinstance(parsed, dict):
        return False
    scene = _coerce_text(parsed.get("scene"), "", limit=24)
    mood = _coerce_text(parsed.get("mood"), "", limit=16)
    recent_focus = _coerce_text(parsed.get("recent_focus"), "", limit=32)
    if not scene or not mood or not recent_focus:
        return False
    if _is_placeholderish(scene) or _is_placeholderish(recent_focus):
        return False
    if len(scene) > 16 or len(recent_focus) > 24:
        return False
    if re.search(r"[A-Za-z]{4,}", scene) or re.search(r"[A-Za-z]{4,}", recent_focus):
        return False
    if mood not in _VALID_MOODS and len(mood) > 12:
        return False
    return True


def _looks_too_generic(user_msg: str, state: dict[str, Any]) -> bool:
    text = str(user_msg or "")
    scene = str(state.get("scene") or "").strip()
    recent_focus = str(state.get("recent_focus") or "").strip()
    if not scene or not recent_focus:
        return True
    if _is_placeholderish(scene) or _is_placeholderish(recent_focus):
        return True
    if scene in _DEFAULT_SCENES and recent_focus in _DEFAULT_FOCI:
        return True
    if recent_focus in {"没什么", "无事", "先缓一会儿"} and any(token in text for token in ("累", "疲", "想你", "陪我", "焦虑", "难受")):
        return True
    if any(token in text for token in ("累", "疲", "加班", "忙", "困", "烦", "难受", "想你", "陪我", "饿", "生病", "待会儿", "一个人")):
        expected = (
            "加班",
            "工作",
            "忙",
            "累",
            "疲",
            "休息",
            "回家",
            "夜",
            "晚",
            "一个人",
            "安静",
            "发呆",
            "歇",
            "床",
            "沙发",
            "车里",
            "路上",
            "电脑",
            "办公室",
        )
        if not any(token in f"{scene}{recent_focus}" for token in expected):
            return True
    return False


def save_compiled_state(state: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(state, dict):
        state = {}
    normalized = dict(state)
    normalized["scene"] = _clean_scene(normalized.get("scene"))
    normalized["mood"] = _coerce_text(normalized.get("mood"), "neutral", limit=12)
    normalized["energy"] = _coerce_int(normalized.get("energy"), 50, minimum=0, maximum=100)
    normalized["initiative"] = _normalize_choice(
        normalized.get("initiative"),
        "normal",
        aliases={
            "low": "low",
            "medium": "normal",
            "moderate": "normal",
            "normal": "normal",
            "high": "high",
        },
        limit=24,
    )
    normalized["closeness_pull"] = _coerce_int(normalized.get("closeness_pull"), 55, minimum=0, maximum=100)
    normalized["recent_focus"] = _clean_recent_focus(normalized.get("recent_focus"))
    normalized["tone_bias"] = _normalize_choice(
        normalized.get("tone_bias"),
        "short_gentle",
        aliases={
            "warm": "warm_short",
            "soft": "soft_short",
            "quiet": "quiet_short",
            "professional": "short_gentle",
            "formal": "short_gentle",
            "casual": "short_gentle",
            "conversational": "short_gentle",
            "gentle": "short_gentle",
            "neutral": "short_gentle",
            "sharp": "short_sharp",
            "direct": "short_direct",
        },
        limit=24,
    )
    normalized["voice_mode"] = _normalize_choice(
        normalized.get("voice_mode"),
        "light_short",
        aliases={
            "very_short": "very_short",
            "quiet": "quiet_soft",
            "warm": "warm_short",
            "soft": "soft_short",
            "clear": "light_short",
            "moderate": "light_short",
            "normal": "light_short",
            "short": "light_short",
        },
        limit=24,
    )
    normalized["boundary_pressure"] = _coerce_text(normalized.get("boundary_pressure"), "low", limit=16)
    normalized["expire_hours"] = _coerce_int(normalized.get("expire_hours"), 4, minimum=1, maximum=24)
    normalized["renderer"] = load_state_renderer_template()
    normalized["updated_at"] = int(time.time())
    _save_cache(normalized)
    return normalized


def _state_prompt(user_msg: str, context: dict[str, Any] | None = None) -> list[dict[str, str]]:
    ctx = context or {}
    recent_states = _clean_recent_states(ctx.get("recent_user_states") or [])
    current_state = ctx.get("current_state") or {}
    external_awareness = ctx.get("external_awareness") or {}
    local_time = datetime.now().astimezone().isoformat(timespec="minutes")
    return [
        {
            "role": "system",
            "content": (
                "你是恋爱聊天里的生活状态生成器，只负责生成她此刻像个活人在过日子的后台状态。\n"
                "只输出严格 JSON，不要解释，不要附加文字。\n"
                "必须输出这些键：scene, mood, energy, initiative, closeness_pull, recent_focus, tone_bias, voice_mode, boundary_pressure, expire_hours。\n"
                "scene 要写成具体生活切片，2 到 8 个字，像“窝在床上”“刚洗完澡”“在回家路上”“抱着杯子发呆”；不要写“在家、空闲、默认、无事、累了”这种空词。\n"
                "recent_focus 要写成她此刻挂着的小念头，3 到 12 个字，像“想先歇会儿”“脑子还有点乱”“等你再多说一句”“想吃点热的”；不要写“没什么”“???”。\n"
                "如果没有明显新信号，就沿用 current_state 做小幅漂移，不要每轮突然换场景，更不要编故事。\n"
                "mood 只能从 neutral, soft, low, warm, happy, angry, shy, jealous, tired, sleepy, calm, mixed, quiet, anxious 中选。\n"
                "initiative 只能是 low, normal, high。\n"
                "tone_bias 只能是 short_gentle, warm_short, soft_short, quiet_short, short_direct, short_sharp 之一。\n"
                "voice_mode 只能是 very_short, quiet_soft, soft_short, light_short, warm_short 之一。\n"
                "boundary_pressure 只能是 low, medium, high 之一。\n"
                "energy 和 closeness_pull 必须是 0 到 100 的整数。\n"
                "expire_hours 用 1 到 6 的整数，状态明显会变时给短一点。\n"
                "示例：{\"scene\":\"窝在床上\",\"mood\":\"low\",\"energy\":38,\"initiative\":\"low\",\"closeness_pull\":61,\"recent_focus\":\"想先歇会儿\",\"tone_bias\":\"soft_short\",\"voice_mode\":\"very_short\",\"boundary_pressure\":\"low\",\"expire_hours\":2}"
            ),
        },
        {
            "role": "user",
            "content": json.dumps(
                {
                    "user_msg": user_msg or "",
                    "current_state": current_state,
                    "recent_user_states": recent_states,
                    "emotion": ctx.get("emotion") or "neutral",
                    "intimacy_stage": ctx.get("intimacy_stage") or "",
                    "style_hint": ctx.get("style_hint") or "",
                    "external_awareness": external_awareness,
                    "local_time": local_time,
                    "renderer": load_state_renderer_template(),
                },
                ensure_ascii=False,
            ),
        },
    ]


def _fallback_state(user_msg: str, context: dict[str, Any] | None = None) -> dict[str, Any]:
    ctx = context or {}
    recent = _clean_recent_states(ctx.get("recent_user_states") or [])
    external_awareness = ctx.get("external_awareness") or {}
    external_summary = _coerce_text(
        external_awareness.get("life_hint") or external_awareness.get("summary"),
        "",
        limit=28,
    )
    external_time = external_awareness.get("time") or {}
    external_weather = external_awareness.get("weather") or {}
    external_digest = external_awareness.get("subscription_digest") or {}
    external_items = external_digest.get("items") or []
    external_title = ""
    if external_items and isinstance(external_items[0], dict):
        external_title = _coerce_text(external_items[0].get("title"), "", limit=18)
    mood = str(ctx.get("emotion") or "neutral").strip() or "neutral"
    scene = _default_scene_by_hour()
    voice_mode = "light_short"
    tone_bias = "short_gentle"
    recent_focus = _default_focus_by_hour()
    initiative = "normal"
    closeness_pull = 55
    energy = 52 if mood == "neutral" else 46
    text = str(user_msg or "")

    if any(token in text for token in ("晚安", "困", "睡", "休息", "明天见")):
        scene = "准备休息"
        mood = "sleepy"
        recent_focus = "想慢慢睡过去"
        voice_mode = "quiet_soft"
        tone_bias = "quiet_short"
        initiative = "low"
        energy = 26
    elif any(token in text for token in ("累", "疲", "撑不住", "烦", "压得慌", "焦虑")):
        scene = "靠着缓神"
        mood = "anxious" if any(token in text for token in ("焦虑", "压得慌")) else "tired"
        recent_focus = "想先歇会儿" if mood == "tired" else "脑子有点乱"
        voice_mode = "very_short"
        tone_bias = "soft_short"
        initiative = "low"
        energy = 30
    elif any(token in text for token in ("想你", "陪我", "抱抱", "回来", "在吗", "别走")):
        scene = "抱着手机等你"
        mood = "soft"
        recent_focus = "想你多待一会儿"
        voice_mode = "warm_short"
        tone_bias = "warm_short"
        initiative = "high"
        closeness_pull = 72
        energy = 48
    elif any(token in text for token in ("吃饭", "做饭", "饿", "甜", "咖啡", "奶茶")):
        scene = "在吃东西"
        mood = "warm"
        recent_focus = "想吃点热的"
        voice_mode = "light_short"
        tone_bias = "warm_short"
        energy = 57
    elif any(token in text for token in ("上班", "工作", "加班", "开会", "项目", "赶进度")):
        scene = "被事缠着"
        mood = "neutral"
        recent_focus = "先把手头弄完"
        voice_mode = "light_short"
        tone_bias = "short_direct"
        initiative = "low"
        energy = 44

    if str(external_time.get("daypart") or "") in {"evening", "late"} and scene == _default_scene_by_hour():
        scene = "鏅氫笂"
        recent_focus = external_summary or recent_focus
        voice_mode = "quiet_soft"
        tone_bias = "quiet_short"
    elif str(external_weather.get("weather_text") or "").strip() and scene == _default_scene_by_hour():
        scene = "鐪嬩簡鐪嬪ぉ姘?"
        recent_focus = external_summary or recent_focus

    if recent and recent_focus == _default_focus_by_hour():
        recent_focus = _clean_recent_focus(recent[-1], default=recent_focus)
    if external_title:
        recent_focus = external_title
    elif external_summary and recent_focus == _default_focus_by_hour():
        recent_focus = external_summary
    if recent and mood == "neutral":
        if recent[-1] == "累":
            mood = "tired"
            scene = "靠着缓神"
            recent_focus = "想先歇会儿"
            tone_bias = "soft_short"
            voice_mode = "very_short"
            initiative = "low"
            energy = 32
        elif recent[-1] == "睡不着":
            mood = "quiet"
            scene = "还没睡"
            recent_focus = "脑子还醒着"
            tone_bias = "quiet_short"
            voice_mode = "quiet_soft"
            initiative = "low"
            energy = 28
        elif recent[-1] == "难受":
            mood = "low"
            scene = "缩着发呆"
            recent_focus = "想被安静陪着"
            tone_bias = "soft_short"
            voice_mode = "very_short"
            initiative = "low"
            energy = 29

    return {
        "scene": _clean_scene(scene),
        "mood": mood,
        "energy": energy,
        "initiative": initiative,
        "closeness_pull": closeness_pull,
        "recent_focus": _clean_recent_focus(recent_focus),
        "tone_bias": tone_bias,
        "voice_mode": voice_mode,
        "boundary_pressure": "low",
        "expire_hours": 2 if mood in {"tired", "sleepy", "anxious", "low"} else 4,
        "updated_at": int(time.time()),
    }


def _normalize_state(parsed: dict[str, Any], *, context: dict[str, Any] | None = None) -> dict[str, Any]:
    ctx = context or {}
    normalized = dict(parsed)
    normalized["scene"] = _clean_scene(normalized.get("scene"))
    normalized["mood"] = _coerce_text(normalized.get("mood"), str(ctx.get("emotion") or "neutral"), limit=12)
    normalized["energy"] = _coerce_int(normalized.get("energy"), 50, minimum=0, maximum=100)
    normalized["initiative"] = _normalize_choice(
        normalized.get("initiative"),
        "normal",
        aliases={
            "low": "low",
            "medium": "normal",
            "moderate": "normal",
            "normal": "normal",
            "high": "high",
        },
        limit=24,
    )
    normalized["closeness_pull"] = _coerce_int(normalized.get("closeness_pull"), 55, minimum=0, maximum=100)
    normalized["recent_focus"] = _clean_recent_focus(normalized.get("recent_focus"))
    normalized["tone_bias"] = _normalize_choice(
        normalized.get("tone_bias"),
        "short_gentle",
        aliases={
            "warm": "warm_short",
            "soft": "soft_short",
            "quiet": "quiet_short",
            "professional": "short_gentle",
            "formal": "short_gentle",
            "casual": "short_gentle",
            "conversational": "short_gentle",
            "gentle": "short_gentle",
            "neutral": "short_gentle",
            "sharp": "short_sharp",
            "direct": "short_direct",
        },
        limit=24,
    )
    normalized["voice_mode"] = _normalize_choice(
        normalized.get("voice_mode"),
        "light_short",
        aliases={
            "very_short": "very_short",
            "quiet": "quiet_soft",
            "warm": "warm_short",
            "soft": "soft_short",
            "clear": "light_short",
            "moderate": "light_short",
            "normal": "light_short",
            "short": "light_short",
        },
        limit=24,
    )
    normalized["boundary_pressure"] = _coerce_text(normalized.get("boundary_pressure"), "low", limit=16)
    normalized["expire_hours"] = _coerce_int(normalized.get("expire_hours"), 4, minimum=1, maximum=24)
    normalized["updated_at"] = int(time.time())
    normalized["renderer"] = load_state_renderer_template()
    return normalized


def compile_state_snapshot(user_msg: str = "", *, context: dict[str, Any] | None = None, timeout: float = 18.0) -> dict[str, Any]:
    ctx = dict(context or {})
    if not STATE_LM_URL:
        return save_compiled_state(_fallback_state(user_msg, ctx))

    payload = {
        "model": STATE_MODEL_INFO.get("model_name") or STATE_MODEL,
        "messages": _state_prompt(user_msg, ctx),
        "stream": False,
        "temperature": 0.15,
        "top_p": 0.75,
        "max_tokens": 128,
        "response_format": {"type": "json_object"},
    }
    try:
        resp = _provider_post_chat_completion("state", payload, timeout=timeout)
        resp.raise_for_status()
        data = resp.json()
        content = ""
        if isinstance(data, dict):
            choices = data.get("choices") or []
            if choices and isinstance(choices[0], dict):
                message = choices[0].get("message") or {}
                if isinstance(message, dict):
                    content = str(message.get("content") or "").strip()
        parsed = json.loads(content) if content else None
        if isinstance(parsed, dict) and _looks_valid_state(parsed):
            normalized = _normalize_state(parsed, context=ctx)
            if not _looks_too_generic(user_msg, normalized):
                return save_compiled_state(normalized)
    except Exception:
        pass
    return save_compiled_state(_fallback_state(user_msg, ctx))


def get_cached_state(
    user_msg: str = "",
    *,
    context: dict[str, Any] | None = None,
    refresh_if_stale: bool = True,
) -> dict[str, Any]:
    state = _load_cache()
    if state:
        invalid = (not _looks_valid_state(state)) or _looks_too_generic(user_msg, state)
        if invalid:
            if refresh_if_stale:
                return compile_state_snapshot(user_msg, context=context)
            return save_compiled_state(_fallback_state(user_msg, context))
        expire_hours = int(state.get("expire_hours") or 4)
        updated_at = int(state.get("updated_at") or 0)
        stale = (time.time() - updated_at) > (expire_hours * 3600)
        if not stale or not refresh_if_stale:
            return state
    if refresh_if_stale:
        return compile_state_snapshot(user_msg, context=context)
    return state or _fallback_state(user_msg, context)


def render_state_inject(state: dict[str, Any] | None) -> str:
    if not isinstance(state, dict):
        return ""
    template = load_state_renderer_template()
    data = _SafeFormatDict(
        scene=str(state.get("scene") or "").strip(),
        mood=str(state.get("mood") or "neutral").strip(),
        energy=str(state.get("energy") or "").strip(),
        initiative=str(state.get("initiative") or "").strip(),
        closeness_pull=str(state.get("closeness_pull") or "").strip(),
        tone_bias=str(state.get("tone_bias") or "").strip(),
        voice_mode=str(state.get("voice_mode") or "").strip(),
        recent_focus=str(state.get("recent_focus") or "").strip(),
        boundary_pressure=str(state.get("boundary_pressure") or "").strip(),
    )
    try:
        rendered = template.format_map(data).strip()
        return rendered or ""
    except Exception:
        parts = [f"{key}={value}" for key, value in data.items() if value]
        return "；".join(parts)


def refresh_state_async(user_msg: str = "", *, context: dict[str, Any] | None = None) -> None:
    if not _STATE_LOCK.acquire(blocking=False):
        return

    def _worker():
        try:
            compile_state_snapshot(user_msg, context=context)
        finally:
            _STATE_LOCK.release()

    thread = threading.Thread(target=_worker, daemon=True)
    thread.start()
