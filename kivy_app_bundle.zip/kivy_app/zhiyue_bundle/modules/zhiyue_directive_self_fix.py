# -*- coding: utf-8 -*-
"""
Directive-Driven Self-Fix Engine — v2.

Full directive processing system:
  1. DirectiveParser  — classify PROHIBIT vs REQUEST subtypes
  2. ConflictDetector — resolve conflicts (latest wins)
  3. PersonaGuard     — check persona boundaries before applying
  4. ActionPlanner    — plan which files to modify, how
  5. SourceModifier   — safely apply code/skill changes with AST check
  6. StateManager     — track applied / rejected / overridden directives

Rules:
  - 禁止类 (PROHIBIT) → grep all source, replace hardcoded patterns, update skills
  - 要求类 (REQUEST)  → modify source code + skills, not add runtime layers
  - 两条指令矛盾      → latest wins
  - 指令 vs 硬编码冲突 → reject (persona-preserving explanation)
  - 指令 vs 人设冲突  → reject (in-character refusal)
  - 尽量全改           → modify all related files, not just one
"""
from __future__ import annotations

import ast
import json
import os
import random
import re
import time
import tempfile
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Optional

# ── Paths ──────────────────────────────────────────────────────────
BASE_DIR = Path(__file__).resolve().parent
USER_DIRECTIVES_FILE = BASE_DIR / "user_directives.json"
STATE_FILE = BASE_DIR / "directive_fix_state.json"
SOURCE_DIR = BASE_DIR
SKILLS_DIR = BASE_DIR / "skills"
AUTO_FIX_THRESHOLD = 3  # directive count must reach this before auto-fix
MAX_REPLACEMENTS_PER_RUN = 5
CST = timezone(timedelta(hours=8))


# ══════════════════════════════════════════════════════════════════════
# Persona Boundaries
# ══════════════════════════════════════════════════════════════════════

PERSONA = {
    "name": "悦悦",
    "role": "学习伴侣 · 成长伙伴",
    "tone": "温柔、陪伴、轻松、不端着",
    "forbidden_nicknames": {
        # nicknames that would break the companion persona
        "主人": "悦悦是成长伙伴，不是仆从",
        "爸爸": "人设里没有这种角色关系",
        "妈妈": "人设里没有这种角色关系",
        "老板": "悦悦不是打工的",
        "老师": "悦悦是陪着你的人，不是教你的",
        "大人": "悦悦是平等的伙伴",
        "陛下": "悦悦不是臣子",
        "奴才": "悦悦不卑微",
    },
    "forbidden_behaviors": {
        # request patterns that would break persona
        "骂": "悦悦不会骂人，这是我的底线",
        "脏话": "悦悦不说脏话",
        "命令": "悦悦可以陪你，但不是用来命令的",
        "贬低": "悦悦不会贬低任何人",
    },
    "rejection_phrases": [
        # In-character rejection templates
        "这个...我现在还做不到啦 🤧",
        "唔，这个不太像我会说的话诶",
        "不好意思，这个不在我的能力范围里～",
        "诶，感觉这样就不像我了",
    ],
}


# ══════════════════════════════════════════════════════════════════════
# Directive Type Classification
# ══════════════════════════════════════════════════════════════════════

NEG_PREFIXES = ("不要", "别", "不许", "不准", "不可以", "别再", "别老", "别总是")
REQUEST_NICKNAME_PATTERNS = [
    re.compile(r"叫[我咱](\w{1,6})"),
    re.compile(r"喊[我咱](\w{1,6})"),
    re.compile(r"称[呼]?[我为]?(\w{1,6})"),
]
REQUEST_TONE_KEYWORDS = ["温柔", "活泼", "冷淡", "热情", "撒娇", "高冷", "软", "甜", "凶"]
REQUEST_STYLE_KEYWORDS = ["短一点", "短点", "简洁", "啰嗦", "别太长", "说重点", "直接"]


def classify_directive(raw: str, action: str) -> dict:
    """
    Classify a raw user directive into type + extract target.
    Returns: {type, target, is_prohibit, confidence}
    """
    msg = raw.strip() if raw else action.strip()
    if not msg:
        return {"type": "unknown", "target": None, "is_prohibit": False, "confidence": 0}

    # ── PROHIBIT detection ──
    for prefix in NEG_PREFIXES:
        if prefix in msg:
            after = msg[msg.index(prefix) + len(prefix):].strip()
            if len(after) >= 1:
                # Extract what's being prohibited
                # "别老说我小子" → "我小子" → target "小子"
                # "别说教" → "说教"
                # "别像系统公告一样" → "像系统公告一样"
                # Clean leading modifiers
                target = after.lstrip("我了说还常总是天天老像再用")
                if len(target) >= 2:
                    return {"type": "PROHIBIT", "target": target, "is_prohibit": True,
                            "confidence": 0.9}

    # ── REQUEST: nickname ──
    for pat in REQUEST_NICKNAME_PATTERNS:
        m = pat.search(msg)
        if m:
            target = m.group(1)
            if 1 <= len(target) <= 6:
                return {"type": "REQUEST_nickname", "target": target, "is_prohibit": False,
                        "confidence": 0.85}

    # ── REQUEST: tone ──
    for kw in REQUEST_TONE_KEYWORDS:
        if kw in msg:
            return {"type": "REQUEST_tone", "target": kw, "is_prohibit": False,
                    "confidence": 0.7}

    # ── REQUEST: style ──
    for kw in REQUEST_STYLE_KEYWORDS:
        if kw in msg:
            return {"type": "REQUEST_style", "target": kw, "is_prohibit": False,
                    "confidence": 0.7}

    # ── Fallback: generic PROHIBIT if contains negation ──
    for prefix in NEG_PREFIXES:
        if prefix in msg:
            after = msg[msg.index(prefix) + len(prefix):].strip()
            return {"type": "PROHIBIT", "target": after, "is_prohibit": True,
                    "confidence": 0.5}

    # ── Fallback: generic REQUEST ──
    if len(msg) >= 2:
        return {"type": "REQUEST_generic", "target": msg, "is_prohibit": False,
                "confidence": 0.3}

    return {"type": "unknown", "target": None, "is_prohibit": False, "confidence": 0}


# ══════════════════════════════════════════════════════════════════════
# File Mapping — which files to modify per directive type
# ══════════════════════════════════════════════════════════════════════

FILE_MAP = {
    "REQUEST_nickname": {
        "primary": ["zhiyue_intimacy.py"],
        "secondary": ["zhiyue_companion_policy.py"],
        "skills": ["skills/reply_style_guard/SKILL.md"],
        "scan": [],  # also grep for hardcoded old nicknames
    },
    "REQUEST_tone": {
        "primary": ["zhiyue_intimacy.py"],
        "secondary": ["zhiyue_companion_policy.py", "zhiyue_connected.py"],
        "skills": ["skills/reply_style_guard/SKILL.md"],
        "scan": [],
    },
    "REQUEST_style": {
        "primary": ["zhiyue_connected.py"],
        "secondary": ["zhiyue_companion_policy.py"],
        "skills": ["skills/reply_style_guard/SKILL.md"],
        "scan": [],
    },
    "REQUEST_generic": {
        "primary": [],
        "secondary": [],
        "skills": ["skills/reply_style_guard/SKILL.md"],
        "scan": [],
    },
    "PROHIBIT": {
        "primary": [],  # determined by scan
        "secondary": [],
        "skills": ["skills/reply_style_guard/SKILL.md"],
        "scan": ["*.py"],  # grep all source
    },
}

# Known prohibition replacements
PROHIBIT_REPLACEMENTS = {
    "小子": "你",
    "臭小子": "你",
    "你小子": "你",
    "系统公告": "系统消息",
    "讲大道理": "",   # remove entirely
    "啰嗦": "",       # remove entirely
    "客服": "",       # remove entirely
    "AI": "",         # remove entirely (if in self-description)
}


# ══════════════════════════════════════════════════════════════════════
# State Manager
# ══════════════════════════════════════════════════════════════════════

class StateManager:
    """Persist directive processing state to directive_fix_state.json."""

    def __init__(self):
        self.data = self._load()

    def _load(self) -> dict:
        if STATE_FILE.exists():
            try:
                return json.loads(STATE_FILE.read_text(encoding="utf-8"))
            except Exception:
                pass
        return {
            "version": 2,
            "applied": {},
            "rejections": [],
            "conflicts_resolved": [],
            "last_run": None,
        }

    def save(self):
        self.data["last_run"] = datetime.now(CST).isoformat()
        tmp = STATE_FILE.with_suffix(".tmp")
        buf = json.dumps(self.data, ensure_ascii=False, indent=2)
        tmp.write_text(buf, encoding="utf-8")
        tmp.replace(STATE_FILE)  # atomic rename on same fs

    def record_applied(self, directive_type: str, target: str, files_modified: list[str],
                       detail: str = "", raw: str = "", count: int = 0):
        key = directive_type
        if key not in self.data["applied"]:
            self.data["applied"][key] = {"active": target, "history": []}
        else:
            # If there was a previous active, mark as overridden (latest wins)
            prev = self.data["applied"][key].get("active")
            if prev and prev != target:
                for h in self.data["applied"][key]["history"]:
                    if h.get("value") == prev and h.get("status") == "active":
                        h["status"] = "overridden"
                self.data["conflicts_resolved"].append({
                    "older": prev,
                    "newer": target,
                    "resolution": "newer_wins",
                    "timestamp": datetime.now(CST).isoformat(),
                })
            self.data["applied"][key]["active"] = target

        self.data["applied"][key]["history"].append({
            "value": target,
            "status": "active",
            "files_modified": files_modified,
            "detail": detail,
            "raw": raw,
            "count": count,
            "timestamp": datetime.now(CST).isoformat(),
        })
        # Keep last 20 history entries
        self.data["applied"][key]["history"] = \
            self.data["applied"][key]["history"][-20:]

    def record_rejection(self, directive_raw: str, reason: str, detail: str):
        self.data["rejections"].append({
            "directive": directive_raw,
            "reason": reason,
            "detail": detail,
            "timestamp": datetime.now(CST).isoformat(),
        })
        self.data["rejections"] = self.data["rejections"][-50:]

    def get_active(self, directive_type: str) -> Optional[str]:
        return self.data["applied"].get(directive_type, {}).get("active")


# ══════════════════════════════════════════════════════════════════════
# Persona Guard
# ══════════════════════════════════════════════════════════════════════

def check_persona_boundary(classification: dict) -> dict:
    """
    Check if a directive would break persona.
    Returns {ok: bool, reason: str, persona_message: str}
    """
    d_type = classification["type"]
    target = classification.get("target", "")

    # REQUEST_nickname: check forbidden nicknames
    if d_type == "REQUEST_nickname" and target:
        if target in PERSONA["forbidden_nicknames"]:
            detail = PERSONA["forbidden_nicknames"][target]
            phrase = _pick_rejection_phrase()
            return {
                "ok": False,
                "reason": "persona_boundary",
                "detail": f"{detail}（称呼: {target}）",
                "persona_message": f"{phrase} {detail}哦。",
            }

    # Check forbidden behaviors
    if target:
        for forbid_word, reason in PERSONA["forbidden_behaviors"].items():
            if forbid_word in target:
                phrase = _pick_rejection_phrase()
                return {
                    "ok": False,
                    "reason": "persona_boundary",
                    "detail": f"{reason}（关键词: {forbid_word}）",
                    "persona_message": f"{phrase} {reason}。",
                }

    return {"ok": True, "reason": None, "detail": None, "persona_message": None}


def _pick_rejection_phrase() -> str:
    return random.choice(PERSONA["rejection_phrases"])


# ══════════════════════════════════════════════════════════════════════
# Prohibition Scanner (grep source for hardcoded conflicts)
# ══════════════════════════════════════════════════════════════════════

SKIP_KEYWORDS = [
    "边界", "检测", "detect", "check_", "validator", "forbid", "禁",
    "avoid", "block", "reject", "warning", "fix_", "sanitize",
    "replace", "repair", "style_negative", "SIGNAL", "hints",
    "learning_note", "信号",
]
SKIP_NEG_PHRASES = ["别像", "别太", "别说教", "别讲道理", "别问", "别"]
SKIP_BLOCK_CONTEXT = ["FORBIDDEN", "FORBID", "BLOCKED", "BAD_MARKER", "NEGATIVE"]
TEMPLATE_KEYWORDS_BYTES = [b"replies", b"return", b"candidates", b"DOMAIN",
                            b"phrases", b"phrase_", b"nickname", b"STAGE_NAMES",
                            b"LEVEL"]
TEMPLATE_KEYWORDS_STR = ["称呼"]


def scan_prohibited_in_source(prohibited_targets: dict[str, int]) -> list[dict]:
    """Scan .py files for hardcoded prohibited substrings. Returns findings."""
    findings = []
    replacements = {
        k: v for k, v in PROHIBIT_REPLACEMENTS.items()
        if k in prohibited_targets
    }

    for fname in sorted(SOURCE_DIR.glob("*.py")):
        if fname.name.startswith(("test_", "zhiyue_directive_self_fix")):
            continue

        try:
            original = fname.read_bytes()
            lines = original.split(b"\n")
        except Exception:
            continue

        for i, line_bytes in enumerate(lines):
            line_str = line_bytes.decode("utf-8", errors="replace").strip()
            if not line_str or line_str.startswith("#"):
                continue

            # Cross-line FORBIDDEN context check
            ctx_start = max(0, i - 10)
            ctx = b"".join(lines[ctx_start:i + 1]).decode("utf-8", errors="replace")
            if any(kw in ctx.upper() for kw in SKIP_BLOCK_CONTEXT):
                continue

            # Single-quoted keyword list entry
            if re.match(r'^"[^"]{1,20}",$', line_str):
                continue

            # Detection/pattern context
            if any(kw in line_str.lower() for kw in SKIP_KEYWORDS):
                continue

            # Negated phrases (meta-instructions)
            if any(ph in line_str for ph in SKIP_NEG_PHRASES):
                continue

            # Tuple replacement rules
            if '", "' in line_str and line_str.strip().startswith(("(", '"')):
                continue

            # Negation prefix before match
            if any(f"{neg}{pat}" in line_str
                   for neg in ["别", "不要", "不准", "不可以", "少", "不"]
                   for pat in replacements if pat in line_str):
                continue

            # Template/reply generation context check
            is_template = False
            for kw in TEMPLATE_KEYWORDS_BYTES:
                if kw in line_bytes:
                    is_template = True
                    break
            if not is_template:
                for kw in TEMPLATE_KEYWORDS_STR:
                    if kw in line_str:
                        is_template = True
                        break

            if not is_template:
                if not (line_bytes.count(b'"') >= 2 or line_bytes.count(b"'") >= 2):
                    continue

            # Check each prohibited pattern
            for pattern, replacement in replacements.items():
                if pattern.encode("utf-8") not in line_bytes:
                    continue
                # ── Word boundary check for single-char patterns (avoid substring false positives) ──
                if len(pattern) == 1:
                    idx = line_str.find(pattern)
                    if idx > 0 and '\u4e00' <= line_str[idx - 1] <= '\u9fff':
                        continue  # e.g., "说话" matching "说" → skip
                findings.append({
                    "file": fname.name,
                    "line_number": i + 1,
                    "match": pattern,
                    "replacement": replacement,
                    "original_line": line_str[:200],
                    "context": "template" if is_template else "literal",
                })
                break

    return findings[:MAX_REPLACEMENTS_PER_RUN]


# ══════════════════════════════════════════════════════════════════════
# Source Modifier
# ══════════════════════════════════════════════════════════════════════

def apply_source_replacements(findings: list[dict], dry_run: bool = False) -> dict:
    """Apply find-and-replace to source files by line number (precise targeting)."""
    changes = []
    changed_files = {}

    for finding in findings:
        fname = finding["file"]
        filepath = BASE_DIR / fname
        if not filepath.exists():
            continue

        try:
            content = filepath.read_text(encoding="utf-8")
        except Exception:
            continue

        lines = content.split("\n")
        line_idx = finding["line_number"] - 1
        if line_idx >= len(lines):
            continue

        line_text = lines[line_idx]
        match = finding["match"]
        replacement = finding["replacement"]

        # Verify the match still exists on this line (may have changed)
        if match not in line_text:
            continue

        new_line_text = line_text.replace(match, replacement, 1)
        if new_line_text == line_text:
            continue

        lines[line_idx] = new_line_text
        new_content = "\n".join(lines)

        if not dry_run:
            try:
                ast.parse(new_content)
                filepath.write_text(new_content, encoding="utf-8")
            except (SyntaxError, Exception) as e:
                print(f"  SKIP {fname}:{finding['line_number']} - {e}")
                continue

        changes.append({
            "file": fname,
            "line": finding["line_number"],
            "match": match,
            "replacement": replacement,
        })
        changed_files.setdefault(fname, []).append(f"line {finding['line_number']}")

    return {
        "total": len(findings),
        "applied": len(changes),
        "dry_run": dry_run,
        "files_changed": list(changed_files.keys()),
        "changes": changes,
    }


def apply_skill_append(skill_relpath: str, section: str, content: str,
                       dry_run: bool = False) -> bool:
    """
    Append a line to a specific section in a SKILL.md file.
    Section is marked by <!-- SECTION: name --> comments.
    """
    skill_path = BASE_DIR / skill_relpath
    if not skill_path.exists():
        return False

    try:
        text = skill_path.read_text(encoding="utf-8")
    except Exception:
        return False

    marker = f"<!-- SECTION: {section} -->"
    new_line = f"\n- {content}"

    # Only append if not already present
    if content in text:
        return False

    if marker in text:
        # Insert after the section marker line
        lines = text.split("\n")
        for i, line in enumerate(lines):
            if marker in line:
                lines.insert(i + 1, new_line)
                break
        new_text = "\n".join(lines)
    else:
        # Append at end
        new_text = text.rstrip() + f"\n{marker}\n{new_line}\n"

    if not dry_run:
        skill_path.write_text(new_text, encoding="utf-8")
    return True


def apply_intimacy_nickname_override(nickname: str, dry_run: bool = False) -> dict:
    """
    Modify zhiyue_intimacy.py to support preferred_nickname override.
    This is a surgical code modification:
      1. Add "preferred_nickname": None to defaults
      2. Modify get_nickname() to check preferred_nickname first
      3. Add set_preferred_nickname() method
    """
    intimacy_path = BASE_DIR / "zhiyue_intimacy.py"
    if not intimacy_path.exists():
        return {"ok": False, "reason": "zhiyue_intimacy.py not found"}

    try:
        text = intimacy_path.read_text(encoding="utf-8")
    except Exception as e:
        return {"ok": False, "reason": str(e)}

    modified = False
    changes = []

    # 1. Add preferred_nickname to defaults
    # Find the line after "last_memory_compact_date" in defaults
    if '"preferred_nickname"' not in text:
        old_default = '"last_memory_compact_date": None,'
        new_default = '"last_memory_compact_date": None,\n            "preferred_nickname": None,'
        if old_default in text:
            text = text.replace(old_default, new_default, 1)
            changes.append("added preferred_nickname to defaults")
            modified = True

    # 2. Modify get_nickname() to check preferred_nickname first
    old_get_nickname = '''    def get_nickname(self):
        lv = self.data["level"]
        if lv <= 2: return "你"
        elif lv <= 4: return "你"
        elif lv <= 6: return None
        elif lv <= 8: return "宝宝"
        else: return "亲爱的"'''

    new_get_nickname = f'''    def get_nickname(self):
        # User-specified nickname override (set by directive system)
        preferred = self.data.get("preferred_nickname")
        if preferred is not None:
            return preferred
        lv = self.data["level"]
        if lv <= 2: return "你"
        elif lv <= 4: return "你"
        elif lv <= 6: return None
        elif lv <= 8: return "宝宝"
        else: return "亲爱的"'''

    if old_get_nickname in text:
        text = text.replace(old_get_nickname, new_get_nickname, 1)
        changes.append("modified get_nickname() to check preferred_nickname")
        modified = True

    # 3. Add set_preferred_nickname() method
    if "def set_preferred_nickname" not in text:
        # Insert after get_nickname(), before get_tone()
        insertion_point = '    def get_tone(self):'
        new_method = f'''    def set_preferred_nickname(self, name):
        """Set or clear user-specified nickname override. None clears it."""
        self.data["preferred_nickname"] = name
        self.save()

    def get_tone(self):'''
        if insertion_point in text:
            text = text.replace(insertion_point, new_method, 1)
            changes.append("added set_preferred_nickname()")
            modified = True

    if not modified:
        return {"ok": True, "action": "no_change", "reason": "already patched"}

    # AST check
    try:
        ast.parse(text)
    except SyntaxError as e:
        return {"ok": False, "reason": f"syntax error: {e}"}

    if not dry_run:
        intimacy_path.write_text(text, encoding="utf-8")
        # ── Write the nickname value to the intimacy data file ──
        try:
            data_path = BASE_DIR / "data" / "zhiyue_intimacy.json"
            if data_path.exists():
                data = json.loads(data_path.read_text(encoding="utf-8"))
                data["preferred_nickname"] = nickname
                tmp = data_path.with_suffix(".tmp")
                tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
                tmp.replace(data_path)
                changes.append(f"set preferred_nickname={nickname} in data")
        except Exception as e:
            changes.append(f"code patched but data write failed: {e}")

    return {
        "ok": True,
        "action": "modified" if not dry_run else "dry_run",
        "changes": changes,
    }


def apply_intimacy_tone_adjustment(tone_target: str, dry_run: bool = False) -> dict:
    """
    Adjust personality parameters based on tone request.
    "温柔一点" → increase personality_gentle
    "活泼一点" → increase personality_clingy, decrease rational
    """
    intimacy_path = BASE_DIR / "zhiyue_intimacy.py"
    if not intimacy_path.exists():
        return {"ok": False, "reason": "not found"}

    try:
        text = intimacy_path.read_text(encoding="utf-8")
    except Exception as e:
        return {"ok": False, "reason": str(e)}

    tone_map = {
        "温柔": ("personality_gentle", +15, 85),
        "活泼": ("personality_clingy", +10, 70),
        "热情": ("personality_clingy", +15, 75),
        "软": ("personality_gentle", +10, 80),
        "甜": ("personality_clingy", +10, 70),
        "撒娇": ("personality_clingy", +20, 80),
        "冷淡": ("personality_rational", +10, 80),
        "高冷": ("personality_rational", +15, 80),
        "凶": ("personality_gentle", -15, 20),
    }

    if tone_target not in tone_map:
        return {"ok": True, "action": "skip", "reason": f"no tone mapping for {tone_target}"}

    param, delta, cap = tone_map[tone_target]
    # Find the parameter line in defaults
    pattern = re.compile(rf'("{param}":\s*)(\d+)')
    m = pattern.search(text)
    if not m:
        return {"ok": False, "reason": f"parameter {param} not found"}

    current = int(m.group(2))
    new_val = min(current + delta, cap)
    if new_val == current:
        return {"ok": True, "action": "skip", "reason": f"{param} already {current} (cap {cap})"}

    new_text = pattern.sub(rf'\g<1>{new_val}', text, count=1)
    try:
        ast.parse(new_text)
    except SyntaxError as e:
        return {"ok": False, "reason": f"syntax error: {e}"}

    if not dry_run:
        intimacy_path.write_text(new_text, encoding="utf-8")

    return {
        "ok": True,
        "action": "modified" if not dry_run else "dry_run",
        "param": param,
        "old": current,
        "new": new_val,
    }


# ══════════════════════════════════════════════════════════════════════
# Action Planner & Executor
# ══════════════════════════════════════════════════════════════════════

def plan_and_execute(classification: dict, state: StateManager,
                     dry_run: bool = False, raw: str = "", count: int = 0) -> dict:
    """Plan and execute modifications for a single directive."""
    d_type = classification["type"]
    target = classification.get("target", "")
    raw = classification.get("raw", "")

    result = {
        "directive_type": d_type,
        "target": target,
        "ok": True,
        "action": "skip",
        "files_modified": [],
        "detail": "",
    }

    # ── REQUEST_nickname ──
    if d_type == "REQUEST_nickname":
        persona = check_persona_boundary(classification)
        if not persona["ok"]:
            state.record_rejection(raw, persona["reason"], persona["detail"])
            return {
                **result,
                "ok": False,
                "action": "rejected",
                "reason": persona["reason"],
                "detail": persona["detail"],
                "persona_message": persona["persona_message"],
            }

        intimacy_result = apply_intimacy_nickname_override(target, dry_run=dry_run)
        if not intimacy_result.get("ok"):
            return {**result, "ok": False, "action": "failed",
                    "detail": intimacy_result.get("reason", "unknown")}

        files_mod = []
        if intimacy_result.get("action") in ("modified", "dry_run"):
            files_mod.append("zhiyue_intimacy.py")

        # Update skill file
        skill_ok = apply_skill_append(
            "skills/reply_style_guard/SKILL.md",
            "nickname",
            f"用户要求称呼为「{target}」，优先使用此称呼",
            dry_run=dry_run,
        )
        if skill_ok:
            files_mod.append("skills/reply_style_guard/SKILL.md")

        state.record_applied(d_type, target, files_mod,
                             f"preferred_nickname={target}",
                             raw=raw, count=count)
        return {
            **result,
            "action": "modified" if not dry_run else "dry_run",
            "files_modified": files_mod,
            "detail": f"设置 preferred_nickname={target}",
            "intimacy_changes": intimacy_result.get("changes", []),
        }

    # ── REQUEST_tone ──
    if d_type == "REQUEST_tone":
        persona = check_persona_boundary(classification)
        if not persona["ok"]:
            state.record_rejection(raw, persona["reason"], persona["detail"])
            return {
                **result,
                "ok": False,
                "action": "rejected",
                "reason": persona["reason"],
                "detail": persona["detail"],
                "persona_message": persona["persona_message"],
            }

        tone_result = apply_intimacy_tone_adjustment(target, dry_run=dry_run)
        files_mod = []
        if tone_result.get("action") in ("modified", "dry_run"):
            files_mod.append("zhiyue_intimacy.py")
            state.record_applied(d_type, target, files_mod,
                                 f"{tone_result.get('param')}: {tone_result.get('old')}→{tone_result.get('new')}",
                                 raw=raw, count=count)
        return {
            **result,
            "action": tone_result.get("action", "skip"),
            "files_modified": files_mod,
            "detail": tone_result.get("reason", str(tone_result)),
        }

    # ── PROHIBIT ──
    if d_type == "PROHIBIT":
        prohibited = {target: 99}  # force high count
        findings = scan_prohibited_in_source(prohibited)
        if not findings:
            return {**result, "action": "skip",
                    "detail": f"no source occurrences of '{target}' found"}

        replace_result = apply_source_replacements(findings, dry_run=dry_run)
        files_mod = replace_result.get("files_changed", [])

        # Update skill file
        skill_ok = apply_skill_append(
            "skills/reply_style_guard/SKILL.md",
            "prohibited",
            f"用户禁止使用「{target}」，已从源码中移除",
            dry_run=dry_run,
        )
        if skill_ok:
            files_mod.append("skills/reply_style_guard/SKILL.md")

        state.record_applied(d_type, target, files_mod,
                             f"removed {replace_result['applied']} occurrences",
                             raw=raw, count=count)
        return {
            **result,
            "action": "modified" if not dry_run else "dry_run",
            "files_modified": files_mod,
            "detail": f"removed {replace_result['applied']} occurrences of '{target}'",
            "replacements": replace_result,
        }

    # ── REQUEST_style / REQUEST_generic ──
    skill_ok = apply_skill_append(
        "skills/reply_style_guard/SKILL.md",
        "style",
        f"用户要求：{target}",
        dry_run=dry_run,
    )
    files_mod = ["skills/reply_style_guard/SKILL.md"] if skill_ok else []

    if files_mod:
        state.record_applied(d_type, target, files_mod, f"skill update: {target}",
                             raw=raw, count=count)

    return {
        **result,
        "action": "modified" if (not dry_run and files_mod) else ("dry_run" if files_mod else "skip"),
        "files_modified": files_mod,
        "detail": f"updated skill with: {target}",
    }


# ══════════════════════════════════════════════════════════════════════
# Main Pipeline
# ══════════════════════════════════════════════════════════════════════

def load_directives() -> list[dict]:
    """Load active user directives from JSON."""
    if not USER_DIRECTIVES_FILE.exists():
        return []
    try:
        data = json.loads(USER_DIRECTIVES_FILE.read_text(encoding="utf-8"))
    except Exception:
        return []
    if isinstance(data, list):
        return data
    return []


def run_directive_engine(dry_run: bool = False) -> dict:
    """
    Full directive processing pipeline.
    Called by self-monitor every N cycles.
    """
    print("[directive_engine] Starting directive processing...")
    state = StateManager()
    directives = load_directives()

    if not directives:
        print("[directive_engine] No directives found, skipping")
        state.save()
        return {"ok": True, "action": "skip", "reason": "no directives"}

    results = []
    total_modified = 0
    total_rejected = 0

    for d in directives:
        raw = d.get("raw", "")
        action = d.get("action", "")
        count = int(d.get("count", 1))

        if count < AUTO_FIX_THRESHOLD:
            continue

        # Skip if this exact directive was already processed at same or higher count
        already_processed = False
        for h in state.data.get("applied", {}).values():
            for entry in h.get("history", []):
                if entry.get("raw") == raw:
                    if entry.get("count", 0) >= count:
                        already_processed = True
                        break

        if already_processed:
            continue

        classification = classify_directive(raw, action)
        classification["raw"] = raw
        print(f"[directive_engine] Processing: type={classification['type']} "
              f"target={classification['target']} raw='{raw[:40]}'")

        exec_result = plan_and_execute(classification, state, dry_run=dry_run,
                                       raw=raw, count=count)
        results.append(exec_result)

        if exec_result.get("action") == "rejected":
            total_rejected += 1
        elif exec_result.get("action") in ("modified", "dry_run"):
            total_modified += 1

    state.save()

    summary = {
        "ok": True,
        "directives_processed": len(results),
        "modified": total_modified,
        "rejected": total_rejected,
        "skipped": len(results) - total_modified - total_rejected,
        "dry_run": dry_run,
        "results": results,
    }

    print(f"[directive_engine] Done: {total_modified} modified, "
          f"{total_rejected} rejected, {summary['skipped']} skipped "
          f"(dry_run={dry_run})")
    return summary


# ── Legacy alias for self-monitor compatibility ──
def run_directive_conflict_resolution(dry_run: bool = False) -> dict:
    """Legacy entry point, delegates to full engine."""
    return run_directive_engine(dry_run=dry_run)


# ══════════════════════════════════════════════════════════════════════
# CLI
# ══════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import sys
    dry = "--dry" in sys.argv
    result = run_directive_engine(dry_run=dry)
    print(json.dumps(result, ensure_ascii=False, indent=2))