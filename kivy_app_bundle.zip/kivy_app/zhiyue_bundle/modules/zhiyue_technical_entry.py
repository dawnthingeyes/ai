# -*- coding: utf-8 -*-
from __future__ import annotations

import zhiyue_companion_closer as companion_closer
from zhiyue_reply_payloads import build_forced_technical_review_payload
from zhiyue_technical_review import local_code_review_reply


def handle_forced_technical_review(
    *,
    user_msg,
    source_dir,
    clean_reply_for_mode,
    build_display_messages,
    recent_history,
    technical_history,
    level,
    stage,
):
    try:
        from zhiyue_code_fix import scan_and_accumulate_issues

        scan_and_accumulate_issues(source_dir)
    except Exception:
        pass

    raw_reply = clean_reply_for_mode(
        local_code_review_reply(user_msg, source_dir=source_dir, recent_history=recent_history[-12:]),
        technical=True,
    )
    raw_reply = companion_closer.close_technical_reply(user_msg, raw_reply)

    try:
        from zhiyue_code_fix import get_pending_summary, format_pending_for_user

        summary = get_pending_summary()
        if summary["should_notify"]:
            raw_reply += "\n\n" + format_pending_for_user()
    except Exception:
        pass

    technical_history.append({"role": "user", "content": user_msg})
    technical_history.append({"role": "assistant", "content": raw_reply})
    if len(technical_history) > 50:
        del technical_history[:-50]
    return build_forced_technical_review_payload(
        user_msg=user_msg,
        reply=raw_reply,
        messages=build_display_messages(user_msg, raw_reply),
        level=level,
        stage=stage,
    )
