# -*- coding: utf-8 -*-
from __future__ import annotations


def auto_generate_code_proposal(*, user_msg, ai_reply, score, reasons, layers, log_runtime_exception, logger):
    if score >= 5:
        return None
    if not layers or not hasattr(layers, "self_improvement"):
        return None

    reasons_list = [str(item).strip() for item in (reasons or []) if str(item).strip()]
    reasons_str = " ".join(reasons_list).lower()
    problem_type = None
    fix_template = None
    structural_markers = {
        "aggressive_rule": ["rule", "deterministic", "规则", "误拦截"],
        "off_topic": ["off_topic", "topic", "跑题", "不相关"],
        "memory_boundary": ["memory_probe_no_recall", "memory", "记忆", "recall"],
        "system_leak": ["system_leak", "template_or_system_leak", "身份暴露", "系统味", "ooc_or_system_leak"],
        "mojibake": ["garbled", "mojibake", "乱码"],
    }
    if any(marker in reasons_str for marker in structural_markers["aggressive_rule"]):
        problem_type = "aggressive_rule"
        fix_template = {"title": "Relax deterministic rule conditions", "rationale": "Rules incorrectly intercept normal conversations"}
    elif any(marker in reasons_str for marker in structural_markers["off_topic"]):
        problem_type = "off_topic"
        fix_template = {"title": "Improve context relevance detection", "rationale": "Replies lack relevance to user messages"}
    elif any(marker in reasons_str for marker in structural_markers["memory_boundary"]):
        problem_type = "memory_boundary"
        fix_template = {"title": "Harden memory recall and boundary handling", "rationale": "Memory recall or memory isolation is not stable enough"}
    elif any(marker in reasons_str for marker in structural_markers["system_leak"]):
        problem_type = "system_leak"
        fix_template = {"title": "Tighten system leak guard", "rationale": "Runtime guard failed to block system-flavored output"}
    elif any(marker in reasons_str for marker in structural_markers["mojibake"]):
        problem_type = "mojibake"
        fix_template = {"title": "Tighten mojibake guard and encoding fallback", "rationale": "Runtime allowed garbled text into the reply path"}
    if not problem_type:
        return None
    try:
        candidate = layers.self_improvement.record_candidate(
            source="autonomous_detect",
            category=f"auto_fix.{problem_type}",
            title=fix_template["title"],
            recommendation=fix_template["rationale"],
            evidence=[{"user_msg": user_msg[:100], "ai_reply": ai_reply[:100], "score": score, "reasons": reasons[:3] if reasons else []}],
            impact="Auto-detected recurring issue pattern",
            risk="medium",
            meta={"auto_generated": True, "problem_type": problem_type},
        )
        proposal = layers.self_improvement.create_code_proposal(
            source_type="candidate",
            source_id=candidate.get("id", ""),
            status="draft",
            meta={"auto_generated": True, "problem_type": problem_type},
        )
        logger.info("[AUTO] Code proposal created: %s", proposal.get("id"))
        return proposal
    except Exception as err:
        log_runtime_exception("auto_code_proposal", err)
        return None


def auto_generate_skill_update(*, user_msg, ai_reply, score, reasons, layers, log_runtime_exception):
    if score is None or score >= 5:
        return None
    if not layers or not hasattr(layers, "skill_learning"):
        return None
    reasons_list = [str(item).strip() for item in (reasons or []) if str(item).strip()]
    reasons_str = " ".join(reasons_list).lower()
    source_key = ""
    title = ""
    summary = ""
    content = ""
    if any(key in reasons_str for key in ["weak_empathy", "missing_anchor", "低落", "共情", "安抚"]):
        source_key = "comforting"
        title = "Companion runtime fix: comforting"
        summary = "Low-state turns need stronger emotional acknowledgment before anything else."
        content = "Runtime-grounded update:\n1. In low-state turns, name the feeling or directly hold the user first.\n2. Keep replies short and warm.\n3. Do not jump to advice or analysis too early.\n"
    elif any(key in reasons_str for key in ["too_long", "too_structured", "template", "mechanical", "list_tone", "style"]):
        source_key = "reply_style_guard"
        title = "Companion runtime fix: reply style guard"
        summary = "Replies drifted into long, structured, or templated style."
        content = "Runtime-grounded update:\n1. Prefer 1 to 3 natural spoken sentences.\n2. Remove system-announcement tone and list rhythm.\n3. Preserve warmth before completeness.\n"
    elif any(key in reasons_str for key in ["fallback_reply", "generic_reply", "关系修复", "怪", "不自然"]):
        source_key = "relationship_repair"
        title = "Companion runtime fix: relationship repair"
        summary = "When the user signals mismatch, repair tone first and then re-answer."
        content = "Runtime-grounded update:\n1. Acknowledge the mismatch briefly.\n2. Re-answer more naturally instead of defending the previous turn.\n3. Keep the repair soft and concise.\n"
    elif any(key in reasons_str for key in ["memory", "missing_anchor", "memory_probe_no_recall"]):
        source_key = "memory_recall_style"
        title = "Companion runtime fix: memory recall style"
        summary = "Memory-probe turns need more anchored recall phrasing."
        content = "Runtime-grounded update:\n1. If there is a recall cue, answer with anchored recall first.\n2. If uncertain, stay gentle and specific instead of flat fallback.\n3. Do not sound like a database check.\n"
    elif any(key in (user_msg or "") for key in ["睡不着", "失眠", "晚安", "半夜", "先睡了"]):
        source_key = "late_night_companion"
        title = "Companion runtime fix: late night companion"
        summary = "Late-night turns need softer and lower-load responses."
        content = "Runtime-grounded update:\n1. Lower intensity at night.\n2. Avoid adding mental load.\n3. Keep the user company with short, soft phrasing.\n"
    if not source_key:
        return None
    try:
        draft = layers.skill_learning.upsert_draft(
            {
                "source": "runtime_autonomous_learning",
                "source_key": source_key,
                "title": title,
                "slug": source_key,
                "summary": summary,
                "content": content,
                "evidence_count": 1,
                "evidence_json": [{"user_msg": (user_msg or "")[:120], "ai_reply": (ai_reply or "")[:160], "score": score, "reasons": reasons_list[:6]}],
                "status": "draft",
                "meta": {"auto_generated": True, "preferred_path": "skill_update", "from_runtime": True},
            }
        )
        if hasattr(layers, "observability"):
            layers.observability.record_learning_event(
                stage="draft_generator",
                source="runtime_autonomous_learning",
                skill_name=f"skill.{source_key}",
                user_msg=user_msg,
                effect="draft_created",
                judge_score=float(score or 0),
                meta={"reasons": reasons_list[:6], "draft_id": draft.get("id", "")},
            )
        return draft
    except Exception as err:
        log_runtime_exception("auto_skill_update", err)
        return None


def maybe_promote_directives_to_skills(*, layers, load_user_directives):
    if not layers or not hasattr(layers, "skill_learning"):
        return {"ok": False, "error": "skill learning unavailable"}
    directives = load_user_directives()
    created = []
    for item in directives:
        action = str(item.get("action") or "").strip()
        if not action:
            continue
        raw = str(item.get("raw") or "").strip()
        scan_text = f"{action} {raw}"
        source_key = ""
        title = ""
        summary = ""
        content = ""
        if any(term in scan_text for term in ["晚安", "早安", "睡觉", "睡了", "睡吧"]):
            source_key = "late_night_companion"
            title = "User directive preference: late night companion"
            summary = "User explicitly constrained nighttime phrasing."
            content = "User directive grounded update:\n1. Do not overuse bedtime catchphrases.\n2. Only use them when context clearly calls for it.\n3. Prefer natural low-pressure company.\n"
        elif any(term in scan_text for term in ["系统", "客服", "公告", "模板", "机械", "说教", "大道理"]):
            source_key = "reply_style_guard"
            title = "User directive preference: reply style guard"
            summary = "User explicitly constrained system-like or preachy wording."
            content = "User directive grounded update:\n1. Avoid system-announcement tone.\n2. Avoid preachy or lecture-like rhythm.\n3. Keep wording natural and chat-like.\n"
        elif any(term in scan_text for term in ["追问", "为什么", "一直问", "别问"]):
            source_key = "relationship_repair"
            title = "User directive preference: relationship repair"
            summary = "User explicitly constrained probing or pressuring follow-ups."
            content = "User directive grounded update:\n1. Reduce probing follow-up questions.\n2. Repair tone before asking for more detail.\n3. Let the user open up at their own pace.\n"
        elif any(term in scan_text for term in ["太长", "啰嗦", "短一点", "短点"]):
            source_key = "reply_style_guard"
            title = "User directive preference: shorter replies"
            summary = "User explicitly asked for shorter replies."
            content = "User directive grounded update:\n1. Prefer 1 to 2 short spoken sentences.\n2. Do not expand unless the user asks.\n3. Preserve warmth under length constraints.\n"
        if not source_key:
            continue
        draft = layers.skill_learning.upsert_draft(
            {
                "source": "explicit_user_directive",
                "source_key": source_key,
                "title": title,
                "slug": source_key,
                "summary": summary,
                "content": content,
                "evidence_count": int(item.get("count") or 1),
                "evidence_json": [{"directive": action, "raw": raw, "count": int(item.get("count") or 1)}],
                "status": "draft",
                "meta": {"preferred_path": "explicit_preference", "directive_action": action, "directive_raw": raw, "directive_count": int(item.get("count") or 1)},
            }
        )
        created.append(draft)
    applied = layers.skill_learning.auto_apply_runtime_drafts(skills_layer=layers.skills, limit=10)
    return {"ok": True, "created": created, "applied": applied}


def process_low_score_learning(*, user_msg, ai_reply, score, reasons, layers, log_runtime_exception, logger):
    if score is None or score >= 5 or not reasons:
        return {"ok": True, "draft": None, "proposal": None}
    draft = auto_generate_skill_update(
        user_msg=user_msg,
        ai_reply=ai_reply,
        score=score,
        reasons=reasons,
        layers=layers,
        log_runtime_exception=log_runtime_exception,
    )
    if draft is not None and layers and hasattr(layers, "skill_learning"):
        layers.skill_learning.auto_apply_runtime_drafts(skills_layer=layers.skills, limit=10)
        return {"ok": True, "draft": draft, "proposal": None}
    proposal = auto_generate_code_proposal(
        user_msg=user_msg,
        ai_reply=ai_reply,
        score=score,
        reasons=reasons,
        layers=layers,
        log_runtime_exception=log_runtime_exception,
        logger=logger,
    )
    return {"ok": True, "draft": None, "proposal": proposal}
