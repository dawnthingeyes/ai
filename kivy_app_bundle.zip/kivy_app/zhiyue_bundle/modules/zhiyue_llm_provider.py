from __future__ import annotations

import copy
import json
import os
from dataclasses import dataclass
from typing import Any

import requests

from zhiyue_model_registry import model_name_for_request
from zhiyue_project_paths import LLM_PROVIDER_CONFIG_FILE


ROLE_NAMES = ("main", "state", "review")
OPENAI_PROTOCOLS = {
    "openai",
    "openai_compatible",
    "openrouter",
    "dashscope",
    "relay",
    "gemini_openai",
}


_UPSTREAM_MODELS_CACHE: dict[str, tuple[float, list[str]]] = {}
_UPSTREAM_MODELS_TTL_SECONDS = 30.0


@dataclass
class ProviderResponse:
    status_code: int
    payload: dict[str, Any]
    text: str = ""
    headers: dict[str, str] | None = None

    def json(self) -> dict[str, Any]:
        return self.payload

    def raise_for_status(self) -> None:
        if self.status_code >= 400:
            raise requests.HTTPError(self.text or f"HTTP {self.status_code}")


def _safe_json_loads(raw: str, default: Any) -> Any:
    try:
        return json.loads(raw)
    except Exception:
        return default


def _normalize_headers(value: Any) -> dict[str, str]:
    if isinstance(value, dict):
        return {str(k).strip(): str(v) for k, v in value.items() if str(k).strip()}
    if isinstance(value, str) and value.strip():
        parsed = _safe_json_loads(value, {})
        if isinstance(parsed, dict):
            return {str(k).strip(): str(v) for k, v in parsed.items() if str(k).strip()}
    return {}


def _clean_text(value: Any) -> str:
    return str(value or "").strip()


def _default_role_config(role: str) -> dict[str, Any]:
    role_key = role.lower().strip() or "main"
    model_env = f"ZHIYUE_{role_key.upper()}_MODEL"
    url_env = f"ZHIYUE_{role_key.upper()}_LM_URL"
    return {
        "enabled": False,
        "protocol": "",
        "base_url": "",
        "api_url": _clean_text(os.environ.get(url_env, "")),
        "api_key": "",
        "model": _clean_text(os.environ.get(model_env, "")),
        "headers": {},
    }


def _default_config() -> dict[str, Any]:
    base_url = _clean_text(os.environ.get("ZHIYUE_API_BASE_URL", ""))
    protocol = _clean_text(os.environ.get("ZHIYUE_API_PROTOCOL", "openai_compatible")) or "openai_compatible"
    api_key = _clean_text(os.environ.get("ZHIYUE_API_KEY", ""))
    enabled = _clean_text(os.environ.get("ZHIYUE_API_ENABLED", "0")).lower() in {"1", "true", "yes", "on"}
    headers = _normalize_headers(os.environ.get("ZHIYUE_API_HEADERS", ""))
    roles = {role: _default_role_config(role) for role in ROLE_NAMES}
    return {
        "enabled": enabled,
        "protocol": protocol,
        "base_url": base_url,
        "api_key": api_key,
        "headers": headers,
        "roles": roles,
        "mobile_sync": {
            "enabled": False,
            "remote_base_url": "",
            "access_token": "",
        },
    }


def load_provider_config() -> dict[str, Any]:
    config = _default_config()
    if LLM_PROVIDER_CONFIG_FILE.exists():
        loaded = _safe_json_loads(LLM_PROVIDER_CONFIG_FILE.read_text(encoding="utf-8"), {})
        if isinstance(loaded, dict):
            config.update({k: v for k, v in loaded.items() if k != "roles"})
            loaded_roles = loaded.get("roles") if isinstance(loaded.get("roles"), dict) else {}
            for role in ROLE_NAMES:
                role_config = copy.deepcopy(config["roles"][role])
                current = loaded_roles.get(role) if isinstance(loaded_roles, dict) else {}
                if isinstance(current, dict):
                    role_config.update(current)
                config["roles"][role] = role_config

    config["protocol"] = _clean_text(config.get("protocol")) or "openai_compatible"
    config["base_url"] = _clean_text(config.get("base_url"))
    config["api_key"] = _clean_text(config.get("api_key"))
    config["headers"] = _normalize_headers(config.get("headers"))
    config["enabled"] = bool(config.get("enabled"))
    mobile_sync = config.get("mobile_sync") if isinstance(config.get("mobile_sync"), dict) else {}
    config["mobile_sync"] = {
        "enabled": bool(mobile_sync.get("enabled")),
        "remote_base_url": _clean_text(mobile_sync.get("remote_base_url")),
        "access_token": _clean_text(mobile_sync.get("access_token")),
    }
    roles = config.get("roles") if isinstance(config.get("roles"), dict) else {}
    normalized_roles: dict[str, dict[str, Any]] = {}
    for role in ROLE_NAMES:
        role_config = copy.deepcopy(_default_role_config(role))
        current = roles.get(role) if isinstance(roles, dict) else {}
        if isinstance(current, dict):
            role_config.update(current)
        role_config["enabled"] = bool(role_config.get("enabled"))
        role_config["protocol"] = _clean_text(role_config.get("protocol"))
        role_config["base_url"] = _clean_text(role_config.get("base_url"))
        role_config["api_url"] = _clean_text(role_config.get("api_url"))
        role_config["api_key"] = _clean_text(role_config.get("api_key"))
        role_config["model"] = _clean_text(role_config.get("model"))
        role_config["headers"] = _normalize_headers(role_config.get("headers"))
        normalized_roles[role] = role_config
    config["roles"] = normalized_roles
    return config


def save_provider_config(config: dict[str, Any]) -> dict[str, Any]:
    normalized = load_provider_config()
    if isinstance(config, dict):
        for key in ("enabled", "protocol", "base_url", "api_key", "headers", "mobile_sync"):
            if key in config:
                normalized[key] = config[key]
        incoming_roles = config.get("roles") if isinstance(config.get("roles"), dict) else {}
        for role in ROLE_NAMES:
            if isinstance(incoming_roles.get(role), dict):
                merged = dict(normalized["roles"][role])
                merged.update(incoming_roles[role])
                normalized["roles"][role] = merged
    normalized = load_provider_config_from_dict(normalized)
    LLM_PROVIDER_CONFIG_FILE.write_text(
        json.dumps(normalized, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    apply_provider_env(normalized)
    return normalized


def load_provider_config_from_dict(config: dict[str, Any]) -> dict[str, Any]:
    merged = load_provider_config()
    for key in ("enabled", "protocol", "base_url", "api_key", "headers", "mobile_sync"):
        if key in config:
            merged[key] = config[key]
    roles = config.get("roles") if isinstance(config.get("roles"), dict) else {}
    for role in ROLE_NAMES:
        if isinstance(roles.get(role), dict):
            current = dict(merged["roles"][role])
            current.update(roles[role])
            merged["roles"][role] = current
    # Re-run normalization without re-reading the file. We must not drop roles here,
    # otherwise per-role model settings will never persist once a config file exists.
    return _normalize_provider_config(copy.deepcopy(merged))


def _normalize_provider_config(config: dict[str, Any]) -> dict[str, Any]:
    base = _default_config()
    for key in ("enabled", "protocol", "base_url", "api_key", "headers", "mobile_sync"):
        if key in config:
            base[key] = config[key]
    roles = config.get("roles") if isinstance(config.get("roles"), dict) else {}
    for role in ROLE_NAMES:
        merged = dict(base["roles"][role])
        if isinstance(roles.get(role), dict):
            merged.update(roles[role])
        base["roles"][role] = merged
    base["protocol"] = _clean_text(base.get("protocol")) or "openai_compatible"
    base["base_url"] = _clean_text(base.get("base_url"))
    base["api_key"] = _clean_text(base.get("api_key"))
    base["headers"] = _normalize_headers(base.get("headers"))
    base["enabled"] = bool(base.get("enabled"))
    mobile_sync = base.get("mobile_sync") if isinstance(base.get("mobile_sync"), dict) else {}
    base["mobile_sync"] = {
        "enabled": bool(mobile_sync.get("enabled")),
        "remote_base_url": _clean_text(mobile_sync.get("remote_base_url")),
        "access_token": _clean_text(mobile_sync.get("access_token")),
    }
    for role in ROLE_NAMES:
        role_cfg = base["roles"][role]
        role_cfg["enabled"] = bool(role_cfg.get("enabled"))
        role_cfg["protocol"] = _clean_text(role_cfg.get("protocol"))
        role_cfg["base_url"] = _clean_text(role_cfg.get("base_url"))
        role_cfg["api_url"] = _clean_text(role_cfg.get("api_url"))
        role_cfg["api_key"] = _clean_text(role_cfg.get("api_key"))
        role_cfg["model"] = _clean_text(role_cfg.get("model"))
        role_cfg["headers"] = _normalize_headers(role_cfg.get("headers"))
    return base


def apply_provider_env(config: dict[str, Any] | None = None) -> dict[str, Any]:
    config = _normalize_provider_config(config or load_provider_config())
    os.environ["ZHIYUE_API_ENABLED"] = "1" if config["enabled"] else "0"
    os.environ["ZHIYUE_API_PROTOCOL"] = config["protocol"]
    os.environ["ZHIYUE_API_BASE_URL"] = config["base_url"]
    if config["api_key"]:
        os.environ["ZHIYUE_API_KEY"] = config["api_key"]
    for role in ROLE_NAMES:
        runtime = resolve_role_runtime(role, config=config)
        os.environ[f"ZHIYUE_{role.upper()}_LM_URL"] = runtime["api_url"]
        os.environ[f"ZHIYUE_{role.upper()}_MODEL"] = runtime["model"]
        if role == "main":
            os.environ["ZHIYUE_LM_URL"] = runtime["api_url"]
            os.environ["ZHIYUE_LM_MODEL"] = runtime["model"]
    return config


def resolve_role_runtime(role: str, *, config: dict[str, Any] | None = None) -> dict[str, Any]:
    config = _normalize_provider_config(config or load_provider_config())
    role_key = role.lower().strip() if role in ROLE_NAMES else "main"
    global_protocol = config["protocol"]
    global_base_url = config["base_url"]
    global_key = config["api_key"]
    global_headers = dict(config["headers"])
    role_config = dict(config["roles"].get(role_key) or {})
    protocol = _clean_text(role_config.get("protocol") or global_protocol or "openai_compatible")
    base_url = _clean_text(role_config.get("base_url") or global_base_url)
    api_key = _clean_text(role_config.get("api_key") or global_key)
    headers = {**global_headers, **_normalize_headers(role_config.get("headers"))}
    api_url = _clean_text(role_config.get("api_url"))
    if not api_url:
        api_url = build_api_url(base_url, protocol)
    model = _clean_text(role_config.get("model"))
    if not model:
        env_model = _clean_text(os.environ.get(f"ZHIYUE_{role_key.upper()}_MODEL", ""))
        model = model_name_for_request(env_model, default_name=env_model)
    return {
        "enabled": bool(config["enabled"] or role_config.get("enabled")),
        "protocol": protocol,
        "base_url": base_url,
        "api_url": api_url,
        "api_key": api_key,
        "headers": headers,
        "model": model,
    }


def fetch_upstream_models(*, role: str = "main", config: dict[str, Any] | None = None) -> dict[str, Any]:
    """
    Best-effort model listing for UI convenience.
    Only OpenAI-compatible endpoints are supported reliably.
    """
    cfg = _normalize_provider_config(config or load_provider_config())
    runtime = resolve_role_runtime(role, config=cfg)
    protocol = (runtime.get("protocol") or cfg.get("protocol") or "openai_compatible").strip()
    base_url = _clean_text(runtime.get("base_url") or cfg.get("base_url"))
    api_key = _clean_text(runtime.get("api_key") or cfg.get("api_key"))
    headers = dict(runtime.get("headers") or cfg.get("headers") or {})

    if not base_url:
        return {"ok": False, "protocol": protocol, "base_url": base_url, "models": [], "error": "base_url_missing"}

    if protocol not in OPENAI_PROTOCOLS:
        return {"ok": False, "protocol": protocol, "base_url": base_url, "models": [], "error": "protocol_not_supported"}

    root = base_url.rstrip("/")
    if root.endswith("/models") or root.endswith("/v1/models"):
        url = root
    elif root.endswith("/v1"):
        url = root + "/models"
    else:
        url = root + "/v1/models"
    cache_key = f"{protocol}|{url}"
    now = __import__("time").time()
    cached = _UPSTREAM_MODELS_CACHE.get(cache_key)
    if cached and (now - cached[0]) < _UPSTREAM_MODELS_TTL_SECONDS:
        return {"ok": True, "protocol": protocol, "base_url": base_url, "models": list(cached[1]), "error": ""}

    req_headers = {"Accept": "application/json", **_normalize_headers(headers)}
    if api_key:
        req_headers.setdefault("Authorization", f"Bearer {api_key}")

    try:
        resp = requests.get(url, headers=req_headers, timeout=12)
        if resp.status_code >= 400:
            return {"ok": False, "protocol": protocol, "base_url": base_url, "models": [], "error": f"http_{resp.status_code}"}
        payload = resp.json() if resp.content else {}
        data = payload.get("data") if isinstance(payload, dict) else None
        models: list[str] = []
        if isinstance(data, list):
            for item in data:
                if isinstance(item, dict):
                    mid = _clean_text(item.get("id"))
                    if mid:
                        models.append(mid)
        models = sorted(set(models))
        _UPSTREAM_MODELS_CACHE[cache_key] = (now, models)
        return {"ok": True, "protocol": protocol, "base_url": base_url, "models": models, "error": ""}
    except Exception as err:
        return {"ok": False, "protocol": protocol, "base_url": base_url, "models": [], "error": str(err)[:200]}


def build_api_url(base_url: str, protocol: str) -> str:
    root = _clean_text(base_url).rstrip("/")
    mode = _clean_text(protocol).lower() or "openai_compatible"
    if not root:
        # Don't guess a local default in API-first mode.
        # If the user didn't configure base_url/api_url, callers should surface a clear error.
        return _clean_text(os.environ.get("ZHIYUE_LM_URL", ""))
    if mode in OPENAI_PROTOCOLS:
        if root.endswith("/chat/completions") or root.endswith("/v1/chat/completions"):
            return root
        if root.endswith("/v1"):
            return root + "/chat/completions"
        return root + "/v1/chat/completions"
    if mode == "anthropic":
        if root.endswith("/messages") or root.endswith("/v1/messages"):
            return root
        if root.endswith("/v1"):
            return root + "/messages"
        return root + "/v1/messages"
    if mode == "gemini":
        return root
    return root


def _openai_headers(runtime: dict[str, Any]) -> dict[str, str]:
    headers = {"Content-Type": "application/json"}
    api_key = runtime.get("api_key")
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    headers.update(runtime.get("headers") or {})
    return headers


def _normalize_message_text(content: Any) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        chunks: list[str] = []
        for item in content:
            if isinstance(item, dict):
                if item.get("type") == "text":
                    chunks.append(str(item.get("text") or ""))
                elif item.get("type") == "input_text":
                    chunks.append(str(item.get("text") or ""))
            else:
                chunks.append(str(item))
        return "\n".join(part for part in chunks if part).strip()
    return str(content or "")


def _openai_to_anthropic_messages(messages: list[dict[str, Any]]) -> tuple[str, list[dict[str, Any]]]:
    system_parts: list[str] = []
    converted: list[dict[str, Any]] = []
    for item in messages or []:
        role = _clean_text(item.get("role")).lower() or "user"
        text = _normalize_message_text(item.get("content"))
        if not text:
            continue
        if role == "system":
            system_parts.append(text)
            continue
        mapped_role = "assistant" if role == "assistant" else "user"
        converted.append({"role": mapped_role, "content": text})
    if not converted:
        converted.append({"role": "user", "content": "你好"})
    return "\n\n".join(system_parts).strip(), converted


def _extract_json_hint(payload: dict[str, Any]) -> str:
    response_format = payload.get("response_format") if isinstance(payload, dict) else None
    if not isinstance(response_format, dict):
        return ""
    kind = _clean_text(response_format.get("type")).lower()
    if kind == "json_object":
        return "Return a valid JSON object only."
    if kind == "json_schema":
        schema = response_format.get("json_schema") if isinstance(response_format.get("json_schema"), dict) else {}
        return (
            "Return only JSON that matches this schema: "
            + json.dumps(schema.get("schema") or {}, ensure_ascii=False)
        )
    return ""


def _normalize_openai_payload(role: str, payload: dict[str, Any], runtime: dict[str, Any]) -> dict[str, Any]:
    body = copy.deepcopy(payload)
    if not _clean_text(body.get("model")):
        body["model"] = runtime.get("model") or os.environ.get("ZHIYUE_LM_MODEL", "zhiyue")
    return body


def _normalize_anthropic_payload(role: str, payload: dict[str, Any], runtime: dict[str, Any]) -> tuple[dict[str, Any], dict[str, str]]:
    model = _clean_text(payload.get("model")) or _clean_text(runtime.get("model")) or "claude-sonnet-4-0"
    system_text, messages = _openai_to_anthropic_messages(payload.get("messages") or [])
    json_hint = _extract_json_hint(payload)
    if json_hint:
        system_text = (system_text + "\n\n" + json_hint).strip()
    body = {
        "model": model,
        "messages": messages,
        "max_tokens": int(payload.get("max_tokens") or 1024),
        "temperature": payload.get("temperature", 0.7),
        "top_p": payload.get("top_p", 1),
        "stream": False,
    }
    if system_text:
        body["system"] = system_text
    headers = {
        "Content-Type": "application/json",
        "x-api-key": _clean_text(runtime.get("api_key")),
        "anthropic-version": "2023-06-01",
    }
    headers.update(runtime.get("headers") or {})
    return body, headers


def _normalize_gemini_payload(role: str, payload: dict[str, Any], runtime: dict[str, Any]) -> tuple[str, dict[str, Any], dict[str, str]]:
    model = _clean_text(payload.get("model")) or _clean_text(runtime.get("model")) or "gemini-2.5-flash"
    base_url = _clean_text(runtime.get("base_url")).rstrip("/")
    api_key = _clean_text(runtime.get("api_key"))
    system_text, messages = _openai_to_anthropic_messages(payload.get("messages") or [])
    contents = []
    for item in messages:
        contents.append({
            "role": "model" if item.get("role") == "assistant" else "user",
            "parts": [{"text": _normalize_message_text(item.get("content"))}],
        })
    body: dict[str, Any] = {
        "contents": contents,
        "generationConfig": {
            "temperature": payload.get("temperature", 0.7),
            "topP": payload.get("top_p", 1),
            "maxOutputTokens": int(payload.get("max_tokens") or 1024),
        },
    }
    json_hint = _extract_json_hint(payload)
    if json_hint:
        body["generationConfig"]["responseMimeType"] = "application/json"
        system_text = (system_text + "\n\n" + json_hint).strip()
    if system_text:
        body["systemInstruction"] = {"parts": [{"text": system_text}]}
    headers = {"Content-Type": "application/json"}
    headers.update(runtime.get("headers") or {})
    if api_key:
        headers.setdefault("x-goog-api-key", api_key)
    url = base_url
    if not url.endswith(":generateContent"):
        if url.endswith("/v1beta"):
            url = f"{url}/models/{model}:generateContent"
        elif "/models/" not in url:
            url = f"{url}/v1beta/models/{model}:generateContent"
    return url, body, headers


def _openai_like_error(status_code: int, text: str) -> ProviderResponse:
    payload = {
        "error": {
            "message": text[:500],
            "type": "provider_error",
        }
    }
    return ProviderResponse(status_code=status_code, payload=payload, text=text)


def _normalize_anthropic_response(raw: requests.Response) -> ProviderResponse:
    text = raw.text
    if raw.status_code >= 400:
        return _openai_like_error(raw.status_code, text)
    data = _safe_json_loads(text, {})
    content = ""
    if isinstance(data, dict):
        for block in data.get("content") or []:
            if isinstance(block, dict) and block.get("type") == "text":
                content += str(block.get("text") or "")
    payload = {
        "id": data.get("id") if isinstance(data, dict) else "",
        "object": "chat.completion",
        "model": data.get("model") if isinstance(data, dict) else "",
        "choices": [
            {
                "index": 0,
                "message": {"role": "assistant", "content": content},
                "finish_reason": data.get("stop_reason") if isinstance(data, dict) else "stop",
            }
        ],
        "usage": {
            "prompt_tokens": ((data.get("usage") or {}).get("input_tokens") if isinstance(data, dict) else 0) or 0,
            "completion_tokens": ((data.get("usage") or {}).get("output_tokens") if isinstance(data, dict) else 0) or 0,
            "total_tokens": (
                (((data.get("usage") or {}).get("input_tokens") if isinstance(data, dict) else 0) or 0)
                + (((data.get("usage") or {}).get("output_tokens") if isinstance(data, dict) else 0) or 0)
            ),
        },
    }
    return ProviderResponse(status_code=raw.status_code, payload=payload, text=text, headers=dict(raw.headers))


def _normalize_gemini_response(raw: requests.Response, *, model: str) -> ProviderResponse:
    text = raw.text
    if raw.status_code >= 400:
        return _openai_like_error(raw.status_code, text)
    data = _safe_json_loads(text, {})
    content = ""
    if isinstance(data, dict):
        candidates = data.get("candidates") or []
        if candidates and isinstance(candidates[0], dict):
            candidate_content = candidates[0].get("content") or {}
            parts = candidate_content.get("parts") or []
            content = "".join(str(part.get("text") or "") for part in parts if isinstance(part, dict))
    payload = {
        "id": "",
        "object": "chat.completion",
        "model": model,
        "choices": [
            {
                "index": 0,
                "message": {"role": "assistant", "content": content},
                "finish_reason": "stop",
            }
        ],
        "usage": {
            "prompt_tokens": ((data.get("usageMetadata") or {}).get("promptTokenCount") if isinstance(data, dict) else 0) or 0,
            "completion_tokens": ((data.get("usageMetadata") or {}).get("candidatesTokenCount") if isinstance(data, dict) else 0) or 0,
            "total_tokens": ((data.get("usageMetadata") or {}).get("totalTokenCount") if isinstance(data, dict) else 0) or 0,
        },
    }
    return ProviderResponse(status_code=raw.status_code, payload=payload, text=text, headers=dict(raw.headers))


def post_chat_completion(role: str, payload: dict[str, Any], *, timeout: float = 180) -> ProviderResponse | requests.Response:
    runtime = resolve_role_runtime(role)
    if not _clean_text(runtime.get("api_url")):
        return _openai_like_error(503, "API not configured: missing base_url/api_url")
    protocol = _clean_text(runtime.get("protocol")).lower() or "openai_compatible"
    if protocol in OPENAI_PROTOCOLS:
        body = _normalize_openai_payload(role, payload, runtime)
        return requests.post(
            runtime["api_url"],
            json=body,
            headers=_openai_headers(runtime),
            timeout=timeout,
        )
    if protocol == "anthropic":
        body, headers = _normalize_anthropic_payload(role, payload, runtime)
        raw = requests.post(runtime["api_url"], json=body, headers=headers, timeout=timeout)
        return _normalize_anthropic_response(raw)
    if protocol == "gemini":
        url, body, headers = _normalize_gemini_payload(role, payload, runtime)
        raw = requests.post(url, json=body, headers=headers, timeout=timeout)
        return _normalize_gemini_response(raw, model=_clean_text(body.get("model")) or runtime.get("model") or "")
    body = _normalize_openai_payload(role, payload, runtime)
    return requests.post(
        runtime["api_url"],
        json=body,
        headers=_openai_headers(runtime),
        timeout=timeout,
    )


def provider_model_name(role: str) -> str:
    return _clean_text(resolve_role_runtime(role).get("model"))


def provider_chat_url(role: str) -> str:
    return _clean_text(resolve_role_runtime(role).get("api_url"))


def provider_enabled() -> bool:
    return bool(load_provider_config().get("enabled"))


def provider_healthcheck(role: str = "main", *, timeout: float = 20) -> dict[str, Any]:
    runtime = resolve_role_runtime(role)
    test_payload = {
        "model": runtime.get("model"),
        "messages": [{"role": "user", "content": "ping"}],
        "stream": False,
        "temperature": 0,
        "max_tokens": 4,
    }
    try:
        response = post_chat_completion(role, test_payload, timeout=timeout)
        data = response.json()
        content = ""
        if isinstance(data, dict):
            choices = data.get("choices") or []
            if choices and isinstance(choices[0], dict):
                message = choices[0].get("message") or {}
                content = _normalize_message_text(message.get("content"))
        ok = response.status_code < 400 and bool(content or data.get("choices"))
        return {
            "ok": ok,
            "status_code": response.status_code,
            "protocol": runtime.get("protocol"),
            "api_url": runtime.get("api_url"),
            "model": runtime.get("model"),
            "preview": content[:120],
            "error": "" if ok else str(data.get("error") if isinstance(data, dict) else response.text)[:300],
        }
    except Exception as err:
        return {
            "ok": False,
            "status_code": 0,
            "protocol": runtime.get("protocol"),
            "api_url": runtime.get("api_url"),
            "model": runtime.get("model"),
            "preview": "",
            "error": str(err)[:300],
        }
