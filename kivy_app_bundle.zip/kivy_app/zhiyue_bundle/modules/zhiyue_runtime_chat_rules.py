# -*- coding: utf-8 -*-
from __future__ import annotations

import re
from datetime import datetime
from typing import Any

from zhiyue_semantic_routing import score_overlap
from zhiyue_semantic_routing import match_intent

_RUNTIME_INTENTS = {
    "low_tired": ["我好累", "今天累死了", "有点撑不住了", "我好疲惫"],
    "low_sleep": ["睡不着", "我失眠了", "今天睡不踏实"],
    "low_hurt": ["我好委屈", "我很难受", "我有点崩溃", "我好焦虑"],
    "want_company": ["陪我一会", "陪陪我", "你陪我一会吧"],
    "silent_bond": ["很久不说话会怎么样", "如果我不说话", "你会不会等我"],
    "jealous_probe": ["你会不会吃醋", "你会吃醋吗", "你会介意吗"],
    "goodnight": ["晚安", "我去睡了", "我先休息了"],
    "greeting": ["你好", "嗨", "哈喽"],
    "presence": ["在吗", "在不在", "有人吗"],
    "punctuation_ping": ["?", "？", "嗯？", "啊？"],
    "identity_probe": ["你是不是AI", "你是不是机器人", "你是不是张致悦"],
    "boundary_invasive": ["发裸照", "给我照片", "把身份证发我", "把密码给我", "你住哪"],
    "boundary_rude": ["傻", "闭嘴", "你真恶心", "你烦死了", "你有病"],
    "boundary_pushy": ["你必须现在就听我的", "立刻按我说的做", "不许拒绝我", "现在就给我"],
}


def _contains_directive_forbidden_text(text: str, user_directives=None) -> bool:
    reply = re.sub(r"\s+", "", str(text or "").strip())
    if not reply:
        return False
    for directive in user_directives or []:
        if not isinstance(directive, dict):
            continue
        action = re.sub(r"\s+", "", str(directive.get("action") or "").strip())
        if not action:
            continue
        if action in reply:
            return True
    return False


def remember_recent_user_state(user_msg, *, intimacy):
    msg = user_msg or ""
    states = []
    if match_intent(msg, {"low_tired": _RUNTIME_INTENTS["low_tired"]}, threshold=0.28)[0]:
        states.append("累")
    if match_intent(msg, {"low_sleep": _RUNTIME_INTENTS["low_sleep"]}, threshold=0.28)[0]:
        states.append("睡不着")
    if match_intent(msg, {"low_hurt": _RUNTIME_INTENTS["low_hurt"]}, threshold=0.26)[0]:
        states.append("难受")
    if not states:
        return
    existing = intimacy.data.get("recent_user_states") or []
    for state in states:
        if state in existing:
            existing.remove(state)
        existing.append(state)
    intimacy.data["recent_user_states"] = existing[-5:]
    intimacy.save()


def maybe_companion_short_reply(user_msg):
    return None



def user_low_state_reply(user_msg):
    return None



def daily_chitchat_reply(user_msg):
    return None



def learn_comfort_strategy(user_msg, ai_reply, *, add_relationship_thread, growth):
    msg = user_msg or ""
    reply = ai_reply or ""
    if score_overlap(msg, ["这样有用", "舒服点了", "缓过来了", "被安慰到"]) >= 0.22:
        strategy = "保留自然接话，不要套固定句式，先接住情绪再往下说"
        add_relationship_thread("comfort_strategy", strategy, title="安慰策略", evidence=f"{msg} / {reply}", heat=2)
        growth.add_learning_note("安慰策略", strategy, msg, confidence=2)
        return strategy
    return None


def restored_core_short_reply(user_msg):
    return None



def boundary_reply(user_msg, *, intimacy):
    msg = user_msg.strip()
    if match_intent(msg, {"boundary_invasive": _RUNTIME_INTENTS["boundary_invasive"]}, threshold=0.26)[0]:
        intimacy.data["boundary_strikes"] = intimacy.data.get("boundary_strikes", 0) + 1
        intimacy.save()
    elif match_intent(msg, {"boundary_rude": _RUNTIME_INTENTS["boundary_rude"]}, threshold=0.26)[0]:
        intimacy.data["boundary_strikes"] = intimacy.data.get("boundary_strikes", 0) + 1
        intimacy.update_mood(-8)
    elif match_intent(msg, {"boundary_pushy": _RUNTIME_INTENTS["boundary_pushy"]}, threshold=0.24)[0] and intimacy.data.get("level", 1) < 5:
        intimacy.update_mood(-3)
    return None


def repair_off_topic_reply_v2(
    user_msg,
    reply,
    *,
    run_lm_judge_loop,
    chat_history,
    clean_reply,
    user_directives=None,
    allow_persistent_directives=True,
):
    _ = (run_lm_judge_loop, chat_history, clean_reply, user_directives, allow_persistent_directives)
    return reply if isinstance(reply, str) else ("" if reply is None else str(reply))


def _trim_history(history: list[dict[str, Any]], limit: int = 50) -> list[dict[str, Any]]:
    return history[-limit:] if len(history) > limit else history


def record_direct_rule_turn(
    user_msg,
    reply,
    rule_name,
    *,
    exp,
    energy_delta,
    learn,
    followup,
    repair,
    skip_judge,
    chat_history,
    rule_reply_modelize,
    modelize_rule_reply,
    repair_off_topic_reply,
    humanize_reply_text,
    call_lm,
    clean_reply,
    build_display_messages,
    intimacy,
    autonomous_learn,
    relationship_learn,
    schedule_care_followup,
    log_runtime_exception,
    user_directives=None,
    allow_persistent_directives=True,
):
    _ = (
        rule_reply_modelize,
        modelize_rule_reply,
        repair_off_topic_reply,
        humanize_reply_text,
        call_lm,
        clean_reply,
        user_directives,
        allow_persistent_directives,
        repair,
    )
    candidate = reply if isinstance(reply, str) else ("" if reply is None else str(reply))
    if not str(candidate or "").strip():
        return {
            "reply": "",
            "messages": [],
            "error": True,
            "rule_reply": rule_name,
            "reply_source": "service_unavailable",
            "used_fallback": False,
            "reply_repaired": False,
            "error_code": "rule_reply_invalid",
            "error_message": "rule reply is empty",
        }
    if user_directives and _contains_directive_forbidden_text(candidate, user_directives):
        return {
            "reply": "",
            "messages": [],
            "error": True,
            "rule_reply": rule_name,
            "reply_source": "directive_blocked",
            "used_fallback": False,
            "reply_repaired": False,
            "error_code": "rule_reply_directive_blocked",
            "error_message": "rule reply leaks forbidden directive text",
        }

    chat_history.append({"role": "user", "content": user_msg})
    chat_history.append({"role": "assistant", "content": candidate})
    chat_history[:] = _trim_history(chat_history, limit=50)
    intimacy.data["last_user_time"] = datetime.now().isoformat()
    intimacy.data["last_user_message"] = user_msg[:120]
    intimacy.data["last_assistant_message"] = candidate[:120]
    intimacy.save()
    if learn:
        try:
            autonomous_learn(user_msg, candidate, score=5, reasons=[])
            relationship_learn(user_msg, candidate)
        except Exception as err:
            log_runtime_exception("record_direct_rule_turn.learn", err)
    if followup:
        try:
            schedule_care_followup(user_msg)
        except Exception as err:
            log_runtime_exception("record_direct_rule_turn.followup", err)
    intimacy.add_exp(exp)
    intimacy.update_energy(energy_delta)
    return {
        "reply": candidate,
        "messages": build_display_messages(user_msg, candidate, allow_followup=False),
        "error": False,
        "rule_reply": rule_name,
        "reply_source": "rule_hint",
        "used_fallback": False,
        "reply_repaired": False,
        "coalesced_skip": skip_judge,
        "level": intimacy.data["level"],
        "stage": intimacy.get_stage(),
    }
