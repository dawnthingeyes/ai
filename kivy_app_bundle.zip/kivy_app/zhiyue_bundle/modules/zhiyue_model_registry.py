from __future__ import annotations

import os
from pathlib import Path
from typing import Any


LOCAL_MODEL_EXTENSIONS = {".gguf", ".bin", ".safetensors"}
PROJECT_ROOT = Path(
    os.environ.get("ZHIYUE_PROJECT_DIR", Path(__file__).resolve().parent.parent)
).expanduser().resolve()


def _normalize(value: Any) -> str:
    return str(value or "").strip()


def _is_path_like(value: str) -> bool:
    if not value:
        return False
    if any(sep in value for sep in ("/", "\\")):
        return True
    return Path(value).suffix.lower() in LOCAL_MODEL_EXTENSIONS


def resolve_model_reference(value: str, *, default_name: str = "") -> dict[str, Any]:
    raw = _normalize(value)
    if not raw:
        raw = _normalize(default_name)
    if not raw:
        return {
            "raw": "",
            "model_name": "",
            "model_path": None,
            "exists": False,
            "is_local": False,
        }

    if _is_path_like(raw):
        path = Path(os.path.expandvars(raw)).expanduser()
        if not path.is_absolute():
            path = PROJECT_ROOT / path
        model_path = path.resolve()
        model_name = model_path.name
        if model_path.is_file() and model_path.suffix:
            model_name = model_path.stem
        return {
            "raw": raw,
            "model_name": model_name,
            "model_path": str(model_path),
            "exists": model_path.exists(),
            "is_local": True,
        }

    return {
        "raw": raw,
        "model_name": raw,
        "model_path": None,
        "exists": False,
        "is_local": False,
    }


def model_name_for_request(value: str, *, default_name: str = "") -> str:
    return str(resolve_model_reference(value, default_name=default_name).get("model_name") or "").strip()


def model_path_exists(value: str) -> bool:
    info = resolve_model_reference(value)
    model_path = info.get("model_path")
    return bool(model_path and Path(str(model_path)).exists())
