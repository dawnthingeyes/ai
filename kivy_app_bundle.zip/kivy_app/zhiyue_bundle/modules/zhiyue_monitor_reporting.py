# -*- coding: utf-8 -*-
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path


def collect_eval_failures(mode: str, *, load_json, result_file_for) -> list[dict]:
    data = load_json(result_file_for(mode), {})
    failures = []
    for item in data.get("results", []):
        verdict = item.get("verdict") if isinstance(item.get("verdict"), dict) else item
        if verdict and not verdict.get("passed", True):
            failures.append({
                "id": item.get("id") or item.get("name"),
                "input": item.get("input") or item.get("query"),
                "reply": item.get("reply"),
                "issues": verdict.get("issues") or item.get("issues") or [],
                "mode": mode,
            })
    return failures[:20]


def collect_failures(run_result: dict, *, load_json, result_file_for) -> list[dict]:
    mode = run_result.get("mode") or "unknown"
    if mode == "code-review-matrix":
        if run_result.get("ok"):
            return []
        return [{
            "id": "code-review-matrix.process",
            "input": "",
            "reply": "",
            "issues": [f"returncode={run_result.get('returncode')}"],
            "mode": mode,
            "stdout": (run_result.get("stdout") or "")[-1000:],
            "stderr": (run_result.get("stderr") or "")[-1000:],
        }]
    failures = collect_eval_failures(mode, load_json=load_json, result_file_for=result_file_for)
    if failures:
        return failures
    if not run_result.get("ok"):
        return [{
            "id": f"{mode}.process",
            "input": "",
            "reply": "",
            "issues": [f"returncode={run_result.get('returncode')}"],
            "mode": mode,
            "stdout": (run_result.get("stdout") or "")[-1000:],
            "stderr": (run_result.get("stderr") or "")[-1000:],
        }]
    return []


def archive_stale_pending_proposals(
    *,
    proposal_file: Path,
    archive_file: Path,
    baseline_version: str,
    load_json,
    write_json,
    log,
) -> int:
    queue = load_json(proposal_file, [])
    if not isinstance(queue, list) or not queue:
        return 0
    archived = load_json(archive_file, [])
    if not isinstance(archived, list):
        archived = []
    active = []
    moved = 0
    for item in queue:
        if not isinstance(item, dict):
            continue
        baseline = str(item.get("baseline_version") or "")
        created_at = str(item.get("created_at") or "")
        legacy_pending = item.get("status") == "pending" and (
            baseline != baseline_version or created_at.startswith("2026-05-11T0")
        )
        if legacy_pending:
            item["status"] = "archived"
            item["archived_at"] = datetime.now().isoformat()
            item["archive_reason"] = "legacy_monitor_baseline"
            archived.append(item)
            moved += 1
            continue
        active.append(item)
    if moved:
        write_json(proposal_file, active[-100:])
        write_json(archive_file, archived[-200:])
        log(f"archived stale proposals count={moved} baseline={baseline_version}")
    return moved


def append_proposal(
    *,
    state: dict,
    evals: list[dict],
    auto_proposal_min_failures: int,
    proposal_file: Path,
    findings_file: Path,
    baseline_version: str,
    load_json,
    write_json,
    append_finding,
    log,
    result_file_for,
) -> None:
    failures = []
    for item in evals:
        if not item["ok"]:
            failures.extend(
                collect_failures(
                    item,
                    load_json=load_json,
                    result_file_for=result_file_for,
                )
            )
    if not failures:
        return
    if len(failures) < auto_proposal_min_failures:
        log(f"proposal skipped failure_count={len(failures)} threshold={auto_proposal_min_failures}")
        return

    queue = load_json(proposal_file, [])
    if not isinstance(queue, list):
        queue = []
    signature = "|".join(f"{f.get('id')}:{','.join(f.get('issues') or [])}" for f in failures[:8])
    if any(item.get("signature") == signature and item.get("status") == "pending" for item in queue):
        return

    proposal = {
        "id": f"self-monitor-{datetime.now().strftime('%Y%m%d%H%M%S')}",
        "status": "pending",
        "source": "zhiyue_self_monitor",
        "created_at": datetime.now().isoformat(),
        "baseline_version": baseline_version,
        "signature": signature,
        "summary": "自检发现回复质量、接口、记忆或压力测试存在回归，建议先人工审查，再决定是否进入沙盒修复。",
        "human_question": "我攒到一批自检失败。要不要我先整理修复方案并进沙盒验证？会先给改动方案，得到你确认后才继续，回复质量优先，不会直接改源码。",
        "safety": {
            "auto_edit_source": False,
            "uses_temp_state": True,
            "requires_human_approval": True,
            "reply_quality_first": True,
        },
        "failures": failures,
        "next_steps": [
            "汇总至少五条失败样本",
            "提出针对性的改动方案",
            "等待用户确认后进入沙盒验证",
            "汇报沙盒结果后再等待是否应用到源码",
        ],
    }
    queue.append(proposal)
    write_json(proposal_file, queue[-100:])
    append_finding({
        "created_at": proposal["created_at"],
        "proposal_id": proposal["id"],
        "signature": signature,
        "failures": failures,
    })
    log(f"proposal queued id={proposal['id']} failures={len(failures)}")
