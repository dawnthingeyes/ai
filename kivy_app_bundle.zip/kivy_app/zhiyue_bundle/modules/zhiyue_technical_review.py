# -*- coding: utf-8 -*-
from __future__ import annotations

import ast
import hashlib
import re
import unicodedata
from pathlib import Path

# ── 动态分析状态：记录上次分析快照，用于检测变化 ──
_review_state = {
    "last_file_hash": None,
    "last_line_count": 0,
    "last_except_count": 0,
    "last_def_count": 0,
    "last_route_count": 0,
    "last_backup_count": 0,
    "review_round": 0,       # 累计审查轮次
    "followup_depth": 0,     # 当前连续 followup 深度
    "mentioned_lines": set(), # 已经提到过的行号范围，避免重复
}


def normalize_technical_text(text):
    value = unicodedata.normalize("NFKC", str(text or ""))
    value = value.lower()
    value = re.sub(r"\s+", "", value)
    value = re.sub(r"[`'\"，。！？、；：,.!?;:()\[\]{}<>/_\-+=~@#$%^&*|\\]+", "", value)
    return value


def _is_followup_code_review_request(user_msg: str) -> bool:
    msg = normalize_technical_text(user_msg)
    clean_followup_patterns = [
        "继续",
        "然后呢",
        "还有呢",
        "现在呢",
        "接着看",
        "接着改",
        "我刚改了",
        "我已经改了",
        "改完了",
    ]
    if any(normalize_technical_text(p) in msg for p in clean_followup_patterns):
        return True
    followup_patterns = [
        "现在呢",
        "还有什么",
        "还有呢",
        "然后呢",
        "继续",
        "接着看",
        "我刚改了",
        "我已经改了",
        "改完了",
        "继续改",
    ]
    return any(normalize_technical_text(p) in msg for p in followup_patterns)


def is_code_review_followup_with_history(user_msg, history) -> bool:
    if not _is_followup_code_review_request(str(user_msg or "")):
        return False
    markers = [
        "zhiyue_connected.py",
        "except Exception",
        "代码",
        "规则",
        "工具调用",
        "兜底",
        "工具调用",
        "兜底",
        "规则",
        "OpenAI 接口",
        "主目录里放了",
        "职责太杂",
    ]
    for msg in reversed(list(history or [])[-8:]):
        if not isinstance(msg, dict):
            continue
        content = str(msg.get("content") or "")
        if any(marker in content for marker in markers):
            return True
    return False


def looks_like_explicit_code_review_request(user_msg):
    raw = str(user_msg or "")
    msg = normalize_technical_text(raw)
    if not msg:
        return False
    clean_strong_patterns = [
        "你看看你的代码哪里值得优化",
        "你看看你的代码哪里有问题",
        "帮我挑刺",
        "分析一下你的工具调用逻辑",
        "看看你的规则哪里会误伤正常回复",
        "这个文件你读一下",
        "这份代码哪里最该拆",
        "代码哪里有问题",
        "代码哪里值得优化",
    ]
    if any(normalize_technical_text(p) in msg for p in clean_strong_patterns):
        return True

    strong_patterns = [
        "看看你的代码哪里值得优化",
        "看看你的代码哪里可以优化",
        "看看你的代码",
        "代码哪里值得优化",
        "帮我挑刺",
        "我刚改了",
        "我已经改了",
        "改完了",
        "现在呢",
        "还有什么",
        "继续看",
        "继续改",
        "读一下这个文件",
        "分析这个文件",
        "看看这个文件",
        "工具调用逻辑",
        "兜底回复",
        "兜底逻辑",
        "规则哪里",
        "规则误伤",
        "触发逻辑",
        "系统行为",
        "回复方式有问题",
        "这段代码哪里有问题",
        "哪个模块最该拆",
    ]
    if any(normalize_technical_text(p) in msg for p in strong_patterns):
        return True

    if any(ext in raw.lower() for ext in [".py", ".json", ".yaml", ".yml", ".toml"]):
        if any(
            term in msg
            for term in [normalize_technical_text(item) for item in ["文件", "读一下", "读取", "看看", "分析", "代码"]]
        ):
            return True

    meta_topics = [normalize_technical_text(item) for item in ["工具调用", "工具", "规则", "兜底", "触发", "回复方式", "系统行为", "逻辑"]]
    meta_actions = [normalize_technical_text(item) for item in ["分析", "排查", "看看", "优化", "有问题", "哪里", "怎么", "检查", "挑刺"]]
    if any(topic in msg for topic in meta_topics) and any(action in msg for action in meta_actions):
        return True

    broad_topics = [normalize_technical_text(item) for item in ["代码", "工具", "规则", "兜底", "触发", "逻辑", "模块", "文件", "源码", "实现"]]
    broad_actions = [normalize_technical_text(item) for item in ["看看", "分析", "优化", "挑刺", "有问题", "哪里", "怎么", "读一下", "检查", "排查"]]
    return any(term in msg for term in broad_topics) and any(term in msg for term in broad_actions)


def is_tool_deflection_reply(text):
    reply = str(text or "").strip()
    if not reply:
        return True
    norm_reply = normalize_technical_text(reply)
    patterns = [
        "我脑子里没存具体的代码块",
        "光凭感觉可不敢乱点评",
        "你是指之前",
        "还是你有啥新想法",
        "先告诉我你想看哪段",
        "你想让我看哪方面",
        "我先得知道你想让我关注哪方面",
        "没法直接评",
        "不好直接评",
        "不敢乱评",
        "不敢乱点评",
        "光凭感觉",
        "先告诉我范围",
        "你具体想看",
    ]
    return any(normalize_technical_text(p) in norm_reply for p in patterns)


def _compute_file_hash(text: str) -> str:
    return hashlib.md5(text.encode("utf-8", errors="replace")).hexdigest()


def _find_except_locations(text: str, lines: list[str]) -> list[dict]:
    """定位每个裸 except 的位置和上下文，返回详情列表。"""
    results = []
    for i, line in enumerate(lines):
        stripped = line.strip()
        # 匹配 except Exception / except : / except Exception as e 等
        if re.match(r'^\s*except\s+(Exception|\*?\s*:)', stripped):
            # 往前找对应的 try 开始位置
            try_start = i
            for j in range(i - 1, max(i - 30, -1), -1):
                if re.match(r'^\s*try\s*:', lines[j].strip()):
                    try_start = j
                    break
            # 看 except 块里做了什么（往下5行）
            except_body = lines[i + 1:i + 6]
            except_body_text = "\n".join(l.strip() for l in except_body if l.strip())
            results.append({
                "line": i + 1,  # 1-indexed
                "code": stripped[:80],
                "try_start": try_start + 1,
                "body_preview": except_body_text[:120],
            })
    return results


def _find_large_functions(text: str, lines: list[str], threshold: int = 80) -> list[dict]:
    """找出超过阈值的超大函数。"""
    results = []
    try:
        tree = ast.parse(text)
    except Exception:
        tree = None
    if tree is not None:
        for node in ast.walk(tree):
            if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            start = getattr(node, "lineno", 0)
            end = getattr(node, "end_lineno", 0)
            if not start or not end:
                continue
            line_count = end - start + 1
            if line_count > threshold:
                results.append({
                    "name": node.name,
                    "start": start,
                    "end": end,
                    "lines": line_count,
                })
        return sorted(results, key=lambda x: x["lines"], reverse=True)
    current_func = None
    current_start = 0
    for i, line in enumerate(lines):
        m = re.match(r'^(\s*)def\s+(\w+)\s*\(', line)
        if m:
            if current_func and (i - current_start) > threshold:
                results.append({
                    "name": current_func,
                    "start": current_start + 1,
                    "end": i,
                    "lines": i - current_start,
                })
            current_func = m.group(2)
            current_start = i
    # 最后一个函数
    if current_func and (len(lines) - current_start) > threshold:
        results.append({
            "name": current_func,
            "start": current_start + 1,
            "end": len(lines),
            "lines": len(lines) - current_start,
        })
    return sorted(results, key=lambda x: x["lines"], reverse=True)


def _find_duplicate_patterns(text: str, lines: list[str]) -> list[dict]:
    """检测明显的重复代码模式。"""
    patterns = []
    # 检测重复的 judge/评分相关代码块
    judge_blocks = []
    for i, line in enumerate(lines):
        if 'judge_reply_runtime' in line or 'judge_reply(' in line:
            judge_blocks.append(i + 1)
    if len(judge_blocks) >= 5:
        patterns.append({"type": "judge_call_duplicated", "count": len(judge_blocks), "sample_lines": judge_blocks[:5]})

    # 检测重复的 clean_reply 调用
    clean_blocks = []
    for i, line in enumerate(lines):
        if re.match(r'^\s*clean_reply_for_mode\(', line.strip()):
            clean_blocks.append(i + 1)
    if len(clean_blocks) >= 8:
        patterns.append({"type": "clean_reply_duplicated", "count": len(clean_blocks), "sample_lines": clean_blocks[:5]})

    return patterns


def _detect_changes(source_dir: Path, main_file: Path, text: str, lines: list[str]) -> dict:
    """对比上次分析的状态，检测文件发生了什么变化。"""
    global _review_state
    current_hash = _compute_file_hash(text)
    line_count = len(lines)
    except_count = text.count("except Exception")
    def_count = text.count("def ")
    route_count = text.count("@app.route")
    backup_files = sorted(source_dir.glob("zhiyue_connected_backup_*.py"))
    backup_count = len(backup_files)

    changed = {
        "file_changed": current_hash != _review_state.get("last_file_hash"),
        "line_delta": line_count - _review_state.get("last_line_count", line_count),
        "except_delta": except_count - _review_state.get("last_except_count", except_count),
        "def_delta": def_count - _review_state.get("last_def_count", def_count),
        "route_delta": route_count - _review_state.get("last_route_count", route_count),
        "backup_delta": backup_count - _review_state.get("last_backup_count", backup_count),
        "is_first_review": _review_state.get("last_file_hash") is None,
    }

    # 更新状态
    _review_state["last_file_hash"] = current_hash
    _review_state["last_line_count"] = line_count
    _review_state["last_except_count"] = except_count
    _review_state["last_def_count"] = def_count
    _review_state["last_route_count"] = route_count
    _review_state["last_backup_count"] = backup_count
    _review_state["review_round"] += 1

    if _is_followup_code_review_request.__module__ in ("__main__", "zhiyue_technical_review"):  # 简单跟踪
        pass  # followup depth tracking moved to caller

    return changed


def local_code_review_reply(user_msg, *, source_dir, recent_history=None):
    """
    动态代码审查：每次重新读取源文件，基于实际内容生成分析。
    不再使用固定模板，而是根据文件变化、用户关注点、审查历史动态输出。
    """
    global _review_state
    source_dir = Path(source_dir).resolve()
    main_file = source_dir / "zhiyue_connected.py"
    backup_files = sorted(source_dir.glob("zhiyue_connected_backup_*.py"))
    findings = []
    norm_msg = normalize_technical_text(user_msg)
    followup = _is_followup_code_review_request(user_msg)

    # 跟踪 followup 深度
    if followup:
        _review_state["followup_depth"] += 1
    else:
        _review_state["followup_depth"] = 0

    focus_tooling = any(term in norm_msg for term in [normalize_technical_text(x) for x in ["工具", "工具调用", "function calling", "tool"]])
    focus_fallback = any(term in norm_msg for term in [normalize_technical_text(x) for x in ["兜底", "fallback", "默认回复"]])
    focus_rules = any(term in norm_msg for term in [normalize_technical_text(x) for x in ["规则", "触发", "误伤", "回复方式", "系统行为"]])
    focus_split = any(term in norm_msg for term in [normalize_technical_text(x) for x in ["模块", "拆", "结构", "架构"]])
    focus_file = any(ext in str(user_msg or "").lower() for ext in [".py", ".json", ".yaml", ".yml", ".toml"])
    depth = _review_state["followup_depth"]
    round_num = _review_state["review_round"]

    if not main_file.exists():
        return "我这边没读到主文件 `zhiyue_connected.py`，先把路径和工作目录固定住更稳。"

    # ── 读取源文件 ──
    try:
        text = main_file.read_text(encoding="utf-8", errors="replace")
        lines = text.splitlines()
        line_count = len(lines)
    except Exception:
        return "我本地读主文件时出错了，文件可能被占用或权限有问题。"

    # ── 变化检测 ──
    changes = _detect_changes(source_dir, main_file, text, lines)

    # ════════════════════════════════════════════════
    # 第1优先级：报告文件变化（如果确实改了）
    # ════════════════════════════════════════════════
    if changes["file_changed"] and not changes["is_first_review"]:
        delta_parts = []
        if changes["line_delta"] != 0:
            sign = "+" if changes["line_delta"] > 0 else ""
            delta_parts.append(f"行数 {sign}{changes['line_delta']}")
        if changes["except_delta"] != 0:
            sign = "+" if changes["except_delta"] > 0 else ""
            delta_parts.append(f"裸except {sign}{changes['except_delta']}")
        if changes["def_delta"] != 0:
            sign = "+" if changes["def_delta"] > 0 else ""
            delta_parts.append(f"函数 {sign}{changes['def_delta']}")
        if changes["backup_delta"] != 0:
            sign = "+" if changes["backup_delta"] > 0 else ""
            delta_parts.append(f"备份文件 {sign}{changes['backup_delta']}")
        if delta_parts:
            findings.append(f"文件变了。检测到变化：{'、'.join(delta_parts)}。（第{round_num}次审查）")

    # ════════════════════════════════════════════════
    # 第2优先级：备份文件问题（仅首次或数量变化时提）
    # ════════════════════════════════════════════════
    if backup_files and (changes["is_first_review"] or changes["backup_delta"] != 0) and not followup:
        findings.append(f"主目录里有 {len(backup_files)} 个备份文件 `zhiyue_connected_backup_*.py`，建议挪到 `backups/` 子目录。")

    # ════════════════════════════════════════════════
    # 第3优先级：动态结构分析（每次都基于实际数据）
    # ════════════════════════════════════════════════
    except_count = text.count("except Exception")
    except_locs = _find_except_locations(text, lines)
    large_funcs = _find_large_functions(text, lines, threshold=80)
    dup_patterns = _find_duplicate_patterns(text, lines)

    # 文件体积（动态数据，非模板）
    if line_count >= 6000:
        if changes["is_first_review"] and not followup:
            findings.append(f"主文件当前 {line_count} 行，体量偏大。")
        elif followup and depth <= 1:
            findings.append(f"文件还是 {line_count} 行，还没瘦身。")

    # 裸except 分析（带行号，每次不同）
    if except_count >= 15:
        if not followup:
            # 首次：给概要+最可疑的2个位置
            findings.append(f"全文件有 {except_count} 处 `except Exception`。")
            suspicious = [ex for ex in except_locs if "pass" in ex["body_preview"] or "print(" in ex["body_preview"] or not ex["body_preview"]][:2]
            if suspicious:
                for ex in suspicious:
                    findings.append(f"第{ex['line']}行的 except 比较危险（try从第{ex['try_start']}行开始），异常被吞掉了。")
        elif followup and depth == 1:
            # 第一次followup：给下一批except位置
            next_batch = except_locs[2:5]
            if next_batch:
                for ex in next_batch:
                    findings.append(f"第{ex['line']}行还有一处 except（try从第{ex['try_start']}行），这里捕获后只做了{ex['body_preview'][:40] or 'pass'}。")
            else:
                findings.append("裸except的基本情况已经过了一遍，建议开始批量替换为具体异常类型。")
        elif followup and depth >= 2:
            findings.append(f"except 的问题说了几轮了——{except_count} 处，建议一次性全部列出来逐个击破，而不是继续聊概要。")

    # 大函数分析已禁用（用户确认不算问题）
    # if large_funcs:
    #     ...（已跳过）

    # 重复代码
    if dup_patterns and not followup:
        for p in dup_patterns[:2]:
            if p["type"] == "judge_call_duplicated":
                findings.append(f"`judge_reply_runtime` 被调用了 {p['count']} 次，分散在各处，评分逻辑应该统一收敛。")
            elif p["type"] == "clean_reply_duplicated":
                findings.append(f"`clean_reply_for_mode` 调用达 {p['count']} 次，回复清洗逻辑散落各处，建议抽成装饰器或统一入口。")

    # ════════════════════════════════════════════════
    # 第4优先级：用户焦点定向分析
    # ════════════════════════════════════════════════
    if focus_tooling:
        tool_line_nums = [i + 1 for i, line in enumerate(lines) if "run_tool_loop" in line or "def run_tool" in line]
        if tool_line_nums:
            findings.append(f"工具调用主链路在 第{tool_line_nums[0]}行附近，工具失败后的回退逻辑紧接着下面几十行。")
    if focus_fallback:
        fallback_line_nums = [i + 1 for i, line in enumerate(lines) if "build_lm_fallback_reply" in line or "我在听" in line]
        if fallback_line_nums:
            findings.append(f"默认回复（哎我在听）定义在第{fallback_line_nums[0]}行附近，当LLM无响应或judge不通过时会走到这里。")
    if focus_rules:
        rule_line_nums = [i + 1 for i, line in enumerate(lines) if "looks_like_explicit_code_review_request" in line or "rule_hint" in line]
        if rule_line_nums:
            findings.append(f"规则匹配入口分散在多处，第{rule_line_nums[0]}行是技术请求识别，规则短路逻辑在后面。")
    if focus_split:
        findings.append(f"如果要拆分，建议按这几个模块切：`technical_review`(已独立)、`reply_payloads`(已独立)、`judge`(评分)、`chat`(聊天)、`api`(路由)。")
    if focus_file:
        findings.append(f"按文件看：主文件{line_count}行，{except_count}处裸except，{len(backup_files)}个备份文件。")

    # ════════════════════════════════════════════════
    # Followup 深入模式（depth>=2 时给出更具体的建议）
    # ════════════════════════════════════════════════
    if followup and depth >= 2:
        # 给出具体的下一步行动建议
        if except_count > 0:
            findings.append(f"下一步建议：把 `except Exception` 逐个改成具体类型（如 ValueError、KeyError、ConnectionError），每个加上日志。")
        if line_count >= 6000:
            findings.append(f"下一步建议：新建 `zhiyue_judge.py` 把评分/judge逻辑移出去，预计能减掉 ~800 行。")

    # ════════════════════════════════════════════════
    # 兜底：如果什么都没检测到
    # ════════════════════════════════════════════════
    if not findings:
        findings.append(f"扫完了（第{round_num}次）。文件{line_count}行，{except_count}处except，暂时没有新的明显问题。")

    # 去重
    unique_findings = []
    seen = set()
    for item in findings:
        item_key = item[:60]  # 用前60字符去重
        if item_key not in seen:
            seen.add(item_key)
            unique_findings.append(item)

    import random as _random
    _persona_leads = [
        "扫完了，给你说下我看到的：",
        "我看了一下，情况是这样的：",
        "给你汇报一下，",
        "翻了一遍代码，发现这些：",
        "嗯……看完了，说几个点：",
    ]
    _lead = _random.choice(_persona_leads) if not followup else ""

    # 不截断，完整返回所有 findings
    body = "\n".join(unique_findings).strip()
    if not body:
        body = f"扫完了（第{round_num}次）。文件{line_count}行，{except_count}处except，暂时没有新的明显问题。"

    return (_lead + " " + body).strip()
