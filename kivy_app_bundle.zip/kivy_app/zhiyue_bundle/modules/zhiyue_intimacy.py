# -*- coding: utf-8 -*-
"""亲密关系状态管理（从 zhiyue_connected.py 拆分）"""
import json
import os
import logging
from datetime import datetime, date
from pathlib import Path
from zhiyue_project_paths import INTIMACY_FILE as PROJECT_INTIMACY_FILE

_dbg = logging.getLogger("zhiyue")

DEFAULT_INTIMACY_FILE = str(PROJECT_INTIMACY_FILE)


class IntimacySystem:
    def __init__(self, file_path: str = DEFAULT_INTIMACY_FILE):
        self.path = file_path
        self.data = self._load()

    def _load(self):
        defaults = {
            "level": 1, "exp": 0, "total_chats": 0, "total_days": 0,
            "first_chat": None, "last_chat": None, "last_date": None,
            "memories": [], "streak": 0,
            "energy": 100,
            "mood": 100,
            "emotion": "neutral",
            "happiness": 50,
            "activity": 50,
            "emotion_history": [],
            "jealousy_level": 0.0,
            "cold_war_turns": 0,
            "emotion_valence": 0.0,
            "emotion_arousal": 0.0,
            "emotion_last_update": None,
            "personality_gentle": 65,
            "personality_rational": 55,
            "personality_indirect": 60,
            "personality_pessimistic": 40,
            "personality_clingy": 50,
            "last_user_time": None,
            "last_proactive_time": None,
            "daily_event_date": None,
            "daily_event": "",
            "life_arc": [],
            "life_arc_date": None,
            "care_followups": [],
            "emotion_carry": "neutral",
            "emotion_carry_turns": 0,
            "boundary_strikes": 0,
            "last_decay_date": None,
            "last_user_message": "",
            "last_assistant_message": "",
            "last_user_wait_marker": None,
            "last_wait_reply": None,
            "quiet_mode_until": None,
            "last_flashback_time": None,
            "last_ambient_time": None,
            "last_micro_story_time": None,
            "last_memory_compact_date": None,
            "preferred_nickname": None,
        }
        if os.path.exists(self.path):
            try:
                with open(self.path, 'r', encoding='utf-8') as f:
                    d = json.load(f)
                    for k, v in defaults.items():
                        d.setdefault(k, v)
                    return d
            except:
                pass
        return defaults

    def save(self):
        with open(self.path, 'w', encoding='utf-8') as f:
            json.dump(self.data, f, ensure_ascii=False, indent=2)

    def get_stage(self):
        lv = self.data["level"]
        if lv <= 2: return "熟人"
        elif lv <= 4: return "朋友"
        elif lv <= 6: return "密友"
        elif lv <= 8: return "暧昧"
        else: return "情侣"

    def get_nickname(self):
        # User-specified nickname override (set by directive system)
        preferred = self.data.get("preferred_nickname")
        if preferred is not None:
            return preferred
        lv = self.data["level"]
        if lv <= 2: return "你"
        elif lv <= 4: return "你"
        elif lv <= 6: return None
        elif lv <= 8: return "宝宝"
        else: return "亲爱的"

    def set_preferred_nickname(self, name):
        """Set or clear user-specified nickname override. None clears it."""
        self.data["preferred_nickname"] = name
        self.save()

    def get_tone(self):
        lv = self.data["level"]
        if lv <= 2: return "shy"
        elif lv <= 4: return "warm"
        elif lv <= 6: return "close"
        elif lv <= 8: return "flirty"
        else: return "love"

    def get_friendship_desc(self):
        lv = self.data["level"]
        exp_ratio = (self.data["exp"] % (lv * 100)) / (lv * 100) * 100 if lv > 0 else 0
        stage_desc = {
            "熟人": f"礼貌且有距离感({int(exp_ratio)}%)",
            "朋友": f"熟悉且轻松({int(exp_ratio)}%)",
            "密友": f"信任且亲密({int(exp_ratio)}%)",
            "暧昧": f"喜欢且心动({int(exp_ratio)}%)",
            "情侣": f"深爱且依赖({int(exp_ratio)}%)",
        }
        return stage_desc.get(self.get_stage(), "")

    def get_personality_desc(self):
        """生成人格底色描述文本"""
        p = self.data
        gentle = p.get("personality_gentle", 65)
        rational = p.get("personality_rational", 55)
        indirect = p.get("personality_indirect", 60)
        pessimistic = p.get("personality_pessimistic", 40)
        clingy = p.get("personality_clingy", 50)

        parts = []
        if gentle >= 70:
            parts.append("很温柔")
        elif gentle <= 30:
            parts.append("有点强势")

        if rational <= 35:
            parts.append("偏感性")
        elif rational >= 70:
            parts.append("偏理性")

        if indirect >= 70:
            parts.append("说话含蓄")
        elif indirect <= 30:
            parts.append("直来直去")

        if pessimistic >= 70:
            parts.append("容易悲观")
        elif pessimistic <= 30:
            parts.append("乐观开朗")

        if clingy >= 70:
            parts.append("比较粘人")
        elif clingy <= 30:
            parts.append("很独立")

        return ", ".join(parts) if parts else "性格平衡"

    def adjust_personality(self, dimension, delta):
        """微调人格维度(范围0-100)"""
        key = f"personality_{dimension}"
        if key in self.data:
            old = self.data[key]
            new_val = max(0, min(100, old + delta))
            self.data[key] = new_val
            self.save()
            _dbg.debug("[人格调整] %s: %s -> %s", dimension, old, new_val)
            return new_val
        return None

    def add_exp(self, amount=3):
        self.data["exp"] = self.data.get("exp", 0) + amount
        self.data["total_chats"] = self.data.get("total_chats", 0) + 1
        now = datetime.now()
        self.data["last_chat"] = now.isoformat()
        if not self.data.get("first_chat"):
            self.data["first_chat"] = now.isoformat()
        today = now.date().isoformat()
        if self.data.get("last_date") != today:
            if self.data["last_date"]:
                last = date.fromisoformat(self.data["last_date"])
                diff = (now.date() - last).days
                if diff == 1:
                    self.data["streak"] = self.data.get("streak", 0) + 1
                elif diff > 1:
                    self.data["streak"] = 1
            else:
                self.data["streak"] = 1
            self.data["last_date"] = today
            self.data["total_days"] += 1
        exp_needed = self.data["level"] * 100
        if self.data["exp"] >= exp_needed and self.data["level"] < 10:
            self.data["level"] += 1
        self.save()
        return self.data["level"]

    def add_memory(self, mem):
        if mem not in self.data["memories"]:
            self.data["memories"].append(mem)
            if len(self.data["memories"]) > 20:
                self.data["memories"] = self.data["memories"][-20:]

    def update_energy(self, delta):
        self.data["energy"] = max(0, min(100, self.data.get("energy", 100) + delta))
        self.save()

    def recover_energy(self):
        """Auto-recover energy based on inactivity. +1 per 5 min since last user message."""
        last_user = self.data.get("last_user_time")
        if not last_user:
            return 0
        now = datetime.now()
        # Prevent over-recovery from frequent health checks (debounce: 1 recovery per 5 min)
        last_recovery = self.data.get("_last_energy_recovery")
        if last_recovery:
            try:
                lr = datetime.fromisoformat(last_recovery)
                if (now - lr).total_seconds() < 290:
                    return 0
            except Exception:
                pass
        try:
            last = datetime.fromisoformat(last_user)
            elapsed_seconds = (now - last).total_seconds()
            elapsed_minutes = elapsed_seconds / 60
            recovery = int(elapsed_seconds / 300)
            # Floor: if energy is low and idle for >30 min, guarantee at least 20
            current = self.data.get("energy", 100)
            if current < 20 and elapsed_minutes >= 30:
                recovery = max(recovery, 20 - current)
            if recovery > 0 and current < 100:
                new = min(100, current + recovery)
                self.data["energy"] = new
                self.data["_last_energy_recovery"] = now.isoformat()
                self.save()
                return recovery
        except Exception:
            pass
        return 0

    def update_mood(self, delta):
        self.data["mood"] = max(0, min(100, self.data.get("mood", 100) + delta))
        self.save()

    def set_value(self, key, value):
        self.data[key] = value
        self.save()

    def get_value(self, key, default=None):
        return self.data.get(key, default)
