# -*- coding: utf-8 -*-
"""zhiyue_memory_v2.py — 智越记忆系统五大优化：
1. 多信号融合检索（FTS5 BM25 + 实体匹配 + 语义向量）
2. 时间感知推理（valid_from/valid_until + 时间过滤）
3. LLM 自动提取记忆（对话→新记忆）
4. 语义去重 + 冲突检测
5. 记忆生命周期管理（合并、衰减、清理）
"""

import re, math, hashlib, json, os, sqlite3
from typing import Any

# --- 复用现有函数（运行时 inject） ---
tokenize = None
clean_snippet = None
normalize_text_key = None
parse_datetime_local = None
now_local = None
now_iso = None
memory_priority = None
recency_bonus = None
JsonDict = dict
cosine_similarity = None


def _inject_deps(ctx):
    """将依赖从现有模块注入。"""
    global tokenize, clean_snippet, normalize_text_key, parse_datetime_local
    global now_local, now_iso, memory_priority, recency_bonus, cosine_similarity
    tokenize = ctx.get("tokenize")
    clean_snippet = ctx.get("clean_snippet")
    normalize_text_key = ctx.get("normalize_text_key")
    parse_datetime_local = ctx.get("parse_datetime_local")
    now_local = ctx.get("now_local")
    now_iso = ctx.get("now_iso")
    memory_priority = ctx.get("memory_priority")
    recency_bonus = ctx.get("recency_bonus")
    cosine_similarity = ctx.get("cosine_similarity")


# =====================================================================
# 优化 1+2：多信号融合检索（FTS5 + 实体 + 时间感知）
# =====================================================================

def init_fts5(memory_db):
    """初始化 FTS5 虚拟表（在 SQLite 中）。"""
    try:
        conn = sqlite3.connect(str(memory_db))
        try:
            conn.execute("""
                CREATE VIRTUAL TABLE IF NOT EXISTS memory_fts5 USING fts5(
                    content, summary, category, mem_type,
                    content='memories', content_rowid='id'
                )
            """)
            conn.commit()
        finally:
            conn.close()
    except Exception:
        pass


def search_fts5(memory_db, query, load_rows_fn, limit=20):
    """BM25 关键词搜索（通过 FTS5 虚拟表）。"""
    terms = tokenize(query, limit=20)
    if not terms:
        return []
    fts_query = " OR ".join('"' + t.replace('"', '""') + '"' if " " in t else t for t in terms[:10])
    conn = sqlite3.connect(str(memory_db))
    try:
        try:
            cur = conn.execute(
                "SELECT rowid, rank FROM memory_fts5 WHERE memory_fts5 MATCH ? ORDER BY rank LIMIT ?",
                (fts_query, limit),
            )
            hits = [(row[0], float(row[1] or 0)) for row in cur.fetchall()]
        except Exception:
            return []
    finally:
        conn.close()

    if not hits:
        return []
    max_rank = max(abs(v) for _, v in hits) or 1.0
    rows = {int(row.get("id") or 0): row for row in load_rows_fn(limit=1000)}
    results = []
    for mem_id, rank in hits:
        row = rows.get(mem_id)
        if not row:
            continue
        score = max(0.0, 1.0 - abs(rank) / max_rank)
        results.append({"row": row, "score": score, "source": "fts5_bm25"})
    return results


def extract_entities(text):
    """从查询文本中提取命名实体。"""
    entities = []
    for pat in [r"[A-Z][a-z]{2,}(?:\s+[A-Z][a-z]+)*", r"[\u4e00-\u9fff]{2,4}"]:
        for m in re.findall(pat, (text or "")):
            m = m.strip()
            if m and m not in entities:
                entities.append(m)
    stops = {
        "什么", "怎么", "如何", "为什么", "这个", "那个", "哪个", "可以", "应该",
        "不要", "没有", "已经", "现在", "不是", "还是", "都是",
    }
    stops.update({"the", "a", "an", "is", "are", "was", "were", "what", "who",
                   "where", "when", "why", "how", "can", "this", "that"})
    return [e for e in entities if e.lower() not in stops]


def search_entity(memory_db, query, load_rows_fn, limit=10):
    """基于实体匹配的检索。"""
    entities = extract_entities(query)
    if not entities:
        return []
    rows = load_rows_fn(limit=500)
    results = []
    for row in rows:
        content = str(row.get("content", "") or row.get("summary", ""))
        matched = [e for e in entities if e in content]
        if matched:
            score = len(matched) / max(1, len(entities))
            results.append({
                "row": row, "score": score, "source": "entity_match",
                "matched_entities": matched,
            })
    results.sort(key=lambda x: x["score"], reverse=True)
    return results[:limit]


def fuse_search_results(vector_results, fts5_results, entity_results, limit):
    """加权 Reciprocal Rank Fusion 融合多通道结果。"""
    scores = {}
    rows = {}

    def add_channel(ch_results, weight):
        for rank, item in enumerate(ch_results, 1):
            row = item.get("row", item)
            mid = int(row.get("id") or 0)
            if not mid:
                continue
            scores[mid] = scores.get(mid, 0.0) + weight / (60.0 + rank)
            rows[mid] = row

    add_channel(vector_results, 1.0)
    add_channel(fts5_results, 0.8)
    add_channel(entity_results, 0.6)

    sorted_ids = sorted(scores.keys(), key=lambda k: scores[k], reverse=True)
    source_map = {}
    for item in (vector_results or []):
        mid = int(item.get("row", {}).get("id") or 0)
        if mid:
            source_map.setdefault(mid, set()).add("vector")
    for item in (fts5_results or []):
        mid = int(item.get("row", {}).get("id") or 0)
        if mid:
            source_map.setdefault(mid, set()).add("fts5")
    for item in (entity_results or []):
        mid = int(item.get("row", {}).get("id") or 0)
        if mid:
            source_map.setdefault(mid, set()).add("entity")

    return [
        {"row": rows[mid], "fused_score": scores[mid],
         "sources": sorted(source_map.get(mid, set()))}
        for mid in sorted_ids[:max(limit * 2, 20)]
    ]


def apply_temporal_filter(memories, query):
    """对检索结果施加时间感知过滤和加权。"""
    from datetime import datetime, timezone, timedelta
    now = datetime.now(timezone(timedelta(hours=8)))
    if not query:
        return memories

    temporal_map = {
        "最近": ("recent", 7), "刚刚": ("recent", 1), "刚才": ("recent", 1),
        "现在": ("current", 30), "目前": ("current", 30),
        "去年": ("year_ago", 365),
        "以前": ("past", 180), "之前": ("past", 180), "过去": ("past", 180),
        "今天": ("today", 1), "昨天": ("yesterday", 1),
        "本周": ("this_week", 7), "这周": ("this_week", 7),
        "这个月": ("this_month", 30),
    }

    mode, days = "current", 90
    for keywords, (m, d) in temporal_map.items():
        if keywords in (query or ""):
            mode, days = m, d
            break

    for item in memories:
        row = item.get("row", item)
        created = _parse_or_none(parse_datetime_local, row.get("created_at"))
        temporal_score = 0.0

        if mode in ("current", "recent", "today", "yesterday", "this_week", "this_month"):
            if created:
                age_days = (now - created).total_seconds() / 86400.0
                if age_days <= days:
                    temporal_score = 0.5 - 0.01 * max(0, age_days)
                elif age_days <= days * 3:
                    temporal_score = 0.15
            vi = _parse_or_none(parse_datetime_local, row.get("valid_until"))
            vf = _parse_or_none(parse_datetime_local, row.get("valid_from"))
            if vi and vi > now:
                temporal_score += 0.3
            if vf and vf < now:
                temporal_score += 0.15
        elif mode in ("past", "year_ago"):
            if created:
                age_days = (now - created).total_seconds() / 86400.0
                target = days * 0.7
                if abs(age_days - target) < target * 0.5:
                    temporal_score = 0.4

        if "fused_score" in item:
            item["fused_score"] = float(item.get("fused_score", 0)) + temporal_score
        elif "score" in item:
            item["score"] = float(item.get("score", 0)) + temporal_score

    return memories


def _parse_or_none(fn, val):
    if not fn or not val:
        return None
    try:
        return fn(str(val))
    except Exception:
        return None


def convert_fusion_to_result(items, limit):
    """将融合后的检索结果转为标准 memory result 格式。"""
    type_labels = {"fact": "事实", "preference": "偏好", "boundary": "底线", "experience": "共同经历"}
    seen = set()
    result = []
    for item in items:
        row = item.get("row", item)
        text = (row.get("summary") or row.get("content") or "").strip()
        key = normalize_text_key(text)
        if not text or key in seen:
            continue
        seen.add(key)
        mt = row.get("mem_type") or "fact"
        result.append({
            "id": row.get("id"),
            "content": text,
            "summary": row.get("summary") or "",
            "category": row.get("category") or "general",
            "importance": row.get("importance") or 1,
            "created_at": row.get("created_at"),
            "last_recall": row.get("last_recall"),
            "recall_count": row.get("recall_count") or 0,
            "mem_type": mt,
            "source": row.get("source") or "chat",
            "status": row.get("status") or "active",
            "confidence": row.get("confidence") or 1.0,
            "last_verified": row.get("last_verified"),
            "verified_count": row.get("verified_count") or 0,
            "type_label": type_labels.get(mt, mt),
            "score": round(float(item.get("fused_score", item.get("score", 0))), 3),
            "matched_terms": [],
            "hit_reason": ["fusion:multi_signal"] + [
                s for s in item.get("sources", [])
            ],
            "retrieval_backend": "multi_signal_fusion",
        })
        if len(result) >= limit:
            break
    return result


# =====================================================================
# 优化 3: LLM 自动提取记忆
# =====================================================================

def extract_memories_from_conversation(messages, memory_layer, max_new=3):
    """从对话中自动提取新记忆（LLM 驱动）。"""
    if not messages:
        return {"ok": False, "error": "no messages", "extracted": 0}

    conv_lines = []
    for msg in messages[-6:]:
        role = msg.get("role", "user")
        content = clean_snippet(str(msg.get("content", "")), 200)
        label = "用户" if role == "user" else "AI"
        conv_lines.append(f"{label}: {content}")
    if not conv_lines:
        return {"ok": False, "error": "empty conversation", "extracted": 0}
    conv_text = "\n".join(conv_lines)

    prompt = f"""从以下对话中提取用户的新信息（事实、偏好、底线、经历），用JSON返回。

对话:
{conv_text}

要求:
1. 只提取用户的新信息，不提取AI说的话
2. 每条标注类型: fact/ preference/ boundary/ experience
3. 标注重要性 1-5（5最重要）
4. 如果对话没有新信息，返回空数组
5. 去重：如果和已有记忆含义重复就不提

返回JSON格式:
{{"memories": [{{"content": "记忆内容（简短，20-60字）", "type": "fact", "importance": 3, "category": "general"}}]}}
只返回JSON，不要其他文本。"""

    schema = {
        "type": "object",
        "properties": {
            "memories": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "content": {"type": "string"},
                        "type": {"type": "string", "enum": ["fact", "preference", "boundary", "experience"]},
                        "importance": {"type": "integer", "minimum": 1, "maximum": 5},
                        "category": {"type": "string"},
                    },
                    "required": ["content", "type", "importance"],
                },
            },
        },
        "required": ["memories"],
    }

    try:
        import zhiyue_connected as _zc
        result = _zc._request_lm_json(
            [{"role": "user", "content": prompt}],
            "memory_extract",
            schema,
            temperature=0.3,
            max_tokens=600,
            timeout=60,
        )
        items = result.get("memories", []) if isinstance(result, dict) else []
        if not isinstance(items, list):
            items = []
    except Exception as err:
        return {"ok": False, "error": f"LLM extraction failed: {err}"[:200], "extracted": 0}

    extracted = 0
    new_memories = []
    for item in items[:max_new]:
        content = clean_snippet(str(item.get("content", "")), 120)
        if len(content) < 8:
            continue
        mem_type = item.get("type", "fact")
        importance = min(5, max(1, int(item.get("importance", 3))))
        category = clean_snippet(str(item.get("category", "general")), 40) or "general"

        # 语义去重检查
        try:
            similar = find_semantic_duplicates(content, memory_layer, threshold=0.82)
            if similar:
                continue
        except Exception:
            pass

        new_memories.append({
            "content": content, "type": mem_type,
            "importance": importance, "category": category,
        })
        extracted += 1

    return {"ok": True, "extracted": extracted, "memories": new_memories}


# =====================================================================
# 优化 4: 语义去重 + 冲突检测
# =====================================================================

def find_semantic_duplicates(content, memory_layer, threshold=0.82):
    """通过语义相似度查找可能重复的记忆。"""
    key = normalize_text_key(content)
    rows = memory_layer._load_memory_rows(limit=500)
    matches = []
    for row in rows:
        existing_key = normalize_text_key(str(row.get("content", "") or ""))
        if key and existing_key:
            if key == existing_key:
                matches.append({"row": row, "similarity": 1.0})
                continue
            min_len = min(len(key), len(existing_key))
            max_len = max(len(key), len(existing_key))
            if min_len > 0 and max_len > 0:
                common = sum(1 for a, b in zip(key, existing_key) if a == b)
                sim = common / max_len
                if sim >= threshold:
                    matches.append({"row": row, "similarity": sim})
    matches.sort(key=lambda m: m["similarity"], reverse=True)
    return matches[:3]


def detect_semantic_conflicts(content, mem_type, memory_layer):
    """检测可能矛盾的已有记忆。"""
    contradictions = {
        "preference": ["不喜欢", "讨厌", "不需要", "不再"],
        "boundary": ["不要", "不想", "不喜欢", "别"],
        "fact": ["不是", "改名", "换了", "不再是"],
    }
    triggers = contradictions.get(mem_type, [])
    has_negation = any(t in (content or "") for t in triggers)
    if not has_negation:
        return []

    clean = content or ""
    for t in triggers:
        clean = clean.replace(t, "").strip()
    key = normalize_text_key(clean)
    if len(key) < 4:
        return []

    rows = memory_layer._load_memory_rows(limit=200)
    conflicts = []
    for row in rows:
        if row.get("mem_type") != mem_type:
            continue
        existing_key = normalize_text_key(str(row.get("content", "") or ""))
        if len(existing_key) < 4:
            continue
        common_chars = len(set(key) & set(existing_key))
        total_chars = max(1, len(set(key) | set(existing_key)))
        overlap = common_chars / total_chars
        if overlap > 0.3:
            conflicts.append({
                "row": row, "overlap": round(overlap, 3),
                "reason": "possible_contradiction",
            })
    return sorted(conflicts, key=lambda c: c["overlap"], reverse=True)[:3]


def check_memory_before_add(content, category, importance, mem_type, source, confidence, status, memory_layer):
    """在写入记忆前做语义去重和冲突检测。"""
    dups = find_semantic_duplicates(content, memory_layer, threshold=0.85)
    if dups:
        dup = dups[0]
        dup_score = round(dup["similarity"], 3)
        is_exact = dup_score >= 0.98
        return {
            "ok": False if is_exact else True,
            "duplicate": is_exact,
            "deduplicated": True,
            "matched_id": dup["row"].get("id"),
            "matched_content": clean_snippet(str(dup["row"].get("content", "")), 80),
            "similarity": dup_score,
        }

    conflicts = detect_semantic_conflicts(content, mem_type, memory_layer)
    return {
        "ok": True,
        "deduplicated": False,
        "conflicts": [
            {
                "id": c["row"].get("id"),
                "content": clean_snippet(str(c["row"].get("content", "")), 80),
                "overlap": c["overlap"],
            }
            for c in conflicts
        ],
    }


# =====================================================================
# 优化 5: 记忆生命周期管理
# =====================================================================

def consolidate_memories(memory_layer, max_merge=10, min_importance=1, max_age_days=90):
    """记忆整合：合并相似记忆 + 衰减低质量记忆。"""
    rows = memory_layer._load_memory_rows(limit=2000)
    conn = memory_layer._connect()
    try:
        from datetime import datetime, timezone, timedelta
        now = datetime.now(timezone(timedelta(hours=8)))

        merged = 0
        pruned = 0

        # 1. 合并语义相似的记忆（同类型）
        seen_keys = set()
        to_merge = []
        for i, a in enumerate(rows):
            key_a = normalize_text_key(str(a.get("content", "") or ""))
            if len(key_a) < 6 or key_a in seen_keys:
                continue
            seen_keys.add(key_a)
            for j, b in enumerate(rows):
                if j <= i:
                    continue
                if a.get("mem_type") != b.get("mem_type"):
                    continue
                key_b = normalize_text_key(str(b.get("content", "") or ""))
                if len(key_b) < 6 or key_b in seen_keys:
                    continue
                min_len = min(len(key_a), len(key_b))
                max_len = max(len(key_a), len(key_b))
                if min_len < 4 or max_len < 4:
                    continue
                common = sum(1 for ca, cb in zip(key_a, key_b) if ca == cb)
                sim = common / max_len
                if sim >= 0.75:
                    to_merge.append((a, b, sim))

        to_merge.sort(key=lambda x: x[2], reverse=True)
        done_ids = set()
        for a, b, sim in to_merge[:max_merge]:
            aid = int(a.get("id") or 0)
            bid = int(b.get("id") or 0)
            if aid in done_ids or bid in done_ids:
                continue
            done_ids.add(aid)
            done_ids.add(bid)
            merged_content = clean_snippet(
                str(a.get("content", ""))[:120] + " | " + str(b.get("content", ""))[:120],
                240,
            )
            new_imp = min(5, int(a.get("importance") or 1) + int(b.get("importance") or 1))
            conn.execute(
                "UPDATE memories SET content=?, importance=?, summary=?, status='active', confidence=confidence+0.1 WHERE id=?",
                (merged_content, new_imp, merged_content[:120], aid),
            )
            conn.execute("UPDATE memories SET status='merged', confidence=0.1 WHERE id=?", (bid,))
            merged += 1

        # 2. 衰减低重要性的旧记忆
        for row in rows:
            mid = int(row.get("id") or 0)
            if mid in done_ids:
                continue
            created = _parse_or_none(parse_datetime_local, row.get("created_at"))
            if not created:
                continue
            age_days = (now - created).total_seconds() / 86400.0
            importance = int(row.get("importance") or 1)
            recall = int(row.get("recall_count") or 0)
            confidence = float(row.get("confidence") or 1.0)

            if age_days > max_age_days and importance <= min_importance and recall <= 1:
                new_conf = max(0.05, confidence - 0.15)
                conn.execute(
                    "UPDATE memories SET confidence=?, status=CASE WHEN ? < 0.1 THEN 'archived' ELSE status END WHERE id=?",
                    (new_conf, new_conf, mid),
                )
                pruned += 1

        conn.commit()
        return {"ok": True, "merged": merged, "pruned": pruned, "total_rows": len(rows)}
    finally:
        conn.close()


def run_memory_consolidation(memory_layer, max_merge=10, min_importance=1, max_age_days=90):
    """记忆整合入口。"""
    return consolidate_memories(
        memory_layer, max_merge=max_merge,
        min_importance=min_importance, max_age_days=max_age_days,
    )