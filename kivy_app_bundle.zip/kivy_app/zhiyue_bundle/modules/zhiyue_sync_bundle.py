from __future__ import annotations

import base64
import hashlib
import io
import json
import os
import sqlite3
import tempfile
import time
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from zhiyue_project_paths import (
    BASE_DIR,
    COGNITIVE_DB,
    GROWTH_DB,
    INTIMACY_FILE,
    MEMORY_DB,
    PERSONA_PROFILE_FILE,
)


def _prompt_asset_dir() -> Path:
    configured = os.environ.get("ZHIYUE_PROMPT_ASSET_DIR", "").strip()
    if configured:
        return Path(configured).expanduser().resolve()
    return (BASE_DIR / "data" / "prompt_assets").resolve()


PROMPT_ASSET_DIR = _prompt_asset_dir()
PROMPT_ASSET_DIR.mkdir(parents=True, exist_ok=True)


SYNC_PATHS: list[tuple[str, Path]] = [
    ("data/zhiyue_memory.db", Path(str(MEMORY_DB)).resolve()),
    ("data/zhiyue_growth.db", Path(str(GROWTH_DB)).resolve()),
    ("data/zhiyue_cognitive.db", Path(str(COGNITIVE_DB)).resolve()),
    ("data/zhiyue_intimacy.json", Path(str(INTIMACY_FILE)).resolve()),
    ("data/zhiyue_persona_profile.json", Path(str(PERSONA_PROFILE_FILE)).resolve()),
    ("data/prompt_assets", PROMPT_ASSET_DIR),
]


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _read_bytes(path: Path) -> bytes:
    return path.read_bytes() if path.is_file() else b""


def build_sync_bundle() -> dict[str, Any]:
    """Return {"archive_b64": str, "sha256": str, "files": {name: {...}}, "sent_at": iso}."""
    files_meta: dict[str, Any] = {}
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for name, path in SYNC_PATHS:
            if path.is_dir():
                # Store directory contents with stable relative paths.
                for child in sorted(path.rglob("*")):
                    if not child.is_file():
                        continue
                    rel = child.relative_to(path).as_posix()
                    arc = f"{name.rstrip('/')}/{rel}"
                    data = child.read_bytes()
                    zf.writestr(arc, data)
                    files_meta[arc] = {
                        "sha256": _sha256_bytes(data),
                        "size": len(data),
                    }
            else:
                if not path.exists():
                    continue
                data = b""
                # For sqlite DBs, snapshot via sqlite backup so WAL changes are included.
                if path.suffix.lower() == ".db":
                    backed_up = False
                    last_err: Exception | None = None
                    for _ in range(5):
                        try:
                            with tempfile.TemporaryDirectory(prefix="zhiyue_db_snapshot_") as t:
                                snap = Path(t) / path.name
                                src = sqlite3.connect(str(path), timeout=5.0)
                                try:
                                    try:
                                        src.execute("PRAGMA busy_timeout=5000")
                                    except Exception:
                                        pass
                                    dst = sqlite3.connect(str(snap), timeout=5.0)
                                    try:
                                        src.backup(dst)
                                    finally:
                                        dst.close()
                                finally:
                                    src.close()
                                data = snap.read_bytes()
                                backed_up = True
                                break
                        except Exception as err:
                            last_err = err
                            time.sleep(0.2)
                    if not backed_up:
                        data = _read_bytes(path)
                else:
                    data = _read_bytes(path)
                zf.writestr(name, data)
                files_meta[name] = {
                    "sha256": _sha256_bytes(data),
                    "size": len(data),
                }
    archive = buf.getvalue()
    return {
        "archive_b64": base64.b64encode(archive).decode("ascii"),
        "sha256": _sha256_bytes(archive),
        "files": files_meta,
    }


def _merge_memory_db(dst_db: Path, src_db: Path) -> dict[str, Any]:
    """Merge src memories into dst by content_key (from memory_retrieval_index)."""
    if not dst_db.exists() or not src_db.exists():
        return {"ok": False, "error": "missing_db"}
    added = 0
    updated = 0
    merged_events = 0
    try:
        dst = sqlite3.connect(str(dst_db))
        src = sqlite3.connect(str(src_db))
        dst.row_factory = sqlite3.Row
        src.row_factory = sqlite3.Row

        # Map existing content_keys
        existing_keys = set()
        for row in dst.execute("SELECT content_key FROM memory_retrieval_index"):
            key = str(row["content_key"] or "").strip()
            if key:
                existing_keys.add(key)

        # Import new memories by content_key. For existing memories, merge basic usage stats.
        src_rows = src.execute(
            "SELECT memory_id, content_key FROM memory_retrieval_index ORDER BY memory_id"
        ).fetchall()
        for row in src_rows:
            content_key = str(row["content_key"] or "").strip()
            memory_id = int(row["memory_id"] or 0)
            if not content_key or memory_id <= 0:
                continue
            if content_key in existing_keys:
                try:
                    src_mem = src.execute("SELECT recall_count, last_recall FROM memories WHERE id=?", (memory_id,)).fetchone()
                    dst_mem = dst.execute(
                        """
                        SELECT m.id, m.recall_count, m.last_recall
                        FROM memories m
                        JOIN memory_retrieval_index idx ON idx.memory_id=m.id
                        WHERE idx.content_key=?
                        """,
                        (content_key,),
                    ).fetchone()
                    if src_mem and dst_mem:
                        src_rc = int(src_mem["recall_count"] or 0)
                        dst_rc = int(dst_mem["recall_count"] or 0)
                        src_lr = str(src_mem["last_recall"] or "")
                        dst_lr = str(dst_mem["last_recall"] or "")
                        new_rc = max(src_rc, dst_rc)
                        new_lr = max(src_lr, dst_lr) if (src_lr and dst_lr) else (src_lr or dst_lr)
                        if new_rc != dst_rc or new_lr != dst_lr:
                            dst.execute(
                                "UPDATE memories SET recall_count=?, last_recall=? WHERE id=?",
                                (new_rc, new_lr, int(dst_mem["id"] or 0)),
                            )
                            updated += 1
                except Exception:
                    pass
                continue
            mem = src.execute("SELECT * FROM memories WHERE id=?", (memory_id,)).fetchone()
            idx = src.execute("SELECT * FROM memory_retrieval_index WHERE memory_id=?", (memory_id,)).fetchone()
            if not mem or not idx:
                continue

            # Insert memory (let AUTOINCREMENT allocate new id)
            cur = dst.execute(
                """
                INSERT INTO memories (
                    content, category, importance, summary, created_at, last_recall, recall_count,
                    mem_type, source, status, confidence, last_verified, verified_count,
                    scope, allow_chat_inject, expires_at, valid_from, valid_until
                ) VALUES (
                    ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?
                )
                """,
                (
                    mem["content"],
                    mem["category"],
                    mem["importance"],
                    mem["summary"],
                    mem["created_at"],
                    mem["last_recall"],
                    mem["recall_count"],
                    mem["mem_type"],
                    mem["source"],
                    mem["status"],
                    mem["confidence"],
                    mem["last_verified"],
                    mem["verified_count"],
                    mem["scope"],
                    mem["allow_chat_inject"],
                    mem["expires_at"],
                    mem["valid_from"],
                    mem["valid_until"],
                ),
            )
            new_id = int(cur.lastrowid or 0)
            if new_id <= 0:
                continue
            dst.execute(
                """
                INSERT INTO memory_retrieval_index (
                    memory_id, search_text, tokens_json, content_key, mem_type, category, source, indexed_at
                ) VALUES (?,?,?,?,?,?,?,?)
                """,
                (
                    new_id,
                    idx["search_text"],
                    idx["tokens_json"],
                    content_key,
                    idx["mem_type"],
                    idx["category"],
                    idx["source"],
                    idx["indexed_at"],
                ),
            )
            existing_keys.add(content_key)
            added += 1

        # Merge events with conservative de-duplication.
        # Some platforms may format created_at differently; prefer (title,date) as the primary key.
        dst_events_full = set(
            (str(r[0] or ""), str(r[1] or ""), str(r[2] or ""))
            for r in dst.execute("SELECT title, date, created_at FROM events").fetchall()
        )
        dst_events_simple = set(
            (str(r[0] or ""), str(r[1] or ""))
            for r in dst.execute("SELECT title, date FROM events").fetchall()
        )
        for r in src.execute("SELECT title, date, created_at, notified FROM events").fetchall():
            title = str(r[0] or "")
            date = str(r[1] or "")
            created_at = str(r[2] or "")
            key_full = (title, date, created_at)
            if key_full in dst_events_full or (title, date) in dst_events_simple:
                continue
            dst.execute(
                "INSERT INTO events(title, date, created_at, notified) VALUES (?,?,?,?)",
                (title, date, created_at, int(r[3] or 0)),
            )
            dst_events_full.add(key_full)
            dst_events_simple.add((title, date))
            merged_events += 1

        # Rebuild FTS after inserts (safe even if no new rows)
        try:
            dst.execute("INSERT INTO memory_fts5(memory_fts5) VALUES('rebuild')")
        except Exception:
            pass
        dst.commit()
        return {"ok": True, "added_memories": added, "updated_memories": updated, "added_events": merged_events}
    except Exception as err:
        return {"ok": False, "error": str(err)[:200]}
    finally:
        try:
            dst.close()
        except Exception:
            pass
        try:
            src.close()
        except Exception:
            pass


def apply_sync_bundle(bundle: dict[str, Any], *, prefer_incoming_files: bool = True) -> dict[str, Any]:
    """Apply bundle to local filesystem. Memory DB is merged; JSON/files are last-write-wins."""
    archive_b64 = str((bundle or {}).get("archive_b64") or "").strip()
    if not archive_b64:
        return {"ok": False, "error": "missing_archive"}
    try:
        archive = base64.b64decode(archive_b64.encode("ascii"), validate=False)
    except Exception:
        return {"ok": False, "error": "invalid_archive_b64"}

    incoming_sha = _sha256_bytes(archive)
    expected_sha = str((bundle or {}).get("sha256") or "").strip()
    if expected_sha and expected_sha != incoming_sha:
        return {"ok": False, "error": "sha256_mismatch"}

    with tempfile.TemporaryDirectory(prefix="zhiyue_sync_") as tmp:
        tmpdir = Path(tmp)
        with zipfile.ZipFile(io.BytesIO(archive), "r") as zf:
            zf.extractall(tmpdir)

        results: dict[str, Any] = {"ok": True, "memory": None, "files": {}}

        # 1) Merge memory db
        incoming_memory = tmpdir / "data" / "zhiyue_memory.db"
        if incoming_memory.exists():
            results["memory"] = _merge_memory_db(Path(str(MEMORY_DB)).resolve(), incoming_memory)

        # 2) Last-write-wins for other DBs and JSON/files.
        def _apply_file(rel: str, dst: Path) -> None:
            src = tmpdir / rel
            if not src.exists() or not src.is_file():
                return
            dst.parent.mkdir(parents=True, exist_ok=True)
            if dst.exists() and not prefer_incoming_files:
                return
            dst.write_bytes(src.read_bytes())
            results["files"][rel] = {"applied": True, "bytes": dst.stat().st_size}

        _apply_file("data/zhiyue_growth.db", Path(str(GROWTH_DB)).resolve())
        _apply_file("data/zhiyue_cognitive.db", Path(str(COGNITIVE_DB)).resolve())
        _apply_file("data/zhiyue_intimacy.json", Path(str(INTIMACY_FILE)).resolve())
        _apply_file("data/zhiyue_persona_profile.json", Path(str(PERSONA_PROFILE_FILE)).resolve())

        incoming_assets = tmpdir / "data" / "prompt_assets"
        if incoming_assets.exists() and incoming_assets.is_dir():
            for child in sorted(incoming_assets.rglob("*")):
                if not child.is_file():
                    continue
                rel = child.relative_to(incoming_assets).as_posix()
                dst = PROMPT_ASSET_DIR / rel
                dst.parent.mkdir(parents=True, exist_ok=True)
                if dst.exists() and not prefer_incoming_files:
                    continue
                dst.write_bytes(child.read_bytes())
                results["files"][f"data/prompt_assets/{rel}"] = {"applied": True, "bytes": dst.stat().st_size}

        return results
