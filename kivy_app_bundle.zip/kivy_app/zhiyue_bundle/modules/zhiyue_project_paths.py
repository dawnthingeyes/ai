from __future__ import annotations

import os
import shutil
from pathlib import Path


def _project_root() -> Path:
    configured = os.environ.get("ZHIYUE_PROJECT_DIR", "").strip()
    if configured:
        return Path(configured).expanduser().resolve()
    return Path(__file__).resolve().parent.parent


def _load_env_file(base_dir: Path) -> None:
    env_path = base_dir / ".env"
    if not env_path.is_file():
        return
    os.environ.setdefault("ZHIYUE_PROJECT_DIR", str(base_dir))
    for raw_line in env_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        if not key or key in os.environ:
            continue
        normalized = os.path.expandvars(value.strip().strip('"').strip("'"))
        path_like = (
            key.endswith(("_DIR", "_DB", "_FILE", "_PATH", "_ROOT"))
            or (key.endswith("_MODEL") and "://" not in normalized and any(sep in normalized for sep in ("/", "\\")))
        )
        if path_like:
            path = Path(normalized).expanduser()
            if not path.is_absolute():
                path = base_dir / path
            normalized = str(path.resolve())
        os.environ[key] = normalized


BASE_DIR = _project_root()
_load_env_file(BASE_DIR)
SOURCE_DIR = BASE_DIR
DATA_DIR = Path(os.environ.get("ZHIYUE_DATA_DIR", str(BASE_DIR / "data"))).resolve()
RUNTIME_DIR = Path(os.environ.get("ZHIYUE_RUNTIME_DIR", str(BASE_DIR / "runtime"))).resolve()
ARTIFACTS_DIR = Path(os.environ.get("ZHIYUE_ARTIFACTS_DIR", str(BASE_DIR / "artifacts"))).resolve()


def ensure_project_layout() -> None:
    for path in (
        DATA_DIR,
        RUNTIME_DIR,
        ARTIFACTS_DIR,
        ARTIFACTS_DIR / "audits",
        ARTIFACTS_DIR / "audio",
        RUNTIME_DIR / "monitor",
        RUNTIME_DIR / "logs",
        RUNTIME_DIR / "weixin",
    ):
        path.mkdir(parents=True, exist_ok=True)


def _target_root(bucket: str) -> Path:
    roots = {
        "data": DATA_DIR,
        "runtime": RUNTIME_DIR,
        "artifacts": ARTIFACTS_DIR,
    }
    return roots[bucket]


def _migrate_legacy_file(target: Path, legacy_names: tuple[str, ...]) -> None:
    if target.exists():
        return
    for legacy_name in legacy_names:
        legacy_path = BASE_DIR / legacy_name
        if not legacy_path.exists() or legacy_path.resolve() == target.resolve():
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        try:
            shutil.move(str(legacy_path), str(target))
            return
        except Exception:
            try:
                shutil.copy2(str(legacy_path), str(target))
                return
            except Exception:
                continue


def managed_path(
    env_var: str,
    default_relative: str,
    *,
    bucket: str,
    legacy_names: tuple[str, ...] = (),
) -> Path:
    env_value = os.environ.get(env_var, "").strip()
    if env_value:
        target = Path(env_value).expanduser()
    else:
        base = _target_root(bucket)
        # Optional per-profile isolation for multi-persona setups.
        # Only affects the data bucket by default; runtime/artifacts remain shared.
        profile_id = os.environ.get("ZHIYUE_PROFILE_ID", "").strip()
        if bucket == "data" and profile_id and profile_id.lower() not in {"default", "main"}:
            target = base / "profiles" / profile_id / default_relative
        else:
            target = base / default_relative
    target = target.resolve()
    target.parent.mkdir(parents=True, exist_ok=True)
    if not env_value:
        _migrate_legacy_file(target, legacy_names or (Path(default_relative).name,))
    return target


ensure_project_layout()

MEMORY_DB = managed_path("ZHIYUE_MEMORY_DB", "zhiyue_memory.db", bucket="data")
GROWTH_DB = managed_path("ZHIYUE_GROWTH_DB", "zhiyue_growth.db", bucket="data")
OBSERVABILITY_DB = managed_path("ZHIYUE_OBSERVABILITY_DB", "zhiyue_observability.db", bucket="data")
COGNITIVE_DB = managed_path("ZHIYUE_COGNITIVE_DB", "zhiyue_cognitive.db", bucket="data")
INTIMACY_FILE = managed_path("ZHIYUE_INTIMACY_FILE", "zhiyue_intimacy.json", bucket="data")
PERSONA_PROFILE_FILE = managed_path("ZHIYUE_PERSONA_PROFILE_FILE", "zhiyue_persona_profile.json", bucket="data")
VOICE_PROFILE_FILE = managed_path("ZHIYUE_VOICE_PROFILE_FILE", "zhiyue_voice_profile.json", bucket="data")
EMOJI_MANIFEST_PATH = managed_path("ZHIYUE_EMOJI_MANIFEST_FILE", "emoji_manifest.json", bucket="data")
EMOJI_REVIEW_STATE_PATH = managed_path("ZHIYUE_EMOJI_REVIEW_STATE_FILE", "zhiyue_emoji_review_state.json", bucket="data")
IMAGE_MANIFEST_PATH = managed_path("ZHIYUE_IMAGE_MANIFEST_FILE", "image_manifest.json", bucket="data")
WEIXIN_CONFIG_FILE = managed_path("ZHIYUE_WEIXIN_CONFIG_FILE", "zhiyue_weixin_config.json", bucket="data")
LLM_PROVIDER_CONFIG_FILE = managed_path("ZHIYUE_LLM_PROVIDER_CONFIG_FILE", "zhiyue_llm_provider_config.json", bucket="data")
REMOTE_CONTROL_PROVIDER_FILE = managed_path(
    "ZHIYUE_REMOTE_CONTROL_PROVIDER_FILE",
    "zhiyue_remote_control_provider.json",
    bucket="data",
)

WEIXIN_QUEUE_FILE = managed_path("ZHIYUE_WEIXIN_QUEUE_FILE", "weixin/zhiyue_weixin_queue.json", bucket="runtime")
WEIXIN_STATE_FILE = managed_path("ZHIYUE_WEIXIN_STATE_FILE", "weixin/zhiyue_weixin_state.json", bucket="runtime")
WEIXIN_DEAD_LETTER_FILE = managed_path("ZHIYUE_WEIXIN_DEAD_LETTER_FILE", "weixin/zhiyue_weixin_dead_letter.json", bucket="runtime")
WEIXIN_LOG_FILE = managed_path("ZHIYUE_WEIXIN_LOG_FILE", "logs/zhiyue_weixin_direct.log", bucket="runtime")
SHUTDOWN_STATE_FILE = managed_path(
    "ZHIYUE_SHUTDOWN_STATE_FILE",
    "shutdown/zhiyue_shutdown_state.json",
    bucket="runtime",
    legacy_names=("zhiyue_shutdown_state.json",),
)
GATEWAY_LOCK_FILE = managed_path("ZHIYUE_GATEWAY_LOCK_FILE", ".zhiyue_gateway.lock", bucket="runtime")
API_CHAT_ERROR_LOG = managed_path("ZHIYUE_API_CHAT_ERROR_LOG", "logs/api_chat_errors.log", bucket="runtime")
TOOL_LOOP_LOG = managed_path("ZHIYUE_TOOL_LOOP_LOG", "logs/tool_loop.log", bucket="runtime")
SELF_MONITOR_LOG_FILE = managed_path("ZHIYUE_SELF_MONITOR_LOG_FILE", "monitor/zhiyue_self_monitor.log", bucket="runtime")
SELF_MONITOR_STATE_FILE = managed_path("ZHIYUE_SELF_MONITOR_STATE_FILE", "monitor/zhiyue_self_monitor_state.json", bucket="runtime")
SELF_MONITOR_PROPOSAL_FILE = managed_path("ZHIYUE_SELF_MONITOR_PROPOSAL_FILE", "monitor/zhiyue_self_improvement_queue.json", bucket="runtime")
SELF_MONITOR_PROPOSAL_ARCHIVE_FILE = managed_path("ZHIYUE_SELF_MONITOR_PROPOSAL_ARCHIVE_FILE", "monitor/zhiyue_self_improvement_queue.archive.json", bucket="runtime")
SELF_MONITOR_FINDINGS_FILE = managed_path("ZHIYUE_SELF_MONITOR_FINDINGS_FILE", "monitor/zhiyue_self_monitor_findings.jsonl", bucket="runtime")

EMOJI_AUDIT_PATH = managed_path("ZHIYUE_EMOJI_AUDIT_FILE", "audits/zhiyue_emoji_audit.jsonl", bucket="artifacts")
OFFICE_AUDIT_FILE = managed_path("ZHIYUE_OFFICE_AUDIT_FILE", "audits/zhiyue_office_audit.jsonl", bucket="artifacts")
WEIXIN_MEDIA_AUDIT_FILE = managed_path("ZHIYUE_WEIXIN_MEDIA_AUDIT_FILE", "audits/zhiyue_weixin_media_audit.jsonl", bucket="artifacts")
REPLY_CACHE_DB = managed_path("ZHIYUE_REPLY_CACHE_DB", "zhiyue_reply_cache.db", bucket="data")
