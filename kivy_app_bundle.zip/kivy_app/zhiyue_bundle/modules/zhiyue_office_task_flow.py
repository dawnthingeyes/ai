# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import os
import re
from datetime import datetime
from pathlib import Path
from typing import Any

import requests
import zhiyue_companion_policy as companion_policy
from zhiyue_project_paths import BASE_DIR, OFFICE_AUDIT_FILE as _OFFICE_AUDIT_FILE
from zhiyue_llm_provider import post_chat_completion as _provider_post_chat_completion

_office_context_state: dict[str, Any] = {}
_OFFICE_CONTEXT_FILE = BASE_DIR / "zhiyue_office_context.json"
_SUPPORTED_LOCAL_SUFFIXES = {".pdf", ".xlsx", ".docx", ".txt", ".md"}
_SUPPORTED_INTENT_KINDS = {"local_file", "browser_read", "browser_fill", "local_file_delete", "local_doc_rewrite"}
_SUPPORTED_OBJECTIVES = {"read", "summary", "meeting_notes", "todo_list", "quiz_select", "form_fill", "delete", "rewrite"}
_SUPPORTED_RESPONSE_MODES = {"direct_return", "write_artifact", "both"}


def _looks_like_low_state(msg: str) -> bool:
    """Delegate low-state detection to the companion policy classifier."""
    try:
        return bool(companion_policy.should_short_circuit_low_state(msg))
    except Exception:
        return False


def _extract_url(text: str) -> str:
    match = re.search(r"https?://[^\s]+", text or "", flags=re.I)
    return match.group(0) if match else ""


def _extract_explicit_path(text: str) -> str:
    match = re.search(r"([A-Za-z]:[/\\\\][^\s]+)", text or "")
    return match.group(1) if match else ""


def _load_json_file(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def _write_json_file(path: Path, data: Any) -> None:
    try:
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        return


def _append_office_audit(stage: str, *, channel: str, user_msg: str, payload: dict[str, Any]) -> None:
    entry = {
        "created_at": datetime.now().isoformat(),
        "stage": stage,
        "channel": channel,
        "user_msg": (user_msg or "")[:500],
        "payload": payload,
    }
    try:
        with _OFFICE_AUDIT_FILE.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(entry, ensure_ascii=False) + "\n")
    except Exception:
        return


def _context_key(channel: str | None = None) -> str:
    value = str(channel or "").strip()
    return value or "default"


def _recent_office_context(channel: str | None = None) -> dict[str, Any]:
    key = _context_key(channel)
    if isinstance(_office_context_state.get(key), dict):
        return dict(_office_context_state.get(key) or {})
    legacy_keys = {"kind", "source_path", "output_path", "url", "title", "file_name", "objective", "extra"}
    if legacy_keys & set(_office_context_state.keys()):
        legacy_state = {k: _office_context_state.get(k) for k in legacy_keys if k in _office_context_state}
        if legacy_state.get("kind"):
            return dict(legacy_state)
    data = _load_json_file(_OFFICE_CONTEXT_FILE, {})
    state = data.get(key) if isinstance(data, dict) and isinstance(data.get(key), dict) else {}
    if state:
        _office_context_state[key] = dict(state)
    return dict(state)


def _remember_office_context(
    *,
    channel: str | None = None,
    kind: str,
    source_path: str = "",
    output_path: str = "",
    url: str = "",
    title: str = "",
    file_name: str = "",
    objective: str = "",
    response_mode: str = "write_artifact",
    extra: dict[str, Any] | None = None,
) -> None:
    key = _context_key(channel)
    state = {
        "kind": kind,
        "source_path": source_path,
        "output_path": output_path,
        "url": url,
        "title": title,
        "file_name": file_name or (Path(source_path).name if source_path else ""),
        "objective": objective,
        "response_mode": response_mode,
        "extra": dict(extra or {}),
    }
    _office_context_state[key] = dict(state)
    data = _load_json_file(_OFFICE_CONTEXT_FILE, {})
    data = data if isinstance(data, dict) else {}
    data[key] = dict(state)
    _write_json_file(_OFFICE_CONTEXT_FILE, data)


def _call_lm_json(*, system_prompt: str, user_payload: dict[str, Any], timeout: int = 45) -> dict[str, Any]:
    response = _provider_post_chat_completion(
        "main",
        {
            "model": os.environ.get("ZHIYUE_LM_MODEL", "qwen/qwen3.6-35b-a3b").strip() or "default",
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": json.dumps(user_payload, ensure_ascii=False)},
            ],
            "stream": False,
            "temperature": 0.1,
            "max_tokens": 1200,
            "think_disabled": True,
        },
        timeout=timeout,
    )
    response.raise_for_status()
    data = response.json()
    choices = data.get("choices") or []
    message = choices[0].get("message") if choices and isinstance(choices[0], dict) else {}
    raw = str((message or {}).get("content") or "").strip()
    raw = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw, flags=re.I | re.M).strip()
    return json.loads(raw) if raw else {}


def _detect_office_intent_with_model(
    user_msg: str,
    *,
    channel: str,
    recent_context: dict[str, Any],
    explicit_path: str,
    explicit_url: str,
) -> dict[str, Any]:
    system_prompt = (
        "你是本地陪伴式办公 agent 的任务分析器。"
        "不要做关键词匹配式回答，而要根据真实目标、最近上下文、对象位置、产物约束和交互方式做结构化判断。"
        "只输出 JSON。"
        "JSON schema: {"
        '"matched": boolean,'
        '"kind": "local_file"|"browser_read"|"browser_fill"|"local_file_delete"|"local_doc_rewrite"|"none",'
        '"objective": "read"|"summary"|"meeting_notes"|"todo_list"|"quiz_select"|"form_fill"|"delete"|"rewrite"|"none",'
        '"interaction": "interactive"|"one_shot",'
        '"scope_preference": "desktop"|"downloads"|"documents"|"workspace"|"any",'
        '"uses_recent_context": boolean,'
        '"path_hint": string,'
        '"url": string,'
        '"instruction": string,'
        '"response_mode": "direct_return"|"write_artifact"|"both",'
        '"execution_plan": [string],'
        '"confidence": number,'
        '"reason": string'
        "}."
        "如果用户明确说不要生成文件，response_mode 必须是 direct_return。"
        "如果用户要你读本地材料后直接总结、筛题、出题，这仍然是 local_file。"
        "如果用户要求继续刚才处理过的文件、网页或产物，uses_recent_context 必须为 true。"
        "如果不是办公执行目标，而是闲聊、情绪对话或纯技术讨论，则 matched=false。"
    )
    payload = {
        "channel": channel,
        "user_msg": user_msg,
        "recent_context": recent_context,
        "explicit_path": explicit_path,
        "explicit_url": explicit_url,
    }
    return _call_lm_json(system_prompt=system_prompt, user_payload=payload)


def _normalize_intent(
    raw: dict[str, Any],
    *,
    channel: str,
    recent_context: dict[str, Any],
    explicit_path: str,
    explicit_url: str,
    user_msg: str,
) -> dict[str, Any]:
    raw = raw if isinstance(raw, dict) else {}
    kind = str(raw.get("kind") or "none").strip()
    objective = str(raw.get("objective") or "none").strip()
    interaction = "interactive" if str(raw.get("interaction") or "").strip() == "interactive" else "one_shot"
    matched = bool(raw.get("matched"))
    uses_recent = bool(raw.get("uses_recent_context"))
    path_hint = str(raw.get("path_hint") or "").strip()
    url = str(raw.get("url") or "").strip()
    instruction = str(raw.get("instruction") or "").strip()
    scope = str(raw.get("scope_preference") or "any").strip() or "any"
    confidence = float(raw.get("confidence") or 0)
    response_mode = str(raw.get("response_mode") or "write_artifact").strip() or "write_artifact"
    execution_plan = raw.get("execution_plan") if isinstance(raw.get("execution_plan"), list) else []
    execution_plan = [str(item).strip() for item in execution_plan if str(item).strip()]

    if kind == "quiz_select":
        kind = "local_file"
        objective = "quiz_select"
        interaction = "interactive"
    elif kind in {"summary", "meeting_notes", "todo_list", "read"}:
        objective = objective if objective in _SUPPORTED_OBJECTIVES else kind
        kind = "local_file"
    elif kind == "delete":
        kind = "local_file_delete"
        objective = "delete"
    elif kind == "rewrite":
        kind = "local_doc_rewrite"
        objective = "rewrite"
    elif kind == "form_fill":
        kind = "browser_fill"
        objective = "form_fill"

    if objective not in _SUPPORTED_OBJECTIVES:
        objective = "read" if kind in {"local_file", "browser_read"} else "none"
    if response_mode not in _SUPPORTED_RESPONSE_MODES:
        response_mode = "write_artifact"

    if explicit_url:
        url = explicit_url
        if kind == "none":
            kind = "browser_fill" if objective == "form_fill" else "browser_read"
        matched = True
    if explicit_path:
        path_hint = explicit_path
        if kind == "none":
            kind = "local_file"
        matched = True
    elif path_hint.lower() in {"desktop", "downloads", "documents", "workspace", "any"}:
        if scope == "any":
            scope = path_hint.lower()
        path_hint = ""

    if uses_recent:
        recent_path = str(recent_context.get("output_path") or recent_context.get("source_path") or "").strip()
        recent_url = str(recent_context.get("url") or "").strip()
        if kind in {"local_file_delete", "local_doc_rewrite", "local_file"} and recent_path:
            path_hint = recent_path
            matched = True
        if kind == "browser_read" and recent_url:
            url = recent_url
            matched = True

    matched = matched and kind in _SUPPORTED_INTENT_KINDS
    if not execution_plan:
        if kind == "local_file" and objective == "quiz_select":
            execution_plan = ["locate_local_file", "extract_content", "plan_quiz", "respond"]
        elif kind == "local_file":
            execution_plan = ["locate_local_file", "extract_content", "respond"]
        elif kind == "local_file_delete":
            execution_plan = ["delete_local_file", "respond"]
        elif kind == "local_doc_rewrite":
            execution_plan = ["rewrite_local_file", "respond"]
        elif kind == "browser_read":
            execution_plan = ["read_browser_page", "respond"]
        elif kind == "browser_fill":
            execution_plan = ["prepare_browser_fill", "respond"]

    intent = {
        "matched": matched,
        "kind": kind if matched else "none",
        "objective": objective if matched else "none",
        "interaction": interaction,
        "scope_preference": scope if scope in {"desktop", "downloads", "documents", "workspace", "any"} else "any",
        "path_hint": path_hint,
        "url": url,
        "instruction": instruction,
        "response_mode": response_mode,
        "execution_plan": execution_plan,
        "from_recent_context": uses_recent,
        "channel": channel,
        "query": user_msg,
        "confidence": confidence,
        "reason": str(raw.get("reason") or "").strip(),
    }
    return intent if intent["matched"] else {"matched": False}


def detect_office_task_intent(user_msg: str, channel: str | None = None, history: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    msg = (user_msg or "").strip()
    if not msg:
        return {"matched": False}
    # Emotional guard: defer to companion policy when user is in low state
    if _looks_like_low_state(msg):
        return {"matched": False}
    try:
        if companion_policy.should_shutdown_request(msg):
            return {"matched": False}
    except Exception:
        return {"matched": False}
    try:
        if companion_policy.should_shutdown_confirmation(msg, history=history):
            return {"matched": False}
    except Exception:
        return {"matched": False}
    channel_key = _context_key(channel)
    recent = _recent_office_context(channel_key)
    explicit_path = _extract_explicit_path(msg)
    explicit_url = _extract_url(msg)
    try:
        raw = _detect_office_intent_with_model(
            msg,
            channel=channel_key,
            recent_context=recent,
            explicit_path=explicit_path,
            explicit_url=explicit_url,
        )
        intent = _normalize_intent(
            raw,
            channel=channel_key,
            recent_context=recent,
            explicit_path=explicit_path,
            explicit_url=explicit_url,
            user_msg=msg,
        )
    except Exception as err:
        intent = {"matched": False, "error": str(err)}
        if explicit_url:
            intent = {
                "matched": True,
                "kind": "browser_read",
                "objective": "read",
                "interaction": "one_shot",
                "scope_preference": "any",
                "path_hint": "",
                "url": explicit_url,
                "instruction": "",
                "response_mode": "direct_return",
                "execution_plan": ["read_browser_page", "respond"],
                "from_recent_context": False,
                "channel": channel_key,
                "query": msg,
                "confidence": 0.0,
                "reason": "fallback explicit url",
            }
        elif explicit_path:
            intent = {
                "matched": True,
                "kind": "local_file",
                "objective": "read",
                "interaction": "one_shot",
                "scope_preference": "any",
                "path_hint": explicit_path,
                "url": "",
                "instruction": "",
                "response_mode": "direct_return",
                "execution_plan": ["locate_local_file", "read_local_file", "respond"],
                "from_recent_context": False,
                "channel": channel_key,
                "query": msg,
                "confidence": 0.0,
                "reason": "fallback explicit path",
            }
    _append_office_audit("intent_detect", channel=channel_key, user_msg=msg, payload=intent if isinstance(intent, dict) else {"matched": False})
    return intent


def _candidate_roots(layers, scope_preference: str) -> list[Path]:
    roots = [Path(item) for item in (getattr(layers.config, "local_read_roots", []) or [])]
    if scope_preference == "any":
        return roots
    scoped = [root for root in roots if scope_preference in root.name.lower()]
    return scoped or roots


def _list_candidate_files(layers, *, scope_preference: str, limit: int = 80) -> list[Path]:
    items: list[tuple[float, Path]] = []
    for root in _candidate_roots(layers, scope_preference):
        if not root.exists():
            continue
        try:
            for path in root.rglob("*"):
                if not path.is_file() or path.suffix.lower() not in _SUPPORTED_LOCAL_SUFFIXES:
                    continue
                try:
                    mtime = path.stat().st_mtime
                except Exception:
                    mtime = 0.0
                items.append((mtime, path))
        except Exception:
            continue
    items.sort(key=lambda item: item[0], reverse=True)
    return [path for _, path in items[:limit]]


def _choose_candidate_with_model(user_msg: str, *, channel: str, intent: dict[str, Any], candidates: list[Path]) -> Path | None:
    if not candidates:
        return None
    if len(candidates) == 1:
        return candidates[0]
    system_prompt = (
        "你是本地办公文件选择器。"
        "根据用户真实目标、最近上下文、执行计划和候选文件列表，选出最可能的目标文件。"
        "只输出 JSON。schema: {\"selected_index\": integer, \"reason\": string}。"
        "selected_index 从 0 开始；如果都不合适，输出 -1。"
    )
    payload = {
        "channel": channel,
        "user_msg": user_msg,
        "intent": intent,
        "instruction": str(intent.get("instruction") or "").strip(),
        "execution_plan": intent.get("execution_plan") or [],
        "candidates": [
            {
                "index": idx,
                "name": path.name,
                "path": str(path),
                "suffix": path.suffix.lower(),
            }
            for idx, path in enumerate(candidates[:40])
        ],
    }
    try:
        result = _call_lm_json(system_prompt=system_prompt, user_payload=payload, timeout=30)
        index = int(result.get("selected_index"))
    except Exception:
        return candidates[0]
    return candidates[index] if 0 <= index < min(len(candidates), 40) else None


def _resolve_local_candidate(layers, *, user_msg: str, intent: dict[str, Any], channel: str) -> Path | None:
    if intent.get("path_hint"):
        candidate = Path(str(intent.get("path_hint")))
        return candidate if candidate.exists() else candidate
    candidates = _list_candidate_files(layers, scope_preference=str(intent.get("scope_preference") or "any"))
    return _choose_candidate_with_model(user_msg, channel=channel, intent=intent, candidates=candidates)


def _read_text_if_exists(path: str, *, limit: int = 3200) -> str:
    if not path:
        return ""
    file_path = Path(path)
    if not file_path.exists() or not file_path.is_file():
        return ""
    if file_path.suffix.lower() not in {".md", ".txt", ".json", ".csv"}:
        return ""
    try:
        return file_path.read_text(encoding="utf-8", errors="replace")[:limit]
    except Exception:
        return ""


def _summarize_direct_return_with_model(*, user_msg: str, file_name: str, objective: str, instruction: str, source_preview: str, extracted_preview: str) -> dict[str, Any]:
    system_prompt = (
        "你是陪伴式办公助理里的直接回传整理器。"
        "用户已经明确要求不要生成文件，或者希望你直接把结果发给他。"
        "根据用户目标、原始材料预览和提取后的整理内容，输出适合直接聊天发送的精炼结果。"
        "只输出 JSON。schema: {\"lead\": string, \"body\": string, \"bullets\": [string]}。"
        "如果是公式总结类任务，要优先给公式、适用条件和相关题型。"
        "语言要自然，不要系统播报口吻。"
    )
    payload = {
        "user_msg": user_msg,
        "file_name": file_name,
        "objective": objective,
        "instruction": instruction,
        "source_preview": source_preview[:1600],
        "extracted_preview": extracted_preview[:2400],
    }
    result = _call_lm_json(system_prompt=system_prompt, user_payload=payload, timeout=45)
    bullets = result.get("bullets") if isinstance(result.get("bullets"), list) else []
    return {
        "lead": str(result.get("lead") or "").strip(),
        "body": str(result.get("body") or "").strip(),
        "bullets": [str(item).strip() for item in bullets if str(item).strip()][:6],
    }


def _plan_quiz_items_with_model(user_msg: str, *, file_name: str, structured_tasks: list[dict[str, Any]], extract_preview: str) -> dict[str, Any]:
    system_prompt = (
        "你是陪伴式办公助理里的出题规划器。"
        "根据用户要求和提取出的材料内容，挑 1 到 3 个更难、更适合拿来现场考用户的点。"
        "优先照顾用户提到的薄弱点，比如公式、死记硬背、易错概念。"
        "只输出 JSON。schema: {\"selected_items\":[{\"topic\":string,\"why\":string,\"question\":string}],\"opening_line\":string}。"
        "question 要直接可发给用户作答，opening_line 要像陪伴式办公，不要像系统播报。"
    )
    payload = {
        "user_msg": user_msg,
        "file_name": file_name,
        "structured_tasks": structured_tasks[:12],
        "extract_preview": extract_preview[:2400],
    }
    result = _call_lm_json(system_prompt=system_prompt, user_payload=payload, timeout=45)
    items = result.get("selected_items") if isinstance(result.get("selected_items"), list) else []
    selected = []
    for item in items[:3]:
        if not isinstance(item, dict):
            continue
        topic = str(item.get("topic") or "").strip()
        question = str(item.get("question") or "").strip()
        if topic and question:
            selected.append({
                "topic": topic,
                "why": str(item.get("why") or "").strip(),
                "question": question,
            })
    return {"selected_items": selected, "opening_line": str(result.get("opening_line") or "").strip()}


def _fallback_quiz_plan(structured_tasks: list[dict[str, Any]]) -> dict[str, Any]:
    selected = []
    for item in structured_tasks[:3]:
        if not isinstance(item, dict):
            continue
        topic = str(item.get("task") or "").strip()
        if not topic:
            continue
        selected.append({
            "topic": topic,
            "why": "",
            "question": f"先来一道和“{topic}”相关的题，你先试着把核心思路或公式说出来。",
        })
    return {"selected_items": selected, "opening_line": "我先帮你挑几道偏难的，我们直接一道一道来。"}


def _build_result(reply: str, *, build_display_messages, user_msg: str, reply_source: str, rule_reply: str = "office_task") -> dict[str, Any]:
    return {
        "reply": reply,
        "messages": build_display_messages(user_msg, reply, allow_followup=False),
        "error": False,
        "rule_reply": rule_reply,
        "reply_source": reply_source,
        "used_fallback": False,
        "reply_repaired": False,
        "coalesced_skip": True,
    }


def _build_execution(kind: str, payload: dict[str, Any]) -> dict[str, Any]:
    return {"kind": kind, "payload": payload}


def _render(runtime, user_msg: str, execution: dict[str, Any], reply_source: str) -> dict[str, Any]:
    reply = runtime["office_response"].render_office_result(user_msg, execution)
    return _build_result(reply, build_display_messages=runtime["build_display_messages"], user_msg=user_msg, reply_source=reply_source)


def execute_office_task_intent(intent: dict[str, Any], *, runtime) -> dict[str, Any] | None:
    if not intent.get("matched"):
        return None
    layers = runtime.get("layers")
    user_msg = runtime["user_msg"]
    channel = runtime.get("channel") or intent.get("channel") or "default"
    response_mode = str(intent.get("response_mode") or "write_artifact")

    if not layers or not hasattr(layers, "skills"):
        return _render(runtime, user_msg, _build_execution("failed", {"error": "本地办公层未加载"}), "office_task_unavailable")

    if intent.get("kind") == "browser_read":
        url = intent.get("url") or ""
        if not url:
            return _render(runtime, user_msg, _build_execution("failed", {"error": "缺少链接"}), "office_task_need_url")
        result = layers.skills.call("browser.read", {"url": url, "max_chars": 4000})
        if not result.get("ok"):
            return _render(runtime, user_msg, _build_execution("failed", {"error": result.get("error")}), "office_task_browser_failed")
        payload = result.get("result") or {}
        _remember_office_context(channel=channel, kind="browser_read", url=url, title=payload.get("title") or "", objective=intent.get("objective") or "read", response_mode=response_mode)
        _append_office_audit("execute", channel=channel, user_msg=user_msg, payload={"kind": "browser_read", "url": url, "response_mode": response_mode})
        return _render(runtime, user_msg, _build_execution("browser_read", {"title": payload.get("title") or "", "content_preview": str(payload.get("content") or "")[:180], "from_recent_context": bool(intent.get("from_recent_context"))}), "office_task_browser_read")

    if intent.get("kind") == "browser_fill":
        url = intent.get("url") or ""
        if not url:
            return _render(runtime, user_msg, _build_execution("failed", {"error": "缺少链接"}), "office_task_need_url")
        _remember_office_context(channel=channel, kind="browser_fill", url=url, objective=intent.get("objective") or "form_fill", response_mode=response_mode)
        _append_office_audit("execute", channel=channel, user_msg=user_msg, payload={"kind": "browser_fill", "url": url, "response_mode": response_mode})
        return _render(runtime, user_msg, _build_execution("browser_fill_ready", {"url": url}), "office_task_browser_fill_ready")

    if intent.get("kind") == "local_file_delete":
        target = str(intent.get("path_hint") or "").strip()
        if not target:
            return _render(runtime, user_msg, _build_execution("failed", {"error": "缺少可删除目标"}), "office_task_delete_missing")
        result = layers.skills.call("local_files.delete", {"path": target, "recursive": False})
        if not result.get("ok"):
            return _render(runtime, user_msg, _build_execution("failed", {"error": result.get("error")}), "office_task_delete_failed")
        payload = result.get("result") or {}
        deleted_path = str(payload.get("path") or target)
        _remember_office_context(channel=channel, kind="local_file_deleted", source_path=deleted_path, file_name=Path(deleted_path).name, objective="delete", response_mode=response_mode, extra={"deleted": True})
        _append_office_audit("execute", channel=channel, user_msg=user_msg, payload={"kind": "local_file_delete", "path": deleted_path, "response_mode": response_mode})
        return _render(runtime, user_msg, _build_execution("local_delete", {"file_name": Path(deleted_path).name, "path": deleted_path}), "office_task_local_delete")

    if intent.get("kind") == "local_doc_rewrite":
        candidate = Path(str(intent.get("path_hint") or "")) if intent.get("path_hint") else None
        if not candidate:
            return _render(runtime, user_msg, _build_execution("failed", {"error": "缺少可继续改写的文件"}), "office_task_rewrite_missing")
        instruction = str(intent.get("instruction") or "").strip()
        if not instruction:
            return _render(runtime, user_msg, _build_execution("need_instruction", {"file_name": candidate.name}), "office_task_rewrite_need_instruction")
        rewrite_result = layers.skills.call("local_docs.rewrite", {"path": str(candidate), "instruction": instruction, "output_name": candidate.stem})
        if not rewrite_result.get("ok"):
            return _render(runtime, user_msg, _build_execution("failed", {"error": rewrite_result.get("error")}), "office_task_rewrite_failed")
        payload = rewrite_result.get("result") or {}
        _remember_office_context(channel=channel, kind="local_doc_rewrite", source_path=str(payload.get("source_path") or candidate), output_path=str(payload.get("output_path") or ""), file_name=Path(str(payload.get("output_path") or candidate)).name, objective="rewrite", response_mode=response_mode, extra={"instruction": instruction})
        _append_office_audit("execute", channel=channel, user_msg=user_msg, payload={"kind": "local_doc_rewrite", "path": str(candidate), "instruction": instruction, "response_mode": response_mode})
        return _render(runtime, user_msg, _build_execution("local_rewrite", {"file_name": candidate.name, "output_path": payload.get("output_path") or "", "instruction": instruction}), "office_task_local_rewrite")

    if intent.get("kind") != "local_file":
        return None

    candidate = _resolve_local_candidate(layers, user_msg=user_msg, intent=intent, channel=channel)
    if not candidate:
        return _render(runtime, user_msg, _build_execution("not_found", {"query": user_msg}), "office_task_not_found")

    suffix = candidate.suffix.lower()
    objective = intent.get("objective") or "read"
    if suffix not in _SUPPORTED_LOCAL_SUFFIXES:
        return _render(runtime, user_msg, _build_execution("failed", {"error": f"不支持处理 {candidate.name} 这个类型"}), "office_task_unsupported")

    if objective == "read" and suffix in {".txt", ".md"}:
        read_result = layers.skills.call("local_files.read", {"path": str(candidate), "start_line": 1, "max_lines": 120})
        if not read_result.get("ok"):
            return _render(runtime, user_msg, _build_execution("failed", {"error": read_result.get("error")}), "office_task_read_failed")
        payload = read_result.get("result") or {}
        _remember_office_context(channel=channel, kind="local_read", source_path=str(candidate), file_name=candidate.name, objective=objective, response_mode=response_mode, extra={"from_recent_context": bool(intent.get("from_recent_context"))})
        _append_office_audit("execute", channel=channel, user_msg=user_msg, payload={"kind": "local_read", "path": str(candidate), "response_mode": response_mode})
        return _render(runtime, user_msg, _build_execution("local_read", {"file_name": candidate.name, "content_preview": str(payload.get("content") or "")[:180], "from_recent_context": bool(intent.get("from_recent_context"))}), "office_task_local_read")

    extract_mode = objective if objective in {"summary", "meeting_notes", "todo_list"} else "summary"
    if objective == "quiz_select":
        extract_mode = "todo_list"

    extract_args = {"path": str(candidate), "mode": extract_mode}
    if intent.get("instruction"):
        extract_args["instruction"] = str(intent.get("instruction") or "")
    extract_result = layers.skills.call("local_docs.extract", extract_args)
    if not extract_result.get("ok"):
        return _render(runtime, user_msg, _build_execution("failed", {"error": extract_result.get("error")}), "office_task_extract_failed")

    payload = extract_result.get("result") or {}
    structured_tasks = payload.get("structured_tasks") or []
    output_path = str(payload.get("output_path") or "")
    output_preview = _read_text_if_exists(output_path, limit=3200)
    _remember_office_context(channel=channel, kind="local_extract", source_path=str(candidate), output_path=output_path, file_name=candidate.name, objective=objective, response_mode=response_mode, extra={"mode": extract_mode})

    if objective == "quiz_select":
        try:
            quiz_plan = _plan_quiz_items_with_model(user_msg, file_name=candidate.name, structured_tasks=structured_tasks, extract_preview=output_preview)
        except Exception:
            quiz_plan = _fallback_quiz_plan(structured_tasks)
        selected_items = quiz_plan.get("selected_items") or []
        if not selected_items:
            quiz_plan = _fallback_quiz_plan(structured_tasks)
            selected_items = quiz_plan.get("selected_items") or []
        _remember_office_context(channel=channel, kind="local_quiz", source_path=str(candidate), output_path=output_path, file_name=candidate.name, objective=objective, response_mode=response_mode, extra={"mode": extract_mode, "quiz_items": selected_items, "opening_line": str(quiz_plan.get("opening_line") or "").strip()})
        _append_office_audit("execute", channel=channel, user_msg=user_msg, payload={"kind": "local_quiz", "path": str(candidate), "response_mode": response_mode, "selected_items": selected_items})
        return _render(runtime, user_msg, _build_execution("local_quiz", {"file_name": candidate.name, "output_path": output_path, "selected_items": selected_items, "opening_line": str(quiz_plan.get("opening_line") or "").strip()}), "office_task_quiz_select")

    if response_mode == "direct_return":
        try:
            direct_payload = _summarize_direct_return_with_model(
                user_msg=user_msg,
                file_name=candidate.name,
                objective=objective,
                instruction=str(intent.get("instruction") or ""),
                source_preview="",
                extracted_preview=output_preview,
            )
        except Exception:
            direct_payload = {"lead": "", "body": output_preview[:600], "bullets": []}
        _append_office_audit("execute", channel=channel, user_msg=user_msg, payload={"kind": "local_extract_direct", "path": str(candidate), "mode": extract_mode, "response_mode": response_mode})
        return _render(
            runtime,
            user_msg,
            _build_execution(
                "local_extract_direct",
                {
                    "file_name": candidate.name,
                    "mode": extract_mode,
                    "lead": direct_payload.get("lead") or "",
                    "body": direct_payload.get("body") or "",
                    "bullets": direct_payload.get("bullets") or [],
                },
            ),
            "office_task_local_extract_direct",
        )

    _append_office_audit("execute", channel=channel, user_msg=user_msg, payload={"kind": "local_extract", "path": str(candidate), "mode": extract_mode, "response_mode": response_mode})
    return _render(
        runtime,
        user_msg,
        _build_execution(
            "local_extract",
            {
                "file_name": candidate.name,
                "mode": extract_mode,
                "output_path": output_path,
                "structured_tasks": structured_tasks,
                "response_mode": response_mode,
            },
        ),
        "office_task_local_extract",
    )
