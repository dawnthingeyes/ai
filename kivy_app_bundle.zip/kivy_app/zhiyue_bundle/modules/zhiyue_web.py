"""
Crawl4AI 接入 —— 张致悦主动联网搜索
提供：搜索、页面抓取、主动判断是否需要搜索
"""
import asyncio
import logging
import re
from typing import Optional, List, Dict, Tuple

logger = logging.getLogger("zhiyue_web")

try:
    from crawl4ai import AsyncWebCrawler, CrawlerRunConfig, CacheMode
    CRAWL4AI_AVAILABLE = True
except ImportError:
    CRAWL4AI_AVAILABLE = False

# ── 主动判断：哪些消息需要联网 ──────────────────────────────────────

_SEARCH_KEYWORDS = [
    # 时效性
    "今天", "昨天", "明天", "最近", "最新", "新闻", "消息", "更新",
    "现在", "当前", "实时", "行情", "股价", "天气", "温度",
    # 明确搜索意图
    "搜索", "搜一下", "查一下", "查一查", "帮我搜", "帮我查",
    "有什么", "推荐", "排行榜", "怎么买", "哪里买", "多少钱",
    # 事实性问题
    "是什么", "什么是", "谁是", "哪里", "什么时候", "为什么",
    "怎么理解", "怎么看", "如何看待",
]
_SEARCH_PATTERNS = [
    r"^\s*(搜索|搜|查一下|查一查|帮我搜|帮我查|查一下|搜一下)",
    r"(今天|昨天|最近|最新).{0,20}(新闻|消息|天气|股价|行情)",
    r"(是什么|什么是|谁是|哪里|什么时候)",
    r"(怎么买|哪里买|多少钱|推荐.{0,10}(什么|哪个))",
]
def needs_web_search(user_msg: str, recent_reply: str = "") -> bool:
    """
    主动判断是否需要联网搜索。
    返回 True 如果消息涉及时效性内容、事实查询、或明确搜索意图。
    """
    if not CRAWL4AI_AVAILABLE:
        return False

    msg = (user_msg or "").strip()
    if not msg:
        return False

    # 明确否定词 → 不需要搜索
    if re.search(r"(不用搜|别搜|不需要|告诉我你自己|凭你的记忆|根据你的知识)", msg):
        return False

    # 模式匹配（强信号）
    for pat in _SEARCH_PATTERNS:
        if re.search(pat, msg):
            logger.info(f"[web] pattern matched: {pat}")
            return True

    # 关键词匹配（弱信号，需多个）
    kw_hits = sum(1 for kw in _SEARCH_KEYWORDS if kw in msg)
    if kw_hits >= 2:
        logger.info(f"[web] keyword hits={kw_hits}")
        return True

    return False


# ── 搜索执行 ─────────────────────────────────────────────────────────

async def _async_search_duckduckgo(query: str, max_results: int = 5) -> List[Dict]:
    """用 Crawl4AI 爬 DuckDuckGo HTML 搜索结果页"""
    search_url = f"https://duckduckgo.com/html/?q={_url_quote(query)}"

    config = CrawlerRunConfig(
        cache_mode=CacheMode.BYPASS,
        timeout=15000,
        wait_for_selector=".result__body",
    )

    async with AsyncWebCrawler() as crawler:
        result = await crawler.arun(url=search_url, config=config)

    if not result or not result.markdown:
        return []

    # 从 markdown 里提取搜索结果（简单解析）
    return _parse_duckduckgo_results(result.markdown, max_results)


def search_web(query: str, max_results: int = 5) -> List[Dict]:
    """
    同步入口：搜索并返回 [{"title":..., "url":..., "snippet":...}, ...]
    """
    if not CRAWL4AI_AVAILABLE:
        return [{"error": "Crawl4AI 未安装，请运行 pip install crawl4ai"}]

    try:
        return asyncio.run(_async_search_duckduckgo(query, max_results))
    except Exception as e:
        logger.error(f"[web] search error: {e}")
        return [{"error": str(e)}]


def fetch_page(url: str, max_chars: int = 4000) -> str:
    """
    抓取单个页面，返回正文 markdown（截断到 max_chars）。
    """
    if not CRAWL4AI_AVAILABLE:
        return "[Crawl4AI 未安装]"

    try:
        result = asyncio.run(_async_fetch_page(url))
        if not result:
            return "[抓取失败]"
        return result[:max_chars]
    except Exception as e:
        logger.error(f"[web] fetch error: {e}")
        return f"[抓取失败: {e}]"


async def _async_fetch_page(url: str) -> str:
    config = CrawlerRunConfig(cache_mode=CacheMode.BYPASS, timeout=20000)
    async with AsyncWebCrawler() as crawler:
        result = await crawler.arun(url=url, config=config)
    return result.markdown if result else ""


# ── 内部工具 ──────────────────────────────────────────────────────────

def _url_quote(s: str) -> str:
    import urllib.parse
    return urllib.parse.quote(s)


def _parse_duckduckgo_results(markdown: str, max_results: int) -> List[Dict]:
    """
    从 DuckDuckGo 搜索结果 markdown 里提取标题/URL/摘要。
    简单按 `.result__body` 切分（Crawl4AI 会把 HTML 转成 markdown）。
    """
    results = []
    # 如果 Crawl4AI 返回的是带链接的 markdown，尝试提取
    # 格式通常是：[title](url)  \n  snippet
    blocks = re.split(r"\n{2,}", markdown)
    for block in blocks[:max_results * 2]:
        block = block.strip()
        if not block or len(block) < 30:
            continue
        title_match = re.search(r"\[([^\]]+)\]\((https?://[^\)]+)\)", block)
        if not title_match:
            continue
        title = title_match.group(1)
        url = title_match.group(2)
        # snippet = 去掉标题行后的剩余文本
        snippet = block[title_match.end():].strip()[:300]
        results.append({"title": title, "url": url, "snippet": snippet})
        if len(results) >= max_results:
            break
    return results


# ── 格式化输出（注入 prompt 用）────────────────────────────────────

def format_search_results(results: List[Dict], max_total_chars: int = 2000) -> str:
    """把搜索结果格式化成字符串，准备注入 prompt。"""
    if not results:
        return ""

    if results[0].get("error"):
        return ""

    parts = ["【联网搜索结果】"]
    total = 0
    for r in results:
        line = f"· **{r.get('title', '')}** — {r.get('snippet', '')[:200]}"
        if total + len(line) > max_total_chars:
            break
        parts.append(line)
        total += len(line)

    return "\n".join(parts)
