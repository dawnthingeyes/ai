"""
LlamaIndex RAG — 张致悦文档阅读
复用现有嵌入 API，文档摄入 → 索引 → 检索 → 注入 prompt
"""
import os, json, logging, hashlib, struct
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Optional, Tuple

logger = logging.getLogger("zhiyue_rag")

# ── 依赖检测 ──
LLAMA_AVAILABLE = False
BaseEmbedding = object  # type: ignore[assignment]
try:
    from llama_index.core import (
        VectorStoreIndex, StorageContext,
        load_index_from_storage, Settings, Document,
    )
    from llama_index.core.node_parser import SentenceSplitter
    from llama_index.core.embeddings import BaseEmbedding
    LLAMA_AVAILABLE = True
except ImportError:
    logger.warning("llama-index 未安装；RAG 不可用")

import requests

# ── 路径 ──
RAG_DIR = Path(__file__).parent / "data" / "rag"
INDEX_DIR = RAG_DIR / "indices"
META_PATH = RAG_DIR / "doc_meta.json"

# ── 嵌入适配器：对接 zhiyue_layers 用的同一个 embedding API ──

class ZhiyueEmbedding(BaseEmbedding):
    """复用现有 ZHIYUE_EMBEDDING_URL 的嵌入服务"""
    _model: str = "text-embedding-nomic-embed-text-v1.5@q4_k_m"
    _api_url: str = ""

    def __init__(self, model=None, api_url=None, **kwargs):
        super().__init__(**kwargs)
        if model:
            self._model = model
        self._api_url = api_url or os.environ.get(
            "ZHIYUE_EMBEDDING_URL",
            "http://localhost:1234/v1/embeddings",
        )

    def _embed_batch(self, texts: List[str]) -> List[List[float]]:
        if not texts:
            return []

        # 单次遍历：成功就收集，任何一次失败就整批回退到 hash。
        results = []
        api_dim = getattr(self, '_api_dim', 768)
        for text in texts:
            emb = self._call_api(text)
            if emb is None:
                # API 有任何一次失败，整批回退
                logger.warning("[rag] API embed failed, falling back to hash for batch")
                return [self._hash_embed(item, dim=api_dim) for item in texts]
            api_dim = len(emb)
            self._api_dim = api_dim
            results.append(emb)

        return results

    def _call_api(self, text: str) -> Optional[List[float]]:
        try:
            resp = requests.post(
                self._api_url,
                json={"model": self._model, "input": text},
                timeout=30,
            )
            data = resp.json()
            if isinstance(data, dict):
                if isinstance(data.get("data"), list) and data["data"]:
                    emb = data["data"][0].get("embedding")
                    if isinstance(emb, list):
                        return [float(x) for x in emb]
                if isinstance(data.get("embedding"), list):
                    return [float(x) for x in data["embedding"]]
        except Exception:
            pass
        return None

    @staticmethod
    def _hash_embed(text: str, dim: int = 384) -> List[float]:
        h = hashlib.sha256(text.encode("utf-8")).digest()
        floats = [
            float(struct.unpack("<I", h[i:i+4])[0] % 1000) / 1000.0
            for i in range(0, min(len(h) - 3, dim * 4), 4)
        ]
        # SHA-256 只有 32 字节=8个float；如果 dim>8，重复填充
        while len(floats) < dim:
            need = dim - len(floats)
            floats.extend(floats[:min(len(floats), need)])
        return floats[:dim]

    def _get_query_embedding(self, query: str) -> List[float]:
        return self._embed_batch([query])[0]

    def _get_text_embedding(self, text: str) -> List[float]:
        return self._embed_batch([text])[0]

    def _get_text_embeddings(self, texts: List[str]) -> List[List[float]]:
        return self._embed_batch(texts)

    async def _aget_query_embedding(self, query: str) -> List[float]:
        return self._get_query_embedding(query)

    async def _aget_text_embedding(self, text: str) -> List[float]:
        return self._get_text_embedding(text)


# ── 元数据 ──

def _ensure_dirs():
    RAG_DIR.mkdir(parents=True, exist_ok=True)

def _load_meta() -> Dict:
    _ensure_dirs()
    if META_PATH.exists():
        return json.loads(META_PATH.read_text(encoding="utf-8"))
    return {"docs": {}, "chunks": 0}

def _save_meta(meta: Dict):
    _ensure_dirs()
    META_PATH.write_text(
        json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8"
    )


# ── PDF / Excel / CSV 提取 ──

def _extract_pdf_text(fp: Path) -> str:
    """从 PDF 提取文字，优先 pdfplumber（更可靠），不可用则回退 LlamaIndex PDFReader"""
    # pdfplumber 先行——对中英文混合 PDF 的 OCR-like 文本提取更稳定
    try:
        import pdfplumber
        with pdfplumber.open(str(fp)) as pdf:
            pages = [p.extract_text() or "" for p in pdf.pages]
            text = "\n\n".join(pages)
            if text.strip():
                return text
    except Exception:
        pass
    # 回退：LlamaIndex 原生 PDFReader
    try:
        from llama_index.readers.file import PDFReader
        docs = PDFReader().load_data(str(fp))
        if docs:
            return "\n\n".join(d.text for d in docs)
    except Exception:
        pass
    raise ImportError("PDF 阅读器未安装 (pip install pdfplumber 或 llama-index-readers-file)")


def _extract_excel_text(fp: Path) -> str:
    """从 Excel 提取文字：每个 sheet 转成表格文本"""
    try:
        import pandas as pd
        xls = pd.ExcelFile(str(fp))
        parts = []
        for sn in xls.sheet_names:
            df = pd.read_excel(xls, sheet_name=sn)
            parts.append(f"=== Sheet: {sn} ===")
            parts.append(df.to_string(index=False, max_rows=200))
        return "\n\n".join(parts)
    except Exception:
        pass
    try:
        import openpyxl
        wb = openpyxl.load_workbook(str(fp), read_only=True, data_only=True)
        parts = []
        for sn in wb.sheetnames:
            ws = wb[sn]
            rows = []
            for row in ws.iter_rows(values_only=True):
                rows.append("\t".join(str(c) if c is not None else "" for c in row))
                if len(rows) >= 500:
                    break
            parts.append(f"=== Sheet: {sn} ===")
            parts.append("\n".join(rows))
        wb.close()
        return "\n\n".join(parts)
    except Exception:
        raise ImportError("Excel 阅读器未安装 (pip install pandas openpyxl)")


def _extract_csv_text(fp: Path) -> str:
    """从 CSV/TSV 提取文字"""
    try:
        import pandas as pd
        sep = "\t" if fp.suffix.lower() == ".tsv" else ","
        df = pd.read_csv(str(fp), sep=sep, nrows=500)
        return df.to_string(index=False)
    except Exception:
        return fp.read_text(encoding="utf-8", errors="replace")


# ── 索引管理 ──

def _configure():
    if not LLAMA_AVAILABLE:
        return
    Settings.embed_model = ZhiyueEmbedding()
    Settings.node_parser = SentenceSplitter(chunk_size=512, chunk_overlap=64)

def _get_index() -> Optional[Tuple]:
    """获取已有索引或返回 None"""
    if not LLAMA_AVAILABLE:
        return None
    _configure()
    persist_dir = str(INDEX_DIR)
    if os.path.exists(persist_dir) and os.listdir(persist_dir):
        try:
            sc = StorageContext.from_defaults(persist_dir=persist_dir)
            idx = load_index_from_storage(sc)
            return idx
        except Exception as e:
            logger.warning(f"[rag] load index failed: {e}")
    return None


# ── 核心 API ──

def ingest_document(file_path: str, doc_name: str = "") -> Dict:
    """摄入文档。返回 {"ok": True, "doc_id": "...", ...} 或 {"error": "..."}"""
    if not LLAMA_AVAILABLE:
        return {"error": "llama-index 未安装"}

    fp = Path(file_path)
    if not fp.exists():
        return {"error": f"文件不存在: {file_path}"}

    doc_name = doc_name or fp.name

    try:
        suffix = fp.suffix.lower()
        if suffix in (".pdf",):
            # pdfplumber 优先（兼容性更好），不可用则回退 LlamaIndex PDFReader
            content = _extract_pdf_text(fp)
        elif suffix in (".xlsx", ".xls"):
            content = _extract_excel_text(fp)
        elif suffix in (".csv", ".tsv"):
            content = _extract_csv_text(fp)
        else:
            content = fp.read_text(encoding="utf-8", errors="replace")

        if not content.strip():
            return {"error": "文档为空"}

    except Exception as e:
        return {"error": f"读取文件失败: {e}"}

    doc_id = hashlib.md5(f"{doc_name}{len(content)}".encode()).hexdigest()[:12]

    try:
        _configure()
        doc = Document(
            text=content,
            metadata={"doc_id": doc_id, "doc_name": doc_name, "source": str(fp)},
        )

        persist_dir = str(INDEX_DIR)
        if os.path.exists(persist_dir) and os.listdir(persist_dir):
            sc = StorageContext.from_defaults(persist_dir=persist_dir)
            idx = load_index_from_storage(sc)
            idx.insert(doc)
        else:
            idx = VectorStoreIndex.from_documents([doc])
        idx.storage_context.persist(persist_dir=persist_dir)

        meta = _load_meta()
        meta["docs"][doc_id] = {
            "name": doc_name,
            "source": str(fp),
            "chars": len(content),
            "ingested_at": datetime.now().isoformat(),
        }
        meta["chunks"] = meta.get("chunks", 0) + max(1, len(content) // 512)
        _save_meta(meta)

        logger.info(f"[rag] ingested {doc_name} ({len(content)} chars)")
        return {"ok": True, "doc_id": doc_id, "name": doc_name, "chars": len(content)}

    except Exception as e:
        logger.error(f"[rag] ingest error: {e}")
        return {"error": str(e)}


def query_rag(query: str, top_k: int = 3) -> List[Dict]:
    """检索相关文档片段 → [{"text": ..., "score": ..., "doc_name": ...}]"""
    idx = _get_index()
    if idx is None:
        return []

    try:
        retriever = idx.as_retriever(similarity_top_k=top_k)
        nodes = retriever.retrieve(query)

        results = []
        for node in nodes:
            results.append({
                "text": node.get_text()[:800],
                "score": round(float(node.score) if node.score else 0, 3),
                "doc_name": node.metadata.get("doc_name", ""),
                "doc_id": node.metadata.get("doc_id", ""),
            })
        return results
    except Exception as e:
        logger.error(f"[rag] query error: {e}")
        return []


def list_documents() -> Dict:
    """列出已摄入文档"""
    meta = _load_meta()
    return meta


def needs_rag_lookup(user_msg: str) -> bool:
    """判断用户消息是否引用了已存储的文档"""
    if not LLAMA_AVAILABLE:
        return False
    meta = _load_meta()
    if not meta.get("docs"):
        return False

    for doc_id, info in meta["docs"].items():
        name = info.get("name", "")
        if name and len(name) > 3 and name[: min(len(name), 20)] in user_msg:
            return True

    doc_keywords = ["文档", "文件", "资料", "合同", "报告", "这本书", "这篇文章",
                     "刚才那个", "那份", "这个PDF", "之前看过的", "记录",
                     "风格", "指南", "手册", "笔记", "日志", "说明",
                     "怎么写", "怎么回", "说过"]
    return any(kw in user_msg for kw in doc_keywords)


def format_rag_context(chunks: List[Dict], max_chars: int = 1500) -> str:
    """格式化 RAG 检索结果为 prompt 注入文本"""
    if not chunks:
        return ""

    lines = ["【文档资料】"]
    total = 0
    for c in chunks:
        doc_name = f" ({c.get('doc_name', '')})" if c.get("doc_name") else ""
        snippet = c.get("text", "")[:300]
        line = f"· {doc_name}: {snippet}"
        if total + len(line) > max_chars:
            break
        lines.append(line)
        total += len(line)

    if len(lines) == 1:
        return ""
    lines.append("【提示】以上内容来自你已读过的文档，回复时自然引用，不要复述。")
    return "\n".join(lines)


def get_rag_inject(user_msg: str) -> str:
    """一站式：判断 → 检索 → 格式化，返回可注入 prompt 的文本"""
    if not needs_rag_lookup(user_msg):
        return ""
    chunks = query_rag(user_msg, top_k=3)
    return format_rag_context(chunks)


# ── 工具注册 ──

def ingest_pdf(file_path: str, doc_name: str = "") -> Dict:
    """摄入 PDF 文档（便捷入口，内部调用 ingest_document）"""
    return ingest_document(file_path, doc_name)


def ingest_excel(file_path: str, doc_name: str = "") -> Dict:
    """摄入 Excel/CSV 文档（便捷入口，内部调用 ingest_document）"""
    return ingest_document(file_path, doc_name)


# ── 工具注册 ──

def register_rag_tools(bind_fn):
    """在 layers.skills 里注册 RAG 工具"""
    def _ingest(args):
        path = str((args or {}).get("path", ""))
        name = str((args or {}).get("name", ""))
        return ingest_document(path, name)

    def _query(args):
        q = str((args or {}).get("query", ""))
        return query_rag(q, top_k=int((args or {}).get("top_k", 3)))

    def _list(args):
        return list_documents()

    bind_fn("rag.ingest", _ingest)
    bind_fn("rag.query", _query)
    bind_fn("rag.list", _list)
    logger.info("[rag] tools registered")
