# -*- coding: utf-8 -*-
from __future__ import annotations


def close_office_reply(user_msg: str, reply: str) -> str:
    text = (reply or "").strip()
    if not text:
        return text
    return text


def close_technical_reply(user_msg: str, reply: str) -> str:
    text = (reply or "").strip()
    if not text:
        return text
    msg = user_msg or ""
    if any(term in msg for term in ["看看", "读一下", "分析", "哪里有问题", "挑刺"]):
        if text.startswith(("我看了一下", "扫完了", "给你说下我看到的")):
            return text
        return "我看了一下，" + text
    if not text.startswith(("我", "先", "看")):
        return "我先给你捋一下，" + text
    return text
