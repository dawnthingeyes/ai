from __future__ import annotations

from typing import Any, Callable


def register_capability_routes(app, *, jsonify, request, get_layers: Callable[[], Any]) -> None:
    @app.route('/api/voice/transcribe', methods=['POST'])
    def api_voice_transcribe():
        layers = get_layers()
        if not layers:
            return jsonify({"ok": False, "error": "layers unavailable"}), 200
        data = request.json or {}
        return jsonify(layers.skills.call("voice.transcribe", {"path": data.get("path", "")}))

    @app.route('/api/voice/speak', methods=['POST'])
    def api_voice_speak():
        layers = get_layers()
        if not layers:
            return jsonify({"ok": False, "error": "layers unavailable"}), 200
        data = request.json or {}
        result = layers.voice_desktop.speak(
            data.get("text", ""),
            data.get("out_path"),
            prompt_audio=data.get("prompt_audio"),
            emo_audio_prompt=data.get("emo_audio_prompt"),
            emotion_text=data.get("emotion_text"),
            provider=data.get("provider"),
        )
        result["resolved_prompt_audio"] = layers.voice_desktop.resolve_prompt_audio(data.get("prompt_audio"))
        return jsonify(result)

    @app.route('/api/desktop/open_url', methods=['POST'])
    def api_desktop_open_url():
        layers = get_layers()
        if not layers:
            return jsonify({"ok": False, "error": "layers unavailable"}), 200
        data = request.json or {}
        return jsonify(layers.skills.call("desktop.open_url", {"url": data.get("url", "")}))

    @app.route('/api/local_docs/extract', methods=['POST'])
    def api_local_docs_extract():
        layers = get_layers()
        if not layers:
            return jsonify({"ok": False, "error": "layers unavailable"}), 200
        data = request.json or {}
        return jsonify(
            layers.skills.call(
                "local_docs.extract",
                {
                    "path": data.get("path", ""),
                    "mode": data.get("mode", ""),
                    "instruction": data.get("instruction", ""),
                    "output_name": data.get("output_name", ""),
                },
            )
        )

    @app.route('/api/local_files/write_text', methods=['POST'])
    def api_local_files_write_text():
        layers = get_layers()
        if not layers:
            return jsonify({"ok": False, "error": "layers unavailable"}), 200
        data = request.json or {}
        return jsonify(
            layers.skills.call(
                "local_files.write_text",
                {
                    "path": data.get("path", ""),
                    "content": data.get("content", ""),
                    "overwrite": bool(data.get("overwrite")),
                },
            )
        )

    @app.route('/api/local_files/mkdir', methods=['POST'])
    def api_local_files_mkdir():
        layers = get_layers()
        if not layers:
            return jsonify({"ok": False, "error": "layers unavailable"}), 200
        data = request.json or {}
        return jsonify(layers.skills.call("local_files.mkdir", {"path": data.get("path", "")}))

    @app.route('/api/local_files/copy', methods=['POST'])
    def api_local_files_copy():
        layers = get_layers()
        if not layers:
            return jsonify({"ok": False, "error": "layers unavailable"}), 200
        data = request.json or {}
        return jsonify(
            layers.skills.call(
                "local_files.copy",
                {
                    "src": data.get("src", ""),
                    "dst": data.get("dst", ""),
                    "overwrite": bool(data.get("overwrite")),
                },
            )
        )

    @app.route('/api/local_files/move', methods=['POST'])
    def api_local_files_move():
        layers = get_layers()
        if not layers:
            return jsonify({"ok": False, "error": "layers unavailable"}), 200
        data = request.json or {}
        return jsonify(
            layers.skills.call(
                "local_files.move",
                {
                    "src": data.get("src", ""),
                    "dst": data.get("dst", ""),
                    "overwrite": bool(data.get("overwrite")),
                },
            )
        )

    @app.route('/api/browser/read', methods=['POST'])
    def api_browser_read():
        layers = get_layers()
        if not layers:
            return jsonify({"ok": False, "error": "layers unavailable"}), 200
        data = request.json or {}
        return jsonify(
            layers.skills.call(
                "browser.read",
                {
                    "url": data.get("url", ""),
                    "max_chars": data.get("max_chars", 6000),
                },
            )
        )

    @app.route('/api/browser/fill_form', methods=['POST'])
    def api_browser_fill_form():
        layers = get_layers()
        if not layers:
            return jsonify({"ok": False, "error": "layers unavailable"}), 200
        data = request.json or {}
        return jsonify(
            layers.skills.call(
                "browser.fill_form",
                {
                    "url": data.get("url", ""),
                    "fields": data.get("fields", {}),
                    "submit_selector": data.get("submit_selector", ""),
                },
            )
        )
