# -*- coding: utf-8 -*-
from __future__ import annotations


def finalize_growth_reply(
    user_msg,
    *,
    pipeline_result,
    effective_history,
    chat_history,
    is_placeholder_reply,
    append_history_turn,
    growth,
    autonomous_learn,
    relationship_learn,
    self_review_turn,
    intimacy,
    emotion,
    cognitive,
    log_runtime_exception,
    memory,
    build_display_messages,
):
    reply_source = pipeline_result.get("reply_source") or "lm_judge_loop"
    raw_reply = "" if pipeline_result.get("reply") is None else str(pipeline_result.get("reply"))
    if not raw_reply.strip() or is_placeholder_reply(raw_reply):
        raw_reply = ""
        reply_source = "lm_fallback"

    append_history_turn(chat_history, user_msg, raw_reply)
    score, reasons = growth.evaluate(user_msg, raw_reply)
    learned = autonomous_learn(user_msg, raw_reply, score=score, reasons=reasons)
    woven_learned = relationship_learn(user_msg, raw_reply)
    reviews = self_review_turn(user_msg, raw_reply, score=score, reasons=reasons)

    intimacy.add_exp(3)
    intimacy.update_energy(-2)
    emotion.update(user_msg, raw_reply)
    intimacy.data["last_user_message"] = user_msg[:120]
    intimacy.data["last_assistant_message"] = raw_reply[:120]
    intimacy.save()

    if cognitive:
        try:
            cognitive.infer_from_message(user_msg, raw_reply, intimacy_level=intimacy.data["level"])
        except Exception as err:
            log_runtime_exception("cognitive_infer", err)

    try:
        if raw_reply.strip():
            memory.add_memory(user_msg[:100], category="chat", importance=1, mem_type="experience")
    except Exception as err:
        log_runtime_exception("growth_finalize.memory", err)

    payload = {
        "reply": raw_reply,
        "messages": build_display_messages(user_msg, raw_reply, allow_followup=False),
        "score": score,
        "mood": emotion.happiness,
        "mood_emoji": {"happy": "开心", "angry": "生气", "shy": "害羞", "jealous": "吃醋", "neutral": "平静"}.get(emotion.emotion, "平静"),
        "mood_state": emotion.emotion,
        "level": intimacy.data["level"],
        "exp": intimacy.data["exp"],
        "stage": intimacy.get_stage(),
        "energy": intimacy.data.get("energy", 100),
        "mood_value": intimacy.data.get("mood", 100),
        "streak": intimacy.data.get("streak", 0),
        "total_chats": intimacy.data.get("total_chats", 0),
        "personality": intimacy.get_personality_desc(),
        "learned": learned,
        "woven_learned": woven_learned,
        "reviews": reviews,
        "scheduled_followup": effective_history is not None,
        "reply_source": reply_source,
        "judge": pipeline_result.get("judge") or {},
        "judge_trace": pipeline_result.get("judge_trace") or [],
        "used_fallback": False,
        "reply_repaired": bool(pipeline_result.get("reply_repaired")),
        "human_likeness": pipeline_result.get("human_likeness") or {},
        "self_correction": pipeline_result.get("self_correction") or {},
        "reply_quality": pipeline_result.get("reply_quality") or {},
        "error": False,
    }
    if not raw_reply.strip():
        payload["reply_quality"] = {"passed": False, "action": "rejected_empty"}
    return payload
