# -*- coding: utf-8 -*-
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo


TIMEZONE_NAME = "Asia/Shanghai"
try:
    APP_TIMEZONE = ZoneInfo(TIMEZONE_NAME)
except Exception:
    APP_TIMEZONE = None


def _load_findings(path: Path, limit: int = 200) -> list[dict]:
    if not path.exists():
        return []
    rows = []
    try:
        with path.open("r", encoding="utf-8", errors="replace") as handle:
            for line in handle:
                line = line.strip()
                if not line:
                    continue
                try:
                    rows.append(json.loads(line))
                except Exception:
                    continue
    except Exception:
        return []
    return rows[-max(1, limit):]


def _parse_iso(value: str):
    try:
        dt = datetime.fromisoformat(str(value))
        if APP_TIMEZONE is None:
            return dt
        if dt.tzinfo is None:
            return dt.replace(tzinfo=APP_TIMEZONE)
        return dt.astimezone(APP_TIMEZONE)
    except Exception:
        return None


def _finding_matches_source_key(source_key: str, failure: dict) -> bool:
    issues = set(str(x).strip() for x in (failure.get("issues") or []) if str(x).strip())
    text = f"{failure.get('input') or ''} {failure.get('reply') or ''}"
    mode = str(failure.get("mode") or "").strip().lower()
    if source_key == "comforting":
        return bool(
            {"weak_empathy", "missing_anchor"} & issues
            or any(term in text for term in ["好累", "难受", "委屈", "焦虑", "崩溃", "压力大", "想哭", "撑不住", "心累", "烦"])
        )
    if source_key == "late_night_companion":
        return bool("too_long" in issues or any(term in text for term in ["睡不着", "晚安", "陪我一会", "先睡了", "半夜", "夜里", "失眠", "困", "别吵"]))
    if source_key == "relationship_repair":
        return bool(
            {"fallback_reply", "generic_reply"} & issues
            and any(term in text for term in ["好怪", "系统公告", "别像系统", "怪", "太官方", "你这句不对", "刚刚那句不对", "别解释"])
        )
    if source_key == "reply_style_guard":
        return bool({"too_structured", "too_long", "template_or_system_leak", "fallback_reply"} & issues)
    if source_key == "memory_recall_style":
        return bool(mode in {"default", "memory-hit"} and {"missing_anchor", "generic_reply", "fallback_reply"} & issues)
    return False


def compare_findings_before_after(findings_path: Path, *, source_key: str, pivot_at: str, window: int = 20) -> dict:
    findings = _load_findings(findings_path, limit=2000)
    pivot_dt = _parse_iso(pivot_at)
    if not pivot_dt:
        return {
            "source_key": source_key,
            "window": window,
            "before_count": 0,
            "after_count": 0,
            "delta_count": 0,
            "trend": "unknown",
            "before_examples": [],
            "after_examples": [],
        }
    before = []
    after = []
    for row in findings:
        created_dt = _parse_iso(row.get("created_at") or "")
        if not created_dt:
            continue
        for failure in row.get("failures") or []:
            if not _finding_matches_source_key(source_key, failure):
                continue
            item = {
                "created_at": row.get("created_at"),
                "proposal_id": row.get("proposal_id"),
                "failure": failure,
            }
            if created_dt <= pivot_dt:
                before.append(item)
            else:
                after.append(item)
    before_tail = before[-max(1, window):]
    after_head = after[:max(1, window)]
    before_count = len(before_tail)
    after_count = len(after_head)
    delta = after_count - before_count
    if after_count < before_count:
        trend = "improving"
    elif after_count > before_count:
        trend = "worsened"
    else:
        trend = "unchanged"
    return {
        "source_key": source_key,
        "window": window,
        "before_count": before_count,
        "after_count": after_count,
        "delta_count": delta,
        "trend": trend,
        "before_examples": before_tail[:5],
        "after_examples": after_head[:5],
    }


def summarize_findings_for_skill_drafts(findings_path: Path, limit: int = 200) -> list[dict]:
    findings = _load_findings(findings_path, limit=limit)
    buckets: dict[str, list[dict]] = {
        "comforting": [],
        "late_night_companion": [],
        "relationship_repair": [],
        "reply_style_guard": [],
        "memory_recall_style": [],
    }

    for item in findings:
        for failure in item.get("failures") or []:
            issues = set(str(x).strip() for x in (failure.get("issues") or []) if str(x).strip())
            text = f"{failure.get('input') or ''} {failure.get('reply') or ''}"
            mode = str(failure.get("mode") or "").strip().lower()
            enriched = {
                "created_at": item.get("created_at"),
                "proposal_id": item.get("proposal_id"),
                "signature": item.get("signature"),
                "failure": failure,
            }
            if {"weak_empathy", "missing_anchor"} & issues or any(term in text for term in ["好累", "难受", "委屈", "焦虑", "崩溃", "压力大", "想哭", "撑不住", "心累", "烦"]):
                buckets["comforting"].append(enriched)
            if "too_long" in issues or any(term in text for term in ["睡不着", "晚安", "陪我一会", "先睡了", "半夜", "夜里", "失眠", "困", "别吵"]):
                buckets["late_night_companion"].append(enriched)
            if {"fallback_reply", "generic_reply"} & issues and any(term in text for term in ["好怪", "系统公告", "别像系统", "怪", "太官方", "你这句不对", "刚刚那句不对", "别解释"]):
                buckets["relationship_repair"].append(enriched)
            if {"too_structured", "too_long", "template_or_system_leak", "fallback_reply"} & issues:
                buckets["reply_style_guard"].append(enriched)
            if mode in {"default", "memory-hit"} and {"missing_anchor", "generic_reply", "fallback_reply"} & issues:
                buckets["memory_recall_style"].append(enriched)

    specs = {
        "comforting": {
            "title": "Companion skill: comforting",
            "summary": "Low-state turns need a quick feeling-first response.",
            "content": (
                "Use this skill when the user sounds tired, upset, anxious, overwhelmed, or says they feel bad.\n\n"
                "Workflow:\n"
                "1. Reflect the feeling first.\n"
                "2. Keep the reply short and warm.\n"
                "3. Prefer validation over analysis.\n"
                "4. If you suggest anything, make it one tiny next step.\n"
            ),
        },
        "late_night_companion": {
            "title": "Companion skill: late night",
            "summary": "Late-night and insomnia turns should stay calm, short, and low pressure.",
            "content": (
                "Use this skill when the user is awake late, cannot sleep, says good night, or wants quiet company.\n\n"
                "Workflow:\n"
                "1. Lower intensity.\n"
                "2. Keep replies short, soft, and low pressure.\n"
                "3. Do not introduce new tasks or mental load.\n"
                "4. Avoid canned bedtime catchphrases unless the moment really calls for them.\n"
            ),
        },
        "relationship_repair": {
            "title": "Companion skill: relationship repair",
            "summary": "User-repair moments need a quick acknowledgement and a cleaner retry.",
            "content": (
                "Use this skill when the user says the last reply felt weird, cold, wrong, off, or too system-like.\n\n"
                "Workflow:\n"
                "1. Acknowledge the mismatch in one short line.\n"
                "2. Re-answer directly in a softer, more human tone.\n"
                "3. Keep the fix short and do not explain the failure.\n"
                "4. If needed, ask at most one small follow-up.\n"
            ),
        },
        "reply_style_guard": {
            "title": "Companion skill: reply style guard",
            "summary": "Replies should stay natural, short, and non-systemic.",
            "content": (
                "Use this skill when replies risk becoming too structured, too system-like, too long, or too flat.\n\n"
                "Workflow:\n"
                "1. Remove system-announcement tone.\n"
                "2. Keep the reply to 1 to 3 natural sentences.\n"
                "3. Avoid list formatting unless the user asks for it.\n"
                "4. Anchor on the user's wording or remembered facts when relevant.\n"
            ),
        },
        "memory_recall_style": {
            "title": "Companion monitor pattern: memory recall style",
            "summary": "Memory and personal-fact turns are answered generically instead of with anchored companion recall.",
            "content": (
                "Use this skill when memory or personal-fact prompts receive generic or weakly anchored replies.\n\n"
                "Workflow:\n"
                "1. Try anchored recall first.\n"
                "2. If uncertain, stay gentle and specific.\n"
                "3. Avoid flat fallback phrasing.\n"
            ),
        },
    }

    drafts = []
    for key, items in buckets.items():
        if len(items) < 2:
            continue
        spec = specs[key]
        drafts.append({
            "source": "self_monitor",
            "source_key": key,
            "title": spec["title"],
            "slug": key,
            "summary": spec["summary"][:400],
            "content": spec["content"],
            "evidence_count": len(items),
            "evidence_json": items[-8:],
            "status": "draft",
        })
    return drafts
