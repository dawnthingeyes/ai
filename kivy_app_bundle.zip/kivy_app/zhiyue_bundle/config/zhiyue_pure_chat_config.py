from __future__ import annotations

import os
from pathlib import Path

from zhiyue_model_registry import resolve_model_reference, model_name_for_request


def _project_root() -> Path:
    configured = os.environ.get("ZHIYUE_PROJECT_DIR", "").strip()
    if configured:
        return Path(configured).expanduser().resolve()
    return Path(__file__).resolve().parent.parent


def _load_env_file(base_dir: Path) -> None:
    env_path = base_dir / ".env"
    if not env_path.is_file():
        return
    os.environ.setdefault("ZHIYUE_PROJECT_DIR", str(base_dir))
    for raw_line in env_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        if not key or key in os.environ:
            continue
        normalized = os.path.expandvars(value.strip().strip('"').strip("'"))
        if key.endswith(("_DIR", "_DB", "_FILE", "_PATH", "_ROOT")) or (
            key.endswith("_MODEL") and "://" not in normalized and any(sep in normalized for sep in ("/", "\\"))
        ):
            path = Path(normalized).expanduser()
            if not path.is_absolute():
                path = base_dir / path
            normalized = str(path.resolve())
        os.environ[key] = normalized


BASE_DIR = _project_root()
_load_env_file(BASE_DIR)


def _env_flag(name: str, default: bool = False) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return default
    return raw.strip().lower() not in {"0", "false", "no", "off"}


MODE = os.environ.get("ZHIYUE_MODE", "pure_chat").strip().lower() or "pure_chat"
PURE_CHAT_MODE = MODE in {"pure_chat", "chat", "chat_only"}

MAIN_LM_URL = os.environ.get(
    "ZHIYUE_MAIN_LM_URL",
    os.environ.get("ZHIYUE_LM_URL", "http://127.0.0.1:1234/v1/chat/completions"),
).strip()
DEFAULT_MAIN_MODEL = str(BASE_DIR / "models" / "main-model.gguf")
MAIN_MODEL = os.environ.get(
    "ZHIYUE_MAIN_MODEL",
    os.environ.get("ZHIYUE_LM_MODEL", DEFAULT_MAIN_MODEL),
).strip()
MAIN_MODEL_INFO = resolve_model_reference(MAIN_MODEL, default_name=DEFAULT_MAIN_MODEL)
MAIN_MODEL_NAME = MAIN_MODEL_INFO.get("model_name") or MAIN_MODEL
DEFAULT_TRAIN_MODEL = str(BASE_DIR / "hf_models" / "train" / "CoSER-Llama-3.1-8B")
TRAIN_BASE_MODEL = os.environ.get(
    "ZHIYUE_TRAIN_BASE_MODEL",
    DEFAULT_TRAIN_MODEL,
).strip()
TRAIN_BASE_MODEL_INFO = resolve_model_reference(TRAIN_BASE_MODEL, default_name=DEFAULT_TRAIN_MODEL)
STATE_LM_URL = os.environ.get(
    "ZHIYUE_STATE_LM_URL",
    "http://127.0.0.1:1235/v1/chat/completions",
).strip()
DEFAULT_STATE_MODEL = str(BASE_DIR / "models" / "state-model.gguf")
STATE_MODEL = os.environ.get(
    "ZHIYUE_STATE_MODEL",
    DEFAULT_STATE_MODEL,
).strip()
STATE_MODEL_INFO = resolve_model_reference(STATE_MODEL, default_name=DEFAULT_STATE_MODEL)
STATE_MODEL_NAME = STATE_MODEL_INFO.get("model_name") or STATE_MODEL
REVIEW_LM_URL = os.environ.get(
    "ZHIYUE_REVIEW_LM_URL",
    "http://127.0.0.1:1236/v1/chat/completions",
).strip()
DEFAULT_REVIEW_MODEL = str(BASE_DIR / "models" / "review-model.gguf")
REVIEW_MODEL = os.environ.get(
    "ZHIYUE_REVIEW_MODEL",
    DEFAULT_REVIEW_MODEL,
).strip()
REVIEW_MODEL_INFO = resolve_model_reference(REVIEW_MODEL, default_name=DEFAULT_REVIEW_MODEL)
REVIEW_MODEL_NAME = REVIEW_MODEL_INFO.get("model_name") or REVIEW_MODEL

ENABLE_TECHNICAL = False if PURE_CHAT_MODE else _env_flag("ZHIYUE_ENABLE_TECHNICAL", False)
ENABLE_EMOJI = False if PURE_CHAT_MODE else _env_flag("ZHIYUE_ENABLE_EMOJI", False)
ENABLE_TOOLS = False if PURE_CHAT_MODE else _env_flag("ZHIYUE_ENABLE_TOOLS", False)
ENABLE_BROWSER = False if PURE_CHAT_MODE else _env_flag("ZHIYUE_ENABLE_BROWSER", False)
ENABLE_OFFICE = False if PURE_CHAT_MODE else _env_flag("ZHIYUE_ENABLE_OFFICE", False)
ENABLE_SKILL_LEARNING = False if PURE_CHAT_MODE else _env_flag("ZHIYUE_ENABLE_SKILL_LEARNING", False)
ENABLE_SELF_IMPROVEMENT_CODE = False if PURE_CHAT_MODE else _env_flag("ZHIYUE_ENABLE_SELF_IMPROVEMENT_CODE", False)
ENABLE_GROWTH_REVIEW = _env_flag("ZHIYUE_GROWTH_ENABLE", True)

PROMPT_ASSET_DIR = Path(
    os.environ.get("ZHIYUE_PROMPT_ASSET_DIR", str(BASE_DIR / "data" / "prompt_assets"))
).resolve()
PROMPT_ASSET_DIR.mkdir(parents=True, exist_ok=True)
