# -*- coding: utf-8 -*-
from __future__ import annotations

import random

import _bootstrap_runtime  # noqa: F401
import zhiyue_companion_policy as companion_policy


def _record_companion_direct_reply(
    reply: str | None,
    *,
    user_msg: str,
    chat_history,
    intimacy,
    build_display_messages,
    clean_reply,
    record_direct_rule_turn,
    rule_name: str,
    exp: int = 1,
    energy_delta: int = -1,
    allow_followup: bool = False,
):
    if not reply:
        return None
    result = record_direct_rule_turn(
        user_msg,
        reply,
        rule_name,
        exp=exp,
        energy_delta=energy_delta,
        repair=False,
        user_directives=[],
    )
    return result


def get_growth_payload(user_msg, source_history=None, *, runtime):
    chat_history = runtime["chat_history"]
    intimacy = runtime["intimacy"]
    growth = runtime["growth"]
    emotion = runtime["emotion"]
    cognitive = runtime["cognitive"]
    layers = runtime["layers"]

    def _finalize_direct(result):
        if not isinstance(result, dict):
            return result
        return runtime["enforce_model_reply_quality"](
            result,
            user_msg,
            channel=runtime.get("channel") or "web",
            history=chat_history,
            user_directives=[],
            allow_persistent_directives=True,
        )

    pre = runtime["growth_entry"].preprocess_growth_turn(
        user_msg,
        source_history=source_history,
        chat_history=chat_history,
        maybe_decay_learning_notes=runtime["maybe_decay_learning_notes"],
        prune_expired_state=runtime["prune_expired_state"],
        maybe_compact_memories=runtime["maybe_compact_memories"],
        clean_reply=runtime["clean_reply"],
        build_display_messages=runtime["build_display_messages"],
        detect_user_directive=runtime["detect_user_directive"],
        load_user_directives=runtime["load_user_directives"],
        save_user_directives=runtime["save_user_directives"],
        state_hygiene_reply=runtime["state_hygiene_reply"],
        append_history_turn=runtime["append_history_turn"],
        intimacy=intimacy,
    )
    if pre["done"]:
        return pre["result"]

    effective_history = pre["effective_history"]
    user_directives = pre["active_directives"] or []

    shutdown_state = {}
    try:
        shutdown_state = companion_policy.get_shutdown_pending_state() or {}
    except Exception:
        shutdown_state = {}

    if companion_policy.should_shutdown_confirmation(user_msg, history=effective_history, shutdown_state=shutdown_state):
        try:
            farewell_reply = "嗯，我在。你慢慢说。"
            shutdown_result = {
                "ok": True,
                "reply": farewell_reply,
                "messages": [{"type": "text", "content": farewell_reply}],
                "reply_source": "shutdown_farewell",
                "requires_shutdown_confirmation": False,
                "shutdown_pending": True,
            }
            return shutdown_result
        except Exception as err:
            runtime["log_runtime_exception"]("shutdown_confirmation", err)

    if companion_policy.should_ack_reply_quality_feedback(user_msg, history=effective_history):
        reply = companion_policy.build_reply_quality_feedback_ack(user_directives=user_directives)
        result = runtime["record_direct_rule_turn"](
            user_msg,
            reply,
            "reply_quality_feedback_ack",
            exp=1,
            energy_delta=0,
            repair=False,
            user_directives=user_directives,
        )
        return _finalize_direct(result)

    if companion_policy.should_short_circuit_low_state(user_msg, history=effective_history):
        try:
            runtime["schedule_care_followup"](user_msg)
        except Exception as err:
            runtime["log_runtime_exception"]("user_low_state_hard.followup", err)
        reply = companion_policy.build_low_state_direct_reply(user_directives=user_directives)
        result = runtime["record_direct_rule_turn"](
            user_msg,
            reply,
            "user_low_state_hard",
            exp=1,
            energy_delta=-1,
            repair=False,
            user_directives=user_directives,
        )
        return _finalize_direct(result)

    try:
        runtime["remember_recent_user_state"](user_msg)
    except Exception as err:
        runtime["log_runtime_exception"]("remember_recent_user_state", err)

    if companion_policy.should_identity_probe(user_msg, history=effective_history):
        reply = companion_policy.build_identity_probe_reply(user_directives=user_directives)
        result = runtime["record_direct_rule_turn"](
            user_msg,
            reply,
            "identity_probe",
            exp=1,
            energy_delta=-1,
            repair=False,
            user_directives=user_directives,
        )
        return _finalize_direct(result)

    restored = runtime["restored_core_short_reply"](user_msg)
    if restored:
        if isinstance(restored, tuple):
            if len(restored) >= 2:
                rule_name, reply = restored[:2]
            else:
                rule_name, reply = "restored_core_short_reply", restored[0]
        else:
            rule_name, reply = "restored_core_short_reply", restored
        result = runtime["record_direct_rule_turn"](
            user_msg,
            reply,
            rule_name,
            exp=1,
            energy_delta=-1,
            repair=False,
            user_directives=user_directives,
        )
        return _finalize_direct(result)

    force_llm = False
    rule_hints = runtime["rule_hints_builder"].build_rule_hints(
        user_msg,
        force_llm=force_llm,
        load_persona_profile=runtime["load_persona_profile"],
        clean_person_name=runtime["clean_person_name"],
        learn_user_event=runtime["learn_user_event"],
        learn_life_event=runtime["learn_life_event"],
        schedule_care_followup=runtime["schedule_care_followup"],
        persona_fact_reply=runtime["persona_fact_reply"],
        user_low_state_reply=runtime["user_low_state_reply"],
        maybe_companion_short_reply=runtime["maybe_companion_short_reply"],
        recall_user_event_reply=runtime["recall_user_event_reply"],
        maybe_wait_return_reply=runtime["maybe_wait_return_reply"],
        growth=growth,
        log_runtime_exception=runtime["log_runtime_exception"],
    )

    intimacy.data["last_user_time"] = runtime["now_iso_local"]() if "now_iso_local" in runtime else intimacy.data.get("last_user_time")
    intimacy.save()
    runtime["schedule_care_followup"](user_msg)

    boundary_result = runtime["boundary_reply"](user_msg)
    if boundary_result:
        result = runtime["record_direct_rule_turn"](
            user_msg,
            boundary_result,
            "boundary_reply",
            exp=0,
            energy_delta=-1,
            repair=True,
            user_directives=user_directives,
        )
        result["boundary"] = True
        return _finalize_direct(result)

    if growth.check_boundary(user_msg) >= 2:
        intimacy.add_exp(5)

    effective_history = source_history if source_history is not None else chat_history
    pipeline_result = runtime["run_lm_judge_loop"](
        user_msg,
        effective_history,
        route_hint="lm",
        rule_hints=rule_hints,
        user_directives=user_directives,
    )

    return runtime["growth_finalize"].finalize_growth_reply(
        user_msg,
        pipeline_result=pipeline_result,
        effective_history=effective_history,
        chat_history=chat_history,
        is_placeholder_reply=runtime["is_placeholder_reply"],
        append_history_turn=runtime["append_history_turn"],
        growth=growth,
        autonomous_learn=runtime["autonomous_learn"],
        relationship_learn=runtime["relationship_learn"],
        self_review_turn=runtime["self_review_turn"],
        intimacy=intimacy,
        emotion=emotion,
        cognitive=cognitive,
        log_runtime_exception=runtime["log_runtime_exception"],
        memory=runtime["memory"],
        build_display_messages=runtime["build_display_messages"],
    )
