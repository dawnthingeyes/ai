from __future__ import annotations

import os
import sys
from pathlib import Path


CORE_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = CORE_DIR.parent.resolve()
MODULES_DIR = (PROJECT_ROOT / "modules").resolve()
CONFIG_DIR = (PROJECT_ROOT / "config").resolve()

_LOCAL_MODEL_SUFFIXES = {".gguf", ".bin", ".safetensors"}
_LOCAL_PATH_KEYS = ("_DIR", "_DB", "_FILE", "_PATH", "_ROOT")


def _looks_like_local_path(key: str, value: str) -> bool:
    if not value or "://" in value:
        return False
    if key.endswith(_LOCAL_PATH_KEYS):
        return True
    if key.endswith("_MODEL"):
        path = Path(value)
        return (
            any(sep in value for sep in ("/", "\\"))
            or value.startswith(".")
            or path.suffix.lower() in _LOCAL_MODEL_SUFFIXES
        )
    return False


def _normalize_env_value(key: str, value: str) -> str:
    normalized = os.path.expandvars(value.strip().strip('"').strip("'"))
    if _looks_like_local_path(key, normalized):
        path = Path(normalized).expanduser()
        if not path.is_absolute():
            path = PROJECT_ROOT / path
        return str(path.resolve())
    return normalized


def ensure_sys_path() -> None:
    for path in (CORE_DIR, MODULES_DIR, CONFIG_DIR):
        candidate = str(path)
        if candidate not in sys.path:
            sys.path.insert(0, candidate)


def load_project_env() -> Path:
    os.environ.setdefault("ZHIYUE_PROJECT_DIR", str(PROJECT_ROOT))
    env_path = PROJECT_ROOT / ".env"
    if not env_path.is_file():
        return env_path

    for raw_line in env_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        if not key or key in os.environ:
            continue
        os.environ[key] = _normalize_env_value(key, value)
    return env_path


ensure_sys_path()
load_project_env()
