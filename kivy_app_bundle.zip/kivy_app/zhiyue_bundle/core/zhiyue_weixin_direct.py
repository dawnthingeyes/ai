# -*- coding: utf-8 -*-
"""
Zhiyue Weixin direct bridge.

This bridge polls the Weixin iLink bot API and forwards text messages to the
local Zhiyue chat service. It bypasses CC Connect/Codex for replies.

If the local model or gateway is not ready, inbound messages are persisted in a
small local queue and retried in order.
"""
from __future__ import annotations

import base64
import hashlib
import ipaddress
import json
import logging
import os
import random
import re
import struct
import time
from dataclasses import dataclass
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import _bootstrap_runtime  # noqa: F401
import requests
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from PIL import Image
from zhiyue_project_paths import (
    BASE_DIR,
    WEIXIN_CONFIG_FILE,
    WEIXIN_DEAD_LETTER_FILE as DEAD_LETTER_FILE,
    WEIXIN_LOG_FILE as LOG_FILE,
    WEIXIN_QUEUE_FILE as QUEUE_FILE,
    WEIXIN_STATE_FILE as STATE_FILE,
)

EMOJI_DIR = Path(os.environ.get("ZHIYUE_EMOJI_DIR", str(BASE_DIR / "emojis")))
ILINK_CDN_BASE_URL = os.environ.get("ZHIYUE_ILINK_CDN_BASE_URL", "https://novac2c.cdn.weixin.qq.com/c2c").rstrip("/")

_wx_logger = logging.getLogger("zhiyue.weixin")
_wx_logger.setLevel(logging.DEBUG)
class _SafeRotatingFileHandler(RotatingFileHandler):
    def doRollover(self) -> None:  # pragma: no cover - defensive logging path
        try:
            super().doRollover()
        except PermissionError:
            self.stream = self._open()


_wx_log_path = str(LOG_FILE)
if not any(getattr(handler, "baseFilename", "") == _wx_log_path for handler in _wx_logger.handlers):
    _wx_handler = _SafeRotatingFileHandler(
        _wx_log_path, maxBytes=512 * 1024, backupCount=3, encoding="utf-8", delay=True
    )
    _wx_handler.setFormatter(logging.Formatter("%(asctime)s %(message)s", "%Y-%m-%d %H:%M:%S"))
    _wx_logger.addHandler(_wx_handler)
_wx_logger.propagate = False


def _log(message: str) -> None:
    try:
        _wx_logger.info(message)
    except Exception:
        pass


def _load_weixin_options() -> dict[str, Any]:
    if not WEIXIN_CONFIG_FILE.exists():
        return {}
    try:
        data = json.loads(WEIXIN_CONFIG_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


_WEIXIN_OPTIONS = _load_weixin_options()

LOCAL_CHAT_URL = os.environ.get("ZHIYUE_WECHAT_TARGET_URL", "http://127.0.0.1:8899/api/chat")
ILINK_BASE_URL = os.environ.get(
    "ZHIYUE_ILINK_BASE_URL",
    str(_WEIXIN_OPTIONS.get("base_url") or "https://ilinkai.weixin.qq.com"),
).rstrip("/")
ILINK_TOKEN = os.environ.get("ZHIYUE_ILINK_TOKEN", str(_WEIXIN_OPTIONS.get("token") or "")).strip()
if ILINK_TOKEN == "SETUP_REQUIRED":
    ILINK_TOKEN = ""
ILINK_ACCOUNT_ID = os.environ.get(
    "ZHIYUE_ILINK_ACCOUNT_ID",
    str(_WEIXIN_OPTIONS.get("account_id") or "zhiyue"),
).strip() or "zhiyue"
ILINK_ROUTE_TAG = os.environ.get("ZHIYUE_ILINK_ROUTE_TAG", str(_WEIXIN_OPTIONS.get("route_tag") or "")).strip()
ILINK_CHANNEL_VERSION = os.environ.get("ZHIYUE_ILINK_CHANNEL_VERSION", str(_WEIXIN_OPTIONS.get("channel_version") or "1.0.0")).strip() or "1.0.0"
_ALLOW_FROM_DEFAULT = str(_WEIXIN_OPTIONS.get("allow_from") or "*")
ILINK_ALLOW_FROM = {
    item.strip()
    for item in os.environ.get("ZHIYUE_ILINK_ALLOW_FROM", _ALLOW_FROM_DEFAULT).split(",")
    if item.strip()
}
POLL_FALLBACK_MS = int(os.environ.get("ZHIYUE_WEIXIN_POLL_MS", "35000"))
SLEEP_BETWEEN_POLLS = float(os.environ.get("ZHIYUE_WEIXIN_SLEEP", "1.0"))
EMOJI_HAPPINESS_THRESHOLD = int(os.environ.get("ZHIYUE_WEIXIN_EMOJI_HAPPINESS_THRESHOLD", "72"))
MAX_QUEUE_ATTEMPTS = max(1, int(os.environ.get("ZHIYUE_WEIXIN_MAX_ATTEMPTS", "4")))
LOCAL_CHAT_TIMEOUT_SECONDS = max(10, float(os.environ.get("ZHIYUE_WEIXIN_LOCAL_CHAT_TIMEOUT", "45")))
SEND_TEXT_TIMEOUT_SECONDS = max(10, float(os.environ.get("ZHIYUE_WEIXIN_SEND_TEXT_TIMEOUT", "20")))
SEND_MEDIA_TIMEOUT_SECONDS = max(15, float(os.environ.get("ZHIYUE_WEIXIN_SEND_MEDIA_TIMEOUT", "30")))
UPLOAD_TIMEOUT_SECONDS = max(15, float(os.environ.get("ZHIYUE_WEIXIN_UPLOAD_TIMEOUT", "30")))

_MEDIA_IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"}


def _make_uin() -> str:
    value = random.getrandbits(32)
    return base64.b64encode(struct.pack("<I", value)).decode("ascii")


def _read_json(path: Path, fallback: Any) -> Any:
    if not path.exists():
        return fallback
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return fallback


def _write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _append_jsonl(path: Path, row: dict[str, Any]) -> None:
    try:
        with path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
    except Exception:
        pass


def _is_public_http_url(url: str) -> bool:
    raw = str(url or "").strip()
    if not raw or not re.match(r"^https?://", raw, flags=re.I):
        return False
    parsed = urlparse(raw)
    host = (parsed.hostname or "").strip().lower()
    if not host or host in {"localhost"} or host.endswith(".local"):
        return False
    try:
        ip = ipaddress.ip_address(host)
        if any((ip.is_private, ip.is_loopback, ip.is_link_local, ip.is_reserved, ip.is_multicast, ip.is_unspecified)):
            return False
    except ValueError:
        pass
    return True


def _update_recent_session(state: dict[str, Any], *, reply_target: str, context_token: str, channel: str, message_id: str, from_user_id: str = "", to_user_id: str = "") -> None:
    state["recent_session"] = {
        "reply_target": str(reply_target or ""),
        "context_token": str(context_token or ""),
        "channel": str(channel or ""),
        "message_id": str(message_id or ""),
        "from_user_id": str(from_user_id or ""),
        "to_user_id": str(to_user_id or ""),
        "updated_at": int(time.time()),
    }
    state["last_target"] = str(reply_target or "")
    state["last_context_token"] = str(context_token or "")


def _load_state() -> dict[str, Any]:
    data = _read_json(STATE_FILE, {})
    return data if isinstance(data, dict) else {}


def _save_state(state: dict[str, Any]) -> None:
    _write_json(STATE_FILE, state)


def _load_queue() -> list[dict[str, Any]]:
    data = _read_json(QUEUE_FILE, [])
    return data if isinstance(data, list) else []


def _save_queue(items: list[dict[str, Any]]) -> None:
    _write_json(QUEUE_FILE, items)


def _append_dead_letter(item: dict[str, Any], reason: str) -> None:
    rows = _read_json(DEAD_LETTER_FILE, [])
    if not isinstance(rows, list):
        rows = []
    row = dict(item)
    row["dead_letter_reason"] = str(reason or "")
    row["dead_letter_at"] = int(time.time())
    rows.append(row)
    _write_json(DEAD_LETTER_FILE, rows[-500:])


def _extract_text(message: dict[str, Any]) -> str:
    for item in message.get("item_list") or []:
        if not isinstance(item, dict):
            continue
        if item.get("type") == 1:
            text_item = item.get("text_item") or {}
            text = text_item.get("text")
            if isinstance(text, str) and text.strip():
                return text.strip()
    return ""


def _message_id(message: dict[str, Any], text: str, from_user_id: str, context_token: str) -> str:
    explicit = message.get("message_id") or message.get("msg_id") or message.get("id")
    if explicit:
        return str(explicit)
    raw = json.dumps(message, ensure_ascii=False, sort_keys=True)
    stable = f"{from_user_id}|{context_token}|{text}|{raw}"
    return hashlib.sha1(stable.encode("utf-8", errors="ignore")).hexdigest()


def _split_weixin_reply(text: str) -> list[str]:
    text = (text or "").strip()
    if not text:
        return []
    if "---" in text:
        parts = [part.strip() for part in re.split(r"\s*---+\s*", text) if part.strip()]
        return parts[:4]
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    raw_parts = [part.strip() for part in re.split(r"(?<=[。！？!?…])\s*", text) if part.strip()]
    if not raw_parts:
        return [text]
    bubbles: list[str] = []
    current = ""
    for part in raw_parts:
        if not current:
            current = part
            continue
        projected = current + part
        if len(projected) <= 26:
            current = projected
        else:
            bubbles.append(current)
            current = part
    if current:
        bubbles.append(current)
    return bubbles[:4]


def _payload_to_bubbles(payload: dict[str, Any]) -> list[str]:
    messages = payload.get("messages")
    if isinstance(messages, list):
        bubbles: list[str] = []
        for message in messages:
            if not isinstance(message, dict):
                continue
            if str(message.get("type") or "").strip().lower() != "text":
                continue
            content = str(message.get("content") or "").strip()
            if content:
                bubbles.append(content)
        if bubbles:
            return bubbles[:4]
    return _split_weixin_reply(str(payload.get("reply") or ""))


class ILinkClient:
    def __init__(self) -> None:
        if not ILINK_TOKEN:
            raise RuntimeError("ZHIYUE_ILINK_TOKEN is required")
        self.session = requests.Session()
        self.headers = {
            "Content-Type": "application/json",
            "AuthorizationType": "ilink_bot_token",
            "Authorization": f"Bearer {ILINK_TOKEN}",
            "X-WECHAT-UIN": _make_uin(),
        }
        if ILINK_ROUTE_TAG:
            self.headers["SKRouteTag"] = ILINK_ROUTE_TAG
        self.api_base = f"{ILINK_BASE_URL}/ilink/bot"
        self.cdn_base_url = ILINK_CDN_BASE_URL

    def post(self, endpoint: str, payload: dict[str, Any], timeout: int = 45) -> dict[str, Any]:
        url = f"{self.api_base}/{endpoint.lstrip('/')}"
        payload = {
            "base_info": {"channel_version": ILINK_CHANNEL_VERSION},
            **payload,
        }
        resp = self.session.post(url, headers=self.headers, json=payload, timeout=timeout)
        resp.raise_for_status()
        raw = resp.content or b""
        if not raw.strip():
            return {}
        try:
            data = json.loads(raw.decode("utf-8", errors="replace"))
        except Exception:
            data = resp.json()
        if not isinstance(data, dict):
            raise RuntimeError(f"unexpected response from {endpoint}")
        ret = data.get("ret")
        if ret not in (None, 0, "0"):
            raise RuntimeError(f"{endpoint} failed ret={ret} payload={data}")
        return data

    def get_updates(self, cursor: str) -> dict[str, Any]:
        timeout = 12 if _load_queue() else max(15, min(25, int(POLL_FALLBACK_MS / 1000)))
        return self.post("getupdates", {"get_updates_buf": cursor}, timeout=timeout)

    def send_text(self, to_user_id: str, context_token: str, text: str) -> dict[str, Any]:
        payload = {
            "msg": {
                "to_user_id": to_user_id,
                "from_user_id": "",
                "client_id": f"zhiyue-weixin-{hashlib.sha1(f'{to_user_id}|{context_token}|{text}'.encode('utf-8', errors='ignore')).hexdigest()[:16]}",
                "message_type": 2,
                "message_state": 2,
                "context_token": context_token,
                "item_list": [{"type": 1, "text_item": {"text": text}}],
            }
        }
        result = self.post("sendmessage", payload, timeout=SEND_TEXT_TIMEOUT_SECONDS)
        _log(f"sendmessage ok to={to_user_id} ctx={context_token[:12]} text={text[:40]!r} resp={result}")
        return result

    def get_upload_url(self, *, filekey: str, media_type: int, to_user_id: str, rawsize: int, rawfilemd5: str, filesize: int, aeskey_hex: str) -> dict[str, Any]:
        payload = {
            "filekey": filekey,
            "media_type": media_type,
            "to_user_id": to_user_id,
            "rawsize": int(rawsize),
            "rawfilemd5": rawfilemd5,
            "filesize": int(filesize),
            "no_need_thumb": True,
            "aeskey": aeskey_hex,
        }
        return self.post("getuploadurl", payload, timeout=UPLOAD_TIMEOUT_SECONDS)

    def send_image(self, to_user_id: str, context_token: str, *, download_param: str, aeskey_b64: str, mid_size: int, width: int | None = None, height: int | None = None, caption: str = "") -> dict[str, Any]:
        if caption.strip():
            self.send_text(to_user_id=to_user_id, context_token=context_token, text=caption.strip())
        payload = {
            "msg": {
                "to_user_id": to_user_id,
                "from_user_id": "",
                "client_id": f"zhiyue-weixin-{hashlib.sha1(f'{to_user_id}|{context_token}|image|{download_param}'.encode('utf-8', errors='ignore')).hexdigest()[:16]}",
                "message_type": 2,
                "message_state": 2,
                "context_token": context_token,
                "item_list": [
                    {
                        "type": 2,
                        "image_item": {
                            "media": {
                                "encrypt_query_param": download_param,
                                "aes_key": aeskey_b64,
                                "encrypt_type": 1,
                            },
                            "mid_size": int(mid_size),
                            "width": int(width or 0),
                            "height": int(height or 0),
                        },
                    }
                ],
            }
        }
        result = self.post("sendmessage", payload, timeout=SEND_MEDIA_TIMEOUT_SECONDS)
        _log(f"sendimage ok to={to_user_id} ctx={context_token[:12]} resp={result}")
        return result

@dataclass
class _UploadedMedia:
    download_param: str
    aeskey_hex: str
    aeskey_b64: str
    aeskey_file_b64: str
    plaintext_size: int
    ciphertext_size: int


def _pkcs7_pad(data: bytes, block_size: int = 16) -> bytes:
    pad_len = block_size - (len(data) % block_size)
    return data + bytes([pad_len]) * pad_len


def _aes_ecb_encrypt(data: bytes, key: bytes) -> bytes:
    cipher = Cipher(algorithms.AES(key), modes.ECB())
    encryptor = cipher.encryptor()
    padded = _pkcs7_pad(data, 16)
    return encryptor.update(padded) + encryptor.finalize()


def _ciphertext_size(plaintext_size: int) -> int:
    return ((plaintext_size // 16) + 1) * 16


def _upload_media(client: ILinkClient, *, to_user_id: str, file_path: Path, media_type: int) -> _UploadedMedia:
    raw = file_path.read_bytes()
    aeskey = os.urandom(16)
    aeskey_hex = aeskey.hex()
    aeskey_b64 = base64.b64encode(aeskey).decode("ascii")
    aeskey_file_b64 = base64.b64encode(aeskey_hex.encode("ascii")).decode("ascii")
    filekey = os.urandom(16).hex()
    upload = client.get_upload_url(
        filekey=filekey,
        media_type=media_type,
        to_user_id=to_user_id,
        rawsize=len(raw),
        rawfilemd5=hashlib.md5(raw).hexdigest(),
        filesize=_ciphertext_size(len(raw)),
        aeskey_hex=aeskey_hex,
    )
    upload_param = str(upload.get("upload_param") or "")
    if not upload_param:
        raise RuntimeError(f"getuploadurl returned no upload_param: {upload}")
    ciphertext = _aes_ecb_encrypt(raw, aeskey)
    upload_url = f"{client.cdn_base_url}/upload?encrypted_query_param={requests.utils.quote(upload_param, safe='')}&filekey={requests.utils.quote(filekey, safe='')}"
    resp = requests.post(upload_url, data=ciphertext, headers={"Content-Type": "application/octet-stream"}, timeout=60)
    resp.raise_for_status()
    download_param = resp.headers.get("x-encrypted-param") or ""
    if not download_param:
        raise RuntimeError("CDN upload missing x-encrypted-param header")
    return _UploadedMedia(
        download_param=download_param,
        aeskey_hex=aeskey_hex,
        aeskey_b64=aeskey_b64,
        aeskey_file_b64=aeskey_file_b64,
        plaintext_size=len(raw),
        ciphertext_size=len(ciphertext),
    )


def _emoji_path(name: str) -> Path | None:
    filename = Path(str(name or "")).name
    if not filename:
        return None
    path = EMOJI_DIR / filename
    return path if path.exists() and path.is_file() else None


def _prepare_image_for_weixin(src: Path) -> Path:
    dst = src.with_name(f"wx_{hashlib.sha1(str(src).encode('utf-8', errors='ignore')).hexdigest()[:10]}.png")
    with Image.open(src) as img:
        if getattr(img, "is_animated", False):
            img.seek(0)
        frame = img.convert("RGBA")
        bg = Image.new("RGBA", frame.size, (255, 255, 255, 255))
        merged = Image.alpha_composite(bg, frame).convert("RGB")
        max_side = max(merged.size)
        if max_side > 512:
            scale = 512.0 / float(max_side)
            new_size = (max(1, int(merged.size[0] * scale)), max(1, int(merged.size[1] * scale)))
            merged = merged.resize(new_size)
        merged.save(dst, format="PNG", optimize=True)
    return dst


def _image_dimensions(path: Path) -> tuple[int, int]:
    with Image.open(path) as img:
        return int(img.width), int(img.height)


def _extract_emoji_names(payload: dict[str, Any]) -> list[str]:
    names: list[str] = []
    for item in payload.get("messages") or []:
        if isinstance(item, dict) and item.get("type") == "emoji":
            content = item.get("content")
            if isinstance(content, str) and content.strip():
                names.append(Path(content).name)
                continue
            url = item.get("url")
            if isinstance(url, str) and url.strip():
                names.append(f"url:{url.strip()}")
    return names[:2]


def _download_remote_emoji(url: str) -> Path | None:
    try:
        if not _is_public_http_url(url):
            return None
        resp = requests.get(url, timeout=15)
        resp.raise_for_status()
        mime = str(resp.headers.get("content-type") or "").lower()
        if "image" not in mime:
            return None
        final_url = str(resp.url or "").strip()
        if final_url and not _is_public_http_url(final_url):
            return None
        raw = resp.content or b""
        if not raw or len(raw) > 2 * 1024 * 1024:
            return None
        try:
            from io import BytesIO as _BytesIO
            with Image.open(_BytesIO(raw)) as img:
                if getattr(img, "is_animated", False):
                    img.seek(0)
                frame = img.convert("RGBA")
                bg = Image.new("RGBA", frame.size, (255, 255, 255, 255))
                merged = Image.alpha_composite(bg, frame).convert("RGB")
                if merged.width < 16 or merged.height < 16 or merged.width > 1024 or merged.height > 1024:
                    return None
                temp = BASE_DIR / f"_wx_remote_{hashlib.sha1(url.encode('utf-8', errors='ignore')).hexdigest()[:10]}.png"
                merged.save(temp, format="PNG", optimize=True)
        except Exception:
            return None
        return temp
    except Exception:
        return None


def _resolve_local_media_path(value: str) -> Path | None:
    candidate = Path(str(value or "").strip())
    if not candidate.is_absolute():
        candidate = (BASE_DIR / candidate).resolve()
    try:
        candidate.relative_to(BASE_DIR.resolve())
    except Exception:
        return None
    if not candidate.exists() or not candidate.is_file():
        return None
    if candidate.suffix.lower() not in _MEDIA_IMAGE_SUFFIXES:
        return None
    return candidate


def _should_auto_emoji_fallback(payload: dict[str, Any], incoming_text: str = "") -> bool:
    if not isinstance(payload, dict):
        return False
    media_policy = payload.get("media_policy") if isinstance(payload.get("media_policy"), dict) else {}
    if not bool(media_policy.get("auto_emoji", False)):
        return False
    if payload.get("media_actions"):
        return False
    if any(isinstance(message, dict) and str(message.get("type") or "").strip().lower() == "emoji" for message in (payload.get("messages") or [])):
        return False
    reply = str(payload.get("reply") or "").strip()
    incoming = str(incoming_text or "").strip()
    technical_terms = ("文件", "代码", "测试", "接口", "脚本", "日志", "报错", "路径", "函数", "部署")
    if any(term in incoming for term in technical_terms) or any(term in reply for term in technical_terms):
        return False
    try:
        mood = int(payload.get("mood") or 0)
    except Exception:
        mood = 0
    return mood >= EMOJI_HAPPINESS_THRESHOLD and bool(reply)


def _fallback_positive_emoji_names(payload: dict[str, Any], incoming_text: str = "") -> list[str]:
    _ = incoming_text
    preferred = []
    for value in ("开心.png", "偷笑.png", "笑.png", "smile.png"):
        if _emoji_path(value):
            preferred.append(value)
    return preferred[:1]

class ZhiyueWeixinBridge:
    PROACTIVE_INTERVAL = 180  # check proactive every 3 min

    def __init__(self) -> None:
        self.client = ILinkClient()
        self.state = _load_state()
        self.handled_ids = set(self.state.get("handled_ids") or [])
        self._last_proactive_check = 0.0

    def _allowed(self, from_user_id: str) -> bool:
        return "*" in ILINK_ALLOW_FROM or from_user_id in ILINK_ALLOW_FROM

    def _local_chat_ready(self) -> bool:
        try:
            resp = requests.get("http://127.0.0.1:8899/api/gateway/health", timeout=3)
            if resp.status_code >= 500:
                return False
        except Exception:
            return False
        try:
            resp = requests.get("http://127.0.0.1:8899/api/health", timeout=3)
            return resp.status_code < 500
        except Exception:
            return False

    def _lm_model_ready(self) -> bool:
        """Check if LM Studio has a loaded model that can handle requests."""
        try:
            resp = requests.get("http://127.0.0.1:1234/v1/models", timeout=5)
            if resp.status_code != 200:
                return False
            data = resp.json()
            models = data.get("data") or []
            return any(m.get("id", "").startswith("qwen") for m in models)
        except Exception:
            return False

    def _local_chat_payload(self, text: str, channel: str) -> dict[str, Any]:
        if not self._local_chat_ready():
            raise RuntimeError("local chat backend unavailable")
        resp = requests.post(
            LOCAL_CHAT_URL,
            json={"message": text, "channel": f"weixin:{channel}"},
            timeout=LOCAL_CHAT_TIMEOUT_SECONDS,
        )
        resp.raise_for_status()
        payload = resp.json()
        if isinstance(payload, dict):
            reply = payload.get("reply")
            if isinstance(reply, str) and reply.strip():
                return payload
            messages = payload.get("messages")
            if isinstance(messages, list):
                for message in messages:
                    if isinstance(message, dict):
                        content = message.get("content")
                        if isinstance(content, str) and content.strip():
                            payload["reply"] = content.strip()
                            return payload
        raise RuntimeError("local chat returned empty reply")

    def _local_chat_reply(self, text: str, channel: str) -> dict[str, Any]:
        return self._local_chat_payload(text, channel)

    def _normalize_local_chat_result(self, result: Any) -> dict[str, Any]:
        if isinstance(result, dict):
            payload = dict(result)
            reply = payload.get("reply")
            if isinstance(reply, str) and reply.strip():
                return payload
            messages = payload.get("messages")
            if isinstance(messages, list):
                for message in messages:
                    if isinstance(message, dict):
                        content = message.get("content")
                        if isinstance(content, str) and content.strip():
                            payload["reply"] = content.strip()
                            return payload
            raise RuntimeError("local chat returned empty reply")
        if isinstance(result, str):
            text = result.strip()
            if text:
                return {"reply": text, "messages": [{"type": "text", "content": text}]}
        raise RuntimeError("local chat returned empty reply")

    def _build_queue_item(self, message: dict[str, Any]) -> dict[str, Any] | None:
        if message.get("message_type") not in (None, 1):
            return None
        from_user_id = str(message.get("from_user_id") or "").strip()
        to_user_id = str(message.get("to_user_id") or "").strip()
        if not from_user_id or not self._allowed(from_user_id):
            _log(f"skip message from={from_user_id!r}")
            return None
        text = _extract_text(message)
        if not text:
            _log(f"skip empty text from={from_user_id!r}")
            return None
        context_token = str(message.get("context_token") or "")
        queue_id = _message_id(message, text, from_user_id, context_token)
        if queue_id in self.handled_ids:
            _log(f"skip handled message_id={queue_id}")
            return None
        is_private = not to_user_id or to_user_id == ILINK_ACCOUNT_ID or not str(message.get("session_id") or "").strip()
        reply_target = from_user_id if is_private else to_user_id
        return {
            "id": queue_id,
            "from_user_id": from_user_id,
            "to_user_id": to_user_id,
            "reply_target": reply_target,
            "chat_type": "private" if is_private else "group",
            "client_id": f"zhiyue-weixin-{queue_id[:16]}",
            "context_token": context_token,
            "channel": str(message.get("session_id") or from_user_id),
            "text": text,
            "created_at": time.time(),
            "attempts": 0,
        }

    def _enqueue_if_new(self, item: dict[str, Any]) -> bool:
        queue = _load_queue()
        existing_ids = {str(queued.get("id")) for queued in queue if isinstance(queued, dict)}
        item_id = str(item.get("id") or "")
        if not item_id or item_id in existing_ids or item_id in self.handled_ids:
            return False
        queue.append(item)
        _save_queue(queue)
        _log(
            "queued message "
            f"id={item_id} "
            f"type={item.get('chat_type')} "
            f"reply_target={item.get('reply_target')!r} "
            f"text={str(item.get('text', ''))[:40]!r}"
        )
        return True

    def _flush_pending(self) -> int:
        queue = _load_queue()
        if not queue:
            return 0
        local_chat_ready = self._local_chat_ready()
        has_ready_payload = any(
            isinstance(item, dict) and isinstance(item.get("ready_payload"), dict) and (
                str((item.get("ready_payload") or {}).get("reply") or "").strip()
                or bool((item.get("ready_payload") or {}).get("messages"))
                or bool((item.get("ready_payload") or {}).get("media_actions"))
            )
            for item in queue
        )
        if not local_chat_ready and not has_ready_payload:
            _log("local chat not ready, keep pending queue untouched")
            return 0
        remaining: list[dict[str, Any]] = []
        flushed = 0
        for index, item in enumerate(queue):
            if not isinstance(item, dict):
                continue
            try:
                item["attempts"] = int(item.get("attempts") or 0) + 1
                payload = item.get("ready_payload") if isinstance(item.get("ready_payload"), dict) else {}
                if not payload:
                    if not local_chat_ready:
                        remaining.append(item)
                        continue
                    payload = self._normalize_local_chat_result(
                        self._local_chat_reply(str(item.get("text") or ""), str(item.get("channel") or "wechat"))
                    )
                    item["ready_payload"] = payload
                reply = str(payload.get("reply") or "").strip()
                target = str(item.get("reply_target") or item.get("from_user_id") or item.get("to_user_id") or "")
                context = str(item.get("context_token") or "")
                for part in _payload_to_bubbles(payload):
                    self.client.send_text(to_user_id=target, context_token=context, text=part)
                    time.sleep(0.25)
                explicit_emoji_names = []
                for message in (payload.get("messages") or []):
                    if not isinstance(message, dict):
                        continue
                    if str(message.get("type") or "").strip().lower() != "emoji":
                        continue
                    value = str(message.get("content") or message.get("url") or "").strip()
                    if value:
                        explicit_emoji_names.append(Path(value).name if not value.startswith("url:") else value)
                emoji_names = []
                for action in (payload.get("media_actions") or []):
                    if not isinstance(action, dict):
                        continue
                    kind = str(action.get("kind") or action.get("type") or "").strip().lower()
                    if kind not in {"emoji", "image"}:
                        continue
                    value = str(action.get("value") or action.get("filename") or "").strip()
                    if value:
                        emoji_names.append(value)
                if explicit_emoji_names:
                    emoji_names = explicit_emoji_names + emoji_names
                elif not emoji_names and _should_auto_emoji_fallback(payload, str(item.get("text") or "")):
                    emoji_names = _fallback_positive_emoji_names(payload, str(item.get("text") or ""))
                for emoji_name in emoji_names:
                    remote_temp = None
                    try:
                        emoji_path = None
                        if str(emoji_name).startswith("url:"):
                            remote_temp = _download_remote_emoji(str(emoji_name)[4:])
                            emoji_path = remote_temp
                        else:
                            emoji_path = _resolve_local_media_path(emoji_name) or _emoji_path(emoji_name)
                        if not emoji_path:
                            continue
                        emoji_media = _prepare_image_for_weixin(emoji_path)
                        width, height = _image_dimensions(emoji_media)
                        uploaded = _upload_media(self.client, to_user_id=target, file_path=emoji_media, media_type=1)
                        self.client.send_image(
                            to_user_id=target,
                            context_token=context,
                            download_param=uploaded.download_param,
                            aeskey_b64=uploaded.aeskey_file_b64,
                            mid_size=uploaded.ciphertext_size,
                            width=width,
                            height=height,
                        )
                        time.sleep(0.25)
                    except Exception as media_err:
                        _log(f"emoji send failed id={item.get('id')} emoji={emoji_name!r}: {media_err}")
                    finally:
                        if remote_temp and remote_temp.exists():
                            try:
                                remote_temp.unlink()
                            except Exception:
                                pass
                item_id = str(item.get("id") or "")
                if item_id:
                    self.handled_ids.add(item_id)
                flushed += 1
            except Exception as err:
                # LM model still loading — don't count this as a real failure; keep waiting
                if not self._lm_model_ready():
                    item["attempts"] = max(0, int(item.get("attempts") or 0) - 1)
                    _log(f"flush waiting (LM loading) id={item.get('id')} attempts={item.get('attempts')}")
                    remaining.append(item)
                    remaining.extend(x for x in queue[index + 1:] if isinstance(x, dict))
                    break
                _log(f"flush pending failed id={item.get('id')} attempts={item.get('attempts')}: {err}")
                if int(item.get("attempts") or 0) >= MAX_QUEUE_ATTEMPTS:
                    _append_dead_letter(item, str(err))
                    item_id = str(item.get("id") or "")
                    if item_id:
                        self.handled_ids.add(item_id)
                    _log(f"moved to dead-letter id={item.get('id')} attempts={item.get('attempts')}")
                    continue
                remaining.append(item)
                remaining.extend(x for x in queue[index + 1:] if isinstance(x, dict))
                break
        if not remaining:
            _save_queue([])
        else:
            _save_queue(remaining[-500:])
        self.state["handled_ids"] = sorted(self.handled_ids)[-500:]
        _save_state(self.state)
        if flushed:
            _log(f"flushed pending count={flushed} remaining={len(remaining)}")
        return flushed

    def _handle_message(self, message: dict[str, Any]) -> bool:
        item = self._build_queue_item(message)
        if not item:
            return False
        _update_recent_session(
            self.state,
            reply_target=str(item.get("reply_target") or ""),
            context_token=str(item.get("context_token") or ""),
            channel=str(item.get("channel") or ""),
            message_id=str(item.get("id") or ""),
            from_user_id=str(item.get("from_user_id") or ""),
            to_user_id=str(item.get("to_user_id") or ""),
        )
        _save_state(self.state)
        return self._enqueue_if_new(item)

    def run_once(self) -> int:
        cursor = str(self.state.get("get_updates_buf") or "")
        try:
            self._flush_pending()
        except Exception as err:
            _log(f"initial flush failed: {err}")
        payload = self.client.get_updates(cursor)
        msgs = payload.get("msgs") or []
        if not isinstance(msgs, list):
            msgs = []
        queued = 0
        for msg in msgs:
            if isinstance(msg, dict):
                try:
                    _log(
                        "incoming "
                        f"from={msg.get('from_user_id')!r} "
                        f"to={msg.get('to_user_id')!r} "
                        f"session={msg.get('session_id')!r} "
                        f"state={msg.get('message_state')!r}"
                    )
                    if self._handle_message(msg):
                        queued += 1
                except Exception as err:
                    _log(f"message handling failed: {err}")
        try:
            self._flush_pending()
        except Exception as err:
            _log(f"final flush failed: {err}")
        new_cursor = payload.get("get_updates_buf")
        if isinstance(new_cursor, str) and new_cursor:
            self.state["get_updates_buf"] = new_cursor
        _save_state(self.state)
        _log(f"poll ok queued={queued} cursor_set={bool(new_cursor)} pending={len(_load_queue())}")
        return queued

    def _check_and_send_proactive(self) -> bool:
        """Poll backend for proactive messages and deliver them."""
        if not self._lm_model_ready():
            return False
        if not self._local_chat_ready():
            return False
        recent = self.state.get("recent_session") or {}
        target = str(recent.get("reply_target") or "").strip()
        context = str(recent.get("context_token") or "").strip()
        if not target:
            target = str(self.state.get("last_target") or self.state.get("last_reply_target") or "").strip()
        if not context:
            context = str(self.state.get("last_context_token") or self.state.get("last_reply_context") or "").strip()
        if not target or not context:
            return False
        try:
            resp = requests.get(
                LOCAL_CHAT_URL.replace('/api/chat', '/api/proactive'),
                timeout=90,
            )
            data = resp.json()
            if not isinstance(data, dict) or not data.get("ok"):
                return False
            reply = str(data.get("reply") or "").strip()
            if not reply and not data.get("messages"):
                return False
            _log(f"proactive reply: {reply[:60]!r}")
            self.state["last_target"] = target
            self.state["last_context_token"] = context
            _save_state(self.state)
            for part in _payload_to_bubbles(data):
                self.client.send_text(to_user_id=target, context_token=context, text=part)
                time.sleep(0.25)
            return True
        except Exception as err:
            _log(f"proactive check failed: {err}")
        return False

    def run_forever(self) -> None:
        while True:
            try:
                self.run_once()
            except Exception as err:
                _log(f"poll failed: {err}")
                try:
                    self._flush_pending()
                except Exception as flush_err:
                    _log(f"flush after poll failure failed: {flush_err}")
                time.sleep(max(1.0, min(5.0, SLEEP_BETWEEN_POLLS + 1.0)))
                continue
            # Proactive check (throttled to every 3 min)
            now_ts = time.time()
            if now_ts - self._last_proactive_check >= self.PROACTIVE_INTERVAL:
                self._last_proactive_check = now_ts
                try:
                    self._check_and_send_proactive()
                except Exception as err:
                    _log(f"proactive delivery failed: {err}")
            time.sleep(max(0.5, SLEEP_BETWEEN_POLLS))


def main() -> int:
    bridge = ZhiyueWeixinBridge()
    bridge.run_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
