from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
import zipfile
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import _bootstrap_runtime  # noqa: F401
import requests

import manage_zhiyue as mz
from zhiyue_project_paths import BASE_DIR, RUNTIME_DIR


CORE_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = CORE_DIR.parent.resolve()
ENGINE_DIR = PROJECT_ROOT / "Engine"
MODELS_DIR = PROJECT_ROOT / "models"
PORTABLE_DIR = RUNTIME_DIR / "portable"
PORTABLE_LOG_DIR = PORTABLE_DIR / "logs"
HARDWARE_PROFILE_FILE = PORTABLE_DIR / "hardware_profile.json"
RUNTIME_STATE_FILE = PORTABLE_DIR / "kobold_runtime_state.json"

MAIN_PORT = 5001
STATE_PORT = 5002
REVIEW_PORT = 5003
WARMUP_PORT = 5010
MODEL_PORTS = (MAIN_PORT, STATE_PORT, REVIEW_PORT, WARMUP_PORT)

DEFAULT_FULL_VRAM_GB = float(os.environ.get("ZHIYUE_FULL_VRAM_GB", "20"))
DEFAULT_BALANCED_VRAM_GB = float(os.environ.get("ZHIYUE_BALANCED_VRAM_GB", "10"))
DEFAULT_SINGLE_VRAM_GB = float(os.environ.get("ZHIYUE_SINGLE_VRAM_GB", "4"))
DEFAULT_MAIN_CONTEXT = int(os.environ.get("ZHIYUE_MAIN_CONTEXT", "4096"))
DEFAULT_AUX_CONTEXT = int(os.environ.get("ZHIYUE_AUX_CONTEXT", "2048"))
DEFAULT_WARMUP_CONTEXT = int(os.environ.get("ZHIYUE_WARMUP_CONTEXT", "1024"))
DEFAULT_BALANCED_STATE_LAYERS = int(os.environ.get("ZHIYUE_BALANCED_STATE_GPU_LAYERS", "12"))
DEFAULT_BALANCED_REVIEW_LAYERS = int(os.environ.get("ZHIYUE_BALANCED_REVIEW_GPU_LAYERS", "8"))
DEFAULT_CPU_THREADS = max(2, min(os.cpu_count() or 4, int(os.environ.get("ZHIYUE_CPU_THREADS_MAX", "8"))))
DEFAULT_HTTP_TIMEOUT = float(os.environ.get("ZHIYUE_PORTABLE_HTTP_TIMEOUT_SECONDS", "3"))
DEFAULT_READY_TIMEOUT = float(os.environ.get("ZHIYUE_PORTABLE_READY_TIMEOUT_SECONDS", "150"))
DEFAULT_WARMUP_TIMEOUT = float(os.environ.get("ZHIYUE_PORTABLE_WARMUP_TIMEOUT_SECONDS", "90"))
DEFAULT_RELEASE_BASE = os.environ.get(
    "ZHIYUE_KOBOLDCPP_RELEASE_BASE",
    "https://github.com/LostRuins/koboldcpp/releases/latest/download",
).rstrip("/")
LMSTUDIO_PORT = int(os.environ.get("ZHIYUE_LMSTUDIO_PORT", "1234"))
LMSTUDIO_HOST = os.environ.get("ZHIYUE_LMSTUDIO_HOST", "127.0.0.1").strip() or "127.0.0.1"
LMSTUDIO_URL = f"http://{LMSTUDIO_HOST}:{LMSTUDIO_PORT}/v1/chat/completions"
LMSTUDIO_MODELS_URL = f"http://{LMSTUDIO_HOST}:{LMSTUDIO_PORT}/v1/models"
OLLAMA_PORT = int(os.environ.get("ZHIYUE_OLLAMA_PORT", "11434"))
OLLAMA_HOST = os.environ.get("ZHIYUE_OLLAMA_HOST", "127.0.0.1").strip() or "127.0.0.1"
OLLAMA_URL = f"http://{OLLAMA_HOST}:{OLLAMA_PORT}/v1/chat/completions"
OLLAMA_MODELS_URL = f"http://{OLLAMA_HOST}:{OLLAMA_PORT}/api/tags"
ENGINE_PREFERENCE = [
    item.strip().lower()
    for item in os.environ.get("ZHIYUE_ENGINE_PREFERENCE", "lmstudio").split(",")
    if item.strip()
]

MODEL_PATHS = {
    "main": Path(os.environ.get("ZHIYUE_MAIN_MODEL", str(MODELS_DIR / "main-model.gguf"))).expanduser().resolve(),
    "state": Path(os.environ.get("ZHIYUE_STATE_MODEL", str(MODELS_DIR / "state-model.gguf"))).expanduser().resolve(),
    "review": Path(os.environ.get("ZHIYUE_REVIEW_MODEL", str(MODELS_DIR / "review-model.gguf"))).expanduser().resolve(),
}

ENGINE_VARIANTS = {
    "cuda": {
        "target": ENGINE_DIR / "koboldcpp_cuda.exe",
        "fallbacks": ("koboldcpp.exe", "koboldcpp_cublas.exe"),
        "candidates": (
            "koboldcpp.exe",
            "koboldcpp_cuda.exe",
            "koboldcpp_cublas.exe",
            "koboldcpp.zip",
            "koboldcpp_cuda.zip",
            "koboldcpp_cublas.zip",
        ),
    },
    "vulkan": {
        "target": ENGINE_DIR / "koboldcpp_vulkan.exe",
        "fallbacks": ("koboldcpp_nocuda.exe", "koboldcpp.exe"),
        "candidates": (
            "koboldcpp_vulkan.exe",
            "koboldcpp_nocuda.exe",
            "koboldcpp_vulkan.zip",
            "koboldcpp_nocuda.zip",
        ),
    },
    "cpu": {
        "target": ENGINE_DIR / "koboldcpp_oldpc.exe",
        "fallbacks": ("koboldcpp_oldcpu.exe", "koboldcpp_nocuda.exe", "koboldcpp_vulkan.exe"),
        "candidates": (
            "koboldcpp_oldpc.exe",
            "koboldcpp_oldcpu.exe",
            "koboldcpp_nocuda.exe",
            "koboldcpp_oldpc.zip",
            "koboldcpp_oldcpu.zip",
            "koboldcpp_nocuda.zip",
        ),
    },
}
_PROBE_CACHE: dict[tuple[str, str, int, int], tuple[bool, str]] = {}


@dataclass
class GpuInfo:
    name: str
    vendor: str
    vram_gb: float
    pnp_device_id: str
    driver_version: str
    video_processor: str
    is_software: bool = False


@dataclass
class HardwareProfile:
    requested_backend: str
    requested_profile: str
    selected_backend: str
    selected_profile: str
    primary_gpu: str
    vendor: str
    vram_gb: float
    cuda_available: bool
    vulkan_available: bool
    engine_path: str
    source: str
    reasons: list[str]
    gpus: list[dict[str, Any]]


@dataclass
class ServerSpec:
    name: str
    port: int
    model_path: Path
    context_size: int
    gpu_layers: int | None
    alias: str
    shared_with: str | None = None


@dataclass
class LaunchPlan:
    profile: str
    backend: str
    servers: list[ServerSpec]
    env: dict[str, str]
    reasons: list[str]


def ensure_dirs() -> None:
    PORTABLE_LOG_DIR.mkdir(parents=True, exist_ok=True)
    ENGINE_DIR.mkdir(parents=True, exist_ok=True)


def json_dump(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def safe_json_print(payload: Any) -> None:
    text = json.dumps(payload, ensure_ascii=False, indent=2)
    try:
        print(text)
    except UnicodeEncodeError:
        sys.stdout.buffer.write(text.encode("utf-8", errors="backslashreplace"))
        sys.stdout.buffer.write(b"\n")


def _vendor_from_name(name: str, pnp_device_id: str = "") -> str:
    lowered = f"{name} {pnp_device_id}".lower()
    if any(token in lowered for token in ("nvidia", "geforce", "rtx", "quadro", "tesla")):
        return "nvidia"
    if any(token in lowered for token in ("amd", "radeon", "rx ", "firepro")):
        return "amd"
    if "intel" in lowered:
        return "intel"
    if "microsoft basic" in lowered:
        return "microsoft"
    return "unknown"


def _extract_named_vram_gb(name: str) -> float:
    match = re.search(r"(\d+(?:\.\d+)?)\s*gb\b", name, re.IGNORECASE)
    if not match:
        return 0.0
    try:
        return float(match.group(1))
    except Exception:
        return 0.0


def _run_capture(command: list[str], *, timeout: float = 10.0) -> tuple[int, str]:
    try:
        proc = subprocess.run(
            command,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            cwd=str(PROJECT_ROOT),
        )
        output = (proc.stdout or "") + (proc.stderr or "")
        return proc.returncode, output.strip()
    except Exception as err:
        return 1, str(err)


def _run_capture_env(command: list[str], *, timeout: float = 30.0, env: dict[str, str] | None = None) -> tuple[int, str]:
    runtime_env = os.environ.copy()
    if env:
        runtime_env.update({key: str(value) for key, value in env.items()})
    try:
        proc = subprocess.run(
            command,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            cwd=str(PROJECT_ROOT),
            env=runtime_env,
        )
        output = (proc.stdout or "") + (proc.stderr or "")
        return proc.returncode, output.strip()
    except Exception as err:
        return 1, str(err)


def _run_powershell_json(script: str) -> Any:
    rc, output = _run_capture(["powershell", "-NoProfile", "-Command", script], timeout=15.0)
    if rc != 0 or not output:
        return None
    try:
        return json.loads(output)
    except Exception:
        return None


def probe_windows_gpus() -> list[GpuInfo]:
    payload = _run_powershell_json(
        "Get-CimInstance Win32_VideoController | "
        "Select-Object Name,AdapterRAM,PNPDeviceID,DriverVersion,VideoProcessor | "
        "ConvertTo-Json -Compress"
    )
    if isinstance(payload, dict):
        payload = [payload]
    gpus: list[GpuInfo] = []
    for item in payload or []:
        if not isinstance(item, dict):
            continue
        name = str(item.get("Name") or "").strip()
        if not name:
            continue
        try:
            ram = int(item.get("AdapterRAM") or 0)
        except Exception:
            ram = 0
        vendor = _vendor_from_name(name, str(item.get("PNPDeviceID") or ""))
        adapter_vram_gb = round(max(ram, 0) / (1024 ** 3), 2)
        named_vram_gb = _extract_named_vram_gb(name)
        gpu = GpuInfo(
            name=name,
            vendor=vendor,
            vram_gb=max(adapter_vram_gb, named_vram_gb),
            pnp_device_id=str(item.get("PNPDeviceID") or ""),
            driver_version=str(item.get("DriverVersion") or ""),
            video_processor=str(item.get("VideoProcessor") or ""),
            is_software=vendor == "microsoft",
        )
        gpus.append(gpu)
    gpus.sort(key=lambda item: item.vram_gb, reverse=True)
    return gpus


def probe_cuda_devices() -> list[GpuInfo]:
    rc, output = _run_capture(
        [
            "nvidia-smi",
            "--query-gpu=name,memory.total,driver_version",
            "--format=csv,noheader,nounits",
        ],
        timeout=8.0,
    )
    if rc != 0 or not output:
        return []
    devices: list[GpuInfo] = []
    for raw_line in output.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        parts = [item.strip() for item in line.split(",")]
        if len(parts) < 2:
            continue
        name = parts[0]
        try:
            vram_gb = round(float(parts[1]) / 1024.0, 2)
        except Exception:
            vram_gb = 0.0
        devices.append(
            GpuInfo(
                name=name,
                vendor="nvidia",
                vram_gb=vram_gb,
                pnp_device_id="",
                driver_version=parts[2] if len(parts) > 2 else "",
                video_processor=name,
                is_software=False,
            )
        )
    return devices


def _probe_vulkan_loader() -> bool:
    vulkan_info = shutil.which("vulkaninfo")
    if vulkan_info:
        rc, _ = _run_capture([vulkan_info, "--summary"], timeout=10.0)
        if rc == 0:
            return True
    system32 = Path(os.environ.get("WINDIR", r"C:\Windows")) / "System32" / "vulkan-1.dll"
    if not system32.exists():
        return False
    payload = _run_powershell_json(
        "$paths=@('HKLM:\\SOFTWARE\\Khronos\\Vulkan\\Drivers','HKLM:\\SOFTWARE\\WOW6432Node\\Khronos\\Vulkan\\Drivers');"
        "$found=@();"
        "foreach($path in $paths){ if(Test-Path $path){ $found += (Get-ChildItem $path | Select-Object -ExpandProperty PSChildName) } };"
        "$found | ConvertTo-Json -Compress"
    )
    if isinstance(payload, list):
        return len(payload) > 0
    return bool(payload)


def detect_hardware(requested_backend: str = "auto", requested_profile: str = "auto") -> HardwareProfile:
    ensure_dirs()
    windows_gpus = probe_windows_gpus()
    cuda_devices = probe_cuda_devices()
    cuda_available = bool(cuda_devices)
    vulkan_available = _probe_vulkan_loader() and any(g.vendor in {"nvidia", "amd", "intel"} and not g.is_software for g in windows_gpus)

    reasons: list[str] = []
    selected_backend = requested_backend if requested_backend in {"cuda", "vulkan", "cpu"} else "auto"
    selected_profile = requested_profile if requested_profile in {"full", "balanced", "single", "cpu_fallback"} else "auto"

    if selected_backend == "auto":
        if cuda_available:
            selected_backend = "cuda"
            reasons.append("auto_backend:cuda")
        elif vulkan_available:
            selected_backend = "vulkan"
            reasons.append("auto_backend:vulkan")
        else:
            selected_backend = "cpu"
            reasons.append("auto_backend:cpu")
    else:
        reasons.append(f"manual_backend:{selected_backend}")

    primary_name = ""
    vendor = "unknown"
    vram_gb = 0.0
    source = "windows"
    if selected_backend == "cuda" and cuda_devices:
        primary = max(cuda_devices, key=lambda item: item.vram_gb)
        primary_name = primary.name
        vendor = primary.vendor
        vram_gb = primary.vram_gb
        source = "nvidia-smi"
    else:
        eligible = [gpu for gpu in windows_gpus if gpu.vendor in {"nvidia", "amd", "intel"} and not gpu.is_software]
        if eligible:
            primary = max(eligible, key=lambda item: item.vram_gb)
            primary_name = primary.name
            vendor = primary.vendor
            vram_gb = primary.vram_gb
        elif windows_gpus:
            primary = windows_gpus[0]
            primary_name = primary.name
            vendor = primary.vendor
            vram_gb = primary.vram_gb

    if selected_profile == "auto":
        if selected_backend == "cpu":
            selected_profile = "cpu_fallback"
            reasons.append("auto_profile:cpu_fallback")
        elif vram_gb >= DEFAULT_FULL_VRAM_GB:
            selected_profile = "full"
            reasons.append(f"auto_profile:full(vram={vram_gb})")
        elif vram_gb >= DEFAULT_BALANCED_VRAM_GB:
            selected_profile = "balanced"
            reasons.append(f"auto_profile:balanced(vram={vram_gb})")
        elif vram_gb >= DEFAULT_SINGLE_VRAM_GB:
            selected_profile = "single"
            reasons.append(f"auto_profile:single(vram={vram_gb})")
        else:
            selected_profile = "cpu_fallback"
            reasons.append(f"auto_profile:cpu_fallback(vram={vram_gb})")
    else:
        reasons.append(f"manual_profile:{selected_profile}")

    engine_path = str(resolve_engine_path(selected_backend))
    profile = HardwareProfile(
        requested_backend=requested_backend,
        requested_profile=requested_profile,
        selected_backend=selected_backend,
        selected_profile=selected_profile,
        primary_gpu=primary_name,
        vendor=vendor,
        vram_gb=vram_gb,
        cuda_available=cuda_available,
        vulkan_available=vulkan_available,
        engine_path=engine_path,
        source=source,
        reasons=reasons,
        gpus=[asdict(item) for item in windows_gpus],
    )
    json_dump(HARDWARE_PROFILE_FILE, asdict(profile))
    return profile


def resolve_engine_path(backend: str) -> Path:
    variant = ENGINE_VARIANTS[backend]
    target = Path(variant["target"])
    if target.exists():
        return target
    for fallback_name in variant["fallbacks"]:
        candidate = ENGINE_DIR / fallback_name
        if candidate.exists():
            return candidate
    return target


def _download_binary(url: str, destination: Path) -> bool:
    request = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    try:
        with urllib.request.urlopen(request, timeout=45) as response:
            destination.write_bytes(response.read())
        return True
    except urllib.error.URLError:
        return False
    except Exception:
        return False


def _extract_engine_asset(asset_path: Path, backend: str) -> Path | None:
    try:
        with zipfile.ZipFile(asset_path) as archive:
            members = [
                member for member in archive.namelist()
                if member.lower().endswith(".exe") and "koboldcpp" in member.lower()
            ]
            if not members:
                return None
            preferred = []
            if backend == "cuda":
                preferred = [member for member in members if any(token in member.lower() for token in ("cublas", "cuda", "koboldcpp.exe"))]
            elif backend == "vulkan":
                preferred = [member for member in members if any(token in member.lower() for token in ("vulkan", "nocuda"))]
            elif backend == "cpu":
                preferred = [member for member in members if any(token in member.lower() for token in ("oldpc", "oldcpu", "nocuda"))]
            member = preferred[0] if preferred else members[0]
            target = ENGINE_VARIANTS[backend]["target"]
            with archive.open(member) as src, target.open("wb") as dst:
                shutil.copyfileobj(src, dst)
            return target
    except Exception:
        return None
    return None


def ensure_engine_binary(backend: str) -> Path:
    ensure_dirs()
    target = Path(ENGINE_VARIANTS[backend]["target"])
    if target.exists():
        return target
    for fallback_name in ENGINE_VARIANTS[backend]["fallbacks"]:
        candidate = ENGINE_DIR / fallback_name
        if candidate.exists():
            return candidate

    with tempfile.TemporaryDirectory(prefix="zhiyue_kobold_dl_") as td:
        temp_dir = Path(td)
        for asset_name in ENGINE_VARIANTS[backend]["candidates"]:
            url = f"{DEFAULT_RELEASE_BASE}/{asset_name}"
            downloaded = temp_dir / asset_name
            if not _download_binary(url, downloaded):
                continue
            if downloaded.suffix.lower() == ".zip":
                extracted = _extract_engine_asset(downloaded, backend)
                if extracted and extracted.exists():
                    return extracted
                continue
            target.write_bytes(downloaded.read_bytes())
            return target

    raise FileNotFoundError(
        f"Unable to prepare KoboldCpp {backend} backend automatically. "
        f"Place a matching binary under {ENGINE_DIR}."
    )


def http_ready(url: str, timeout: float = DEFAULT_HTTP_TIMEOUT) -> bool:
    try:
        with urllib.request.urlopen(url, timeout=timeout) as response:
            code = int(getattr(response, "status", 200) or 200)
            return 200 <= code < 300
    except Exception:
        return False


def wait_http_ready(url: str, timeout_seconds: float) -> bool:
    deadline = time.time() + max(1.0, timeout_seconds)
    while time.time() < deadline:
        if http_ready(url, timeout=DEFAULT_HTTP_TIMEOUT):
            return True
        time.sleep(1.0)
    return False


def wait_chat_ready(url: str, *, model_name: str = "warmup", timeout_seconds: float = DEFAULT_WARMUP_TIMEOUT) -> bool:
    deadline = time.time() + max(5.0, timeout_seconds)
    payload = {
        "model": model_name,
        "messages": [{"role": "user", "content": "ping"}],
        "max_tokens": 1,
        "temperature": 0,
        "stream": False,
    }
    while time.time() < deadline:
        try:
            response = requests.post(url, json=payload, timeout=DEFAULT_HTTP_TIMEOUT * 2)
            if response.status_code < 500:
                data = response.json()
                choices = data.get("choices") or []
                if choices:
                    return True
        except Exception:
            pass
        time.sleep(1.0)
    return False


def iter_process_rows() -> list[tuple[int, str, str]]:
    payload = _run_powershell_json(
        "Get-CimInstance Win32_Process | "
        "Where-Object { $_.Name -like 'python*.exe' -or $_.Name -like 'koboldcpp*.exe' } | "
        "Select-Object ProcessId,Name,CommandLine | ConvertTo-Json -Compress"
    )
    if isinstance(payload, dict):
        payload = [payload]
    rows: list[tuple[int, str, str]] = []
    for item in payload or []:
        if not isinstance(item, dict):
            continue
        try:
            pid = int(item.get("ProcessId") or 0)
        except Exception:
            continue
        rows.append((pid, str(item.get("Name") or ""), str(item.get("CommandLine") or "")))
    return rows


def kobold_server_pids(*ports: int) -> list[int]:
    matches: list[int] = []
    for pid, name, command_line in iter_process_rows():
        if "koboldcpp" not in name.lower() and "koboldcpp" not in command_line.lower():
            continue
        lowered = command_line.lower()
        if not ports:
            matches.append(pid)
            continue
        for port in ports:
            if f"--port {port}" in lowered or f"--port={port}" in lowered:
                matches.append(pid)
                break
    return sorted(set(matches))


def stop_kobold_servers(*ports: int) -> int:
    count = 0
    for pid in kobold_server_pids(*ports):
        subprocess.run(
            ["taskkill", "/F", "/PID", str(pid)],
            cwd=str(PROJECT_ROOT),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )
        count += 1
    return count


def server_log_paths(name: str) -> tuple[Path, Path]:
    safe = name.replace(" ", "_").lower()
    return PORTABLE_LOG_DIR / f"{safe}.stdout.log", PORTABLE_LOG_DIR / f"{safe}.stderr.log"


def log_excerpt(name: str, *, max_lines: int = 12) -> str:
    _, stderr_path = server_log_paths(name)
    if not stderr_path.exists():
        return ""
    try:
        lines = stderr_path.read_text(encoding="utf-8", errors="replace").splitlines()
    except Exception:
        return ""
    return "\n".join(lines[-max_lines:])


def start_kobold_server(engine_path: Path, backend: str, spec: ServerSpec) -> bool:
    stop_kobold_servers(spec.port)
    stdout_path, stderr_path = server_log_paths(spec.name)
    args = [
        str(engine_path),
        "--model",
        str(spec.model_path),
        "--port",
        str(spec.port),
        "--host",
        "127.0.0.1",
        "--contextsize",
        str(spec.context_size),
        "--threads",
        str(DEFAULT_CPU_THREADS),
        "--quiet",
    ]
    if backend == "cuda":
        args.append("--usecuda")
    elif backend == "vulkan":
        args.append("--usevulkan")
    else:
        args.append("--usecpu")
    if spec.gpu_layers is not None:
        args.extend(["--gpulayers", str(spec.gpu_layers)])

    creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    with stdout_path.open("ab") as stdout_handle, stderr_path.open("ab") as stderr_handle:
        subprocess.Popen(
            args,
            cwd=str(PROJECT_ROOT),
            stdout=stdout_handle,
            stderr=stderr_handle,
            creationflags=creationflags,
        )
    models_url = f"http://127.0.0.1:{spec.port}/v1/models"
    if not wait_http_ready(models_url, timeout_seconds=DEFAULT_READY_TIMEOUT):
        return False
    return wait_chat_ready(
        f"http://127.0.0.1:{spec.port}/v1/chat/completions",
        model_name=spec.alias,
        timeout_seconds=DEFAULT_WARMUP_TIMEOUT,
    )


def candidate_profiles(profile: str) -> list[str]:
    if profile == "full":
        return ["full", "balanced", "single", "cpu_fallback"]
    if profile == "balanced":
        return ["balanced", "single", "cpu_fallback"]
    if profile == "single":
        return ["single", "cpu_fallback"]
    return ["cpu_fallback"]


def candidate_backends(backend: str) -> list[str]:
    if backend == "cuda":
        return ["cuda", "vulkan", "cpu"]
    if backend == "vulkan":
        return ["vulkan", "cpu"]
    return ["cpu"]


def engine_preference_sequence() -> list[str]:
    sequence = [engine for engine in ENGINE_PREFERENCE if engine in {"api", "koboldcpp", "lmstudio", "ollama"}]
    return sequence or ["api"]


def engine_is_available(engine_name: str) -> bool:
    if engine_name == "api":
        return True
    if engine_name == "koboldcpp":
        return True
    if engine_name == "lmstudio":
        return bool(find_lms_exe()) or lmstudio_server_ready()
    if engine_name == "ollama":
        return bool(find_ollama_exe()) or ollama_server_ready()
    return False


def usable_engine_sequence() -> list[str]:
    sequence = [engine for engine in engine_preference_sequence() if engine_is_available(engine)]
    return sequence or ["api"]


def launch_api_runtime(target: str, profile_name: str) -> tuple[bool, str]:
    """API-only runtime: don't launch local inference, just start services and rely on configured provider."""
    try:
        from zhiyue_llm_provider import load_provider_config as _load_provider_config
        from zhiyue_llm_provider import apply_provider_env as _apply_provider_env
        from zhiyue_llm_provider import resolve_role_runtime as _resolve_role_runtime
    except Exception as err:
        return False, f"provider module unavailable: {err}"

    cfg = _load_provider_config()
    _apply_provider_env(cfg)

    os.environ["ZHIYUE_ENGINE"] = "api"
    os.environ["ZHIYUE_BACKEND"] = "api"
    os.environ["ZHIYUE_PROFILE"] = profile_name or os.environ.get("ZHIYUE_PROFILE", "full")

    try:
        start_runtime_services(target)
    except Exception as err:
        stop_runtime_services()
        return False, str(err)

    # Best-effort auto sync on boot (pull then push).
    try:
        import requests as _requests

        backend_base = "http://127.0.0.1:8898"
        for _ in range(40):
            try:
                r = _requests.get(backend_base + "/api/health", timeout=1.5)
                if r.status_code < 500:
                    break
            except Exception:
                pass
            time.sleep(0.25)

        try:
            _requests.post(backend_base + "/api/mobile-sync/pull", json={}, timeout=25)
        except Exception:
            pass
        try:
            _requests.post(backend_base + "/api/mobile-sync/push", json={}, timeout=25)
        except Exception:
            pass
    except Exception:
        pass

    models = {role: str(_resolve_role_runtime(role, config=cfg).get("model") or "") for role in ("main", "state", "review")}
    payload = {
        "selected_backend": "api",
        "selected_profile": os.environ.get("ZHIYUE_PROFILE", "full"),
        "target": target,
        "engine_path": "api",
        "engine": "api",
        "models": models,
        "ports": {},
        "saved_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }
    hardware_payload = {
        "requested_backend": os.environ.get("ZHIYUE_BACKEND", "api"),
        "requested_profile": profile_name,
        "selected_backend": "api",
        "selected_profile": os.environ.get("ZHIYUE_PROFILE", "full"),
        "primary_gpu": "n/a (api)",
        "vendor": "api",
        "vram_gb": 0.0,
        "cuda_available": False,
        "vulkan_available": False,
        "engine_path": "api",
        "source": "api",
        "reasons": ["engine:api", "provider:configured_or_pending"],
        "gpus": [],
    }
    json_dump(HARDWARE_PROFILE_FILE, hardware_payload)
    json_dump(RUNTIME_STATE_FILE, payload)
    return True, ",".join(models.get(role, "") for role in ("main", "state", "review"))


def _main_alias_for_profile(profile: str) -> str:
    return f"main-{profile}"


def build_launch_plan(backend: str, profile: str) -> LaunchPlan:
    reasons = [f"backend:{backend}", f"profile:{profile}"]
    main_model = MODEL_PATHS["main"]
    state_model = MODEL_PATHS["state"]
    review_model = MODEL_PATHS["review"]

    main_url = f"http://127.0.0.1:{MAIN_PORT}/v1/chat/completions"
    state_url = f"http://127.0.0.1:{STATE_PORT}/v1/chat/completions"
    review_url = f"http://127.0.0.1:{REVIEW_PORT}/v1/chat/completions"

    if profile == "full":
        servers = [
            ServerSpec("main", MAIN_PORT, main_model, DEFAULT_MAIN_CONTEXT, 999 if backend != "cpu" else None, _main_alias_for_profile(profile)),
            ServerSpec("state", STATE_PORT, state_model, DEFAULT_AUX_CONTEXT, 999 if backend != "cpu" else None, "state-full"),
            ServerSpec("review", REVIEW_PORT, review_model, DEFAULT_AUX_CONTEXT, 999 if backend != "cpu" else None, "review-full"),
        ]
    elif profile == "balanced":
        servers = [
            ServerSpec("main", MAIN_PORT, main_model, DEFAULT_MAIN_CONTEXT, 999 if backend != "cpu" else None, _main_alias_for_profile(profile)),
            ServerSpec("state", STATE_PORT, state_model, 1536, DEFAULT_BALANCED_STATE_LAYERS if backend != "cpu" else None, "state-balanced"),
            ServerSpec("review", REVIEW_PORT, review_model, 1536, DEFAULT_BALANCED_REVIEW_LAYERS if backend != "cpu" else None, "review-balanced"),
        ]
        reasons.append("balanced_aux_gpu_layers:reduced")
    else:
        shared_name = "main"
        shared_alias = _main_alias_for_profile(profile)
        servers = [
            ServerSpec("main", MAIN_PORT, main_model, 3072 if profile == "single" else 2048, 999 if backend != "cpu" else None, shared_alias),
        ]
        state_url = main_url
        review_url = main_url
        state_model = main_model
        review_model = main_model
        reasons.append("state_review:reuse_main")
        if profile == "cpu_fallback":
            reasons.append("gpu_unavailable:cpu_only")

    env = {
        "ZHIYUE_BACKEND": backend,
        "ZHIYUE_PROFILE": profile,
        "ZHIYUE_LM_URL": main_url,
        "ZHIYUE_MAIN_LM_URL": main_url,
        "ZHIYUE_STATE_LM_URL": state_url,
        "ZHIYUE_REVIEW_LM_URL": review_url,
        "ZHIYUE_MAIN_MODEL": str(main_model),
        "ZHIYUE_STATE_MODEL": str(state_model),
        "ZHIYUE_REVIEW_MODEL": str(review_model),
        "ZHIYUE_LM_MODEL": servers[0].alias,
        "ZHIYUE_PORT": "8898",
        "ZHIYUE_MODE": os.environ.get("ZHIYUE_MODE", "pure_chat"),
    }
    return LaunchPlan(profile=profile, backend=backend, servers=servers, env=env, reasons=reasons)


def model_candidates_for_role(role: str, used_paths: list[Path] | None = None) -> list[Path]:
    used_paths = used_paths or []
    role_orders = {
        "main": ["main", "state", "review"],
        "state": ["state", "review", "main"],
        "review": ["review", "state", "main"],
    }
    ordered = [MODEL_PATHS[key] for key in role_orders.get(role, ["main", "state", "review"]) if MODEL_PATHS.get(key)]
    unique: list[Path] = []
    seen: set[str] = set()

    def push(path: Path) -> None:
        resolved = path.resolve()
        key = str(resolved).lower()
        if key in seen or not resolved.exists():
            return
        seen.add(key)
        unique.append(resolved)

    for path in ordered:
        if path.resolve() not in [item.resolve() for item in used_paths]:
            push(path)
    for path in ordered:
        push(path)
    return unique


def probe_model_candidate(
    engine_path: Path,
    backend: str,
    role: str,
    model_path: Path,
    *,
    context_size: int,
    gpu_layers: int | None,
) -> tuple[bool, str]:
    cache_key = (backend, str(model_path.resolve()).lower(), int(gpu_layers or 0), int(context_size))
    if cache_key in _PROBE_CACHE:
        return _PROBE_CACHE[cache_key]
    probe_name = f"probe-{role}-{model_path.stem[:24]}"
    spec = ServerSpec(
        name=probe_name,
        port=WARMUP_PORT,
        model_path=model_path.resolve(),
        context_size=context_size,
        gpu_layers=gpu_layers,
        alias=probe_name,
    )
    stop_kobold_servers(WARMUP_PORT)
    ok = start_kobold_server(engine_path, backend, spec)
    detail = "" if ok else log_excerpt(probe_name)
    stop_kobold_servers(WARMUP_PORT)
    _PROBE_CACHE[cache_key] = (ok, detail)
    return ok, detail


def resolve_plan_models(engine_path: Path, plan: LaunchPlan) -> tuple[LaunchPlan | None, str]:
    resolved_servers: list[ServerSpec] = []
    used_paths: list[Path] = []
    reasons = list(plan.reasons)
    for server in plan.servers:
        selected: ServerSpec | None = None
        last_detail = ""
        for candidate in model_candidates_for_role(server.name, used_paths=used_paths):
            ok, detail = probe_model_candidate(
                engine_path,
                plan.backend,
                server.name,
                candidate,
                context_size=min(DEFAULT_WARMUP_CONTEXT, server.context_size),
                gpu_layers=server.gpu_layers,
            )
            if not ok:
                last_detail = detail
                continue
            selected = ServerSpec(
                name=server.name,
                port=server.port,
                model_path=candidate,
                context_size=server.context_size,
                gpu_layers=server.gpu_layers,
                alias=server.alias,
                shared_with=server.shared_with,
            )
            used_paths.append(candidate)
            if candidate.resolve() != server.model_path.resolve():
                reasons.append(f"{server.name}_fallback:{candidate.name}")
            break
        if selected is None:
            return None, last_detail or f"No compatible model candidate found for role={server.name}"
        resolved_servers.append(selected)

    env = dict(plan.env)
    mapping = {server.name: server for server in resolved_servers}
    env["ZHIYUE_MAIN_MODEL"] = str(mapping["main"].model_path)
    env["ZHIYUE_LM_MODEL"] = mapping["main"].alias
    if "state" in mapping:
        env["ZHIYUE_STATE_MODEL"] = str(mapping["state"].model_path)
    if "review" in mapping:
        env["ZHIYUE_REVIEW_MODEL"] = str(mapping["review"].model_path)

    return LaunchPlan(
        profile=plan.profile,
        backend=plan.backend,
        servers=resolved_servers,
        env=env,
        reasons=reasons,
    ), ""


def build_warmup_spec(plan: LaunchPlan) -> ServerSpec:
    review_model = MODEL_PATHS["review"] if MODEL_PATHS["review"].exists() else MODEL_PATHS["main"]
    gpu_layers = None
    if plan.backend != "cpu":
        if plan.profile == "full":
            gpu_layers = 999
        elif plan.profile == "balanced":
            gpu_layers = max(DEFAULT_BALANCED_STATE_LAYERS, DEFAULT_BALANCED_REVIEW_LAYERS)
        else:
            gpu_layers = 999
    return ServerSpec(
        name=f"warmup-{plan.profile}-{plan.backend}",
        port=WARMUP_PORT,
        model_path=review_model,
        context_size=DEFAULT_WARMUP_CONTEXT,
        gpu_layers=gpu_layers,
        alias=f"warmup-{plan.profile}-{plan.backend}",
    )


def build_primary_probe_spec(plan: LaunchPlan) -> ServerSpec:
    primary = plan.servers[0]
    return ServerSpec(
        name=f"probe-main-{plan.profile}-{plan.backend}",
        port=WARMUP_PORT,
        model_path=primary.model_path,
        context_size=min(DEFAULT_WARMUP_CONTEXT, primary.context_size),
        gpu_layers=primary.gpu_layers,
        alias=f"probe-main-{plan.profile}-{plan.backend}",
    )


def find_lms_exe() -> str | None:
    candidates = (
        os.environ.get("ZHIYUE_LMSTUDIO_EXE"),
        shutil.which("lms"),
        r"E:\AI\LMStudio\resources\app\.webpack\lms.exe",
        str(Path.home() / ".lmstudio" / "bin" / "lms.exe"),
    )
    for candidate in candidates:
        if candidate and Path(candidate).exists():
            return candidate
    return None


def find_lmstudio_gui() -> str | None:
    candidates = (
        os.environ.get("ZHIYUE_LMSTUDIO_GUI"),
        r"E:\AI\LMStudio\LM Studio.exe",
        os.path.expandvars(r"%LOCALAPPDATA%\Programs\LM Studio\LM Studio.exe"),
        os.path.expandvars(r"%LOCALAPPDATA%\LM Studio\LM Studio.exe"),
        r"C:\Program Files\LM Studio\LM Studio.exe",
    )
    for candidate in candidates:
        if candidate and Path(candidate).exists():
            return candidate
    return None


def start_lmstudio_minimizer() -> None:
    script = PROJECT_ROOT / "scripts" / "_minimize_lmstudio.ps1"
    if not script.exists():
        return
    creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    subprocess.Popen(
        ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(script)],
        cwd=str(PROJECT_ROOT),
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        creationflags=creationflags,
    )


def start_lmstudio_gui_minimized() -> tuple[bool, str]:
    gui_path = find_lmstudio_gui()
    if not gui_path:
        return False, "LM Studio.exe not found"
    startupinfo = None
    creationflags = 0
    if os.name == "nt":
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        startupinfo.wShowWindow = 7
        creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        subprocess.Popen(
            [gui_path],
            cwd=str(Path(gui_path).parent),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            startupinfo=startupinfo,
            creationflags=creationflags,
        )
        start_lmstudio_minimizer()
    except Exception as err:
        return False, str(err)
    return True, gui_path


def lmstudio_server_ready() -> bool:
    return http_ready(LMSTUDIO_MODELS_URL, timeout=DEFAULT_HTTP_TIMEOUT)


def lmstudio_start_server() -> tuple[bool, str]:
    if lmstudio_server_ready():
        return True, ""
    lms_exe = find_lms_exe()
    if lms_exe:
        rc, output = _run_capture_env([lms_exe, "server", "start", "-p", str(LMSTUDIO_PORT)], timeout=60.0)
        if rc == 0 and wait_http_ready(LMSTUDIO_MODELS_URL, timeout_seconds=45):
            return True, output
    ok, detail = start_lmstudio_gui_minimized()
    if not ok:
        return False, detail
    if not wait_http_ready(LMSTUDIO_MODELS_URL, timeout_seconds=60):
        if not lms_exe:
            lms_exe = find_lms_exe()
        if not lms_exe:
            return False, "LM Studio GUI started but lms.exe is still unavailable"
        rc, output = _run_capture_env([lms_exe, "server", "start", "-p", str(LMSTUDIO_PORT)], timeout=60.0)
        if rc != 0:
            return False, output
    if not wait_http_ready(LMSTUDIO_MODELS_URL, timeout_seconds=45):
        return False, "LM Studio server did not become ready"
    start_lmstudio_minimizer()
    return True, detail


def lmstudio_list_disk_models() -> list[dict[str, Any]]:
    lms_exe = find_lms_exe()
    if not lms_exe:
        return []
    rc, output = _run_capture_env([lms_exe, "ls", "--json"], timeout=30.0)
    if rc != 0 or not output:
        return []
    try:
        payload = json.loads(output)
    except Exception:
        return []
    return payload if isinstance(payload, list) else []


def lmstudio_loaded_models() -> list[dict[str, Any]]:
    lms_exe = find_lms_exe()
    if not lms_exe:
        return []
    rc, output = _run_capture_env([lms_exe, "ps", "--json"], timeout=30.0)
    if rc != 0 or not output:
        return []
    try:
        payload = json.loads(output)
    except Exception:
        return []
    return payload if isinstance(payload, list) else []


def lmstudio_import_model(path: Path) -> tuple[bool, str]:
    lms_exe = find_lms_exe()
    if not lms_exe:
        return False, "lms.exe not found"
    repo_name = re.sub(r"[^a-z0-9._-]+", "-", path.stem.lower()).strip("-") or "zhiyue-model"
    attempts = [
        ["--hard-link"],
        ["--symbolic-link"],
        ["--copy"],
    ]
    last_output = ""
    for mode in attempts:
        rc, output = _run_capture_env(
            [lms_exe, "import", *mode, "-y", "--user-repo", f"local/{repo_name}", str(path.resolve())],
            timeout=300.0,
        )
        last_output = output
        if rc == 0:
            return True, output
    return False, last_output


def _lmstudio_model_key_candidates(path: Path, role: str) -> list[str]:
    candidates: list[str] = []
    for raw in (
        path.stem,
        path.name,
        role,
        f"{role}-model",
        str(path).replace("\\", "/"),
    ):
        value = str(raw or "").strip().lower()
        if value and value not in candidates:
            candidates.append(value)
    return candidates


def lmstudio_pick_llm_model_key_for_role(role: str, models: list[dict[str, Any]] | None = None) -> str | None:
    models = models if models is not None else lmstudio_ensure_disk_models()
    llm_models = [item for item in models if str(item.get("type") or "").strip().lower() == "llm"]
    if not llm_models:
        return None
    path = MODEL_PATHS.get(role)
    candidates = _lmstudio_model_key_candidates(path or Path(role), role)
    for item in llm_models:
        haystack = " ".join(
            str(item.get(field) or "").strip().lower()
            for field in ("modelKey", "path", "indexedModelIdentifier", "displayName")
        )
        if any(candidate in haystack for candidate in candidates):
            return str(item.get("modelKey") or item.get("selectedVariant") or "").strip() or None
    if role == "main":
        preferred = next((item for item in llm_models if "qwen" in str(item.get("modelKey") or "").lower()), None)
        chosen = preferred or llm_models[0]
        return str(chosen.get("modelKey") or chosen.get("selectedVariant") or "").strip() or None
    return None


def lmstudio_ensure_disk_models() -> list[dict[str, Any]]:
    models = lmstudio_list_disk_models()
    required_roles = ("main", "state", "review")
    missing_roles = [role for role in required_roles if not lmstudio_pick_llm_model_key_for_role(role, models)]
    for role in missing_roles:
        path = MODEL_PATHS[role]
        if not path.exists():
            continue
        lmstudio_import_model(path)
    return lmstudio_list_disk_models()


def lmstudio_pick_llm_model_key() -> str | None:
    return lmstudio_pick_llm_model_key_for_role("main")


def lmstudio_load_model(model_key: str, identifier: str, *, profile: str) -> tuple[bool, str]:
    lms_exe = find_lms_exe()
    if not lms_exe:
        return False, "lms.exe not found"
    if any(str(item.get("identifier") or item.get("id") or "").strip() == identifier for item in lmstudio_loaded_models()):
        return True, "already_loaded"
    gpu = "off" if profile == "cpu_fallback" else "max"
    context = "3072" if profile == "single" else "4096"
    rc, output = _run_capture_env(
        [
            lms_exe,
            "load",
            model_key,
            "--identifier",
            identifier,
            "--gpu",
            gpu,
            "--context-length",
            context,
            "-y",
        ],
        timeout=300.0,
    )
    if rc == 0:
        return True, output
    lowered = output.lower()
    if "already exists" in lowered or "already loaded" in lowered:
        return True, output
    return False, output


def lmstudio_unload_all_models() -> tuple[bool, str]:
    lms_exe = find_lms_exe()
    if not lms_exe:
        return False, "lms.exe not found"
    loaded = lmstudio_loaded_models()
    if not loaded:
        return True, "already_empty"
    rc, output = _run_capture_env([lms_exe, "unload", "--all"], timeout=300.0)
    if rc == 0:
        return True, output
    lowered = output.lower()
    if "no models loaded" in lowered:
        return True, output
    return False, output


def lmstudio_role_context_length(role: str, profile_name: str) -> str:
    if role == "main":
        return "3072" if profile_name == "single" else "4096"
    return "1536" if profile_name == "single" else "2048"


def find_ollama_exe() -> str | None:
    candidate = shutil.which("ollama")
    if candidate and Path(candidate).exists():
        return candidate
    return None


def ollama_server_ready() -> bool:
    return http_ready(OLLAMA_MODELS_URL, timeout=DEFAULT_HTTP_TIMEOUT)


def ollama_start_server() -> tuple[bool, str]:
    if ollama_server_ready():
        return True, ""
    ollama_exe = find_ollama_exe()
    if not ollama_exe:
        return False, "ollama not found"
    creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    subprocess.Popen(
        [ollama_exe, "serve"],
        cwd=str(PROJECT_ROOT),
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        creationflags=creationflags,
    )
    if not wait_http_ready(OLLAMA_MODELS_URL, timeout_seconds=30):
        return False, "Ollama server did not become ready"
    return True, ""


def ollama_pick_model() -> str | None:
    ok, detail = ollama_start_server()
    if not ok:
        return None
    try:
        response = requests.get(OLLAMA_MODELS_URL, timeout=DEFAULT_HTTP_TIMEOUT * 2)
        response.raise_for_status()
        payload = response.json()
    except Exception:
        return None
    models = payload.get("models") or []
    if not isinstance(models, list) or not models:
        return None
    preferred = next((item for item in models if "qwen" in str(item.get("name") or "").lower()), None)
    chosen = preferred or models[0]
    return str(chosen.get("name") or "").strip() or None


def launch_ollama_runtime(target: str, profile_name: str) -> tuple[bool, str]:
    model_name = ollama_pick_model()
    if not model_name:
        return False, "No Ollama model is available."
    if not wait_chat_ready(OLLAMA_URL, model_name=model_name, timeout_seconds=DEFAULT_WARMUP_TIMEOUT):
        return False, "Ollama model warmup failed"
    env = {
        "ZHIYUE_ENGINE": "ollama",
        "ZHIYUE_BACKEND": "ollama",
        "ZHIYUE_PROFILE": "single" if profile_name == "cpu_fallback" else profile_name,
        "ZHIYUE_LM_URL": OLLAMA_URL,
        "ZHIYUE_MAIN_LM_URL": OLLAMA_URL,
        "ZHIYUE_STATE_LM_URL": OLLAMA_URL,
        "ZHIYUE_REVIEW_LM_URL": OLLAMA_URL,
        "ZHIYUE_LM_MODEL": model_name,
        "ZHIYUE_MAIN_MODEL": model_name,
        "ZHIYUE_STATE_MODEL": model_name,
        "ZHIYUE_REVIEW_MODEL": model_name,
        "ZHIYUE_PORT": "8898",
        "ZHIYUE_MODE": os.environ.get("ZHIYUE_MODE", "pure_chat"),
    }
    for key, value in env.items():
        os.environ[key] = str(value)
    try:
        start_runtime_services(target)
    except Exception as err:
        stop_runtime_services()
        return False, str(err)
    payload = {
        "selected_backend": "ollama",
        "selected_profile": env["ZHIYUE_PROFILE"],
        "target": target,
        "engine_path": find_ollama_exe() or "ollama",
        "engine": "ollama",
        "models": {"main": model_name, "state": model_name, "review": model_name},
        "ports": {"ollama": OLLAMA_PORT},
        "saved_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }
    json_dump(RUNTIME_STATE_FILE, payload)
    return True, model_name


def launch_lmstudio_runtime(target: str, profile_name: str) -> tuple[bool, str]:
    ok, detail = lmstudio_start_server()
    if not ok:
        return False, detail
    models = lmstudio_ensure_disk_models()
    role_mapping: dict[str, tuple[str, str]] = {}
    for role in ("main", "state", "review"):
        model_key = lmstudio_pick_llm_model_key_for_role(role, models)
        if not model_key:
            return False, f"LM Studio is missing a mapped model for role={role}"
        role_mapping[role] = (model_key, model_key)
    ok, detail = lmstudio_unload_all_models()
    if not ok:
        return False, detail
    for role in ("main", "state", "review"):
        model_key, identifier = role_mapping[role]
        ok, detail = lmstudio_load_model(model_key, identifier, profile=profile_name)
        if not ok:
            return False, f"failed to load {role}: {detail}"
        if not wait_chat_ready(LMSTUDIO_URL, model_name=identifier, timeout_seconds=DEFAULT_WARMUP_TIMEOUT):
            return False, f"LM Studio model warmup failed for role={role}"

    env = {
        "ZHIYUE_ENGINE": "lmstudio",
        "ZHIYUE_BACKEND": "lmstudio",
        "ZHIYUE_PROFILE": "single" if profile_name == "cpu_fallback" else profile_name,
        "ZHIYUE_LM_URL": LMSTUDIO_URL,
        "ZHIYUE_MAIN_LM_URL": LMSTUDIO_URL,
        "ZHIYUE_STATE_LM_URL": LMSTUDIO_URL,
        "ZHIYUE_REVIEW_LM_URL": LMSTUDIO_URL,
        "ZHIYUE_LM_MODEL": role_mapping["main"][1],
        "ZHIYUE_MAIN_MODEL": role_mapping["main"][1],
        "ZHIYUE_STATE_MODEL": role_mapping["state"][1],
        "ZHIYUE_REVIEW_MODEL": role_mapping["review"][1],
        "ZHIYUE_PORT": "8898",
        "ZHIYUE_MODE": os.environ.get("ZHIYUE_MODE", "pure_chat"),
    }
    for key, value in env.items():
        os.environ[key] = str(value)
    try:
        start_runtime_services(target)
    except Exception as err:
        stop_runtime_services()
        return False, str(err)
    payload = {
        "selected_backend": "lmstudio",
        "selected_profile": env["ZHIYUE_PROFILE"],
        "target": target,
        "engine_path": find_lms_exe() or "lms",
        "engine": "lmstudio",
        "models": {
            "main": role_mapping["main"][1],
            "state": role_mapping["state"][1],
            "review": role_mapping["review"][1],
        },
        "ports": {"lmstudio": LMSTUDIO_PORT},
        "saved_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }
    hardware_payload = {
        "requested_backend": os.environ.get("ZHIYUE_BACKEND", "lmstudio"),
        "requested_profile": profile_name,
        "selected_backend": "lmstudio",
        "selected_profile": env["ZHIYUE_PROFILE"],
        "primary_gpu": "managed by LM Studio",
        "vendor": "lmstudio",
        "vram_gb": 0.0,
        "cuda_available": False,
        "vulkan_available": False,
        "engine_path": find_lms_exe() or "lms",
        "source": "lmstudio",
        "reasons": ["engine:lmstudio", "local_install:minimized_start"],
        "gpus": [],
    }
    json_dump(HARDWARE_PROFILE_FILE, hardware_payload)
    json_dump(RUNTIME_STATE_FILE, payload)
    return True, ",".join(role_mapping[role][1] for role in ("main", "state", "review"))


def apply_runtime_env(plan: LaunchPlan) -> None:
    for key, value in plan.env.items():
        os.environ[key] = str(value)


def write_runtime_state(profile: HardwareProfile, plan: LaunchPlan, target: str) -> None:
    payload = {
        "selected_backend": profile.selected_backend,
        "selected_profile": profile.selected_profile,
        "target": target,
        "engine_path": profile.engine_path,
        "gpus": profile.gpus,
        "reasons": profile.reasons + plan.reasons,
        "ports": {server.name: server.port for server in plan.servers},
        "models": {server.name: str(server.model_path) for server in plan.servers},
        "env": plan.env,
        "saved_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }
    json_dump(RUNTIME_STATE_FILE, payload)


def _service_targets_for_launch(target: str) -> list[str]:
    if target == "full":
        return ["core", "wechat"]
    if target == "local_weixin":
        return ["core", "weixin"]
    return ["core"]


def start_runtime_services(target: str) -> None:
    for service_target in _service_targets_for_launch(target):
        rc = mz.command_start(service_target)
        if rc != 0:
            raise RuntimeError(f"Failed to start service target: {service_target}")


def stop_runtime_services() -> None:
    mz.command_stop("all")


def perform_warmup(engine_path: Path, plan: LaunchPlan) -> tuple[bool, str]:
    warmup_spec = build_warmup_spec(plan)
    stop_kobold_servers(WARMUP_PORT)
    ok = start_kobold_server(engine_path, plan.backend, warmup_spec)
    detail = "" if ok else log_excerpt(warmup_spec.name)
    stop_kobold_servers(WARMUP_PORT)
    return ok, detail


def perform_primary_probe(engine_path: Path, plan: LaunchPlan) -> tuple[bool, str]:
    probe_spec = build_primary_probe_spec(plan)
    stop_kobold_servers(WARMUP_PORT)
    ok = start_kobold_server(engine_path, plan.backend, probe_spec)
    detail = "" if ok else log_excerpt(probe_spec.name)
    stop_kobold_servers(WARMUP_PORT)
    return ok, detail


def launch_models(engine_path: Path, plan: LaunchPlan) -> tuple[bool, str]:
    started_ports: list[int] = []
    try:
        for server in plan.servers:
            if not start_kobold_server(engine_path, plan.backend, server):
                return False, log_excerpt(server.name)
            started_ports.append(server.port)
        return True, ""
    except Exception:
        return False, ""
    finally:
        if len(started_ports) != len(plan.servers):
            stop_kobold_servers(*started_ports)


def launch_runtime(target: str, requested_profile: str = "auto", requested_backend: str = "auto") -> int:
    ensure_dirs()
    stop_runtime_services()
    stop_kobold_servers(*MODEL_PORTS)

    hardware = detect_hardware(requested_backend=requested_backend, requested_profile=requested_profile)
    explicit_backend = requested_backend in {"cuda", "vulkan", "cpu"}
    explicit_profile = requested_profile in {"full", "balanced", "single", "cpu_fallback"}

    backend_sequence = [hardware.selected_backend] if explicit_backend else candidate_backends(hardware.selected_backend)
    profile_sequence = [hardware.selected_profile] if explicit_profile else candidate_profiles(hardware.selected_profile)

    attempted: list[str] = []
    last_error = ""
    for engine_name in usable_engine_sequence():
        if engine_name == "api":
            attempted.append("api")
            profile_name = "single" if hardware.selected_profile == "cpu_fallback" else hardware.selected_profile
            ok, detail = launch_api_runtime(target, profile_name)
            if ok:
                safe_json_print({
                    "ok": True,
                    "target": target,
                    "selected_engine": "api",
                    "selected_backend": "api",
                    "selected_profile": profile_name,
                    "attempted": attempted,
                })
                return 0
            last_error = f"api_failed:{detail}"
            continue

        if engine_name == "lmstudio":
            attempted.append("lmstudio")
            profile_name = "single" if hardware.selected_profile == "cpu_fallback" else hardware.selected_profile
            ok, detail = launch_lmstudio_runtime(target, profile_name)
            if ok:
                safe_json_print({
                    "ok": True,
                    "target": target,
                    "selected_engine": "lmstudio",
                    "selected_backend": "lmstudio",
                    "selected_profile": profile_name,
                    "attempted": attempted,
                })
                return 0
            last_error = f"lmstudio_failed:{detail}"
            continue

        if engine_name == "ollama":
            attempted.append("ollama")
            profile_name = "single" if hardware.selected_profile == "cpu_fallback" else hardware.selected_profile
            ok, detail = launch_ollama_runtime(target, profile_name)
            if ok:
                safe_json_print({
                    "ok": True,
                    "target": target,
                    "selected_engine": "ollama",
                    "selected_backend": "ollama",
                    "selected_profile": profile_name,
                    "attempted": attempted,
                })
                return 0
            last_error = f"ollama_failed:{detail}"
            continue

        if engine_name != "koboldcpp":
            attempted.append(f"{engine_name}:unsupported")
            continue

        for backend in backend_sequence:
            try:
                engine_path = ensure_engine_binary(backend)
            except Exception as err:
                attempted.append(f"{backend}:engine_missing")
                last_error = str(err)
                continue
            for profile_name in profile_sequence:
                if profile_name == "cpu_fallback" and backend != "cpu":
                    continue
                if backend == "cpu" and profile_name != "cpu_fallback":
                    continue
                plan = build_launch_plan(backend, profile_name)
                attempted.append(f"koboldcpp:{backend}/{profile_name}")
                resolved_plan, resolution_detail = resolve_plan_models(engine_path, plan)
                if resolved_plan is None:
                    last_error = f"model_resolution_failed:{backend}/{profile_name}\n{resolution_detail}".strip()
                    continue
                plan = resolved_plan
                warmup_ok, warmup_detail = perform_warmup(engine_path, plan)
                if not warmup_ok:
                    last_error = f"warmup_failed:{backend}/{profile_name}\n{warmup_detail}".strip()
                    continue
                primary_probe_ok, primary_probe_detail = perform_primary_probe(engine_path, plan)
                if not primary_probe_ok:
                    last_error = f"primary_probe_failed:{backend}/{profile_name}\n{primary_probe_detail}".strip()
                    continue
                stop_kobold_servers(*MODEL_PORTS)
                launch_ok, launch_detail = launch_models(engine_path, plan)
                if not launch_ok:
                    last_error = f"launch_failed:{backend}/{profile_name}\n{launch_detail}".strip()
                    stop_kobold_servers(*MODEL_PORTS)
                    continue
                selected = HardwareProfile(
                    requested_backend=hardware.requested_backend,
                    requested_profile=hardware.requested_profile,
                    selected_backend=backend,
                    selected_profile=profile_name,
                    primary_gpu=hardware.primary_gpu,
                    vendor=hardware.vendor,
                    vram_gb=hardware.vram_gb,
                    cuda_available=hardware.cuda_available,
                    vulkan_available=hardware.vulkan_available,
                    engine_path=str(engine_path),
                    source=hardware.source,
                    reasons=hardware.reasons + [f"resolved:{backend}/{profile_name}"],
                    gpus=hardware.gpus,
                )
                apply_runtime_env(plan)
                json_dump(HARDWARE_PROFILE_FILE, asdict(selected))
                write_runtime_state(selected, plan, target)
                try:
                    start_runtime_services(target)
                except Exception as err:
                    stop_runtime_services()
                    stop_kobold_servers(*MODEL_PORTS)
                    last_error = f"service_start_failed:{err}"
                    continue
                safe_json_print({
                    "ok": True,
                    "target": target,
                    "selected_engine": "koboldcpp",
                    "selected_backend": backend,
                    "selected_profile": profile_name,
                    "engine_path": str(engine_path),
                    "attempted": attempted,
                })
                return 0

    stop_runtime_services()
    stop_kobold_servers(*MODEL_PORTS)
    safe_json_print({
        "ok": False,
        "target": target,
        "attempted": attempted,
        "error": last_error or "No working backend/profile combination succeeded.",
    })
    return 1


def stop_runtime() -> int:
    stop_runtime_services()
    stopped = stop_kobold_servers(*MODEL_PORTS)
    if RUNTIME_STATE_FILE.exists():
        try:
            RUNTIME_STATE_FILE.unlink()
        except Exception:
            pass
    safe_json_print({
        "ok": True,
        "stopped_kobold_processes": stopped,
    })
    return 0


def port_open(host: str, port: int) -> bool:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(1)
    try:
        sock.connect((host, port))
        return True
    except OSError:
        return False
    finally:
        sock.close()


def runtime_status() -> int:
    payload: dict[str, Any] = {
        "hardware_profile": json.loads(HARDWARE_PROFILE_FILE.read_text(encoding="utf-8")) if HARDWARE_PROFILE_FILE.exists() else {},
        "runtime_state": json.loads(RUNTIME_STATE_FILE.read_text(encoding="utf-8")) if RUNTIME_STATE_FILE.exists() else {},
        "model_ports": {
            str(port): {
                "open": port_open("127.0.0.1", port),
                "models_ready": http_ready(f"http://127.0.0.1:{port}/v1/models", timeout=1.0),
            }
            for port in (MAIN_PORT, STATE_PORT, REVIEW_PORT)
        },
        "core_services": {
            "backend": mz._service_ready_details("backend"),
            "gateway": mz._service_ready_details("gateway"),
            "weixin_direct": mz._service_ready_details("weixin_direct"),
            "wechat_bridge": mz._service_ready_details("wechat_bridge"),
        },
    }
    safe_json_print(payload)
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Unified KoboldCpp portable runtime for Zhiyue Chat.")
    sub = parser.add_subparsers(dest="cmd", required=True)

    detect = sub.add_parser("detect")
    detect.add_argument("--backend", choices=["auto", "cuda", "vulkan", "cpu", "lmstudio", "api"], default=os.environ.get("ZHIYUE_BACKEND", "auto"))
    detect.add_argument(
        "--profile",
        choices=["auto", "full", "balanced", "single", "cpu_fallback"],
        default=os.environ.get("ZHIYUE_PROFILE", "auto"),
    )

    launch = sub.add_parser("launch")
    launch.add_argument("target", choices=["core", "full", "local_weixin"])
    launch.add_argument("--backend", choices=["auto", "cuda", "vulkan", "cpu", "lmstudio", "api"], default=os.environ.get("ZHIYUE_BACKEND", "auto"))
    launch.add_argument(
        "--profile",
        choices=["auto", "full", "balanced", "single", "cpu_fallback"],
        default=os.environ.get("ZHIYUE_PROFILE", "auto"),
    )

    sub.add_parser("stop")
    sub.add_parser("status")

    args = parser.parse_args()
    if args.cmd == "detect":
        safe_json_print(asdict(detect_hardware(args.backend, args.profile)))
        return 0
    if args.cmd == "launch":
        return launch_runtime(args.target, requested_profile=args.profile, requested_backend=args.backend)
    if args.cmd == "stop":
        return stop_runtime()
    return runtime_status()


if __name__ == "__main__":
    raise SystemExit(main())
