# -*- coding: utf-8 -*-
"""
张致悦 AI 守门代理。

第三方应用固定连接 http://127.0.0.1:8899/v1。
守门代理常驻 8899，收到请求后自动拉起：
- LM Studio API: 127.0.0.1:1234
- 成长服务: 127.0.0.1:8898

然后把请求转发给成长服务。这样第三方 API 请求可以唤醒后台。
"""
import os
import atexit
import subprocess
import time
from pathlib import Path
from urllib.parse import urlsplit

import _bootstrap_runtime  # noqa: F401
import requests
from flask import Flask, Response, jsonify, request
from zhiyue_project_paths import BASE_DIR, GATEWAY_LOCK_FILE


GATEWAY_HOST = os.environ.get("ZHIYUE_GATEWAY_HOST", "127.0.0.1")
GATEWAY_PORT = 8899
BACKEND_HOST = "127.0.0.1"
BACKEND_PORT = 8898
BACKEND_BASE = f"http://{BACKEND_HOST}:{BACKEND_PORT}"
BACKEND_HEALTH = f"{BACKEND_BASE}/api/health"
LM_CHAT_URL = os.environ.get(
    "ZHIYUE_LM_URL",
    os.environ.get("ZHIYUE_MAIN_LM_URL", "http://127.0.0.1:5001/v1/chat/completions"),
).strip()
_lm_parts = urlsplit(LM_CHAT_URL)
_lm_host = _lm_parts.hostname or "127.0.0.1"
_lm_port = _lm_parts.port or 5001
_lm_scheme = _lm_parts.scheme or "http"
LM_MODELS_URL = os.environ.get(
    "ZHIYUE_LM_MODELS_URL",
    f"{_lm_scheme}://{_lm_host}:{_lm_port}/v1/models",
).strip()
LM_AUTOSTART_ALLOWED = os.environ.get("ZHIYUE_GATEWAY_AUTOSTART_LM_STUDIO", "0").strip().lower() in {"1", "true", "yes", "on"}
LM_MODEL = (
    os.environ.get("ZHIYUE_LM_MODEL")
    or os.environ.get("ZHIYUE_MAIN_MODEL")
    or os.environ.get("ZHIYUE_MODEL")
    or "qwen/qwen3.6-35b-a3b"
)
LM_WARMUP_CACHE_SECONDS = max(5, int(os.environ.get("ZHIYUE_GATEWAY_LM_WARMUP_CACHE_SECONDS", "30")))
LM_STUDIO_PATHS = [
    os.environ.get("ZHIYUE_LMSTUDIO_GUI"),
    r"E:\AI\LMStudio\LM Studio.exe",
    r"D:\Users\ADMIN\AppData\Local\Programs\LM Studio\LM Studio.exe",
    os.path.expandvars(r"%LOCALAPPDATA%\Programs\LM Studio\LM Studio.exe"),
    os.path.expandvars(r"%LOCALAPPDATA%\LM Studio\LM Studio.exe"),
    r"C:\Program Files\LM Studio\LM Studio.exe",
]

app = Flask(__name__)
backend_proc = None
lm_started = False
_last_lm_warmup_ok_at = 0.0
LOCK_FILE = GATEWAY_LOCK_FILE
_lock_handle = None


def normalize_gateway_path(path: str) -> str:
    return "/" + (path or "").strip("/")


def is_openai_chat_path(path):
    normalized = normalize_gateway_path(path)
    return normalized in {"/v1/chat/completions", "/chat/completions"}


def path_requires_lm_warmup(path: str) -> bool:
    normalized = normalize_gateway_path(path)
    return normalized in {"/v1/chat/completions", "/chat/completions"}


def openai_error_reply(message="刚卡了一下", model_name="zhiyue"):
    created = int(time.time())
    return jsonify({
        "id": f"chatcmpl-zhiyue-gateway-{created}",
        "object": "chat.completion",
        "created": created,
        "model": model_name or "zhiyue",
        "choices": [{
            "index": 0,
            "message": {"role": "assistant", "content": message},
            "finish_reason": "stop",
        }],
        "usage": {
            "prompt_tokens": 0,
            "completion_tokens": 0,
            "total_tokens": 0,
        },
    })


def http_ok(url, timeout=2):
    try:
        resp = requests.get(url, timeout=timeout)
        return resp.status_code < 500
    except Exception:
        return False


def find_lm_studio():
    if not LM_AUTOSTART_ALLOWED:
        return None
    for path in LM_STUDIO_PATHS:
        if path and Path(path).exists():
            return path
    return None


def start_hidden(command, cwd=None, env=None):
    creationflags = 0
    startupinfo = None
    if os.name == "nt":
        creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    return subprocess.Popen(
        command,
        cwd=cwd,
        env=env,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        creationflags=creationflags,
        startupinfo=startupinfo,
    )


def acquire_single_instance_lock() -> bool:
    global _lock_handle
    try:
        handle = open(LOCK_FILE, "a+")
    except Exception:
        return True
    try:
        if os.name == "nt":
            import msvcrt
            handle.seek(0)
            handle.write(str(os.getpid()))
            handle.flush()
            msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        _lock_handle = handle
        return True
    except Exception:
        try:
            handle.close()
        except Exception:
            pass
        return False


def release_single_instance_lock() -> None:
    global _lock_handle
    handle = _lock_handle
    _lock_handle = None
    if not handle:
        return
    try:
        if os.name == "nt":
            import msvcrt
            try:
                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            except Exception:
                pass
        else:
            import fcntl
            try:
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
            except Exception:
                pass
    finally:
        try:
            handle.close()
        except Exception:
            pass
        try:
            LOCK_FILE.unlink(missing_ok=True)
        except Exception:
            pass


atexit.register(release_single_instance_lock)


def warmup_lm_model():
    global _last_lm_warmup_ok_at
    try:
        resp = requests.post(
            LM_CHAT_URL,
            json={
                "model": LM_MODEL,
                "messages": [{"role": "user", "content": "ping"}],
                "max_tokens": 1,
                "temperature": 0,
                "stream": False,
            },
            timeout=60,
        )
        ok = resp.status_code < 500
        if ok:
            data = resp.json()
            choices = data.get("choices", [])
            ok = bool(choices) and any(
                isinstance(c, dict) and c.get("message", {}).get("content") is not None
                for c in choices
            )
        if ok:
            _last_lm_warmup_ok_at = time.time()
        return ok
    except Exception:
        return False


def lm_warmup_cache_valid(now: float | None = None) -> bool:
    now = time.time() if now is None else float(now)
    return (_last_lm_warmup_ok_at > 0) and ((now - _last_lm_warmup_ok_at) < LM_WARMUP_CACHE_SECONDS)


def start_lm_minimizer():
    minimize_script = BASE_DIR / "_minimize_lmstudio.ps1"
    if minimize_script.exists():
        try:
            start_hidden(
                ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(minimize_script)],
                cwd=str(BASE_DIR),
            )
        except Exception:
            pass


def start_lm_studio(*, require_warmup: bool):
    global lm_started
    if require_warmup and lm_warmup_cache_valid():
        return True
    if http_ok(LM_MODELS_URL, timeout=2):
        start_lm_minimizer()
        return warmup_lm_model() if require_warmup else True
    lm_path = find_lm_studio()
    if not lm_path:
        return False
    if lm_started:
        lm_started = False
    if not lm_started:
        try:
            start_hidden([lm_path], cwd=str(BASE_DIR))
            lm_started = True
            start_lm_minimizer()
        except Exception:
            return False

    for _ in range(90):
        if http_ok(LM_MODELS_URL, timeout=2):
            return warmup_lm_model() if require_warmup else True
        time.sleep(1)
    return http_ok(LM_MODELS_URL, timeout=2) and (warmup_lm_model() if require_warmup else True)


def start_backend():
    global backend_proc
    if http_ok(BACKEND_HEALTH, timeout=2):
        return True
    if backend_proc and backend_proc.poll() is None:
        if http_ok(BACKEND_HEALTH, timeout=2):
            return True
        try:
            backend_proc.terminate()
        except Exception:
            pass
        try:
            backend_proc.wait(timeout=3)
        except Exception:
            try:
                backend_proc.kill()
            except Exception:
                pass
        backend_proc = None
    if backend_proc and backend_proc.poll() is None:
        pass
    else:
        env = os.environ.copy()
        env["ZHIYUE_PORT"] = str(BACKEND_PORT)
        env["ZHIYUE_LM_MODEL"] = LM_MODEL
        env.setdefault("ZHIYUE_MODEL", LM_MODEL)
        script = BASE_DIR / "zhiyue_connected.py"
        exe = "pythonw" if os.name == "nt" else "python"
        try:
            backend_proc = start_hidden([exe, str(script)], cwd=str(BASE_DIR), env=env)
        except Exception:
            backend_proc = start_hidden(["python", str(script)], cwd=str(BASE_DIR), env=env)

    for _ in range(90):
        if http_ok(BACKEND_HEALTH, timeout=2):
            return True
        time.sleep(1)
    return http_ok(BACKEND_HEALTH, timeout=2)


def ensure_services(path: str = ""):
    # API mode: don't hard-require LM Studio / local /v1/models health.
    # Backend will talk to the configured provider directly.
    if os.environ.get("ZHIYUE_BACKEND", "").strip().lower() == "api" or os.environ.get("ZHIYUE_API_ENABLED", "0").strip().lower() in {"1", "true", "yes", "on"}:
        lm_ok = True
    else:
        lm_ok = start_lm_studio(require_warmup=path_requires_lm_warmup(path))
    backend_ok = start_backend()
    return lm_ok and backend_ok


def proxy(path=""):
    if not ensure_services(path):
        if is_openai_chat_path(path):
            return openai_error_reply("刚卡了一下"), 200
        return jsonify({
            "ok": False,
            "error": "张致悦后台或 LM Studio 未能自动启动",
            "backend": BACKEND_HEALTH,
            "lm": LM_MODELS_URL,
        }), 503

    target = f"{BACKEND_BASE}/{path}".rstrip("/")
    if request.query_string:
        target += "?" + request.query_string.decode("utf-8", errors="ignore")

    headers = {
        key: value for key, value in request.headers
        if key.lower() not in {"host", "content-length", "connection", "accept-encoding"}
    }
    try:
        resp = requests.request(
            method=request.method,
            url=target,
            headers=headers,
            data=request.get_data(),
            stream=True,
            timeout=300,
        )
    except Exception as err:
        if is_openai_chat_path(path):
            return openai_error_reply("我刚没反应过来"), 200
        return jsonify({"ok": False, "error": str(err)}), 502

    excluded = {"content-encoding", "content-length", "transfer-encoding", "connection"}
    response_headers = [
        (key, value) for key, value in resp.headers.items()
        if key.lower() not in excluded
    ]
    return Response(resp.iter_content(chunk_size=8192), status=resp.status_code, headers=response_headers)


@app.route("/api/gateway/health")
def gateway_health():
    return jsonify({
        "ok": True,
        "gateway": f"http://{GATEWAY_HOST}:{GATEWAY_PORT}",
        "backend": BACKEND_BASE,
        "backend_ready": http_ok(BACKEND_HEALTH, timeout=1),
        "lm_ready": http_ok(LM_MODELS_URL, timeout=1),
    })


@app.route("/", defaults={"path": ""}, methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"])
@app.route("/<path:path>", methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"])
def catch_all(path):
    return proxy(path)


if __name__ == "__main__":
    if not acquire_single_instance_lock():
        raise SystemExit(0)
    app.run(host=GATEWAY_HOST, port=GATEWAY_PORT, debug=False, threaded=True)
