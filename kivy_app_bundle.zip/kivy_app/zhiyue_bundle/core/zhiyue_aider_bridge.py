"""Aider-based code proposal diff generator.

Replaces the hand-written generate_proposal_diff with Aider's Coder API.
Keeps the same return format: {"diff_text": str, "test_commands": list, "ok": bool}

Uses git worktree to give Aider a full-project view (repo map, imports, etc.)
without modifying the main working tree.

Requirements:
- Git installed (C:\\Program Files\\Git\\bin\\git.exe)
- aider-chat installed (pip install aider-chat)
- KoboldCpp / LM Studio running on http://127.0.0.1:5001/v1
"""

import os, sys, tempfile, shutil, subprocess, time
from pathlib import Path

import _bootstrap_runtime
import requests

# ── UTF-8 on Windows ──────────────────────────────────────────────────────
os.environ.setdefault("PYTHONIOENCODING", "utf-8")
if sys.platform == "win32":
    import codecs

    codecs.register(lambda name: codecs.lookup("utf-8") if name == "cp65001" else None)

# ── Git / Aider configuration ──────────────────────────────────────────────
# Git: env > PATH > common install locations
_GIT = os.environ.get("GIT_PYTHON_GIT_EXECUTABLE", "")
if not _GIT or not os.path.isfile(_GIT):
    _GIT = shutil.which("git") or r"git"
    if not os.path.isfile(_GIT):
        _GIT = "git"
os.environ.setdefault("OPENAI_API_BASE", "http://127.0.0.1:5001/v1")
os.environ.setdefault("OPENAI_API_KEY", "sk-not-needed")

try:
    import git as _gitpython
except Exception:
    _gitpython = None
from aider.coders import Coder as _Coder
from aider.models import Model as _Model
from aider.io import InputOutput as _IO


BASE_DIR = _bootstrap_runtime.PROJECT_ROOT
LM_MODELS_URL = os.environ.get("ZHIYUE_LM_MODELS_URL", "http://127.0.0.1:5001/v1/models").strip()
LM_CHAT_URL = os.environ.get("ZHIYUE_LM_URL", "http://127.0.0.1:5001/v1/chat/completions").strip()
LM_WARMUP_CACHE_SECONDS = max(5, int(os.environ.get("ZHIYUE_AIDER_LM_WARMUP_CACHE_SECONDS", "30")))
LM_STUDIO_PATHS = [
    os.environ.get("ZHIYUE_LMSTUDIO_GUI"),
    r"E:\AI\LMStudio\LM Studio.exe",
    os.path.expandvars(r"%LOCALAPPDATA%\Programs\LM Studio\LM Studio.exe"),
    os.path.expandvars(r"%LOCALAPPDATA%\LM Studio\LM Studio.exe"),
    str(Path.home() / "AppData" / "Local" / "Programs" / "LM Studio" / "LM Studio.exe"),
    "LM Studio.exe",
]
_last_lm_warmup_ok_at = 0.0


def _resolve_repo_target(base_dir: str | Path, target_file: str) -> tuple[Path | None, str]:
    base_path = Path(base_dir or BASE_DIR)
    raw_name = str(target_file or "").strip()
    normalized = Path(raw_name).name
    candidates: list[Path] = []
    seen: set[str] = set()
    for candidate in (
        base_path / raw_name,
        base_path / normalized,
        base_path / "modules" / normalized,
        base_path / "core" / normalized,
    ):
        key = str(candidate).lower()
        if key in seen:
            continue
        seen.add(key)
        candidates.append(candidate)
    for candidate in candidates:
        if candidate.exists() and candidate.is_file():
            return candidate, candidate.relative_to(base_path).as_posix()
    fallback = candidates[0] if candidates else (base_path / normalized)
    try:
        repo_rel = fallback.relative_to(base_path).as_posix()
    except Exception:
        repo_rel = Path(raw_name or normalized).as_posix()
    return None, repo_rel


def _normalize_generated_diff_paths(diff_text: str, repo_rel_map: dict[str, str]) -> str:
    normalized = diff_text or ""
    for target_name, repo_rel in repo_rel_map.items():
        bare_name = Path(str(target_name or "")).name.replace("\\", "/")
        repo_name = str(repo_rel or "").replace("\\", "/")
        if not bare_name or not repo_name or bare_name == repo_name:
            continue
        normalized = normalized.replace(f"a/{repo_name}", f"a/{bare_name}")
        normalized = normalized.replace(f"b/{repo_name}", f"b/{bare_name}")
    return normalized


def _default_test_commands(target_files: list[str]) -> list[str]:
    return [
        f"python -m py_compile {' '.join(target_files or ['zhiyue_connected.py'])}",
        "python zhiyue_eval.py --mode api-smoke --transport test-client",
        "python zhiyue_eval.py --mode memory-hit --transport test-client",
    ]


def _git(*args, cwd=None):
    cwd = cwd or os.environ.get("ZHIYUE_PROJECT_DIR", str(BASE_DIR))
    """Run git command, return stdout or raise on failure."""
    r = subprocess.run(
        [_GIT] + list(args),
        cwd=cwd,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    if r.returncode != 0:
        raise RuntimeError(f"git {' '.join(args)} failed: {r.stderr.strip()}")
    return r.stdout.strip()


def _git_quiet(*args, cwd=None):
    cwd = cwd or os.environ.get("ZHIYUE_PROJECT_DIR", str(BASE_DIR))
    """Run git command, return (rc, stdout, stderr). Never raises."""
    r = subprocess.run(
        [_GIT] + list(args),
        cwd=cwd,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    return r.returncode, r.stdout.strip(), r.stderr.strip()


def http_ok(url: str, timeout: float = 2.0) -> bool:
    try:
        resp = requests.get(url, timeout=timeout)
        return resp.status_code < 500
    except Exception:
        return False


def find_lm_studio() -> str | None:
    for path in LM_STUDIO_PATHS:
        if path and Path(path).exists():
            return path
    return None


def start_hidden(command, cwd=None, env=None):
    creationflags = 0
    startupinfo = None
    if os.name == "nt":
        creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    return subprocess.Popen(
        command,
        cwd=cwd,
        env=env,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        creationflags=creationflags,
        startupinfo=startupinfo,
    )


def start_lm_minimizer(base_dir: str = None):
    base_dir = base_dir or os.environ.get("ZHIYUE_PROJECT_DIR", str(BASE_DIR))
    minimize_script = Path(base_dir) / "_minimize_lmstudio.ps1"
    if minimize_script.exists():
        try:
            start_hidden(
                ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(minimize_script)],
                cwd=base_dir,
            )
        except Exception:
            pass


def warmup_lm_model() -> bool:
    global _last_lm_warmup_ok_at
    try:
        resp = requests.post(
            LM_CHAT_URL,
            json={
                "model": os.environ.get("ZHIYUE_LM_MODEL", "qwen/qwen3.6-35b-a3b"),
                "messages": [{"role": "user", "content": "ping"}],
                "max_tokens": 1,
                "temperature": 0,
                "stream": False,
            },
            timeout=60,
        )
        ok = resp.status_code < 500
        if ok:
            try:
                data = resp.json()
                choices = data.get("choices", [])
                ok = bool(choices) and any(
                    isinstance(choice, dict) and choice.get("message", {}).get("content") is not None
                    for choice in choices
                )
            except Exception:
                ok = False
        if ok:
            _last_lm_warmup_ok_at = time.time()
        return ok
    except Exception:
        return False


def lm_warmup_cache_valid(now: float | None = None) -> bool:
    now = time.time() if now is None else float(now)
    return (_last_lm_warmup_ok_at > 0) and ((now - _last_lm_warmup_ok_at) < LM_WARMUP_CACHE_SECONDS)


def ensure_lm_studio_ready(*, base_dir: str = None, require_warmup: bool = True, timeout: int = 90) -> bool:
    if require_warmup and lm_warmup_cache_valid():
        return True
    if http_ok(LM_MODELS_URL, timeout=2):
        start_lm_minimizer(base_dir)
        return warmup_lm_model() if require_warmup else True

    lm_path = find_lm_studio()
    if not lm_path:
        return False

    try:
        start_hidden([lm_path], cwd=base_dir)
    except Exception:
        return False

    start_lm_minimizer(base_dir)
    deadline = time.time() + max(10, int(timeout or 90))
    while time.time() < deadline:
        if http_ok(LM_MODELS_URL, timeout=2):
            return warmup_lm_model() if require_warmup else True
        time.sleep(1)

    return http_ok(LM_MODELS_URL, timeout=2) and (warmup_lm_model() if require_warmup else True)


def generate_proposal_diff_via_aider(
    proposal: dict,
    base_dir: str = None,
    *,
    model_name: str = None,
    edit_format: str = "udiff",
    timeout: int = 120,
) -> dict:
    """Use Aider Coder to generate a unified diff for a draft code proposal.

    Creates a git worktree (full project context!), runs Aider Coder on the
    target files, extracts the diff via git, then cleans up the worktree.

    Args:
        proposal: Dict with target_files, meta.fix_template.{title,rationale}
        base_dir: Source git repository directory.
        model_name: Aider model name (default: openai/qwen/qwen3.6-35b-a3b)
        edit_format: "udiff" (default) or "search_replace"
        timeout: LLM call timeout in seconds.

    Returns:
        {"diff_text": ..., "test_commands": [...], "ok": bool}
    """
    if model_name is None:
        model_name = os.environ.get("ZHIYUE_AIDER_MODEL", "openai/qwen/qwen3.6-35b-a3b")
    base_dir = base_dir or os.environ.get("ZHIYUE_PROJECT_DIR", str(BASE_DIR))

    if _gitpython is None:
        return {
            "diff_text": "",
            "test_commands": [],
            "ok": False,
            "error": "gitpython is not available",
        }

    target_files = proposal.get("target_files") or []
    meta = proposal.get("meta") or {}
    fix_template = meta.get("fix_template") or {}
    title = fix_template.get("title") or proposal.get("title") or "(fix)"
    rationale = fix_template.get("rationale") or proposal.get("rationale") or ""
    repo_rel_map: dict[str, str] = {}
    resolved_repo_files: list[str] = []

    if not target_files:
        return {"diff_text": "", "test_commands": [], "ok": False}

    if not ensure_lm_studio_ready(base_dir=base_dir, require_warmup=True, timeout=timeout):
        return {
            "diff_text": "",
            "test_commands": [],
            "ok": False,
            "error": "LLM Engine (KoboldCpp/LM Studio) is not ready",
        }

    # ── Create git worktree on a temp branch ───────────────────────────────
    ts = int(time.time())
    tmpdir = tempfile.mkdtemp(prefix="aider_wt_")
    branch = f"aider_wt_{ts}"
    cleanup_worktree = True

    try:
        # Sanity: repo must exist and be clean-ish
        main_repo = _gitpython.Repo(base_dir)
        try:
            original_branch = main_repo.active_branch.name
        except Exception:
            # Detached HEAD is still valid input; create the worktree from HEAD.
            original_branch = "HEAD"

        # Create worktree on a new branch (keeps main tree untouched)
        _git("worktree", "add", "-b", branch, tmpdir, original_branch, cwd=base_dir)

        # ── Run Aider Coder on the worktree ────────────────────────────────
        io = _IO(
            yes=True,
            chat_history_file=str(Path(tmpdir) / ".aider.chat.history.md"),
        )
        model = _Model(model_name)

        for target_file in target_files:
            resolved_path, repo_rel = _resolve_repo_target(base_dir, str(target_file))
            if resolved_path is None:
                raise FileNotFoundError(f"target file missing in project: {target_file}")
            repo_rel_map[str(target_file)] = repo_rel
            resolved_repo_files.append(repo_rel)
        abs_fnames = [
            str(Path(tmpdir) / repo_rel)
            for repo_rel in resolved_repo_files
        ]
        for f in abs_fnames:
            if not Path(f).exists():
                raise FileNotFoundError(f"target file missing in worktree: {f}")

        coder = _Coder.create(
            main_model=model,
            edit_format=edit_format,
            io=io,
            fnames=abs_fnames,
            map_tokens=512,
        )

        # Build message — Aider's repo map will provide full context
        message = (
            f"Fix the following issue in the project.\n\n"
            f"Title: {title}\n"
            f"Rationale: {rationale}\n\n"
            f"Target file(s): {', '.join(target_files)}\n\n"
            f"Make ONLY minimal necessary changes. Output exactly one unified "
            f"diff per modified file."
        )
        coder.run(message)

        # ── Extract diff ───────────────────────────────────────────────────
        # Aider auto-commits on the worktree branch.
        # Diff between original branch and the worktree branch.
        wt_repo = _gitpython.Repo(tmpdir)
        try:
            diff_text = _git(
                "diff", f"{original_branch}..{branch}", cwd=tmpdir
            )
        except Exception:
            # Fallback: diff from the worktree's parent commit
            try:
                diff_text = wt_repo.git.diff("HEAD~1") or ""
            except Exception:
                diff_text = ""

        # Determine test commands
        test_commands = (
            fix_template.get("test_commands")
            or proposal.get("test_commands")
            or _default_test_commands(target_files)
        )
        diff_text = _normalize_generated_diff_paths(diff_text, repo_rel_map)

        return {
            "diff_text": diff_text.strip(),
            "test_commands": test_commands,
            "ok": bool(diff_text.strip()),
        }

    except Exception as ex:
        return {
            "diff_text": "",
            "test_commands": [],
            "ok": False,
            "error": f"{type(ex).__name__}: {ex!r}",
        }

    finally:
        # ── Cleanup worktree ───────────────────────────────────────────────
        if cleanup_worktree:
            # Remove worktree entry from main repo
            _git_quiet("worktree", "remove", "--force", tmpdir, cwd=base_dir)
            # Force-delete the temp directory (belt + suspenders)
            shutil.rmtree(tmpdir, ignore_errors=True)
            # Clean up the temp branch
            _git_quiet("branch", "-D", branch, cwd=base_dir)
