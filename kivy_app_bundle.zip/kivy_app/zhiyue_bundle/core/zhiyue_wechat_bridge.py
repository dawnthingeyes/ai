# -*- coding: utf-8 -*-
"""
Zhiyue WeChat bridge.

This is a local relay for a legal/owned WeChat integration path:
- an external relay, CC Connect, or enterprise bot posts inbound messages here
- this bridge forwards them to Zhiyue's chat API
- the bridge returns the assistant reply for the caller to deliver back to WeChat

It does not automate desktop WeChat and does not open new desktop/tool permissions.
"""
from __future__ import annotations

import os
from typing import Any

import _bootstrap_runtime  # noqa: F401
import requests
from flask import Flask, jsonify, request


BRIDGE_HOST = os.environ.get("ZHIYUE_WECHAT_BRIDGE_HOST", "127.0.0.1")
BRIDGE_PORT = int(os.environ.get("ZHIYUE_WECHAT_BRIDGE_PORT", "8911"))
TARGET_URL = os.environ.get("ZHIYUE_WECHAT_TARGET_URL", "http://127.0.0.1:8899/api/chat")
BRIDGE_TOKEN = os.environ.get("ZHIYUE_WECHAT_BRIDGE_TOKEN", "").strip()

app = Flask(__name__)


def _json_error(message: str, code: int = 400):
    return jsonify({"ok": False, "error": message}), code


def _require_token() -> None:
    if not BRIDGE_TOKEN:
        return
    token = (request.headers.get("X-Zhiyue-Token") or request.args.get("token") or "").strip()
    if token != BRIDGE_TOKEN:
        raise PermissionError("invalid bridge token")


def _extract_text(payload: dict[str, Any]) -> str:
    for key in ("text", "content", "msg", "message"):
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ""


@app.route("/health")
def health():
    return jsonify({
        "ok": True,
        "bridge": f"http://{BRIDGE_HOST}:{BRIDGE_PORT}",
        "target_url": TARGET_URL,
        "token_enabled": bool(BRIDGE_TOKEN),
    })


@app.route("/config")
def config():
    return jsonify({
        "ok": True,
        "mode": "wechat_relay",
        "inbound_example": {
            "conversation_id": "group-or-user-id",
            "user_id": "sender-id",
            "text": "你好",
        },
        "outbound_shape": {
            "reply": "张致悦的回复",
            "messages": [{"type": "text", "content": "张致悦的回复"}],
        },
    })


@app.route("/wechat/inbound", methods=["POST"])
def wechat_inbound():
    try:
        _require_token()
    except PermissionError as err:
        return _json_error(str(err), 401)

    data = request.json if isinstance(request.json, dict) else {}
    text = _extract_text(data)
    if not text:
        return _json_error("missing text/content/msg/message")

    channel = data.get("conversation_id") or data.get("chat_id") or data.get("user_id") or "wechat"
    try:
        resp = requests.post(
            TARGET_URL,
            json={"message": text, "channel": f"wechat:{channel}"},
            timeout=300,
        )
        resp.raise_for_status()
        payload = resp.json()
    except Exception as err:
        return _json_error(f"forward failed: {err}", 502)

    return jsonify({
        "ok": True,
        "conversation_id": channel,
        "user_id": data.get("user_id") or "",
        "text": text,
        "reply": payload.get("reply") if isinstance(payload, dict) else "",
        "messages": payload.get("messages") if isinstance(payload, dict) else [],
        "agent_run_id": payload.get("agent_run_id") if isinstance(payload, dict) else "",
        "source": "zhiyue_wechat_bridge",
    })


@app.route("/wechat/send", methods=["POST"])
def wechat_send():
    return wechat_inbound()


if __name__ == "__main__":
    app.run(host=BRIDGE_HOST, port=BRIDGE_PORT, debug=False, threaded=True)
