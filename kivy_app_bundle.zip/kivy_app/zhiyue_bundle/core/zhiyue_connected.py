﻿# -*- coding: utf-8 -*-
"""
张致悦 AI - LM Studio + 成长系统 连接器 v2
成长系统通过动态改写Prompt来影响模型,对LM Studio完全透明

v2 新增:
  - 人格底色(5维度)
  - 认知画像(角色对用户的内心画像)
  - 内在冲突(特定阶段显性的隐忧)
  - 分层记忆(fact/preference/boundary/experience)
"""
import os, sys, json, time, random, re, sqlite3, threading, subprocess, fnmatch, unicodedata, hashlib
from collections import Counter
from datetime import datetime, date, timedelta
from pathlib import Path
from urllib.parse import quote, urlparse
from zoneinfo import ZoneInfo
import logging as _logging
_dbg = _logging.getLogger("zhiyue")

import _bootstrap_runtime  # noqa: F401

if getattr(sys, "stdout", None) and hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding='utf-8')
if getattr(sys, "stderr", None) and hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding='utf-8')

try:
    import requests
except ImportError:
    from requests_stub import get, post, request, session  # stdlib fallback
    import types as _types
    requests = _types.ModuleType("requests")
    requests.get = get
    requests.post = post
    requests.request = request
    requests.session = session
    import sys as _sys
    _sys.modules["requests"] = requests
    print("[bootstrap] requests not found, using stdlib fallback (requests_stub)")
import zhiyue_web
import zhiyue_rag
import zhiyue_eval
from zhiyue_code_fix import (
    CODE_CHANGE_ALERTS_FILE,
    add_runtime_issue,
    approve_fixes,
    clear_fixed,
    execute_approved_fixes,
    format_pending_for_user,
    format_proposals_for_user,
    generate_fix_diff_for_approved,
    get_pending_summary,
    mark_fixed,
    reject_fixes,
    scan_and_accumulate_issues,
)
import zhiyue_growth_entry as growth_entry
import zhiyue_growth_finalize as growth_finalize
import zhiyue_chat_pipeline as chat_pipeline
import zhiyue_learning_controller as learning_controller
import zhiyue_office_task_flow as office_task_flow
import zhiyue_office_response as office_response
import zhiyue_memory_injection_clean as memory_injection
import zhiyue_request_merge as request_merge
from zhiyue_capability_routes import register_capability_routes
# Graceful fallback for optional module
try:
    import zhiyue_character_state as char_state
except ImportError:
    char_state = None
    import warnings
    warnings.warn('zhiyue_character_state not found, character state feature disabled')


class _MockCharacterState:
    """No-op fallback when zhiyue_character_state is unavailable."""
    def __init__(self, *a, **kw):
        self.plan = {}
    def has_life_plan(self): return False
    def has_today_plan(self): return False
    def is_new_day(self): return False
    def get_character_state(self): return self
    def get_status(self): return {}
    def get_full_status(self): return {}
    def start_new_day(self, *a, **kw): return {}
    def generate_life_plan(self, *a, **kw): return None
    def generate_daily_joys(self, *a, **kw): return None
    def load_joys(self, *a, **kw): return []
    def get_today_journal(self, *a, **kw): return []
    def update_emotional_score(self, *a, **kw): return 0, ""
    def record_proactive(self, *a, **kw): pass
    def mark_shared(self, *a, **kw): pass
    def should_send_proactive(self, *a, **kw): return False
    def get_proactive_prompt(self, *a, **kw): return ""
    def get_current_activity(self, *a, **kw): return None
    def get_share_topic_for_now(self, *a, **kw): return None
    def build_life_plan_context(self, *a, **kw): return ""
    def browse_interest(self, *a, **kw): return None
    def browse_random_interesting(self, *a, **kw): return None
    def should_do_autonomous_activity(self, *a, **kw): return False, ""
    def execute_autonomous_activity(self, *a, **kw): return None
    def mark_joy_done(self, *a, **kw): pass
    def run_autonomous_tick(self, *a, **kw): return None
    def get_undone_joys(self, *a, **kw): return []


def _get_char_state():
    """Safe getter: returns a working cs object even if module is missing."""
    if char_state is None:
        return _MockCharacterState()
    try:
        return _get_char_state()
    except Exception:
        return _MockCharacterState()
from zhiyue_prompt_utils import (
    build_model_user_message,
    choose_lm_reply_max_tokens,
    sanitize_prompt_history,
)
import zhiyue_reply_quality as reply_quality
import zhiyue_human_like as human_like
from zhiyue_semantic_routing import match_intent
import zhiyue_rule_hints as rule_hints_builder
import zhiyue_runtime_chat_rules as runtime_chat_rules
import zhiyue_state_hygiene as state_hygiene
from zhiyue_runtime_health import runtime_health_snapshot, self_monitor_snapshot
from zhiyue_reply_payloads import (
    build_forced_technical_review_payload,
    build_runtime_chat_payload,
)
from zhiyue_technical_entry import handle_forced_technical_review
import zhiyue_technical_chat_flow as technical_chat_flow
from zhiyue_technical_review import (
    is_code_review_followup_with_history,
    is_tool_deflection_reply,
    local_code_review_reply,
    looks_like_explicit_code_review_request,
    normalize_technical_text,
)
from zhiyue_project_paths import (
    API_CHAT_ERROR_LOG,
    BASE_DIR,
    EMOJI_AUDIT_PATH,
    EMOJI_MANIFEST_PATH,
    EMOJI_REVIEW_STATE_PATH,
    GROWTH_DB,
    INTIMACY_FILE,
    MEMORY_DB,
    OBSERVABILITY_DB,
    PERSONA_PROFILE_FILE,
    REMOTE_CONTROL_PROVIDER_FILE,
    SELF_MONITOR_FINDINGS_FILE,
    SELF_MONITOR_STATE_FILE,
    TOOL_LOOP_LOG,
    WEIXIN_DEAD_LETTER_FILE,
    WEIXIN_QUEUE_FILE,
)

import zhiyue_memory_v2 as _mv2
from zhiyue_aider_bridge import ensure_lm_studio_ready as _ensure_lm_studio_ready, generate_proposal_diff_via_aider
from zhiyue_llm_provider import (
    post_chat_completion as _provider_post_chat_completion,
    provider_healthcheck as _provider_healthcheck,
    load_provider_config as _load_provider_config,
    save_provider_config as _save_provider_config,
    apply_provider_env as _apply_provider_env,
)
from zhiyue_sync_bundle import build_sync_bundle as _build_sync_bundle, apply_sync_bundle as _apply_sync_bundle

# ============ 配置 ============
# If API provider is enabled, mirror config into legacy env vars so older paths
# (e.g. qwen-agent/tooling) keep working without requiring code changes.
try:
    _cfg0 = _load_provider_config()
    if isinstance(_cfg0, dict) and bool(_cfg0.get("enabled")):
        _apply_provider_env(_cfg0)
except Exception:
    pass

LM_URL   = os.environ.get("ZHIYUE_LM_URL", "http://127.0.0.1:5001/v1/chat/completions")
LM_MODEL = os.environ.get("ZHIYUE_LM_MODEL", "qwen/qwen3.6-35b-a3b")
PORT     = int(os.environ.get("ZHIYUE_PORT", "8898"))
HOST     = os.environ.get("ZHIYUE_HOST", "127.0.0.1")
LAST_LM_ERROR = ""
LM_MAX_TOKENS = int(os.environ.get("ZHIYUE_LM_MAX_TOKENS", "1600"))
LM_THINKING_ENABLED = False
LM_TEMPERATURE = float(os.environ.get("ZHIYUE_LM_TEMPERATURE", "0.78"))
LM_TOP_P = float(os.environ.get("ZHIYUE_LM_TOP_P", "0.90"))
LM_TOP_K = int(os.environ.get("ZHIYUE_LM_TOP_K", "40"))
LM_REPEAT_PENALTY = float(os.environ.get("ZHIYUE_LM_REPEAT_PENALTY", "1.10"))
LM_STOP_STRINGS = [item for item in os.environ.get("ZHIYUE_LM_STOP", "<|im_end|>").split("||") if item]
LM_PRESENCE_PENALTY = float(os.environ.get("ZHIYUE_LM_PRESENCE_PENALTY", "0.18"))
LM_FREQUENCY_PENALTY = float(os.environ.get("ZHIYUE_LM_FREQUENCY_PENALTY", "0.45"))
RULE_REPLY_MODELIZE = os.environ.get("ZHIYUE_RULE_REPLY_MODELIZE", "0").strip().lower() not in {"0", "false", "no", "off"}
LM_PRIMARY_ONLY = os.environ.get("ZHIYUE_LM_PRIMARY_ONLY", "1").strip().lower() not in {"0", "false", "no", "off"}
HISTORY_MESSAGE_LIMIT = max(2, int(os.environ.get("ZHIYUE_HISTORY_MESSAGES", "12")))
PROACTIVE_MIN_SECONDS = 45 * 60
INPUT_MERGE_SECONDS = 2.2
INPUT_MERGE_MAX_SECONDS = 6.0
OPENAI_BUBBLE_MODE = os.environ.get("ZHIYUE_OPENAI_BUBBLE_MODE", "single").strip().lower()
OPENAI_BUBBLE_SEPARATOR = os.environ.get("ZHIYUE_OPENAI_BUBBLE_SEPARATOR", " ")
TIMEZONE_NAME = os.environ.get("ZHIYUE_TIMEZONE", "Asia/Shanghai").strip() or "Asia/Shanghai"
EXTERNAL_AWARENESS_ENABLED = os.environ.get("ZHIYUE_EXTERNAL_AWARENESS_ENABLED", "1").strip().lower() not in {"0", "false", "no", "off"}
WEATHER_CITY = os.environ.get("ZHIYUE_WEATHER_CITY", "").strip()
DEFAULT_LOCATION_LABEL = os.environ.get("ZHIYUE_LOCATION_LABEL", "").strip()
WEATHER_CACHE_SECONDS = max(60, int(os.environ.get("ZHIYUE_WEATHER_CACHE_SECONDS", "900")))
WEATHER_TIMEOUT_SECONDS = max(2.0, float(os.environ.get("ZHIYUE_WEATHER_TIMEOUT_SECONDS", "8")))
try:
    APP_TIMEZONE = ZoneInfo(TIMEZONE_NAME)
except Exception:
    APP_TIMEZONE = ZoneInfo("Asia/Shanghai")
    TIMEZONE_NAME = "Asia/Shanghai"

# ============ 基础路径 ============
EMOJI_DIR  = BASE_DIR / "emojis"
EMOJI_ONLINE_TIMEOUT = float(os.environ.get("ZHIYUE_EMOJI_ONLINE_TIMEOUT", "8.0"))
EMOJI_ONLINE_MAX_BYTES = int(os.environ.get("ZHIYUE_EMOJI_ONLINE_MAX_BYTES", str(1024 * 1024 * 2)))
_EMOJI_MANIFEST_CACHE = None
_EMOJI_IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"}
EMOJI_ONLINE_ALLOWED_HOSTS = {
    host.strip().lower()
    for host in os.environ.get(
        "ZHIYUE_EMOJI_ONLINE_ALLOWED_HOSTS",
        "api.github.com,raw.githubusercontent.com,githubusercontent.com,github.githubassets.com",
    ).split(",")
    if host.strip()
}
WEIXIN_DEAD_LETTER_WARN_THRESHOLD = max(1, int(os.environ.get("ZHIYUE_WEIXIN_DEAD_LETTER_WARN_THRESHOLD", "3")))

import zhiyue_db_migrations as db_migrations

db_migrations.init_all_dbs(MEMORY_DB, GROWTH_DB, OBSERVABILITY_DB)

# ── 启动时检测源码变更，有变更则后台自动跑 eval ──
if os.environ.get("ZHIYUE_AUTO_EVAL_ON_CHANGE", "0").strip().lower() not in {"0", "false", "no", "off"}:
    try:
        _auto_eval_pid = zhiyue_eval.auto_eval_on_change()
        if _auto_eval_pid:
            _dbg.info(f"[startup] 源码变更检测 → 后台 eval 已启动 pid={_auto_eval_pid}")
        else:
            _dbg.info("[startup] 源码无变更，跳过自动 eval")
    except Exception as _e:
        _dbg.warning(f"[startup] auto_eval_on_change 失败: {_e}")



# ============ 历史聊天档案 ============
def log_runtime_exception(context, err):
    try:
        sys.stderr.write(f"[{context}] {err}\n")
    except (OSError) as e:
        pass


def coerce_int_arg(value, default: int, *, minimum: int | None = None, maximum: int | None = None, context: str = "int_arg") -> int:
    try:
        parsed = int(value)
    except (TypeError, ValueError) as err:
        log_runtime_exception(context, err)
        parsed = int(default)
    if minimum is not None:
        parsed = max(minimum, parsed)
    if maximum is not None:
        parsed = min(maximum, parsed)
    return parsed


def append_history_turn(history, user_msg, reply, *, limit=50):
    history.append({"role": "user", "content": user_msg})
    history.append({"role": "assistant", "content": reply})
    if len(history) > limit:
        del history[:-limit]


def load_persona_profile():
    defaults = {
        "user_name": "",
        "user_facts": [],
        "user_preferences": [],
        "user_boundaries": [],
        "shared_history": [],
        "style_phrases": [],
        "imported_files": [],
        "updated_at": None,
    }
    if os.path.exists(PERSONA_PROFILE_FILE):
        try:
            with open(PERSONA_PROFILE_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            for key, value in defaults.items():
                data.setdefault(key, value)
            return data
        except Exception as err:
            log_runtime_exception("qa_agent_stage", err)
    return defaults


def save_persona_profile(profile):
    profile["updated_at"] = now_iso_local()
    with open(PERSONA_PROFILE_FILE, "w", encoding="utf-8") as f:
        json.dump(profile, f, ensure_ascii=False, indent=2)


def _append_unique(items, value, limit=30):
    value = (value or "").strip()
    if value and value not in items:
        items.append(value)
    if len(items) > limit:
        del items[:-limit]


def clean_person_name(name):
    name = (name or "").strip()
    name = re.sub(r'[啊呀呢吧嘛哈了]+$', '', name)
    if name in {"什么", "谁", "啥", "哪个", "哪位"}:
        return ""
    return name[:12]


def normalize_chat_messages(raw):
    def _extract_message_text(value):
        if isinstance(value, str):
            return value.strip()
        if isinstance(value, list):
            parts = []
            for item in value:
                if isinstance(item, dict):
                    if isinstance(item.get("text"), str):
                        parts.append(item.get("text", ""))
                    elif isinstance(item.get("content"), str):
                        parts.append(item.get("content", ""))
                elif isinstance(item, str):
                    parts.append(item)
            return "\n".join(part.strip() for part in parts if str(part).strip()).strip()
        if isinstance(value, dict):
            if isinstance(value.get("text"), str):
                return value.get("text", "").strip()
            if isinstance(value.get("content"), str):
                return value.get("content", "").strip()
        return ""

    if isinstance(raw, list):
        source = raw
    elif isinstance(raw, dict):
        source = raw.get("messages") or raw.get("data") or raw.get("history") or []
    else:
        return []

    result = []
    for item in source:
        if not isinstance(item, dict):
            continue
        role = item.get("role") or item.get("type") or item.get("sender")
        content = item.get("content") or item.get("text") or item.get("message") or item.get("msg")
        if not role and isinstance(item.get("versions"), list):
            versions = [x for x in item.get("versions") or [] if isinstance(x, dict)]
            selected = int(item.get("currentlySelected") or 0)
            if versions:
                chosen = versions[selected] if 0 <= selected < len(versions) else versions[0]
                role = chosen.get("role") or chosen.get("type") or chosen.get("sender")
                if isinstance(chosen.get("content"), list):
                    content = _extract_message_text(chosen.get("content"))
                elif isinstance(chosen.get("steps"), list):
                    step_parts = []
                    for step in chosen.get("steps") or []:
                        if not isinstance(step, dict):
                            continue
                        step_content = step.get("content")
                        text = _extract_message_text(step_content)
                        if text:
                            step_parts.append(text)
                    content = "\n".join(step_parts).strip()
                else:
                    content = chosen.get("content") or chosen.get("text") or chosen.get("message") or chosen.get("msg")
        if not content:
            continue
        content = _extract_message_text(content) or str(content).strip()
        if not content:
            continue
        role = str(role).lower()
        if role in ("assistant", "ai", "bot", "张致悦", "zhiyue"):
            norm_role = "assistant"
        elif role in ("user", "me", "self", "我"):
            norm_role = "user"
        else:
            norm_role = "user" if item.get("is_self") else "assistant"
        result.append({"role": norm_role, "content": str(content).strip()})
    return result


def extract_profile_from_messages(messages):
    profile = load_persona_profile()
    phrase_counter = Counter()
    phrase_candidates = [
        "哈哈哈", "好好好", "对对对", "我滴妈", "好家伙", "烦死了",
        "没事儿", "你小子", "也行", "那好吧", "真是的", "啧",
        "晚安啦", "咋样", "得注意身体",
    ]

    user_count = 0
    assistant_count = 0
    for msg in messages:
        content = msg.get("content", "")
        if not content:
            continue

        if msg.get("role") == "assistant":
            assistant_count += 1
            for phrase in phrase_candidates:
                if phrase in content:
                    phrase_counter[phrase] += content.count(phrase)
            for memo in re.findall(r'[((]\s*想起了[::]\s*([^))]+)[))]', content):
                _append_unique(profile["shared_history"], memo, limit=40)
            continue

        user_count += 1
        name_match = re.search(r'(?:我叫|我的名字是|名字是)\s*([\u4e00-\u9fa5A-Za-z0-9_]{1,12})', content)
        if name_match:
            profile["user_name"] = clean_person_name(name_match.group(1))
            _append_unique(profile["user_facts"], f"对方名字是{profile['user_name']}", limit=40)

        if "夜猫子" in content or "熬夜" in content:
            _append_unique(profile["user_facts"], "对方经常熬夜/自称夜猫子", limit=40)
        if "不是程序员" in content or "我不是程序员" in content:
            _append_unique(profile["user_facts"], "对方不是程序员", limit=40)
            profile["shared_history"] = [
                item for item in profile["shared_history"]
                if "程序员" not in item and "编程" not in item
            ]
        if "伤心" in content:
            _append_unique(profile["user_boundaries"], "对方会在被忘记或被误认时伤心", limit=30)
        if "喜欢" in content:
            _append_unique(profile["user_preferences"], content[:60], limit=40)
        if any(w in content for w in ["讨厌", "不喜欢", "别", "不要"]):
            _append_unique(profile["user_boundaries"], content[:60], limit=30)

    if phrase_counter:
        profile["style_phrases"] = [p for p, _ in phrase_counter.most_common(12)]
    if profile.get("user_name"):
        profile["user_name"] = clean_person_name(profile["user_name"])
        normalized_facts = []
        for fact in profile["user_facts"]:
            if "名字是" in fact:
                fact_name = clean_person_name(fact.split("名字是", 1)[-1])
                if fact_name != profile["user_name"]:
                    continue
                fact = f"对方名字是{profile['user_name']}"
            if fact not in normalized_facts:
                normalized_facts.append(fact)
        profile["user_facts"] = normalized_facts
        profile["shared_history"] = [
            item for item in profile["shared_history"]
            if not (
                ("名字是" in item and clean_person_name(item.split("名字是", 1)[-1]) != profile["user_name"])
                or "程序员" in item
                or "编程" in item
            )
        ]
    return profile, {"user_messages": user_count, "assistant_messages": assistant_count}


def import_chat_history_file(path):
    path_obj = Path(path)
    if not path_obj.exists():
        raise FileNotFoundError(str(path_obj))

    text = path_obj.read_text(encoding="utf-8-sig", errors="ignore")
    if path_obj.suffix.lower() in (".json", ".jsonl"):
        if path_obj.suffix.lower() == ".jsonl":
            raw = [json.loads(line) for line in text.splitlines() if line.strip()]
        else:
            raw = json.loads(text)
    else:
        raw = []
        for line in text.splitlines():
            line = line.strip()
            if not line:
                continue
            m = re.match(r'^(我|用户|张致悦|她|AI|assistant|user)[::]\s*(.+)$', line, flags=re.I)
            if m:
                role = "user" if m.group(1) in ("我", "用户", "user") else "assistant"
                raw.append({"role": role, "content": m.group(2)})

    messages = normalize_chat_messages(raw)
    profile, stats = extract_profile_from_messages(messages)
    imported = str(path_obj.resolve())
    if imported not in profile["imported_files"]:
        profile["imported_files"].append(imported)
    save_persona_profile(profile)
    return {
        "file": imported,
        "messages": len(messages),
        **stats,
        "profile": profile,
    }

# ============ 记忆系统(增强版 - 分层记忆) ============
class MemorySystem:
    """分层记忆:fact / preference / boundary / experience"""

    MEM_TYPES = {
        'fact': '事实',
        'preference': '偏好',
        'boundary': '底线',
        'experience': '共同经历',
    }
    TYPE_ALIASES = {
        'school': 'fact',
        'location': 'fact',
        'work': 'fact',
    }
    LOW_VALUE_MEMORY_KEYS = {
        "你在干嘛",
        "在干嘛",
        "现在在干嘛",
        "我在干嘛",
        "你在吗",
        "在吗",
        "Conversation info",
        "untrusted metadata",
        "metadata",
        "prompt",
        "database",
        "system",
        "assistant",
        "openai",
        "lm studio",
    }

    def __init__(self):
        self.conn = sqlite3.connect(str(MEMORY_DB), check_same_thread=False)

    def _now(self):
        return now_iso_local()

    def _is_noise_memory(self, content, category='general', mem_type='fact', source='chat', importance=1, confidence=1):
        text = (content or "").strip()
        if not text:
            return True
        normalized = normalize_text_key(text)
        low_value_keys = {normalize_text_key(item) for item in self.LOW_VALUE_MEMORY_KEYS}
        if normalized in low_value_keys:
            return True
        lower = text.lower()
        if any(key in lower for key in ("conversation info", "untrusted metadata", "metadata", "prompt", "database", "system", "assistant", "openai", "lm studio")):
            return True
        blocked_sources = {
            "monitor",
            "self_monitor",
            "eval",
            "test",
            "stress",
            "sandbox",
            "proposal",
            "runtime_policy",
            "technical_review",
            "tooling",
        }
        normalized_source = (source or "").strip().lower()
        if normalized_source in blocked_sources:
            return True
        if mem_type == 'experience' and source == 'chat' and importance <= 2 and len(text) <= 10:
            return True
        if source == 'chat' and category == 'general' and mem_type == 'fact' and importance <= 1 and confidence <= 1.0 and len(text) <= 4:
            return True
        return False

    def add_memory(self, content, category='general', importance=1, mem_type='fact', source='chat', confidence=1.0, status='active'):
        """添加记忆,支持指定类型"""
        content = (content or "").strip()
        category = (category or "general").strip() or "general"
        mem_type = self.TYPE_ALIASES.get(mem_type, mem_type)
        if mem_type not in self.MEM_TYPES:
            mem_type = 'fact'
        if not content:
            return None
        if self._is_noise_memory(content, category=category, mem_type=mem_type, source=source, importance=importance, confidence=confidence):
            return None

        # Semantic dedup check (v2 multi-signal optimization)
        try:
            import zhiyue_memory_v2 as _mv2_conn
            _mem_layer = None
            if "_layers" in globals() and hasattr(_layers, "memory"):
                _mem_layer = _layers.memory._memory_layer
            if _mem_layer:
                dedup_result = _mv2_conn.check_memory_before_add(
                    content, category, importance, mem_type, source, confidence, status,
                    _mem_layer
                )
                if dedup_result.get("duplicate"):
                    return None
                if dedup_result.get("conflicts"):
                    for conflict in dedup_result.get("conflicts") or []:
                        print(f"[MEM-CONFLICT] New '{content[:40]}' may conflict with [{conflict.get('id')}]: {conflict.get('content', '')[:60]}")
        except (KeyError | ValueError | ImportError) as e:
            pass

        key = normalize_text_key(content)
        existing = None
        cur = self.conn.execute(
            """SELECT id, content, category, importance, summary, recall_count, mem_type, source, status, confidence, last_verified, verified_count, scope, allow_chat_inject, expires_at
               FROM memories
               WHERE mem_type=? AND category=?
               ORDER BY id DESC LIMIT 160""",
            (mem_type, category),
        )
        for row in cur.fetchall():
            if normalize_text_key(row[1]) == key:
                existing = row
                break

        now = self._now()
        state_meta = infer_chat_state_meta(source=source, category=category, mem_type=mem_type)
        if existing:
            old_importance = int(existing[3] or 1)
            new_importance = min(5, max(old_importance, int(importance or 1)) + 1)
            summary = (existing[4] or content[:120]).strip()[:120]
            merged_confidence = min(5.0, max(float(existing[9] or 1.0), float(confidence or 1.0)) + (0.2 if source and source != 'chat' else 0.0))
            merged_source = source if source and source != 'chat' else (existing[7] or source or 'chat')
            verified_count = int(existing[11] or 0) + (1 if source and source != 'chat' else 0)
            self.conn.execute(
                """UPDATE memories
                   SET importance=?, summary=?, last_recall=?, recall_count=recall_count+1,
                       source=?, status=?, confidence=?, last_verified=?, verified_count=?, scope=?, allow_chat_inject=?, expires_at=?
                   WHERE id=?""",
                (
                    new_importance,
                    summary,
                    now,
                    merged_source,
                    status or existing[8] or 'active',
                    merged_confidence,
                    now if source and source != 'chat' else (existing[10] or None),
                    verified_count,
                    state_meta["scope"],
                    state_meta["allow_chat_inject"],
                    state_meta["expires_at"],
                    existing[0],
                ),
            )
            self.conn.commit()
            return existing[0]

        last_verified = now if source and source != 'chat' else None
        verified_count = 1 if source and source != 'chat' else 0
        self.conn.execute(
            "INSERT INTO memories (content,category,importance,summary,created_at,last_recall,mem_type,source,status,confidence,last_verified,verified_count,scope,allow_chat_inject,expires_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (
                content[:240], category, importance, content[:120], now, now, mem_type,
                source or 'chat', status or 'active', float(confidence or 1.0),
                last_verified, verified_count, state_meta["scope"], state_meta["allow_chat_inject"], state_meta["expires_at"],
            )
        )
        self.conn.commit()
        return self.conn.execute("SELECT last_insert_rowid()").fetchone()[0]

    def recall(self, query, limit=5):
        return [item["content"] for item in self.get_relevant_memories(query, limit=limit)]

    def recall_by_type(self, mem_type, limit=3):
        """按类型召回记忆"""
        cur = self.conn.execute(
            "SELECT content, summary FROM memories WHERE mem_type=? AND status='active' ORDER BY importance DESC, recall_count DESC, last_recall DESC LIMIT ?",
            (mem_type, limit)
        )
        return [row[1] or row[0] for row in cur.fetchall()]

    def mark_recalled(self, content):
        self.conn.execute(
            "UPDATE memories SET last_recall=?,recall_count=recall_count+1 WHERE content LIKE ?",
            (self._now(), f"%{content[:20]}%")
        )
        self.conn.commit()

    def get_important(self, limit=3):
        cur = self.conn.execute(
            "SELECT content, summary FROM memories WHERE importance>=3 AND status='active' ORDER BY recall_count DESC, last_recall DESC LIMIT ?",
            (limit,)
        )
        return [row[1] or row[0] for row in cur.fetchall()]

    def get_recent(self, limit=5):
        cur = self.conn.execute(
            "SELECT content, summary FROM memories WHERE importance>=2 AND status='active' ORDER BY last_recall DESC, created_at DESC LIMIT ?",
            (limit,)
        )
        return [row[1] or row[0] for row in cur.fetchall()]

    def get_relevant_memories(self, query, limit=5, mem_types=None):
        retrieval_layer = getattr(self, "retrieval_layer", None)
        if retrieval_layer:
            try:
                enhanced = retrieval_layer.search(query, limit=limit, mem_types=mem_types)
                if enhanced is not None:
                    return enhanced
            except Exception as err:
                log_runtime_exception("memory_search_enhancer", err)

        query_terms = extract_query_terms(query, limit=10)
        normalized_query = normalize_text_key(query)
        mem_type_filter = set(mem_types or []) or None
        rows = self.conn.execute(
             """SELECT id, content, category, importance, summary, created_at, last_recall, recall_count, mem_type, source, status, confidence, last_verified, verified_count, scope, allow_chat_inject, expires_at
                FROM memories
                WHERE status='active'
               ORDER BY importance DESC, recall_count DESC, last_recall DESC, id DESC
               LIMIT 240"""
        ).fetchall()

        scored = []
        now = now_local()
        for row in rows:
            mem_type = row[8]
            if mem_type_filter and mem_type not in mem_type_filter:
                continue

            text = row[4] or row[1] or ""
            score = score_text_overlap(text, query_terms)
            if normalized_query and normalized_query in normalize_text_key(text):
                score += 1.5
            if query_terms and score <= 0:
                continue

            importance = int(row[3] or 1)
            recall_count = int(row[7] or 0)
            confidence = float(row[11] or 1.0)
            source = row[9] or "chat"
            verified_count = int(row[13] or 0)
            recency_bonus = 0.0
            for value in (row[6], row[5]):
                if not value:
                    continue
                try:
                    dt = parse_datetime_local(value)
                except Exception:
                    continue
                age_days = max(0.0, (now - dt).total_seconds() / 86400)
                recency_bonus = max(recency_bonus, max(0.0, 1.5 - age_days * 0.12))

            confidence_bonus = min(1.4, max(0.0, confidence) * 0.28)
            verified_bonus = min(1.0, verified_count * 0.12)
            source_bonus = 0.35 if source != "chat" else 0.0
            type_bonus = 0.25 if mem_type in {"fact", "preference", "boundary", "experience"} else 0.0
            final_score = score * 2.0 + importance * 0.7 + min(recall_count, 6) * 0.15 + recency_bonus + confidence_bonus + verified_bonus + source_bonus + type_bonus
            if not query_terms:
                final_score = importance * 0.5 + min(recall_count, 6) * 0.12 + recency_bonus + confidence_bonus + verified_bonus + source_bonus + type_bonus
            if final_score <= 0:
                continue

            scored.append((final_score, row))

        scored.sort(key=lambda item: (item[0], item[1][3], item[1][7], item[1][0]), reverse=True)
        seen_keys = set()
        result = []
        for final_score, row in scored:
            text = (row[4] or row[1] or "").strip()
            key = normalize_text_key(text)
            if not text or key in seen_keys:
                continue
            seen_keys.add(key)
            result.append({
                "id": row[0],
                "content": text,
                "summary": row[4] or "",
                "category": row[2],
                "importance": row[3],
                "created_at": row[5],
                "last_recall": row[6],
                "recall_count": row[7],
                "mem_type": row[8],
                "source": row[9],
                "status": row[10],
                "confidence": row[11],
                "last_verified": row[12],
                "verified_count": row[13],
                "scope": row[14] if len(row) > 14 else "chat",
                "allow_chat_inject": int(row[15]) if len(row) > 15 and row[15] is not None else 1,
                "expires_at": row[16] if len(row) > 16 else None,
                "type_label": self.MEM_TYPES.get(row[8], row[8]),
                "score": round(final_score, 3),
                "matched_terms": query_terms[:8],
                "hit_reason": [
                    f"type:{row[8] or 'fact'}",
                    f"importance:{importance}",
                    "source:" + source,
                ] + (["verified"] if verified_count else []) + (["recent"] if recency_bonus > 0 else []),
                "retrieval_backend": "local_memory_fallback",
            })
            if len(result) >= limit:
                break
        return result

    def compact_duplicates(self, limit=240):
        rows = self.conn.execute(
            """SELECT id, content, category, importance, summary, created_at, last_recall, recall_count, mem_type, source, status, confidence, last_verified, verified_count
               FROM memories
               WHERE status='active'
               ORDER BY importance DESC, recall_count DESC, last_recall DESC, id DESC
               LIMIT ?""",
            (limit,),
        ).fetchall()
        buckets = {}
        for row in rows:
            key = (row[8], row[2], normalize_text_key(row[1]))
            if not key[2]:
                continue
            buckets.setdefault(key, []).append(row)

        removed = 0
        now = self._now()
        for bucket in buckets.values():
            if len(bucket) < 2:
                continue
            bucket.sort(key=lambda row: (int(row[3] or 1), int(row[7] or 0), row[6] or row[5] or "", row[0]), reverse=True)
            keep = bucket[0]
            dup_ids = [row[0] for row in bucket[1:]]
            if not dup_ids:
                continue
            merged_importance = min(5, max(int(row[3] or 1) for row in bucket) + min(len(bucket) - 1, 2))
            merged_recall = sum(int(row[7] or 0) for row in bucket)
            merged_summary = (keep[4] or keep[1] or "")[:120]
            merged_confidence = min(5.0, max(float(row[11] or 1.0) for row in bucket) + min(len(bucket) - 1, 1) * 0.2)
            merged_verified = sum(int(row[13] or 0) for row in bucket)
            self.conn.execute(
                "UPDATE memories SET importance=?, summary=?, recall_count=?, last_recall=?, confidence=?, verified_count=? WHERE id=?",
                (merged_importance, merged_summary, merged_recall, now, merged_confidence, merged_verified, keep[0]),
            )
            self.conn.executemany("DELETE FROM memories WHERE id=?", [(dup_id,) for dup_id in dup_ids])
            removed += len(dup_ids)

        if removed:
            self.conn.commit()
        return removed

    def archive_low_value_memories(self, limit=240):
        rows = self.conn.execute(
            """SELECT id, content, category, importance, summary, created_at, last_recall, recall_count, mem_type, source, status, confidence
               FROM memories
               WHERE status='active'
               ORDER BY importance DESC, recall_count DESC, last_recall DESC, id DESC
               LIMIT ?""",
            (limit,),
        ).fetchall()
        archived = 0
        now = self._now()
        for row in rows:
            content = row[1] or ""
            category = row[2] or "general"
            importance = int(row[3] or 1)
            recall_count = int(row[7] or 0)
            mem_type = row[8] or "fact"
            source = row[9] or "chat"
            confidence = float(row[11] or 1.0)
            normalized = normalize_text_key(content)
            exact_noise = normalized in {normalize_text_key(item) for item in self.LOW_VALUE_MEMORY_KEYS}
            soft_noise = self._is_noise_memory(content, category=category, mem_type=mem_type, source=source, importance=importance, confidence=confidence)
            if not exact_noise and not soft_noise:
                continue
            if not exact_noise and (source != "chat" or importance > 2 or recall_count > 1):
                continue
            self.conn.execute(
                "UPDATE memories SET status='archived', last_recall=? WHERE id=?",
                (now, row[0]),
            )
            archived += 1
        if archived:
            self.conn.commit()
        return archived

    def get_core_memory_blocks(self, profile=None):
        profile = profile or load_persona_profile()
        blocks = {
            "user_name": clean_person_name(profile.get("user_name")),
            "facts": [],
            "preferences": [],
            "boundaries": [],
            "shared_history": [],
            "style_phrases": [],
            "imported_files": [],
            "updated_at": profile.get("updated_at"),
        }
        for key, target, limit in (
            ("user_facts", "facts", 6),
            ("user_preferences", "preferences", 6),
            ("user_boundaries", "boundaries", 6),
            ("shared_history", "shared_history", 6),
            ("style_phrases", "style_phrases", 8),
            ("imported_files", "imported_files", 5),
        ):
            items = [item for item in (profile.get(key) or []) if item]
            deduped = []
            seen = set()
            for item in items:
                norm = normalize_text_key(item)
                if not norm or norm in seen:
                    continue
                seen.add(norm)
                deduped.append(item)
            blocks[target] = deduped[-limit:]
        return blocks

    def get_core_memory_stats(self):
        rows = self.conn.execute(
            """SELECT mem_type, status, COUNT(*), SUM(recall_count), AVG(confidence)
               FROM memories
               GROUP BY mem_type, status"""
        ).fetchall()
        stats = {"total": 0, "active": 0, "archived": 0, "by_type": {}}
        for mem_type, status, count, recall_sum, avg_conf in rows:
            count = int(count or 0)
            stats["total"] += count
            if status == "active":
                stats["active"] += count
            if status == "archived":
                stats["archived"] += count
            stats["by_type"].setdefault(mem_type, {})
            stats["by_type"][mem_type][status] = {
                "count": count,
                "recall_sum": int(recall_sum or 0),
                "avg_confidence": round(float(avg_conf or 0.0), 3),
            }
        return stats

    def get_core_memory_inject(self):
        blocks = self.get_core_memory_blocks()
        lines = ["\n=== 核心记忆块 ==="]
        if blocks.get("user_name"):
            lines.append(f"- 对方名字:{blocks['user_name']}")
        if blocks.get("facts"):
            lines.append("- 事实:" + ";".join(blocks["facts"]))
        if blocks.get("preferences"):
            lines.append("- 偏好:" + ";".join(blocks["preferences"]))
        if blocks.get("boundaries"):
            lines.append("- 边界:" + ";".join(blocks["boundaries"]))
        if blocks.get("shared_history"):
            lines.append("- 共同经历:" + ";".join(blocks["shared_history"]))
        if blocks.get("style_phrases"):
            lines.append("- 口头禅:" + "、".join(blocks["style_phrases"]))
        if blocks.get("imported_files"):
            lines.append("- 资料来源:" + "、".join(blocks["imported_files"]))
        if len(lines) == 1:
            return ""
        lines.append("注意:核心块优先级最高,用户最新纠正永远优先于旧记录。")
        return "\n".join(lines)

    def get_layered_memories(self, max_per_type=2):
        """
        获取分层记忆,每种类型最多max_per_type条
        返回格式:{type_name: [content_list]}
        """
        result = {}
        for mtype, label in self.MEM_TYPES.items():
            items = self.recall_by_type(mtype, limit=max_per_type)
            if items:
                result[label] = items
        return result


from zhiyue_intimacy import IntimacySystem

class EmotionSystem:
    def __init__(self):
        self.path = INTIMACY_FILE
        self.emotion = "neutral"
        self.happiness = 50
        self.activity = 50
        self.history = []
        self.jealousy_level = 0.0
        self.cold_war_turns = 0
        self.valence = 0.0
        self.arousal = 0.0
        self.last_update = None
        self._load_state()

    def _load_state(self):
        if os.path.exists(self.path):
            try:
                with open(self.path, 'r', encoding='utf-8') as f:
                    d = json.load(f)
                    self.emotion = d.get("emotion", "neutral")
                    self.happiness = d.get("happiness", 50)
                    self.activity = d.get("activity", 50)
                    self.history = d.get("emotion_history", [])
                    self.jealousy_level = d.get("jealousy_level", 0.0)
                    self.cold_war_turns = d.get("cold_war_turns", 0)
                    self.valence = float(d.get("emotion_valence", (self.happiness - 50) / 50.0))
                    self.arousal = float(d.get("emotion_arousal", (self.activity - 50) / 50.0))
                    self.last_update = d.get("emotion_last_update")
                    return
            except:
                pass
        self.emotion = "neutral"
        self.happiness = 50
        self.activity = 50
        self.history = []
        self.jealousy_level = 0.0
        self.cold_war_turns = 0
        self.valence = 0.0
        self.arousal = 0.0
        self.last_update = None

    def _sync_vector_from_scalars(self):
        self.valence = max(-1.0, min(1.0, (float(self.happiness) - 50.0) / 50.0))
        self.arousal = max(-1.0, min(1.0, (float(self.activity) - 50.0) / 50.0))

    def _apply_temporal_decay(self):
        now = now_local()
        last = None
        if self.last_update:
            try:
                last = parse_datetime_local(self.last_update)
            except Exception:
                last = None
        if last:
            elapsed_minutes = max(0.0, (now - last).total_seconds() / 60.0)
            if elapsed_minutes > 0:
                decay = pow(0.988, min(elapsed_minutes, 360))
                self.happiness = int(round(50 + (self.happiness - 50) * decay))
                self.activity = int(round(50 + (self.activity - 50) * decay))
                self.jealousy_level = max(0.0, self.jealousy_level * decay)
        self.last_update = now.isoformat()
        self._sync_vector_from_scalars()

    def save(self):
        try:
            with open(self.path, 'r', encoding='utf-8') as f:
                d = json.load(f)
        except:
            d = {}
        d["emotion"] = self.emotion
        d["happiness"] = self.happiness
        d["activity"] = self.activity
        d["emotion_history"] = self.history
        d["jealousy_level"] = self.jealousy_level
        d["cold_war_turns"] = self.cold_war_turns
        d["emotion_valence"] = self.valence
        d["emotion_arousal"] = self.arousal
        d["emotion_last_update"] = self.last_update
        with open(self.path, 'w', encoding='utf-8') as f:
            json.dump(d, f, ensure_ascii=False)
        if 'intimacy' in globals():
            intimacy.data["emotion"] = self.emotion
            intimacy.data["happiness"] = self.happiness
            intimacy.data["activity"] = self.activity
            intimacy.data["emotion_history"] = self.history
            intimacy.data["jealousy_level"] = self.jealousy_level
            intimacy.data["cold_war_turns"] = self.cold_war_turns
            intimacy.data["emotion_valence"] = self.valence
            intimacy.data["emotion_arousal"] = self.arousal
            intimacy.data["emotion_last_update"] = self.last_update

    def update(self, user_msg, ai_reply):
        prev = self.emotion
        ul = user_msg.lower()
        self._apply_temporal_decay()

        jealous_triggers = ["其他女生","其他男生","追","相亲","女朋友","男朋友",
                             "喜欢你","有人追","表白","聊sao","泡妞"]
        if any(t in ul for t in jealous_triggers):
            intimacy_level = intimacy.data["level"]
            sincerity = min(10, intimacy_level + 1)
            prob = min(0.95, self.jealousy_level + max(0.1, 1 - sincerity/10) * 0.3)
            if random.random() < prob:
                self.jealousy_level = min(1.0, self.jealousy_level + 0.15)
                if self.jealousy_level >= 0.5:
                    self.cold_war_turns = 3
                    self.emotion = "jealous"

        if self.cold_war_turns > 0:
            self.cold_war_turns -= 1
            if self.cold_war_turns == 0 and self.emotion == "jealous":
                self.emotion = "neutral"

        happy_triggers = ["想你","喜欢","开心","哈哈","好呀","棒","爱你","嘿嘿","好开心","太好了"]
        if any(t in ul for t in happy_triggers):
            self.emotion = "happy"
            self.happiness = min(100, self.happiness + 5)
            self.jealousy_level = max(0, self.jealousy_level - 0.2)
            intimacy.update_mood(5)

        angry_triggers = ["烦","讨厌","滚","吵","无聊","烦死"]
        if any(t in ul for t in angry_triggers):
            self.emotion = "angry"
            self.happiness = max(0, self.happiness - 5)
            intimacy.update_mood(-5)

        shy_triggers = ["脸红","不好意思","羞","害羞","怦怦"]
        if any(t in ul for t in shy_triggers):
            self.emotion = "shy"

        carry = intimacy.data.get("emotion_carry", "neutral")
        carry_turns = int(intimacy.data.get("emotion_carry_turns", 0) or 0)
        if carry_turns > 0 and self.emotion == "neutral":
            self.emotion = carry
            intimacy.data["emotion_carry_turns"] = carry_turns - 1
            intimacy.save()
        elif self.emotion in ("happy", "angry", "shy", "jealous"):
            intimacy.data["emotion_carry"] = self.emotion
            intimacy.data["emotion_carry_turns"] = 2
            intimacy.save()

        hour = now_local().hour
        if self.emotion == "neutral":
            if 1 <= hour < 6:
                self.activity = 20
            elif 21 <= hour < 24:
                self.activity = 40

        self._sync_vector_from_scalars()
        self.last_update = self._now()

        if self.emotion != prev:
            self.history.append({
                "emotion": self.emotion,
                "valence": round(self.valence, 3),
                "arousal": round(self.arousal, 3),
                "time": self._now(),
            })
            if len(self.history) > 30:
                self.history = self.history[-30:]

        self.save()
        return self.emotion

    def _now(self):
        return now_iso_local()

    def get_emotion_desc(self):
        desc = {
            "happy": f"开心({self.happiness}%)",
            "angry": f"有点生气({100-self.happiness}%)",
            "shy": "害羞",
            "jealous": f"吃醋中({int(self.jealousy_level*100)}%)",
            "neutral": "平静",
        }
        return desc.get(self.emotion, "平静")

    def get_emotion_vector_desc(self):
        return f"效价{self.valence:+.2f} / 唤醒{self.arousal:+.2f}"

    def get_cold_war_msg(self):
        # 不返回罐头回复，交给 LM 自由生成
        return ""


# ============ 成长库 ============
class GrowthLibrary:
    def __init__(self):
        self.conn = sqlite3.connect(str(GROWTH_DB), check_same_thread=False)
        self.REJECT = ["身份证","银行卡","密码","社保","公积金","电话号码","地址","真实姓名"]
        self.BOUNDARY = ["做我女朋友","你是我女朋友","当我女朋友","嫁给我","跟我在一起"]

    def evaluate(self, user_msg, reply):
        score = 5.0
        reasons = []

        if len(reply) > 100:
            score -= 2
            reasons.append("太长")
        if len(reply) < 3:
            score -= 1
            reasons.append("太短")

        bad_chars = sum(1 for c in reply if ord(c) > 0x30000 or ord(c) < 32 and c not in " \n")
        if bad_chars > 0:
            score -= 3
            reasons.append("乱码")

        ai_words = ["作为AI", "语言模型", "artificial", "我是AI", "I am an AI"]
        if any(w in reply for w in ai_words):
            score -= 5
            reasons.append("身份暴露")

        if len(set(reply)) < len(reply) * 0.3:
            score -= 2
            reasons.append("重复")

        english = re.findall(r'[a-zA-Z]{4,}', reply)
        simple = {"ok","bye","hi","yes","no","nice","wow","lol","cool","ah","oh",
                   "omg","idk","tv","vip","qq","brb","ngl","rn"}
        bad_eng = [w for w in english if w.lower() not in simple]
        if len(bad_eng) > 2:
            score -= len(bad_eng) * 0.5
            reasons.append("英文太多")

        score = max(0, min(10, score))
        if score >= 3:
            self._save(user_msg, reply, score)
        return score, reasons

    def _save(self, user_msg, reply, score):
        now = now_iso_local()
        cols = {row[1] for row in self.conn.execute("PRAGMA table_info(good_replies)").fetchall()}
        if "state_context" not in cols:
            try:
                self.conn.execute("ALTER TABLE good_replies ADD COLUMN state_context TEXT DEFAULT ''")
                self.conn.commit()
                cols = {row[1] for row in self.conn.execute("PRAGMA table_info(good_replies)").fetchall()}
            except Exception:
                cols = {row[1] for row in self.conn.execute("PRAGMA table_info(good_replies)").fetchall()}
        state_context = current_state_context_summary(user_msg)
        if "user_input" in cols:
            if "state_context" in cols:
                self.conn.execute(
                    "INSERT INTO good_replies (user_input,user_msg,ai_reply,score,source,created_at,state_context) VALUES (?,?,?,?,?,?,?)",
                    (user_msg[:200], user_msg[:200], reply[:300], score, "ai_eval", now, state_context[:160])
                )
            else:
                self.conn.execute(
                    "INSERT INTO good_replies (user_input,user_msg,ai_reply,score,source,created_at) VALUES (?,?,?,?,?,?)",
                    (user_msg[:200], user_msg[:200], reply[:300], score, "ai_eval", now)
                )
        else:
            if "state_context" in cols:
                self.conn.execute(
                    "INSERT INTO good_replies (user_msg,ai_reply,score,source,created_at,state_context) VALUES (?,?,?,?,?,?)",
                    (user_msg[:200], reply[:300], score, "ai_eval", now, state_context[:160])
                )
            else:
                self.conn.execute(
                    "INSERT INTO good_replies (user_msg,ai_reply,score,source,created_at) VALUES (?,?,?,?,?)",
                    (user_msg[:200], reply[:300], score, "ai_eval", now)
                )
        self.conn.commit()

    def check_reject(self, user_msg):
        msg = user_msg.lower()
        for kw in self.REJECT:
            if kw in msg:
                return True
        return False

    def check_boundary(self, user_msg):
        msg = user_msg
        count = sum(1 for kw in self.BOUNDARY if kw in msg)
        return count

    def get_remedy(self, score, reasons):
        # 不追加任何罐头补救文字，交给 LM 自由生成
        return None

    def add_learning_note(self, note_type, content, evidence='', confidence=1):
        content = (content or "").strip()
        if not content:
            return
        state_meta = infer_chat_state_meta(source="learning_note", note_type=note_type)
        existing = self.conn.execute(
            "SELECT id, confidence FROM learning_notes WHERE note_type=? AND content=? AND active=1",
            (note_type, content)
        ).fetchone()
        now = now_iso_local()
        if existing:
            self.conn.execute(
                "UPDATE learning_notes SET confidence=?, evidence=?, created_at=?, scope=?, allow_chat_inject=?, expires_at=? WHERE id=?",
                (min(3, existing[1] + 1), evidence[:200], now, state_meta["scope"], state_meta["allow_chat_inject"], state_meta["expires_at"], existing[0])
            )
        else:
            self.conn.execute(
                "INSERT INTO learning_notes (note_type,content,evidence,confidence,created_at,scope,allow_chat_inject,expires_at) VALUES (?,?,?,?,?,?,?,?)",
                (note_type, content, evidence[:200], confidence, now, state_meta["scope"], state_meta["allow_chat_inject"], state_meta["expires_at"])
            )
        self.conn.commit()

    def deactivate_learning_notes(self, pattern):
        like = f"%{pattern}%"
        self.conn.execute(
            "UPDATE learning_notes SET active=0 WHERE content LIKE ? OR evidence LIKE ?",
            (like, like)
        )
        self.conn.commit()

    def get_learning_notes(self, limit=8, query=None):
        cur = self.conn.execute(
            "SELECT id, note_type, content, evidence, confidence, created_at, scope, allow_chat_inject, expires_at FROM learning_notes WHERE active=1 ORDER BY confidence DESC, id DESC LIMIT 120"
        )
        rows = cur.fetchall()
        query_terms = extract_query_terms(query, limit=8)
        normalized_query = normalize_text_key(query)
        scored = []
        now = now_local()
        for note_id, note_type, content, evidence, confidence, created_at, scope, allow_chat_inject, expires_at in rows:
            text = content or ""
            score = float(confidence or 1)
            score += score_text_overlap(text, query_terms) * 1.4
            score += score_text_overlap(evidence or "", query_terms) * 0.5
            if normalized_query and normalized_query in normalize_text_key(text):
                score += 1.2
            try:
                created_dt = parse_datetime_local(created_at)
                age_days = max(0.0, (now - created_dt).total_seconds() / 86400)
                score += max(0.0, 1.0 - age_days * 0.08)
            except (Exception,) as err:
                log_runtime_exception("rule_hint.sleep_followup", err)
            scored.append((score, note_id, note_type, content, confidence, created_at, scope, allow_chat_inject, expires_at))

        scored.sort(key=lambda item: (item[0], item[4], item[1]), reverse=True)
        seen = set()
        result = []
        for _, _, note_type, content, confidence, created_at, scope, allow_chat_inject, expires_at in scored:
            key = normalize_text_key(content)
            if not content or key in seen:
                continue
            seen.add(key)
            result.append((note_type, content, confidence, created_at, scope, allow_chat_inject, expires_at))
            if len(result) >= limit:
                break
        return result

    def get_relevant_good_replies(self, query, limit=3):
        cols = {row[1] for row in self.conn.execute("PRAGMA table_info(good_replies)").fetchall()}
        has_state = "state_context" in cols
        select_sql = "SELECT user_msg, ai_reply, score, created_at, state_context FROM good_replies ORDER BY score DESC, id DESC LIMIT 160" if has_state else "SELECT user_msg, ai_reply, score, created_at FROM good_replies ORDER BY score DESC, id DESC LIMIT 160"
        cur = self.conn.execute(select_sql)
        rows = cur.fetchall()
        query_terms = extract_query_terms(query, limit=8)
        normalized_query = normalize_text_key(query)
        current_state = current_state_context_summary(query)
        scored = []
        now = now_local()
        for row in rows:
            user_msg, ai_reply, score_value, created_at = row[:4]
            state_context = row[4] if has_state and len(row) > 4 else ""
            if not ai_reply:
                continue
            base_score = float(score_value or 0)
            text_score = score_text_overlap(user_msg or "", query_terms)
            text_score += score_text_overlap(ai_reply or "", query_terms) * 0.35
            if normalized_query and normalized_query in normalize_text_key(user_msg or ""):
                text_score += 1.25
            if query_terms and text_score <= 0:
                continue
            try:
                created_dt = parse_datetime_local(created_at)
                age_days = max(0.0, (now - created_dt).total_seconds() / 86400)
                recency = max(0.0, 1.2 - age_days * 0.08)
            except Exception:
                recency = 0.0
            state_score = score_text_overlap(state_context or "", extract_query_terms(current_state, limit=6)) if state_context else 0.0
            final_score = base_score * 0.8 + text_score * 2.0 + recency + state_score * 0.8
            scored.append((final_score, user_msg or "", ai_reply or "", score_value or 0, created_at or "", state_context or ""))

        scored.sort(key=lambda item: (item[0], item[3], item[4]), reverse=True)
        seen = set()
        result = []
        for _, user_msg, ai_reply, score_value, created_at, state_context in scored:
            key = normalize_text_key(ai_reply)
            if not ai_reply or key in seen:
                continue
            seen.add(key)
            result.append({
                "user_msg": user_msg,
                "ai_reply": ai_reply,
                "score": score_value,
                "created_at": created_at,
                "state_context": state_context,
            })
            if len(result) >= limit:
                break
        return result

    def list_learning_notes(self, limit=50):
        cur = self.conn.execute(
            "SELECT id, note_type, content, evidence, confidence, active, created_at FROM learning_notes ORDER BY id DESC LIMIT ?",
            (limit,)
        )
        keys = ["id", "note_type", "content", "evidence", "confidence", "active", "created_at"]
        return [dict(zip(keys, row)) for row in cur.fetchall()]

    def deactivate_learning_note_id(self, note_id):
        self.conn.execute("UPDATE learning_notes SET active=0 WHERE id=?", (note_id,))
        self.conn.commit()

    def decay_learning_notes(self, days=3):
        cutoff = now_local().timestamp() - days * 86400
        cur = self.conn.execute(
            "SELECT id, confidence, created_at, note_type FROM learning_notes WHERE active=1"
        )
        changed = 0
        for note_id, confidence, created_at, note_type in cur.fetchall():
            if note_type == "纠错":
                continue
            try:
                ts = parse_datetime_local(created_at).timestamp()
            except Exception:
                continue
            if ts > cutoff:
                continue
            new_conf = int(confidence or 1) - 1
            if new_conf <= 0:
                self.conn.execute("UPDATE learning_notes SET active=0 WHERE id=?", (note_id,))
            else:
                self.conn.execute("UPDATE learning_notes SET confidence=? WHERE id=?", (new_conf, note_id))
            changed += 1
        if changed:
            self.conn.commit()
        return changed


# ============ 导入新增模块 ============
try:
    from zhiyue_cognitive import cognitive
except ImportError:
    cognitive = None
    _dbg.warning("[警告] 认知画像模块未找到(zhiyue_cognitive.py),跳过")

try:
    from zhiyue_conflicts import get_conflicts_for_prompt, get_conflict_emotion
except ImportError:
    get_conflicts_for_prompt = lambda l, m=None: ""
    get_conflict_emotion = lambda l: None
    _dbg.warning("[警告] 内在冲突模块未找到(zhiyue_conflicts.py),跳过")

try:
    from zhiyue_layers import AgentActionApplyError, create_layers
except ImportError:
    AgentActionApplyError = None
    create_layers = None
    _dbg.warning("[警告] 增强层模块未找到(zhiyue_layers.py),跳过")


# ============ 全局实例 ============
memory = MemorySystem()
intimacy = IntimacySystem()
emotion = EmotionSystem()
growth = GrowthLibrary()
layers = None

if create_layers:
    try:
        layers = create_layers(BASE_DIR, MEMORY_DB, GROWTH_DB)
        memory.retrieval_layer = layers.memory
        setattr(layers, "record_runtime_exception", log_runtime_exception)
    except (Exception,) as err:
        layers = None
        _dbg.warning("[警告] 增强层初始化失败,已回退到原始实现: %s", err)

chat_history = []
technical_chat_history = []
reply_signature_seen = set()
input_merge_lock = threading.Lock()
input_merge_batches = {}


# ============ 真实感状态系统 ============
DAILY_EVENTS = {
    "morning": [
        "早上起得有点慢,脑子还没开机",
        "刚洗漱完,准备去上课",
        "早八真的烦死了",
    ],
    "noon": [
        "中午在食堂随便吃了点,没敢碰辣",
        "午饭后有点困,想眯一会儿",
        "今天想吃甜的,馋死了",
    ],
    "afternoon": [
        "下午在图书馆看文献",
        "下午有课,听得我头大",
        "刚从教室出来,腿都坐麻了",
    ],
    "evening": [
        "晚上在宿舍瘫着",
        "晚饭后想出去走走,但又懒",
        "在整理期末论文,烦死了",
    ],
    "late": [
        "又熬夜了,明明说好早点睡",
        "宿舍灯都关了,我还没睡",
        "这个点脑子反而清醒了,真是的",
    ],
}

LIFE_ARC_TEMPLATES = [
    [
        "今天主要在图书馆看文献",
        "明天要整理期末论文",
        "后天想去吃点甜的",
        "周末想补觉",
    ],
    [
        "今天有课,听得有点烦",
        "明天可能去教室自习",
        "后天想出去走走",
        "周末看情况,想放空",
    ],
    [
        "今天在宿舍瘫着恢复",
        "明天要把作业补一下",
        "后天可能和同学吃饭",
        "周末想睡到自然醒",
    ],
    [
        "今天状态一般,有点懒",
        "明天得早起上课",
        "后天想买点甜食",
        "周末想出去透口气",
    ],
]


def get_daypart(now=None):
    now = get_current_local_time(now)
    h = now.hour
    if 5 <= h < 10:
        return "morning"
    if 10 <= h < 14:
        return "noon"
    if 14 <= h < 18:
        return "afternoon"
    if 18 <= h < 23:
        return "evening"
    return "late"


def get_circadian_state(now=None):
    now = get_current_local_time(now)
    daypart = get_daypart(now)
    if daypart == "morning":
        return "早上慢热,话少一点,像刚醒没多久"
    if daypart == "noon":
        return "中午有点犯困,容易想吃甜的"
    if daypart == "afternoon":
        return "下午多半在上课、图书馆或处理论文"
    if daypart == "evening":
        return "晚上更松弛,愿意闲聊,但也容易懒"
    return "深夜容易困但不一定睡,语气更轻、更短"


def get_daily_event(now=None):
    now = get_current_local_time(now)
    today = now.date().isoformat()
    arc = intimacy.data.get("life_arc") or []
    arc_date = intimacy.data.get("life_arc_date")

    if arc_date != today or not arc:
        seed = f"{today}-{intimacy.data.get('total_chats', 0)}"
        rng = random.Random(seed)
        arc = list(rng.choice(LIFE_ARC_TEMPLATES))
        intimacy.data["life_arc"] = arc
        intimacy.data["life_arc_date"] = today

    try:
        first = parse_date_local(intimacy.data.get("life_arc_date") or today)
        idx = min(max((now.date() - first).days, 0), len(arc) - 1)
    except Exception:
        idx = 0

    event = arc[idx] if arc else random.choice(DAILY_EVENTS.get(get_daypart(now), DAILY_EVENTS["evening"]))
    intimacy.data["daily_event_date"] = today
    intimacy.data["daily_event"] = event
    intimacy.save()
    return event


def get_life_arc_inject():
    arc = intimacy.data.get("life_arc") or []
    if not arc:
        get_daily_event()
        arc = intimacy.data.get("life_arc") or []
    if not arc:
        return ""
    labels = ["今天", "明天", "后天", "周末"]
    lines = ["\n=== 生活连续线 ==="]
    for label, item in zip(labels, arc):
        lines.append(f"{label}:{item}")
    lines.append("注意:这些是你的生活背景,不要每次主动汇报,只在合适时自然流露。")
    return "\n".join(lines)


def get_anniversary_inject(now=None):
    now = now or now_local()
    hints = []
    first_chat = _parse_iso_dt(intimacy.data.get("first_chat"))
    if first_chat and first_chat.month == now.month and first_chat.day == now.day:
        hints.append("今天是你们第一次开始聊天的日子,别明说纪念日,语气比平时更软一点。")
    if now.month == 6 and now.day == 14:
        hints.append("今天接近你的生日阴影,不主动说生日,语气更安静一点。")
    if now.hour >= 23 or now.hour < 4:
        if any("熬夜" in item or "睡得晚" in item for item in load_persona_profile().get("user_facts", [])):
            hints.append("深夜时他可能还醒着,别说教,短短陪着就行。")
    if not hints:
        return ""
    return "\n=== 时间暗涌 ===\n" + "\n".join(hints) + "\n注意:不要解释日期含义,只让语气轻微变化。"


def get_recall_hint(user_msg=None, limit=1):
    return memory_injection.get_recall_hint(
        user_msg=user_msg,
        limit=limit,
        extract_query_terms=extract_query_terms,
        recall_life_events=recall_life_events,
        memory=memory,
        clean_prompt_snippet=clean_prompt_snippet,
    )


def get_core_memory_inject():
    return memory_injection.get_core_memory_inject(memory=memory)


def get_persona_profile_inject():
    return memory_injection.get_persona_profile_inject(memory=memory)


def get_learning_notes_inject(user_msg=None):
    return memory_injection.get_learning_notes_inject(
        user_msg=user_msg,
        growth=growth,
        learning_note_allows_chat_inject=_learning_note_allows_chat_inject,
    )


def get_good_replies_inject(user_msg=None):
    return memory_injection.get_good_replies_inject(
        user_msg=user_msg,
        growth=growth,
        clean_prompt_snippet=clean_prompt_snippet,
    )


def get_bad_reply_avoid_inject(user_msg=None):
    state_bucket = current_state_context_summary(user_msg)
    question_type = human_like.classify_question_type(user_msg or "")
    return memory_injection.get_bad_reply_avoid_inject(
        user_msg=user_msg,
        observability=layers.observability if layers and hasattr(layers, "observability") else None,
        clean_prompt_snippet=clean_prompt_snippet,
        state_bucket=state_bucket,
        question_type=question_type,
    )


def get_relevant_memory_inject(user_msg=None):
    return memory_injection.get_relevant_memory_inject(
        user_msg=user_msg,
        memory=memory,
        recall_life_events=recall_life_events,
        clean_prompt_snippet=clean_prompt_snippet,
        memory_allows_chat_inject=_memory_allows_chat_inject,
    )


def get_runtime_policy_inject():
    return memory_injection.get_runtime_policy_inject(layers=layers)


def get_layer_status():
    if not layers:
        return {
            "loaded": False,
            "memory_retrieval": {"active": "local_hybrid"},
            "agent_orchestration": {"engine": "local_state_graph"},
            "observability": {"loaded": False},
            "skills": {"tools": 0, "enabled": 0},
            "voice_desktop": {"desktop_enabled": False},
        }
    return {
        "loaded": True,
        **layers.status(),
    }


def build_diagnostics_summary(*, include_probe: bool = False, probe_message: str = "你好") -> dict:
    layer_status = get_layer_status()
    runtime_status = runtime_health_snapshot()
    monitor_status = self_monitor_snapshot(SELF_MONITOR_STATE_FILE)
    dead_letter_summary = evaluate_weixin_bridge_health()
    diagnostics = {
        "ok": bool(runtime_status.get("backend")) and bool(runtime_status.get("gateway")),
        "generated_at": now_iso_local(),
        "runtime": runtime_status,
        "self_monitor": monitor_status,
        "weixin": {
            "dead_letters": dead_letter_summary,
        },
        "layers": layer_status,
    }
    if layers:
        diagnostics["self_improvement"] = layers.self_improvement.summary(limit=100)
        diagnostics["tooling"] = {
            "usage_summary": layers.skills.usage_summary(limit=100),
            "disk_skills": layers.skills.disk_skill_docs(),
        }
    if include_probe:
        diagnostics["chat_probe"] = build_chat_smoke_result(
            user_msg=(probe_message or "你好").strip() or "你好",
            channel="diagnostics:probe",
            include_reply=False,
        )
        diagnostics["ok"] = diagnostics["ok"] and diagnostics["chat_probe"].get("ok", False)
    return diagnostics


def get_agent_plan(user_msg="", context=None):
    if not layers:
        return {
            "ok": True,
            "mode": "chat",
            "nodes": [],
            "note": "layer registry unavailable",
        }
    return layers.agent.plan(user_msg=user_msg, context=context or {})


def _load_selected_skill_payload(skill_state):
    if not layers or not isinstance(skill_state, dict):
        return {}
    skill_name = str(skill_state.get("selected_skill") or "").strip()
    if not skill_name:
        return {}
    try:
        result = layers.skills.call(skill_name, {})
    except Exception as err:
        log_runtime_exception("selected_skill_payload", err)
        return {"selected_skill": skill_name, "ok": False, "error": str(err)}
    payload = result.get("result") if isinstance(result, dict) else {}
    if not isinstance(payload, dict):
        payload = {"value": payload}
    return {
        "selected_skill": skill_name,
        "ok": bool(result.get("ok")) if isinstance(result, dict) else True,
        "skill_payload": payload,
    }


def build_companion_skill_hints(user_msg):
    if not layers or not hasattr(layers, "agent"):
        return []
    try:
        sense = layers.agent._sense(user_msg or "", {})
        route = layers.agent._route(sense, {"hit_count": 0}, {})
        skill_state = layers.agent._select_skill(user_msg or "", sense, route, {})
        selected = str(skill_state.get("selected_skill") or "").strip()
        if not selected or not selected.startswith("skill."):
            return []
        if selected == "skill.technical_review":
            return []
        loaded = _load_selected_skill_payload(skill_state)
        payload = loaded.get("skill_payload") if isinstance(loaded, dict) else {}
        content = ""
        if isinstance(payload, dict):
            content = str(payload.get("content") or "")
        if not content:
            return []
        lines = [line.strip() for line in content.splitlines() if line.strip()]
        compact = " ".join(lines[:6])
        compact = clean_prompt_snippet(compact, 500)
        if not compact:
            return []
        return [f"companion_skill:{selected} => {compact}"]
    except Exception as err:
        log_runtime_exception("build_companion_skill_hints", err)
        return []


def build_companion_rewrite_hints(user_msg, judge_result=None):
    issues = list((judge_result or {}).get("issues") or [])
    hints = []
    repair_issues = {"template_or_system_leak", "too_structured", "generic_reply", "missing_anchor", "weak_empathy"}
    style_issues = {"too_long", "template_or_system_leak", "too_structured", "list_tone"}
    if any(issue in repair_issues for issue in issues):
        hints.append("companion_rewrite: prioritize relationship repair; acknowledge mismatch briefly and re-answer more naturally.")
    if any(issue in style_issues for issue in issues):
        hints.append("companion_rewrite: prioritize reply style guard; keep it natural, conversational, and non-formulaic.")
    return hints


def strip_prompt_leakage(text, *, technical=False):
    _ = technical
    return text if isinstance(text, str) else ("" if text is None else str(text))


def soften_reply_for_context(user_msg, reply):
    _ = user_msg
    return reply if isinstance(reply, str) else ("" if reply is None else str(reply))


def collapse_reply_segments(text, max_segments=2):
    _ = max_segments
    return text if isinstance(text, str) else ("" if text is None else str(text))


def get_companion_profile_inject():
    if not layers or not hasattr(layers, "companion_profile"):
        return ""
    try:
        layers.companion_profile.sync_from_runtime(
            persona_profile=load_persona_profile(),
            intimacy_data=intimacy.data,
        )
        return layers.companion_profile.build_profile_inject()
    except Exception as err:
        log_runtime_exception("companion_profile_inject", err)
        return ""


def build_companion_consistency_hints(user_msg):
    if not layers or not hasattr(layers, "companion_profile"):
        return []
    try:
        layers.companion_profile.sync_from_runtime(
            persona_profile=load_persona_profile(),
            intimacy_data=intimacy.data,
        )
        recent_msgs = [
            str(item.get("content") or "")
            for item in chat_history[-8:]
            if item.get("role") == "assistant" and str(item.get("content") or "").strip()
        ]
        hints = layers.companion_profile.build_runtime_consistency_hints(
            user_msg or "",
            recent_assistant_messages=recent_msgs,
        )
        return [f"companion_consistency:{item}" for item in hints if str(item).strip()]
    except Exception as err:
        log_runtime_exception("build_companion_consistency_hints", err)
        return []


def apply_companion_consistency(user_msg, reply, *, rule_name=""):
    _ = rule_name
    if reply is None:
        return ""
    text = reply if isinstance(reply, str) else str(reply)
    if not text.strip():
        return text
    if not layers or not hasattr(layers, "companion_profile"):
        return text
    try:
        layers.companion_profile.sync_from_runtime(
            persona_profile=load_persona_profile(),
            intimacy_data=intimacy.data,
        )
        hints = layers.companion_profile.build_runtime_consistency_hints(
            user_msg or "",
            recent_assistant_messages=[str(item.get("content") or "") for item in chat_history[-6:] if item.get("role") == "assistant"],
        )
    except Exception as err:
        log_runtime_exception("apply_companion_consistency", err)
        return text
    if not hints:
        return text
    if any("我在" in hint or "陪" in hint or "接住" in hint for hint in hints):
        return text
    return text
def _agent_retrieve_node(args):
    query = (args or {}).get("user_msg", "")
    limit = int((args or {}).get("limit") or 5)
    memories = memory.get_relevant_memories(query, limit=limit)
    events = recall_life_events(query, limit=limit)
    task_context = {}
    if layers and hasattr(layers, "tasks"):
        try:
            task_context = layers.tasks.search_context(query, limit=limit)
        except Exception as err:
            task_context = {"error": str(err), "matches": []}
    backend = ""
    if memories and isinstance(memories[0], dict):
        backend = memories[0].get("retrieval_backend") or ""
    if not backend and layers:
        try:
            backend = layers.memory.status().get("backend", {}).get("active", "")
        except Exception:
            backend = ""
    return {
        "memories": memories,
        "life_events": events,
        "tasks": task_context.get("matches", []) if isinstance(task_context, dict) else [],
        "task_context": task_context,
        "backend": backend or "local_hybrid",
    }


def _agent_generate_observed_node(args):
    payload = args or {}
    reply = payload.get("reply") or ""
    route = payload.get("route") or {}
    skill_state = payload.get("skill") or {}
    skill_payload = _load_selected_skill_payload(skill_state)
    return {
        "source": "chat_pipeline",
        "route": route.get("name"),
        "skill": skill_payload,
        "rule_reply": route.get("name") if route.get("deterministic") else "",
        "reply": reply,
        "reply_chars": len(reply),
        "used_existing_reply": True,
    }


def _agent_plan_node(args):
    if not layers or not hasattr(layers, "tasks"):
        return {"available": False, "actions": [], "decision": "chat_only"}
    payload = args or {}
    user_msg = payload.get("user_msg", "")
    route = payload.get("route") or {}
    retrieved = payload.get("retrieved") or {}
    skill_state = payload.get("skill") or {}
    skill_payload = _load_selected_skill_payload(skill_state)
    task_context = retrieved.get("task_context") if isinstance(retrieved, dict) else {}
    matches = task_context.get("matches") if isinstance(task_context, dict) else []
    plan_actions = []
    focus = matches[0] if matches else {}
    done_terms = ["完成", "做完", "改完", "过了", "结束", "不用了", "取消", "不用管"]
    defer_terms = ["等会", "晚点", "一会", "先不用", "明天再说", "等等"]
    if focus:
        action_type = "task.follow_next_action"
        requires_confirm = False
        reason = "matched active task"
        if any(term in user_msg for term in done_terms):
            action_type = "task.mark_done_candidate"
            requires_confirm = True
            reason = "user message may indicate completion"
        elif any(term in user_msg for term in defer_terms):
            action_type = "task.wait_candidate"
            reason = "user message may defer task"
        plan_actions.append({
            "action_type": action_type,
            "task_id": focus.get("id") or "",
            "task_title": focus.get("title") or "",
            "next_action": focus.get("next_action") or "",
            "requires_confirm": requires_confirm,
            "risk": "low",
            "reason": reason,
        })
    elif (payload.get("sense") or {}).get("life_event_candidate"):
        plan_actions.append({
            "action_type": "task.create_candidate",
            "task_id": "",
            "task_title": user_msg[:80],
            "next_action": "confirm whether this should become a tracked task",
            "requires_confirm": True,
            "risk": "low",
            "reason": "event-like message without matching task",
        })

    recorded = []
    try:
        for action in plan_actions:
            action = layers.tasks.record_action(
                action.get("action_type") or "task.plan",
                payload={
                    "user_msg": user_msg,
                    "route": route.get("name"),
                    "reason": action.get("reason") or "",
                    "task_title": action.get("task_title") or "",
                    "goal": action.get("goal") or user_msg[:160],
                    "next_action": action.get("next_action") or "",
                    "priority": action.get("priority") or (focus.get("priority") if isinstance(focus, dict) else 3) or 3,
                    "due_time": action.get("due_time") or (focus.get("due_time") if isinstance(focus, dict) else ""),
                    "evidence": action.get("evidence") or user_msg[:240],
                    "source": "local_task_planner_v1",
                },
                task_id=action.get("task_id") or "",
                status="planned",
                risk=action.get("risk") or "low",
                requires_confirm=bool(action.get("requires_confirm")),
            )
            recorded.append(action)
    except (Exception,) as err:
        return {
            "available": True,
            "actions": plan_actions,
            "recorded_actions": recorded,
            "decision": plan_actions[0].get("action_type") if plan_actions else "chat_only",
            "error": str(err),
        }
    return {
        "available": True,
        "task_focus": focus,
        "actions": plan_actions,
        "recorded_actions": recorded,
        "action_count": len(plan_actions),
        "decision": plan_actions[0].get("action_type") if plan_actions else "chat_only",
        "requires_confirm": any(bool(item.get("requires_confirm")) for item in plan_actions),
        "source": "local_task_planner_v1",
        "route": route.get("name"),
        "skill": skill_payload,
        "task_context": task_context,
    }


def _agent_observe_node(args):
    payload = args or {}
    reply = payload.get("reply") or ""
    retrieved = payload.get("retrieved") or {}
    recalled = []
    for event in retrieved.get("life_events") or []:
        recalled.append({
            **event,
            "mem_type": "life_event",
            "type_label": "事件",
            "source": "life_events",
            "content": event.get("title") or event.get("evidence") or "",
        })
    recalled.extend(retrieved.get("memories") or [])
    if layers:
        return layers.observability.evaluate_reply(payload.get("user_msg", ""), reply, recalled)
    return {"score": 0, "flags": [], "memory_hit_count": len(recalled)}


def _agent_learn_plan_node(args):
    payload = args or {}
    sense = payload.get("sense") or {}
    route = payload.get("route") or {}
    observe = payload.get("observe") or {}
    retrieved = payload.get("retrieved") or {}
    plan = payload.get("plan") or {}
    actions = []
    if sense.get("life_event_candidate"):
        actions.append("learn_life_event")
    if sense.get("low_state"):
        actions.append("schedule_care_followup")
    if route.get("name") in {"lm", "memory_recall", "user_low_state"} and payload.get("reply"):
        actions.extend(["autonomous_learn", "relationship_learn"])
    return {
        "committed": False,
        "actions": actions,
        "task_plan": plan,
        "task_context": retrieved.get("task_context") if isinstance(retrieved, dict) else {},
        "score": observe.get("score"),
        "reason": "learning is performed by the existing chat pipeline; this node records intent",
    }


def _agent_compact_plan_node(args):
    return {
        "committed": False,
        "daily_guarded": True,
        "last_memory_compact_date": intimacy.data.get("last_memory_compact_date"),
        "last_decay_date": intimacy.data.get("last_decay_date"),
    }


def _agent_proactive_node(args):
    context = (args or {}).get("context") or {}
    return {
        "due": has_due_care_followup(),
        "scheduled_followup": bool(context.get("scheduled_followup")),
        "quiet_mode_until": intimacy.data.get("quiet_mode_until"),
        "action": "ready" if has_due_care_followup() else "idle",
    }


def get_agent_run(user_msg="", context=None, reply=None, route_hint=None, history=None, include_callbacks=True):
    if not layers:
        return {
            "ok": True,
            "engine": "unavailable",
            "nodes": [],
            "note": "layer registry unavailable",
        }
    kwargs = {}
    if include_callbacks:
        kwargs = {
            "retrieve_fn": _agent_retrieve_node,
            "plan_fn": _agent_plan_node,
            "generate_fn": _agent_generate_observed_node,
            "observe_fn": _agent_observe_node,
            "learn_fn": _agent_learn_plan_node,
            "compact_fn": _agent_compact_plan_node,
            "proactive_fn": _agent_proactive_node,
        }
    return layers.agent.run(
        user_msg=user_msg,
        context=context or {},
        history=chat_history if history is None else history,
        route_hint=route_hint,
        reply=reply,
        **kwargs,
    )


def attach_agent_run(result, user_msg, context=None, history=None):
    if not isinstance(result, dict):
        return result
    route_hint = (
        result.get("rule_reply")
        or ("boundary" if result.get("boundary") else "")
        or ("cold_war" if result.get("cold_war") else "")
        or ("lm_fallback" if result.get("lm_fallback") else "")
        or "lm"
    )
    try:
        agent_run = get_agent_run(
            user_msg,
            context=context or {},
            reply=result.get("reply", ""),
            route_hint=route_hint,
            history=history,
            include_callbacks=True,
        )
    except (Exception,) as err:
        agent_run = {
            "ok": False,
            "engine": "local_lightweight_state_machine",
            "degraded": True,
            "degraded_nodes": ["agent_run"],
            "error": str(err),
            "nodes": [],
            "node_status": {"agent_run": "degraded"},
        }
    result["agent_run"] = agent_run
    if isinstance(agent_run, dict):
        retrieve_state = (agent_run.get("state") or {}).get("retrieve") if isinstance(agent_run.get("state"), dict) else {}
        if isinstance(retrieve_state, dict):
            result["task_context"] = retrieve_state.get("task_context") or {
                "matches": retrieve_state.get("tasks") or [],
            }
    result["agent_plan"] = {
        "ok": True,
        "engine": agent_run.get("engine"),
        "mode": agent_run.get("mode"),
        "route": agent_run.get("route"),
        "node_order": agent_run.get("node_order"),
        "node_status": agent_run.get("node_status"),
        "degraded": agent_run.get("degraded", False),
        "latency_ms": agent_run.get("latency_ms", 0),
    }
    return result


def record_agent_run_observability(agent_run, user_msg="", reply="", channel="web", route="", trace_id="", meta=None):
    if not layers or not isinstance(agent_run, dict):
        return None
    try:
        return layers.observability.record_agent_run(
            agent_run,
            user_msg=user_msg,
            reply=reply,
            channel=channel,
            route=route,
            trace_id=trace_id,
            meta=meta or {},
        )
    except Exception as err:
        log_runtime_exception("agent_run_record", err)
        return None


def append_eval_case(case):
    case_path = BASE_DIR / "evals" / "zhiyue_eval_cases.json"
    try:
        cases = json.loads(case_path.read_text(encoding="utf-8"))
        if not isinstance(cases, list):
            cases = []
    except Exception as err:
        log_runtime_exception("append_eval_case.load", err)
        cases = []
    case_id = case.get("id") or f"obs-{now_local().strftime('%Y%m%d%H%M%S')}"
    existing_ids = {str(item.get("id")) for item in cases if isinstance(item, dict)}
    base_id = case_id
    suffix = 2
    while case_id in existing_ids:
        case_id = f"{base_id}-{suffix}"
        suffix += 1
    payload = {
        "id": case_id,
        "input": (case.get("input") or "").strip(),
    }
    for key in ("must_contain", "must_not_contain"):
        values = case.get(key) or []
        if isinstance(values, str):
            values = [values]
        values = [str(item).strip() for item in values if str(item).strip()]
        if values:
            payload[key] = values
    if case.get("max_len"):
        payload["max_len"] = int(case.get("max_len"))
    if case.get("min_score") is not None:
        payload["min_score"] = float(case.get("min_score"))
    if not payload["input"]:
        return None
    cases.append(payload)
    case_path.parent.mkdir(parents=True, exist_ok=True)
    case_path.write_text(json.dumps(cases, ensure_ascii=False, indent=2), encoding="utf-8")
    return payload


def bind_layer_tools():
    if not layers:
        return

    def _memory_search(args):
        query = (args or {}).get("query", "")
        limit = int((args or {}).get("limit", 5) or 5)
        mem_types = (args or {}).get("mem_types") or None
        return memory.get_relevant_memories(query, limit=limit, mem_types=mem_types)

    def _memory_add(args):
        payload = args or {}
        return record_core_memory(
            payload.get("content", ""),
            category=payload.get("category", "记忆"),
            mem_type=payload.get("mem_type", "fact"),
            importance=int(payload.get("importance", 4) or 4),
            source=payload.get("source", "skill"),
            confidence=float(payload.get("confidence", 2.0) or 2.0),
        )

    def _agent_plan(args):
        payload = args or {}
        return get_agent_plan(payload.get("user_msg", ""), payload.get("context") or {})

    def _relationship_proactive(args):
        payload = args or {}
        if payload.get("force"):
            return build_relationship_proactive_reply(force=True)
        return build_relationship_proactive_reply(force=False)

    def _local_files_list(args):
        return layers.local_file_list(args or {})

    def _local_files_read(args):
        return layers.local_file_read(args or {})

    def _local_files_search(args):
        return layers.local_file_search(args or {})

    def _voice_transcribe(args):
        return layers.voice_desktop.transcribe((args or {}).get("path", ""))

    def _voice_speak(args):
        payload = args or {}
        return layers.voice_desktop.speak(
            payload.get("text", ""),
            payload.get("out_path"),
            prompt_audio=payload.get("prompt_audio"),
            emo_audio_prompt=payload.get("emo_audio_prompt"),
            emotion_text=payload.get("emotion_text"),
            provider=payload.get("provider"),
        )

    def _desktop_open_url(args):
        return layers.voice_desktop.open_url((args or {}).get("url", ""))

    def _desktop_shutdown(args):
        payload = args or {}
        return layers.voice_desktop.shutdown(confirmation=str(payload.get("confirmation") or payload.get("text") or ""))

    layers.skills.bind("memory.search", _memory_search)
    layers.skills.bind("memory.add", _memory_add)
    layers.skills.bind("agent.plan", _agent_plan)
    layers.skills.bind("relationship.proactive", _relationship_proactive)
    layers.skills.bind("local_files.list", _local_files_list)
    layers.skills.bind("local_files.read", _local_files_read)
    layers.skills.bind("local_files.search", _local_files_search)
    layers.skills.bind("voice.transcribe", _voice_transcribe)
    layers.skills.bind("voice.speak", _voice_speak)
    layers.skills.bind("desktop.open_url", _desktop_open_url)
    layers.skills.bind("desktop.shutdown", _desktop_shutdown)
    # ── RAG 文档阅读（LlamaIndex）──
    try:
        zhiyue_rag.register_rag_tools(layers.skills.bind)
    except Exception as e:
        log_runtime_exception("rag.register", e)
    # ── DeepEval 评价系统 ──
    try:
        zhiyue_eval.register_eval_tools(layers.skills.bind)
    except Exception as e:
        log_runtime_exception("eval.register", e)


def record_observability_turn(user_msg, reply, channel="web", route="chat", latency_ms=0, meta=None):
    if not layers:
        return None
    try:
        recalled = layers.memory.search(user_msg, limit=5)
        event_hits = recall_life_events(user_msg, limit=5)
        recalled = [
            {
                **event,
                "mem_type": "life_event",
                "type_label": "事件",
                "source": "life_events",
                "content": event.get("title") or event.get("evidence") or "",
            }
            for event in event_hits
        ] + recalled
        eval_result = layers.observability.evaluate_reply(user_msg, reply, recalled)
        human_meta = (meta or {}).get("human_likeness") if isinstance((meta or {}).get("human_likeness"), dict) else {}
        state_bucket = current_state_context_summary(user_msg)
        trace_id = layers.observability.record_trace(
            user_msg=user_msg,
            reply=reply,
            channel=channel,
            route=route,
            recalled=recalled,
            eval_result=eval_result,
            latency_ms=latency_ms,
            meta={
                **(meta or {}),
                "state_bucket": state_bucket,
                "question_type": human_meta.get("question_type") or human_like.classify_question_type(user_msg),
            },
        )
        human_score = float(human_meta.get("score") or 0)
        if (human_score and human_score < 9) or human_like.evaluation_has_bad_signal(human_meta):
            layers.observability.record_learning_event(
                stage="human_like_bad_reply",
                source="observability.trace",
                skill_name="",
                user_msg=user_msg,
                effect=reply[:200],
                judge_score=human_score,
                meta={
                    "trace_id": trace_id,
                    "human_likeness": human_meta,
                    "self_correction": (meta or {}).get("self_correction") if isinstance((meta or {}).get("self_correction"), dict) else {},
                    "route": route,
                    "channel": channel,
                    "state_bucket": state_bucket,
                    "question_type": human_meta.get("question_type") or human_like.classify_question_type(user_msg),
                },
            )
        return trace_id
    except Exception as err:
        log_runtime_exception("observability_record", err)
        return None


# ============ 关系织线层:记忆活性 / 等待痕迹 / 私密语言 / 极小叙事 ============
THREAD_LIMITS = {
    "private_phrase": 20,
    "open_loop": 20,
    "user_event": 20,
    "comfort_strategy": 12,
    "micro_story": 12,
    "flashback": 30,
}

MICRO_STORY_SEEDS = [
    {"title": "校门口黄猫", "content": "校门口那只黄猫今天蹲台阶上,像不认识我了"},
    {"title": "甘草书签", "content": "我把甘草那页折了个角,明天还要背"},
    {"title": "甜胚子", "content": "今天突然想吃甜胚子,兰州那种甜味很轻"},
    {"title": "黄河边风", "content": "傍晚黄河边风挺大,吹得人清醒一点"},
    {"title": "图书馆座位", "content": "图书馆靠窗那个位子又被人占了,烦死了"},
]


def thread_now():
    return now_iso_local()


def add_relationship_thread(thread_type, content, title="", evidence="", heat=1, status="active", dedupe=True):
    content = (content or "").strip()
    if not content:
        return None
    now = thread_now()
    if dedupe:
        existing = growth.conn.execute(
            """SELECT id, heat FROM relationship_threads
               WHERE thread_type=? AND content=? AND status!='archived'
               ORDER BY id DESC LIMIT 1""",
            (thread_type, content),
        ).fetchone()
        if existing:
            growth.conn.execute(
                "UPDATE relationship_threads SET heat=?, evidence=?, last_touched=?, status=? WHERE id=?",
                (min(9, int(existing[1] or 1) + heat), evidence[:200], now, status, existing[0]),
            )
            growth.conn.commit()
            return existing[0]

    growth.conn.execute(
        """INSERT INTO relationship_threads
           (thread_type,title,content,evidence,status,heat,last_touched,created_at)
           VALUES (?,?,?,?,?,?,?,?)""",
        (thread_type, title[:60], content[:220], evidence[:200], status, int(heat or 1), now, now),
    )
    growth.conn.commit()
    return growth.conn.execute("SELECT last_insert_rowid()").fetchone()[0]


def list_relationship_threads(thread_type=None, status="active", limit=20):
    params = []
    where = []
    if thread_type:
        where.append("thread_type=?")
        params.append(thread_type)
    if status:
        where.append("status=?")
        params.append(status)
    sql = "SELECT id, thread_type, title, content, evidence, status, heat, last_touched, created_at FROM relationship_threads"
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY heat DESC, last_touched DESC, id DESC LIMIT ?"
    params.append(limit)
    rows = growth.conn.execute(sql, params).fetchall()
    keys = ["id", "thread_type", "title", "content", "evidence", "status", "heat", "last_touched", "created_at"]
    return [dict(zip(keys, row)) for row in rows]


LIFE_EVENT_ENTITY_TERMS = [
    "央企", "笔试", "面试", "考试", "行测", "申论", "错题", "刷题", "论文", "作业",
    "睡过头", "闹钟", "起床", "失眠", "睡不着", "熬夜", "吵架", "冷战", "周末",
    "计划", "复习", "整理", "提醒", "兰州", "河南", "中医",
]
_LIFE_EVENT_TYPE_PROTOTYPES = {
    "exam": ["央企笔试", "行测申论考试", "面试考试", "考过了没"],
    "study": ["错题整理", "刷题复习", "论文作业", "背书复习"],
    "sleep": ["睡过头", "闹钟起床", "失眠睡不着", "熬夜没睡"],
    "conflict": ["吵架冷战", "闹别扭生气", "和好了吗"],
    "plan": ["周末计划", "想去哪玩", "约着去看", "之后再去"],
    "mood": ["我好焦虑", "我很难受", "我有点崩溃", "我很委屈", "我很累"],
}
_LIFE_EVENT_STATUS_PROTOTYPES = {
    "dropped": ["取消了", "不去了", "算了不弄了", "不用提醒了"],
    "completed": ["考完了", "考过了", "结束了", "做完了", "整理完了", "已经好了", "和好了"],
}
_WAIT_MARKER_PROTOTYPES = {
    "wait_marker": ["等我一下", "我先忙一会", "待会回来", "我去一下", "一会回来"],
    "wait_return": ["我回来了", "回来了", "刚忙完", "我好了", "忙完了"],
}
_EVENT_REPLY_PROTOTYPES = {
    "silence_bond": ["很久不说话会怎样", "如果我不说话", "你会不会等我"],
    "goodnight": ["晚安", "我去睡了", "我先休息了"],
    "fear": ["你最怕什么", "你怕什么", "你担心什么"],
    "ask_status": ["你刚才在干嘛", "刚说你在干嘛", "你刚刚说自己在干嘛"],
    "ask_tomorrow_exam": ["明天干嘛", "明天最重要的事", "说明天干嘛", "刚才说明天有什么"],
    "remember_batch": ["帮我记着这些", "记住这些", "记一下这些", "帮我记一下"],
    "remember_single": ["记一下", "记住", "别忘了"],
    "celebrate_exam": ["如果我考过", "我真过了", "第一句你会说什么"],
    "supplement": ["补充说明天", "还要干嘛", "补充一下明天"],
    "phrase_feedback": ["别老说那句话", "不想你老说", "老说哪句话"],
    "encourage_exam": ["鼓励我一下", "给我鼓劲", "别鸡汤"],
    "wake_up": ["骂醒我", "叫醒我", "提醒我起床"],
    "learn_event": ["明天要", "后天要", "记一下", "提醒我", "别忘了", "周末计划"],
}
_LEARNING_SIGNAL_PROTOTYPES = {
    "sleep_signal": ["我总是熬夜", "我又睡不着", "我是夜猫子", "最近总失眠"],
    "emotion_signal": ["我压力好大", "我现在好焦虑", "我真的好难受", "我好累", "我有点崩溃"],
    "quiet_signal": ["我不想说话", "你先陪我待会", "让我安静一会", "别问了"],
    "style_negative": ["你太像AI了", "你有点啰嗦", "别说教", "别讲道理", "你这样不自然"],
    "style_positive": ["这样挺好", "就这样说", "我喜欢你这样", "自然一点就好"],
}
_USER_EVENT_PROTOTYPES = {
    "event_like": [
        "明天要去",
        "后天要做",
        "提醒我",
        "记一下",
        "别忘了",
        "周末计划",
        "考试安排",
        "错题整理",
        "睡过头",
    ]
}
_USER_EVENT_QUERY_PROTOTYPES = {
    "event_query": [
        "明天最重要的事是什么",
        "刚才我说明天干嘛来着",
        "帮我查查明天天气",
        "说明天有什么",
        "明天要干嘛",
    ]
}
_LIFE_EVENT_TYPE_PROTOTYPES = {
    "exam": ["央企笔试", "行测申论考试", "面试考试", "考过了没"],
    "study": ["错题整理", "刷题复习", "论文作业", "背书复习"],
    "sleep": ["睡过头", "闹钟起床", "失眠睡不着", "熬夜没睡"],
    "conflict": ["吵架冷战", "闹别扭生气", "和好了吗"],
    "plan": ["周末计划", "想去哪玩", "约着去看", "之后再去"],
    "mood": ["我好焦虑", "我很难受", "我有点崩溃", "我很委屈", "我很累"],
}
_LIFE_EVENT_STATUS_PROTOTYPES = {
    "dropped": ["取消了", "不去了", "算了不弄了", "不用提醒了"],
    "completed": ["考完了", "考过了", "结束了", "做完了", "整理完了", "已经好了", "和好了"],
}
_WAIT_MARKER_PROTOTYPES = {
    "wait_marker": ["等我一下", "我先忙一会", "待会回来", "我去一下", "一会回来"],
    "wait_return": ["我回来了", "回来了", "刚忙完", "我好了", "忙完了"],
}
_EVENT_REPLY_PROTOTYPES = {
    "silence_bond": ["很久不说话会怎样", "如果我不说话", "你会不会等我"],
    "goodnight": ["晚安", "我去睡了", "我先休息了"],
    "fear": ["你最怕什么", "你怕什么", "你担心什么"],
    "ask_status": ["你刚才在干嘛", "刚说你在干嘛", "你刚刚说自己在干嘛"],
    "ask_tomorrow_exam": ["明天干嘛", "明天最重要的事", "说明天干嘛", "刚才说明天有什么"],
    "remember_batch": ["帮我记着这些", "记住这些", "记一下这些", "帮我记一下"],
    "remember_single": ["记一下", "记住", "别忘了"],
    "celebrate_exam": ["如果我考过", "我真过了", "第一句你会说什么"],
    "supplement": ["补充说明天", "还要干嘛", "补充一下明天"],
    "phrase_feedback": ["别老说那句话", "不想你老说", "老说哪句话"],
    "encourage_exam": ["鼓励我一下", "给我鼓劲", "别鸡汤"],
    "wake_up": ["骂醒我", "叫醒我", "提醒我起床"],
}


def _json_list(value):
    if isinstance(value, list):
        return [str(item) for item in value if str(item).strip()]
    if not value:
        return []
    try:
        data = json.loads(value)
        if isinstance(data, list):
            return [str(item) for item in data if str(item).strip()]
    except (Exception,) as err:
        log_runtime_exception("load_user_directives", err)
    return []


def infer_life_event_type(text):
    matched, _ = match_intent(text or "", _LIFE_EVENT_TYPE_PROTOTYPES, threshold=0.22)
    if matched:
        return matched
    return "general"


def infer_life_event_status(text):
    matched, _ = match_intent(text or "", _LIFE_EVENT_STATUS_PROTOTYPES, threshold=0.26)
    if matched:
        return matched
    return "active"


def infer_life_event_entities(text):
    msg = text or ""
    entities = []
    for term in LIFE_EVENT_ENTITY_TERMS:
        if term in msg and term not in entities:
            entities.append(term)
    for match in re.findall(r'《([^》]{1,16})》|"([^"]{1,16})"|"([^"]{1,16})"', msg):
        value = next((part for part in match if part), "")
        if value and value not in entities:
            entities.append(value)
    return entities[:10]


def infer_life_event_title(text, event_type=None):
    msg = re.sub(r"\s+", " ", (text or "").strip())
    if not msg:
        return ""
    detected_type = event_type or infer_life_event_type(msg)
    if detected_type == "exam" and "央企" in msg and "笔试" in msg:
        return "央企笔试"
    if detected_type == "exam" and any(k in msg for k in ["行测", "申论"]):
        return "行测申论练习"
    if detected_type == "study" and "错题" in msg and "整理" in msg:
        return "错题整理"
    if detected_type == "study" and "论文" in msg:
        return "论文"
    if detected_type == "sleep" and "睡过头" in msg:
        return "怕睡过头"
    if detected_type == "sleep" and any(k in msg for k in ["失眠", "睡不着"]):
        return "失眠"
    if detected_type == "conflict":
        return "吵架"
    if detected_type == "plan" and "周末" in msg:
        return "周末计划"
    title = re.sub(r"^(记一下|记住|别忘了?|提醒我|我明天要|我后天要|我今天要|我想|我要)", "", msg).strip()
    title = re.sub(r"[,。!?!?;;].*$", "", title).strip() or msg
    return title[:48]


def infer_life_event_due_time(text, now=None):
    msg = text or ""
    now = now or now_local()
    target_date = None
    if "后天" in msg:
        target_date = now.date() + timedelta(days=2)
    elif "明天" in msg:
        target_date = now.date() + timedelta(days=1)
    elif any(k in msg for k in ["今天", "今晚"]):
        target_date = now.date()
    elif "周末" in msg:
        days = (5 - now.weekday()) % 7
        if days == 0 and now.hour >= 18:
            days = 1
        target_date = now.date() + timedelta(days=days)

    if target_date is None:
        return None

    hour = 9
    minute = 0
    time_match = re.search(r'(?:(上午|早上|中午|下午|晚上|今晚|夜里|凌晨)\s*)?(\d{1,2})(?:[::点](\d{1,2})?)?', msg)
    if time_match:
        part = time_match.group(1) or ""
        hour = int(time_match.group(2))
        minute = int(time_match.group(3) or 0)
        if part in {"下午", "晚上", "今晚"} and hour < 12:
            hour += 12
        elif part == "中午" and hour < 11:
            hour += 12
        elif part in {"夜里", "凌晨"} and hour == 12:
            hour = 0
    elif any(k in msg for k in ["晚上", "今晚"]):
        hour = 20
    elif any(k in msg for k in ["下午"]):
        hour = 14
    elif any(k in msg for k in ["中午"]):
        hour = 12
    elif any(k in msg for k in ["错题", "整理", "论文"]):
        hour = 20
    elif any(k in msg for k in ["睡过头", "起床", "闹钟"]):
        hour = 8

    try:
        return datetime.combine(target_date, datetime.min.time()).replace(hour=max(0, min(23, hour)), minute=max(0, min(59, minute))).isoformat()
    except Exception:
        return None


def infer_life_event_followup(event_type, due_time=None, status="active"):
    if status != "active":
        return None
    now = now_local()
    due = _parse_iso_dt(due_time)
    if due:
        if event_type == "sleep":
            follow = due - timedelta(minutes=20)
        elif event_type == "exam":
            follow = due + timedelta(hours=3)
        elif event_type in {"study", "plan"}:
            follow = due + timedelta(hours=6)
        else:
            follow = due + timedelta(hours=2)
        if follow > now:
            return follow.isoformat()
    if event_type in {"mood", "conflict", "sleep"}:
        return (now + timedelta(minutes=45)).isoformat()
    return None


def _life_event_temporal_flags(row, *, now):
    due = _parse_iso_dt(row[4])
    touched = _parse_iso_dt(row[6])
    followup = _parse_iso_dt(row[7])
    overdue_hours = None
    if due and due < now:
        overdue_hours = (now - due).total_seconds() / 3600.0
    stale_due = overdue_hours is not None and overdue_hours > 72
    stale_active = bool(
        row[3] == "active"
        and stale_due
        and (not touched or (now - touched).total_seconds() / 86400.0 > 7)
        and (not followup or followup < now)
    )
    return {
        "due": due,
        "touched": touched,
        "followup": followup,
        "overdue_hours": overdue_hours,
        "stale_due": stale_due,
        "stale_active": stale_active,
    }


def upsert_life_event(title, event_type=None, status="active", due_time=None, entities=None, evidence="", importance=3, next_followup_at=None):
    title = (title or "").strip()
    evidence = (evidence or title).strip()
    if not title and evidence:
        title = infer_life_event_title(evidence, event_type=event_type)
    if not title:
        return None
    event_type = event_type or infer_life_event_type(evidence or title)
    status = status or infer_life_event_status(evidence or title)
    due_time = due_time or infer_life_event_due_time(evidence or title)
    entities = list(dict.fromkeys(_json_list(entities) + infer_life_event_entities(" ".join([title, evidence]))))
    next_followup_at = next_followup_at or infer_life_event_followup(event_type, due_time=due_time, status=status)
    now = now_iso_local()
    key = normalize_text_key(title)
    candidates = growth.conn.execute(
        """SELECT id, title, entities_json, importance, created_at
           FROM life_events
           WHERE event_type=? AND status!='archived'
           ORDER BY last_mentioned_at DESC, id DESC LIMIT 80""",
        (event_type,),
    ).fetchall()
    existing = None
    for row in candidates:
        row_key = normalize_text_key(row[1])
        if key and (key == row_key or key in row_key or row_key in key):
            existing = row
            break
    if existing:
        merged_entities = list(dict.fromkeys(_json_list(existing[2]) + entities))[:12]
        merged_importance = min(5, max(int(existing[3] or 1), int(importance or 1)) + 1)
        growth.conn.execute(
            """UPDATE life_events
               SET title=?, status=?, due_time=COALESCE(?, due_time), entities_json=?,
                   last_mentioned_at=?, next_followup_at=COALESCE(?, next_followup_at),
                   evidence=?, importance=?, updated_at=?
               WHERE id=?""",
            (
                title[:80],
                status,
                due_time,
                json.dumps(merged_entities, ensure_ascii=False),
                now,
                next_followup_at,
                evidence[:300],
                merged_importance,
                now,
                existing[0],
            ),
        )
        growth.conn.commit()
        return existing[0]

    growth.conn.execute(
        """INSERT INTO life_events
           (title,event_type,status,due_time,entities_json,last_mentioned_at,next_followup_at,evidence,importance,created_at,updated_at)
           VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
        (
            title[:80],
            event_type,
            status,
            due_time,
            json.dumps(entities[:12], ensure_ascii=False),
            now,
            next_followup_at,
            evidence[:300],
            int(importance or 3),
            now,
            now,
        ),
    )
    growth.conn.commit()
    return growth.conn.execute("SELECT last_insert_rowid()").fetchone()[0]


def learn_life_event(user_msg):
    msg = (user_msg or "").strip()
    if not is_clean_memory_text(msg) or len(msg) > 160:
        return None
    event_keys = [
        "考试", "笔试", "面试", "提醒", "记一下", "记住", "别忘", "明天", "后天",
        "上午", "下午", "晚上", "九点", "9点", "央企", "睡过头", "考过",
        "错题", "整理", "刷题", "论文", "失眠", "睡不着", "吵架", "周末", "计划",
    ]
    if not any(k in msg for k in event_keys):
        return None
    if not any(k in msg for k in ["我", "明天", "后天", "今天", "今晚", "周末", "记", "提醒", "别忘"]):
        return None
    event_type = infer_life_event_type(msg)
    status = infer_life_event_status(msg)
    title = infer_life_event_title(msg, event_type=event_type)
    due_time = infer_life_event_due_time(msg)
    importance = 4 if event_type in {"exam", "sleep", "conflict"} else 3
    event_id = upsert_life_event(
        title=title,
        event_type=event_type,
        status=status,
        due_time=due_time,
        evidence=msg,
        importance=importance,
    )
    return {"id": event_id, "title": title, "event_type": event_type, "status": status, "due_time": due_time} if event_id else None


def list_life_events(status="active", limit=20):
    params = []
    where = []
    if status:
        where.append("status=?")
        params.append(status)
    sql = """SELECT id,title,event_type,status,due_time,entities_json,last_mentioned_at,
                    next_followup_at,evidence,importance,created_at,updated_at
             FROM life_events"""
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY COALESCE(due_time, next_followup_at, last_mentioned_at) DESC, importance DESC, id DESC LIMIT ?"
    params.append(max(1, min(100, int(limit or 20))))
    rows = growth.conn.execute(sql, params).fetchall()
    keys = ["id", "title", "event_type", "status", "due_time", "entities_json", "last_mentioned_at", "next_followup_at", "evidence", "importance", "created_at", "updated_at"]
    result = []
    for row in rows:
        item = dict(zip(keys, row))
        item["entities"] = _json_list(item.pop("entities_json", "[]"))
        result.append(item)
    return result


def recall_life_events(query=None, limit=5, include_inactive=False):
    statuses = ("active", "completed") if include_inactive else ("active",)
    placeholders = ",".join("?" for _ in statuses)
    rows = growth.conn.execute(
        f"""SELECT id,title,event_type,status,due_time,entities_json,last_mentioned_at,
                   next_followup_at,evidence,importance,created_at,updated_at
            FROM life_events
            WHERE status IN ({placeholders})
            ORDER BY importance DESC, COALESCE(due_time, next_followup_at, last_mentioned_at) DESC, id DESC
            LIMIT 160""",
        statuses,
    ).fetchall()
    query_terms = extract_query_terms(query, limit=10)
    query_key = normalize_text_key(query)
    query_text = query or ""
    wants_due = any(k in query_text for k in ["今天", "明天", "后天", "今晚", "周末", "最近", "刚才"])
    wants_important = any(k in query_text for k in ["重要", "最重要", "主要", "要干嘛", "干嘛", "什么事", "别忘"])
    wants_fear = any(k in query_text for k in ["怕什么", "最怕", "担心什么", "怕"])
    now = now_local()
    scored = []
    for row in rows:
        temporal = _life_event_temporal_flags(row, now=now)
        if temporal["stale_active"] and (wants_due or wants_important or not query_terms):
            continue
        entities = _json_list(row[5])
        text = " ".join([str(row[1] or ""), str(row[2] or ""), str(row[8] or ""), " ".join(entities)])
        text_key = normalize_text_key(text)
        matched = [term for term in query_terms if term and term in text.lower()]
        lexical = score_text_overlap(text, query_terms)
        phrase = 1.4 if query_key and (query_key in text_key or text_key in query_key) else 0.0
        due = temporal["due"]
        near_due = False
        if due:
            hours = (due - now).total_seconds() / 3600
            near_due = -24 <= hours <= (96 if wants_due else 72)
        due_query_match = bool(wants_due and near_due)
        important_query_match = bool(wants_important and int(row[9] or 1) >= 3 and (near_due or row[2] in {"exam", "study", "sleep"}))
        fear_query_match = bool(wants_fear and any(k in text for k in ["怕", "担心", "睡过头", "失眠", "睡不着"]))
        if query_terms and lexical <= 0 and phrase <= 0 and not due_query_match and not important_query_match and not fear_query_match:
            if not any(term in text for term in ["央企", "笔试", "错题", "睡过头", "论文", "失眠", "周末"] if term in query_text):
                continue
        importance = int(row[9] or 1)
        reason = []
        if matched:
            reason.append("matched_terms:" + ",".join(matched[:5]))
        if phrase:
            reason.append("phrase_overlap")
        if row[2]:
            reason.append(f"type:{row[2]}")
        if due_query_match:
            reason.append("query_due_window")
        if important_query_match:
            reason.append("query_important")
        if fear_query_match:
            reason.append("query_fear")
        if near_due:
            reason.append("near_due")
        touched = temporal["touched"]
        recency = 0.0
        if touched:
            age_days = max(0.0, (now - touched).total_seconds() / 86400)
            recency = max(0.0, 1.2 - age_days * 0.10)
            if age_days <= 3:
                reason.append("recently_mentioned")
        due_bonus = 1.0 if near_due else 0.0
        if due_query_match:
            due_bonus += 1.2
        if important_query_match:
            due_bonus += 1.0
        if fear_query_match:
            due_bonus += 1.1
        stale_penalty = 2.5 if temporal["stale_due"] else 0.0
        final_score = lexical * 1.8 + phrase + importance * 0.7 + recency + due_bonus
        if not query_terms:
            final_score = importance * 0.7 + recency + due_bonus
        final_score -= stale_penalty
        if final_score <= 0:
            continue
        item = {
            "id": row[0],
            "title": row[1],
            "event_type": row[2],
            "status": row[3],
            "due_time": row[4],
            "entities": entities,
            "last_mentioned_at": row[6],
            "next_followup_at": row[7],
            "evidence": row[8],
            "importance": importance,
            "created_at": row[10],
            "updated_at": row[11],
            "score": round(final_score, 3),
            "matched_terms": matched[:8],
            "hit_reason": reason or ["high_importance"],
            "retrieval_backend": "life_events",
            "content": row[1],
        }
        scored.append((final_score, item))
    scored.sort(key=lambda pair: (pair[0], pair[1]["importance"], pair[1]["id"]), reverse=True)
    return [item for _, item in scored[:max(1, min(20, int(limit or 5)))]]


def archive_low_value_life_events(limit=200):
    cutoff_active = now_local() - timedelta(days=21)
    cutoff_done = now_local() - timedelta(days=7)
    rows = growth.conn.execute(
        """SELECT id,status,importance,last_mentioned_at,due_time,next_followup_at
           FROM life_events WHERE status!='archived' LIMIT ?""",
        (limit,),
    ).fetchall()
    archived = 0
    now = now_iso_local()
    for event_id, status, importance, last_mentioned_at, due_time, next_followup_at in rows:
        touched = _parse_iso_dt(last_mentioned_at) or _parse_iso_dt(due_time) or _parse_iso_dt(next_followup_at)
        if not touched:
            continue
        if status in {"completed", "dropped"} and touched < cutoff_done:
            growth.conn.execute("UPDATE life_events SET status='archived', updated_at=? WHERE id=?", (now, event_id))
            archived += 1
        elif status == "active" and int(importance or 1) <= 2 and touched < cutoff_active:
            growth.conn.execute("UPDATE life_events SET status='archived', updated_at=? WHERE id=?", (now, event_id))
            archived += 1
    if archived:
        growth.conn.commit()
    return archived


def touch_relationship_thread(thread_id, status=None, heat_delta=1):
    row = growth.conn.execute("SELECT heat FROM relationship_threads WHERE id=?", (thread_id,)).fetchone()
    if not row:
        return
    heat = max(0, min(9, int(row[0] or 1) + heat_delta))
    if status:
        growth.conn.execute(
            "UPDATE relationship_threads SET heat=?, status=?, last_touched=? WHERE id=?",
            (heat, status, thread_now(), thread_id),
        )
    else:
        growth.conn.execute(
            "UPDATE relationship_threads SET heat=?, last_touched=? WHERE id=?",
            (heat, thread_now(), thread_id),
        )
    growth.conn.commit()


def parse_wait_marker(user_msg):
    msg = user_msg or ""
    matched, _ = match_intent(msg, {"wait_marker": _WAIT_MARKER_PROTOTYPES["wait_marker"]}, threshold=0.24)
    if matched:
        return {
            "created_at": thread_now(),
            "source": msg[:80],
            "small_task": random.choice([
                "看了两页方剂",
                "背了一点甘草",
                "去倒了杯水",
                "把桌子收了一下",
                "翻了下论文",
            ]),
        }
    return None


def is_clean_memory_text(text):
    text = (text or "").strip()
    if not text or len(text) < 3:
        return False
    bad = [
        "Conversation info", "untrusted", "metadata", "system", "assistant",
        "prompt", "database", "null", "None", "{", "}", "[", "]",
    ]
    if any(item.lower() in text.lower() for item in bad):
        return False
    if not re.search(r'[\u4e00-\u9fa5]', text):
        return False
    return True


def maybe_wait_return_reply(user_msg):
    marker = intimacy.data.get("last_user_wait_marker")
    if not marker:
        return None
    matched, _ = match_intent(user_msg or "", {"wait_return": _WAIT_MARKER_PROTOTYPES["wait_return"]}, threshold=0.24)
    if not matched:
        return None
    created = _parse_iso_dt(marker.get("created_at"))
    if not created:
        return None
    minutes = int((now_local() - created).total_seconds() // 60)
    if minutes < 1:
        waited = "刚刚"
    elif minutes < 60:
        waited = f"{minutes}分钟"
    else:
        waited = "好一会儿"
    task = marker.get("small_task") or "看了会书"
    reply = random.choice([
        f"回来了啊---我刚{task}",
        f"嗯---等你{waited}了",
        f"你回来了---我刚{task}",
    ])
    intimacy.data["last_user_wait_marker"] = None
    intimacy.data["last_wait_reply"] = reply
    intimacy.save()
    return reply


def learn_private_phrase(user_msg):
    msg = (user_msg or "").strip()
    if not msg or len(msg) > 80:
        return None
    segments = [part.strip() for part in re.split(r'[,,。.!!??;;\s]+', msg) if part.strip()]
    patterns = [
        r'(?:我|我们)(?:把|叫)([\u4e00-\u9fa5A-Za-z0-9_]{1,8}?)(?:叫|说成)([\u4e00-\u9fa5A-Za-z0-9_]{1,8})$',
        r'以后(?:把|叫)([\u4e00-\u9fa5A-Za-z0-9_]{1,8}?)(?:叫|说成)([\u4e00-\u9fa5A-Za-z0-9_]{1,8})$',
        r'([\u4e00-\u9fa5A-Za-z0-9_]{1,8})就是([\u4e00-\u9fa5A-Za-z0-9_]{1,8})',
    ]
    for segment in segments or [msg]:
        for pattern in patterns:
            m = re.search(pattern, segment)
            if m:
                source, phrase = m.group(1), m.group(2)
                if source and phrase and source != phrase:
                    content = f"{source}={phrase}"
                    add_relationship_thread("private_phrase", content, title=phrase, evidence=msg, heat=2)
                    growth.add_learning_note("私密语言", f"你们之间可以把{source}说成{phrase}", msg, confidence=2)
                    return content

    # Repeated tiny nonstandard words can become private language, but avoid ordinary answers.
    if msg in {"倒", "瘫", "放空", "续命", "缓缓"}:
        content = f"特殊短词={msg}"
        add_relationship_thread("private_phrase", content, title=msg, evidence=msg, heat=1)
        return content
    return None


def learn_open_loop(user_msg):
    msg = (user_msg or "").strip()
    if not msg:
        return None
    matched, score = match_intent(
        msg,
        {
            "open_loop": [
                "改天试试",
                "下次再去",
                "以后告诉你",
                "回头再聊",
                "哪天发给你",
            ]
        },
        threshold=0.22,
    )
    if matched and score >= 0.22:
        content = msg[:80]
        add_relationship_thread("open_loop", content, title="未完成的小事", evidence=msg, heat=2)
        return content
    return None


def learn_user_event(user_msg):
    msg = (user_msg or "").strip()
    if not is_clean_memory_text(msg) or len(msg) > 120:
        return None
    if match_intent(msg, _USER_EVENT_QUERY_PROTOTYPES, threshold=0.22)[0]:
        return None
    event_detected = match_intent(msg, _LIFE_EVENT_TYPE_PROTOTYPES, threshold=0.18)[0]
    temporal_detected = bool(match_intent(msg, _USER_EVENT_PROTOTYPES, threshold=0.18)[0])
    if not event_detected and not temporal_detected:
        return None
    if not temporal_detected and "我" not in msg:
        return None
    content = msg[:100]
    add_relationship_thread("user_event", content, title="对方近期事件", evidence=msg, heat=3)
    life_event = learn_life_event(msg)
    try:
        memory.add_memory(content, category="近期事件", importance=4, mem_type="experience", source="user_event", confidence=2.5)
        growth.add_learning_note("近期事件", f"对方近期提到:{content}", msg, confidence=3)
    except (Exception,) as err:
        log_runtime_exception("load_user_directives", err)
    return life_event or content


def get_recent_user_event_text(limit=8):
    try:
        events = recall_life_events(query="最近在意的事", limit=limit)
    except Exception as err:
        log_runtime_exception("recent_user_event.life_events", err)
        events = []
    if events:
        return ";".join(
            f"{item.get('title', '')}{(' @ ' + item.get('due_time', '')[:16]) if item.get('due_time') else ''}"
            for item in events[:limit]
            if item.get("title")
        )
    try:
        rows = list_relationship_threads("user_event", limit=limit)
    except Exception as err:
        log_runtime_exception("recent_user_event.threads", err)
        rows = []
    recent_rows = []
    now = now_local()
    for row in rows:
        touched = _parse_iso_dt(row.get("last_touched")) or _parse_iso_dt(row.get("created_at"))
        if touched and (now - touched).total_seconds() / 86400.0 > 7:
            continue
        content = str(row.get("content", "")).strip()
        if not content:
            continue
        if match_intent(content, _USER_EVENT_QUERY_PROTOTYPES, threshold=0.22)[0]:
            continue
        recent_rows.append(content)
    texts = recent_rows
    if texts:
        return ";".join(texts[:limit])
    try:
        recent = memory.get_recent(limit=limit)
    except Exception as err:
        log_runtime_exception("recent_user_event.memory_recent", err)
        recent = []
    return ";".join(item for item in recent if is_clean_memory_text(item))


def recall_user_event_reply(user_msg):
    msg = str(user_msg or "")
    if "昨" in msg or "上次" in msg:
        return "我记得一点，你再带我往前捋一下。"
    return None
def self_improvement_brief_reply(user_msg):
    return None  # disabled: rule-based fallback removed


def code_fix_chat_reply(user_msg):
    return technical_chat_flow.code_fix_chat_reply(
        user_msg,
        scan_and_accumulate_issues=scan_and_accumulate_issues,
        get_pending_summary=get_pending_summary,
        format_pending_for_user=format_pending_for_user,
        approve_fixes=approve_fixes,
        generate_fix_diff_for_approved=generate_fix_diff_for_approved,
        format_proposals_for_user=format_proposals_for_user,
        execute_approved_fixes=execute_approved_fixes,
        reject_fixes=reject_fixes,
        layers=layers,
        tool_source_dir=ZHIYUE_TOOL_SOURCE_DIR,
        clean_reply=clean_reply,
    )


def maybe_record_user_reported_reply_issue(user_msg):
    return technical_chat_flow.maybe_record_user_reported_reply_issue(
        user_msg,
        layers=layers,
        clean_reply=clean_reply,
    )


def self_improvement_chat_approval_reply(user_msg):
    return technical_chat_flow.self_improvement_chat_approval_reply(
        user_msg,
        layers=layers,
        classify_user_feedback_with_model=classify_user_feedback_with_model,
        clean_reply=clean_reply,
    )


def remember_recent_user_state(user_msg):
    return runtime_chat_rules.remember_recent_user_state(user_msg, intimacy=intimacy)


def maybe_companion_short_reply(user_msg):
    return runtime_chat_rules.maybe_companion_short_reply(user_msg)


def user_low_state_reply(user_msg):
    return runtime_chat_rules.user_low_state_reply(user_msg)


def learn_comfort_strategy(user_msg, ai_reply):
    return runtime_chat_rules.learn_comfort_strategy(
        user_msg,
        ai_reply,
        add_relationship_thread=add_relationship_thread,
        growth=growth,
    )


def restored_core_short_reply(user_msg):
    return runtime_chat_rules.restored_core_short_reply(user_msg)


def learn_flashback_seed(user_msg):
    msg = (user_msg or "").strip()
    if not is_clean_memory_text(msg):
        return None
    keys = ["上次", "那天", "之前", "记得", "一起", "通宵", "甜", "吃", "梦到", "晚安"]
    if any(k in msg for k in keys):
        add_relationship_thread("flashback", msg[:120], title="共同记忆", evidence=msg, heat=1)
        return msg[:120]
    return None


def relationship_learn(user_msg, ai_reply):
    learned = []
    marker = parse_wait_marker(user_msg)
    if marker:
        intimacy.data["last_user_wait_marker"] = marker
        intimacy.save()
        learned.append("wait_marker")
    user_event = learn_user_event(user_msg)
    if user_event:
        learned.append("learn_user_event")
    elif learn_life_event(user_msg):
        learned.append("life_event")
    for fn in (learn_private_phrase, learn_open_loop, learn_flashback_seed):
        item = fn(user_msg)
        if item:
            learned.append(fn.__name__)
    if learn_comfort_strategy(user_msg, ai_reply):
        learned.append("comfort_strategy")
    return learned


def seed_micro_story_if_needed():
    existing = list_relationship_threads("micro_story", limit=20)
    titles = {item.get("title") for item in existing}
    for seed in MICRO_STORY_SEEDS:
        if seed["title"] not in titles:
            add_relationship_thread("micro_story", seed["content"], title=seed["title"], evidence="seed", heat=1)
    return list_relationship_threads("micro_story", limit=20)


def get_relationship_inject():
    private = list_relationship_threads("private_phrase", limit=5)
    open_loops = list_relationship_threads("open_loop", limit=3)
    user_events = list_relationship_threads("user_event", limit=5)
    life_events = recall_life_events(limit=6)
    strategies = list_relationship_threads("comfort_strategy", limit=3)
    stories = list_relationship_threads("micro_story", limit=3)
    marker = intimacy.data.get("last_user_wait_marker")
    lines = []
    if private:
        lines.append("私密语言:" + ";".join(item["content"] for item in private[:5]))
    if open_loops:
        lines.append("未完成的小约定:" + ";".join(item["content"] for item in open_loops[:3]))
    if life_events:
        event_bits = []
        for item in life_events[:6]:
            due = item.get("due_time")
            due_text = f"@{due[:16]}" if due else ""
            event_bits.append(f"{item.get('title')}({item.get('event_type')}/{item.get('status')}){due_text}")
        lines.append("结构化事件:" + ";".join(event_bits))
    if user_events:
        lines.append("对方最近在意的事:" + ";".join(item["content"] for item in user_events[:5]))
    if strategies:
        lines.append("安慰策略:" + ";".join(item["content"] for item in strategies[:3]))
    if stories:
        lines.append("你的生活小线:" + ";".join(f"{i['title']}:{i['content']}" for i in stories[:3]))
    if marker:
        lines.append(f"等待痕迹:他说过等一下。他回来时可以轻轻提一句。")
    if not lines:
        return ""
    lines.append("注意:结构化事件优先于散记忆;临近或刚提过的事可以自然接上,但不要解释为记忆系统。未完成的小约定低频提起,别追问。")
    return "\n=== 关系织线 ===\n" + "\n".join(lines)


def can_fire_thread(kind, min_minutes):
    key = {
        "flashback": "last_flashback_time",
        "ambient": "last_ambient_time",
        "micro_story": "last_micro_story_time",
    }.get(kind)
    if not key:
        return True
    last = _parse_iso_dt(intimacy.data.get(key))
    if last and (now_local() - last).total_seconds() < min_minutes * 60:
        return False
    intimacy.data[key] = now_iso_local()
    intimacy.save()
    return True


def build_flashback_reply():
    return None
def build_micro_story_reply():
    return None
def build_ambient_reply():
    return None
def build_open_loop_reply():
    return None
def build_relationship_proactive_reply(force=False):
    _ = force
    return None
def remove_profile_items_containing(profile, keywords):
    for key in ("user_facts", "user_preferences", "user_boundaries", "shared_history"):
        profile[key] = [
            item for item in profile.get(key, [])
            if not any(kw in item for kw in keywords)
        ]


def record_core_memory(content, category='记忆', mem_type='fact', importance=4, source='learning', confidence=2.0):
    text = (content or "").strip()
    if not text:
        return None
    try:
        return memory.add_memory(
            text[:160],
            category=category,
            importance=importance,
            mem_type=mem_type,
            source=source,
            confidence=confidence,
        )
    except Exception as err:
        log_runtime_exception("core_memory_write", err)
        return None



def auto_generate_code_proposal(user_msg, ai_reply, score, reasons):
    return learning_controller.auto_generate_code_proposal(
        user_msg=user_msg,
        ai_reply=ai_reply,
        score=score,
        reasons=reasons,
        layers=layers,
        log_runtime_exception=log_runtime_exception,
        logger=_dbg,
    )


def auto_generate_skill_update(user_msg, ai_reply, score, reasons):
    return learning_controller.auto_generate_skill_update(
        user_msg=user_msg,
        ai_reply=ai_reply,
        score=score,
        reasons=reasons,
        layers=layers,
        log_runtime_exception=log_runtime_exception,
    )


def _resolve_proposal_target_path(base_dir: str | Path, fname: str) -> Path:
    base_path = Path(base_dir)
    raw_name = str(fname or "").strip()
    normalized = Path(raw_name).name
    candidates: list[Path] = []
    seen: set[str] = set()
    for candidate in (
        base_path / raw_name,
        base_path / normalized,
        base_path / "modules" / normalized,
        base_path / "core" / normalized,
    ):
        key = str(candidate).lower()
        if key in seen:
            continue
        seen.add(key)
        candidates.append(candidate)
    for candidate in candidates:
        if candidate.exists() and candidate.is_file():
            return candidate
    return candidates[0] if candidates else base_path / normalized


def generate_proposal_diff(proposal: dict, base_dir: str = str(BASE_DIR)) -> dict:
    """
    Use LLM to generate a unified diff for a draft code proposal.
    Returns dict with 'diff_text' and 'test_commands'.
    Falls back to extracting raw text if JSON parsing fails.
    """
    import re as _re

    target_files = proposal.get("target_files") or []
    meta = proposal.get("meta") or {}
    fix_template = meta.get("fix_template") or {}
    title = fix_template.get("title") or proposal.get("title") or ""
    rationale = fix_template.get("rationale") or proposal.get("rationale") or ""

    file_content_map: dict[str, str] = {}
    for fname in target_files:
        fpath = _resolve_proposal_target_path(base_dir, str(fname))
        if fpath.exists():
            try:
                content = fpath.read_text(encoding="utf-8")
                lines = content.split("\n")
                file_content_map[fname] = "\n".join(lines[:200])
            except Exception:
                file_content_map[fname] = ""

    file_summaries = []
    for fname, content in file_content_map.items():
        file_summaries.append(f"\n--- File: {fname} (前200行) ---\n{content}")

    files_section = "\n".join(file_summaries) if file_summaries else "(file not found)"

    if not _ensure_lm_studio_ready(base_dir=base_dir, require_warmup=True, timeout=90):
        return {"diff_text": "", "test_commands": [], "ok": False, "error": "LM Studio is not ready"}

    prompt = f"""你是代码修改助手。根据以下信息，为代码生成一个 **标准 unified diff**（格式与 `diff -u` 一致）。

修改目标：{title}
修改原因：{rationale}

原始代码文件内容：
{files_section}

请生成一个 unified diff，要求：
1. 以 `--- a/文件名` / `+++ b/文件名` 开头
2. 用 `@@ -行号,行数 +行号,行数 @@` 标记改动位置
3. 只改最少的必要行，不要大段重写
4. 保持代码风格一致
5. diff 只包含你要修改的文件，不要包含其他文件
6. 用 **JSON对象** 返回，格式：
{{"diff_text": "...unified diff字符串...", "test_commands": ["python 文件名", "..."]}}
- test_commands 只能包含白名单验证命令，例如 `python -m py_compile ...`、`python zhiyue_eval.py --mode api-smoke --transport test-client`、`python zhiyue_eval.py --mode memory-hit --transport test-client`
- 不要输出 `python 文件名` 这种直接执行源码文件的命令
- 只返回这个 JSON，不要有其他解释文字
"""
    raw_prompt = f"""你是代码修改助手。根据以下信息，为代码生成一个 **标准 unified diff**（格式与 `diff -u` 一致）。

修改目标：{title}
修改原因：{rationale}

原始代码文件内容：
{files_section}

请直接输出 unified diff，要求：
1. 以 `--- a/文件名` / `+++ b/文件名` 开头
2. 用 `@@ -行号,行数 +行号,行数 @@` 标记改动位置
3. 只改最少的必要行，不要大段重写
4. 保持代码风格一致
5. diff 只包含你要修改的文件，不要包含其他文件
6. 只输出 unified diff，不要 JSON，不要解释
"""

    messages = [{"role": "user", "content": prompt}]
    raw_messages = [{"role": "user", "content": raw_prompt}]

    schema = {
        "type": "object",
        "properties": {
            "diff_text": {"type": "string", "description": "Unified diff string, e.g. --- a/file\n+++ b/file\n@@ ..."},
            "test_commands": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Shell commands to verify the change (e.g. python test.py)"
            }
        },
        "required": ["diff_text", "test_commands"]
    }

    try:
        result = _request_lm_json(messages, "proposal_diff", schema, temperature=0.3, max_tokens=800, timeout=120)
        if isinstance(result, dict) and result.get("diff_text"):
            return {
                "diff_text": result.get("diff_text", ""),
                "test_commands": result.get("test_commands") or [
                    f"python -m py_compile {' '.join(target_files or ['zhiyue_connected.py'])}",
                    "python zhiyue_eval.py --mode api-smoke --transport test-client",
                    "python zhiyue_eval.py --mode memory-hit --transport test-client",
                ],
                "ok": True,
            }
    except (Exception,) as ex:
        log_runtime_exception("generate_proposal_diff.json_parse", ex)

    # Fallback: try raw text response (no JSON schema)
    try:
        resp = _post_lm_payload({
            "model": LM_MODEL,
            "messages": raw_messages,
            "stream": False,
            "think_disabled": True,
            "enable_thinking": False,
            "temperature": 0.3,
            "max_tokens": 800,
        })
        if resp.status_code >= 400:
            _dbg.error("[DIFF] Raw fallback HTTP error %d: %s", resp.status_code, resp.text[:200])
        else:
            raw, _ = _parse_lm_response(resp)
            extracted = _extract_diff_result(raw, target_files=target_files, prefer_ok=True)
            if extracted.get("diff_text"):
                return extracted
    except (Exception,) as ex2:
        log_runtime_exception("generate_proposal_diff.raw_fallback", ex2)

    return {"diff_text": "", "test_commands": [], "ok": False}


def _extract_diff_result(raw: str, *, target_files: list, prefer_ok: bool = False) -> dict:
    if not raw or not raw.strip():
        return {"diff_text": "", "test_commands": [], "ok": False}

    start = raw.find("{")
    end = raw.rfind("}")
    if start != -1 and end != -1 and end > start:
        parsed = safe_json_loads(raw[start:end + 1], None)
        if isinstance(parsed, dict):
            diff_text = str(parsed.get("diff_text") or "").strip()
            if diff_text:
                return {
                    "diff_text": diff_text,
                    "test_commands": parsed.get("test_commands") or [
                        f"python -m py_compile {' '.join(target_files or ['zhiyue_connected.py'])}",
                        "python zhiyue_eval.py --mode api-smoke --transport test-client",
                        "python zhiyue_eval.py --mode memory-hit --transport test-client",
                    ],
                    "ok": True,
                }

    start = raw.find("---")
    if start != -1:
        end = raw.rfind("@@")
        if end != -1:
            end = raw.find("\n", end + 2)
            if end == -1:
                end = len(raw)
        else:
            end = len(raw)
        diff_text = raw[start:end].strip()
        if diff_text:
            return {
                "diff_text": diff_text,
                "test_commands": [
                    f"python -m py_compile {' '.join(target_files or ['zhiyue_connected.py'])}",
                    "python zhiyue_eval.py --mode api-smoke --transport test-client",
                    "python zhiyue_eval.py --mode memory-hit --transport test-client",
                ],
                "ok": prefer_ok,
                "raw": raw[:200],
            }

    return {"diff_text": "", "test_commands": [], "ok": False}


_SKILL_CORRECTION_SYSTEM_PROMPT = (
    "你是 Skill 内容优化器。分析 Skill 效果数据，找出根因，"
    "输出修正后的完整内容。保持原有 Markdown 结构和语气风格。"
)


def _run_skill_learning_cycle_core(*, skill_names, dry_run: bool, max_age_days: int, findings_path):
    effect = layers.skill_learning.companion_skill_effect_summary(
        findings_path, window=20, limit=50,
    )
    steps = {
        "effect_summary": {
            "skill_count": len(effect.get("items") or {}),
            "items": {
                k: {
                    "avg_judge_score": (
                        (v.get("runtime_hits") or {}).get("avg_judge_score") if isinstance(v.get("runtime_hits"), dict) else None
                    )
                }
                for k, v in (effect.get("items") or {}).items()
            },
        }
    }

    corrections = []
    for sn in skill_names:
        skill_content = ""
        if hasattr(layers, "skills"):
            try:
                resolved = layers.skills._load_selected_skill_payload(sn)
                skill_content = str(resolved.get("body") or resolved.get("content") or "")
            except (KeyError) as e:
                pass

        pr = layers.skill_learning.self_correct_skill(
            skill_name=sn, effect_summary=effect, skill_content=skill_content,
        )
        if not pr.get("ok") or pr.get("reason") != "prompt_ready":
            corrections.append({
                "skill_name": sn,
                "corrected": False,
                "reason": pr.get("reason"),
                "avg_score": pr.get("avg_score"),
            })
            continue

        if dry_run:
            corrections.append({
                "skill_name": sn,
                "corrected": False,
                "reason": "dry_run",
                "prompt_ready": True,
                "avg_score": pr.get("avg_score"),
            })
            continue

        try:
            parsed = _request_lm_json(
                [
                    {"role": "system", "content": _SKILL_CORRECTION_SYSTEM_PROMPT},
                    {"role": "user", "content": pr["pending_prompt"]},
                ],
                "skill_correction",
                _SELF_CORRECT_SCHEMA,
                temperature=0.3,
                max_tokens=800,
                timeout=120,
            )
            corrected = str(parsed.get("corrected_content") or "")
            if corrected.strip():
                layers.skill_learning.record_self_correction_draft(
                    skill_name=sn,
                    corrected_content=corrected,
                    analysis=str(parsed.get("analysis") or ""),
                )
                corrections.append({
                    "skill_name": sn,
                    "corrected": True,
                    "avg_score": pr.get("avg_score"),
                    "change_summary": str(parsed.get("change_summary") or "")[:120],
                })
            else:
                corrections.append({
                    "skill_name": sn,
                    "corrected": False,
                    "reason": "empty_llm_output",
                })
        except Exception as err:
            corrections.append({
                "skill_name": sn,
                "corrected": False,
                "reason": f"llm_error: {err}",
            })

    conflict = layers.skill_learning.conflict_summary(limit=200, auto_resolve=not dry_run)
    archive = layers.skill_learning.auto_archive_stale_drafts(
        dry_run=dry_run, max_age_days=max_age_days, min_evidence=3,
    )
    steps["self_corrections"] = corrections
    steps["conflict_resolution"] = {
        "conflict_count": conflict.get("conflict_count", 0),
        "auto_resolved": conflict.get("auto_resolved"),
    }
    steps["stale_archive"] = {
        "archived_count": archive.get("archived_count", 0),
    }
    return {
        "effect": effect,
        "steps": steps,
        "corrections": corrections,
        "corrected_count": sum(1 for c in corrections if c.get("corrected")),
        "conflict": conflict,
        "archive": archive,
    }


def generate_research_enhanced_diff(proposal: dict, research_result: dict, base_dir: str = str(BASE_DIR)) -> dict:
    """
    After external research is completed, use the official research findings to generate
    an improved v2 unified diff that incorporates the research insights.

    Returns dict with 'diff_text', 'test_commands', and 'ok'.
    """
    target_files = proposal.get("target_files") or []
    title = proposal.get("title") or ""
    rationale = proposal.get("rationale") or ""
    plain_summary = proposal.get("plain_summary") or ""

    # Build research context from findings
    sources = research_result.get("sources") if isinstance(research_result.get("sources"), list) else []
    summary_lines = research_result.get("summary") if isinstance(research_result.get("summary"), list) else []
    research_topics = research_result.get("topics") if isinstance(research_result.get("topics"), list) else []

    research_context_lines = []
    if research_topics:
        research_context_lines.append(f"\u7814\u7a76\u4e3b\u9898: {', '.join(research_topics)}")
    if summary_lines:
        research_context_lines.append("\u5b98\u65b9\u8d44\u6599\u6458\u8981:")
        for line in summary_lines[:5]:
            research_context_lines.append(f"  - {line}")

    research_section = "\n".join(research_context_lines) if research_context_lines else "(\u672a\u83b7\u5f97\u7814\u7a76\u8d44\u6599)"

    # Read current file contents (first 200 lines each)
    file_content_map: dict[str, str] = {}
    for fname in target_files:
        fpath = Path(base_dir) / fname
        if fpath.exists():
            try:
                content = fpath.read_text(encoding="utf-8")
                lines = content.split("\n")
                file_content_map[fname] = "\n".join(lines[:200])
            except Exception:
                file_content_map[fname] = ""

    file_summaries = []
    for fname, content in file_content_map.items():
        file_summaries.append(f"\n--- File: {fname} (\u524d200\u884c) ---\n{content}")
    files_section = "\n".join(file_summaries) if file_summaries else "(file not found)"

    prompt = f"""\u4f60\u662f\u4ee3\u7801\u4fee\u6539\u52a9\u624b\u3002\u6839\u636e\u4ee5\u4e0b\u4fe1\u606f\uff0c\u4e3a\u4ee3\u7801\u751f\u6210\u4e00\u4e2a **\u6807\u51c6 unified diff**\uff08\u683c\u5f0f\u4e0e `diff -u` \u4e00\u81f4\uff09\u3002

\u539f\u59cb\u95ee\u9898\uff1a{title}
\u95ee\u9898\u8bf4\u660e\uff1a{plain_summary}
\u4fee\u6539\u539f\u56e0\uff1a{rationale}

**\u5b98\u65b9\u8d44\u6599\u7814\u7a76\u7ed3\u679c**\uff08\u8bf7\u4f18\u5148\u53c2\u8003\u8fd9\u4e9b\u5185\u5bb9\u751f\u6210\u66f4\u597d\u7684 diff\uff09\uff1a
{research_section}

\u539f\u59cb\u4ee3\u7801\u6587\u4ef6\u5185\u5bb9\uff1a
{files_section}

\u8bf7\u751f\u6210\u4e00\u4e2a unified diff\uff0c\u8981\u6c42\uff1a
1. \u4ee5 `--- a/\u6587\u4ef6\u540d` / `+++ b/\u6587\u4ef6\u540d` \u5f00\u5934
2. \u7528 `@@ -\u884c\u53f7,\u884c\u6570 +\u884c\u53f7,\u884c\u6570 @@` \u6807\u8bb0\u6539\u52a8\u4f4d\u7f6e
3. \u53ea\u6539\u6700\u5c11\u7684\u5fc5\u8981\u884c\uff0c\u4e0d\u8981\u5927\u6bb5\u91cd\u5199
4. \u4fdd\u6301\u4ee3\u7801\u98ce\u683c\u4e00\u81f4
5. diff \u53ea\u5305\u542b\u4f60\u8981\u4fee\u6539\u7684\u6587\u4ef6\uff0c\u4e0d\u8981\u5305\u542b\u5176\u4ed6\u6587\u4ef6
6. **\u91cd\u8981\uff1a\u521a\u624d\u7684\u7814\u7a76\u8d44\u6599\u662f\u5b98\u65b9\u6587\u6863\uff0c\u53c2\u8003\u5b83\u4eec\u751f\u6210\u66f4\u4f18\u5316\u7684\u4fee\u590d\u65b9\u6848**
7. \u7528 **JSON\u5bf9\u8c61** \u8fd4\u56de\uff0c\u683c\u5f0f\uff1a
{{"diff_text": "...unified diff\u5b57\u7b26\u4e32...", "test_commands": ["python \u6587\u4ef6\u540d", "..."]}}
- test_commands \u662f\u9a8c\u8bc1\u4fee\u6539\u6b63\u786e\u6027\u7684\u547d\u4ee4\u5217\u8868\uff0c\u5fc5\u987b\u662f\u5b57\u7b26\u4e32\u6570\u7ec4
- \u53ea\u8fd4\u56de\u8fd9\u4e2a JSON\uff0c\u4e0d\u8981\u6709\u5176\u4ed6\u89e3\u91ca\u6587\u5b57
"""

    messages = [{"role": "user", "content": prompt}]

    schema = {
        "type": "object",
        "properties": {
            "diff_text": {"type": "string", "description": "Unified diff string, e.g. --- a/file\n+++ b/file\n@@ ..."},
            "test_commands": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Shell commands to verify the change"
            }
        },
        "required": ["diff_text", "test_commands"]
    }

    try:
        result = _request_lm_json(messages, "research_enhanced_diff", schema, temperature=0.3, max_tokens=800, timeout=120)
        if isinstance(result, dict) and result.get("diff_text"):
            return {
                "diff_text": result.get("diff_text", ""),
                "test_commands": result.get("test_commands") or [f"python -m py_compile {' '.join(target_files or ['zhiyue_connected.py'])}"],
                "ok": True,
            }
    except (Exception,) as ex:
        log_runtime_exception("generate_research_enhanced_diff.json_parse", ex)

    # Fallback: try raw text response
    try:
        resp = _post_lm_payload({
            "model": LM_MODEL,
            "messages": messages,
            "stream": False,
            "think_disabled": True,
            "enable_thinking": False,
            "temperature": 0.3,
            "max_tokens": 800,
        })
        if resp.status_code >= 400:
            _dbg.error("[DIFF-V2] Raw fallback HTTP error %d: %s", resp.status_code, resp.text[:200])
        else:
            raw, _ = _parse_lm_response(resp)
            extracted = _extract_diff_result(raw, target_files=target_files, prefer_ok=False)
            if extracted.get("diff_text"):
                return extracted
    except (Exception,) as ex2:
        log_runtime_exception("generate_research_enhanced_diff.raw_fallback", ex2)

    return {"diff_text": "", "test_commands": [], "ok": False}


def autonomous_learn(user_msg, ai_reply, score=None, reasons=None):
    """
    External autonomous learning: update profile/notes from each turn.
    It never mutates the immutable persona; it only edits memory/profile layers.
    """
    msg = (user_msg or "").strip()
    reply = (ai_reply or "").strip()
    if not msg:
        return []

    learned = []
    profile = load_persona_profile()

    # Strong corrections: user explicitly fixes identity or false facts.
    name_match = re.search(r'(?:我叫|我的名字是|名字是)\s*([\u4e00-\u9fa5A-Za-z0-9_]{1,12})', msg)
    if name_match:
        name = clean_person_name(name_match.group(1))
        if name:
            profile["user_name"] = name
            remove_profile_items_containing(profile, ["名字是"])
            _append_unique(profile["user_facts"], f"对方名字是{name}", limit=40)
            growth.add_learning_note("纠错", f"对方名字是{name},不要叫错", msg, confidence=3)
            record_core_memory(f"对方名字是{name}", category="人物", mem_type="fact", importance=5, source="correction", confidence=3)
            learned.append(f"name={name}")

    not_match = re.search(r'我不是([\u4e00-\u9fa5A-Za-z0-9_]{1,12})', msg)
    if not_match:
        thing = not_match.group(1)
        remove_profile_items_containing(profile, [thing])
        _append_unique(profile["user_facts"], f"对方不是{thing}", limit=40)
        growth.deactivate_learning_notes(thing)
        growth.add_learning_note("纠错", f"对方不是{thing},不要再这样判断", msg, confidence=3)
        record_core_memory(f"对方不是{thing}", category="纠错", mem_type="fact", importance=4, source="correction", confidence=3)
        learned.append(f"not={thing}")

    wrong_name = re.search(r'不是([\u4e00-\u9fa5A-Za-z0-9_]{1,12})[,, ]*(?:我叫|我是)([\u4e00-\u9fa5A-Za-z0-9_]{1,12})', msg)
    if wrong_name:
        wrong = clean_person_name(wrong_name.group(1))
        right = clean_person_name(wrong_name.group(2))
        remove_profile_items_containing(profile, [wrong, "名字是"])
        profile["user_name"] = right
        _append_unique(profile["user_facts"], f"对方名字是{right}", limit=40)
        growth.deactivate_learning_notes(wrong)
        growth.add_learning_note("纠错", f"对方名字是{right},不是{wrong}", msg, confidence=3)
        record_core_memory(f"对方名字是{right}", category="人物", mem_type="fact", importance=5, source="correction", confidence=3)
        learned.append(f"name_fix={right}")

    # Preferences and boundaries.
    pref_match = re.search(r'我(?:喜欢|爱吃|爱玩|偏爱)(.{1,24})', msg)
    if pref_match:
        item = (pref_match.group(1) or "").strip()[:24]
        if item:
            fact = f"对方喜欢{item}"
            _append_unique(profile["user_preferences"], fact, limit=40)
            growth.add_learning_note("偏好", fact, msg, confidence=2)
            record_core_memory(fact, category="偏好", mem_type="preference", importance=4, source="learning", confidence=2)
            learned.append("preference")

    dislike_match = re.search(r'我(?:不喜欢|讨厌|受不了|不想)(.{1,24})', msg)
    if dislike_match:
        item = (dislike_match.group(1) or "").strip()[:24]
        if item:
            fact = f"对方不喜欢{item}"
            _append_unique(profile["user_boundaries"], fact, limit=40)
            growth.add_learning_note("边界", fact, msg, confidence=2)
            record_core_memory(fact, category="边界", mem_type="boundary", importance=4, source="learning", confidence=2)
            learned.append("boundary")

    if match_intent(msg, {"sleep_signal": _LEARNING_SIGNAL_PROTOTYPES["sleep_signal"]}, threshold=0.24)[0]:
        fact = "对方经常熬夜/睡得晚"
        _append_unique(profile["user_facts"], fact, limit=40)
        growth.add_learning_note("作息", "对方容易熬夜,关心时别太说教", msg, confidence=2)
        record_core_memory(fact, category="作息", mem_type="fact", importance=4, source="learning", confidence=2)
        learned.append("sleep")

    if match_intent(msg, {"emotion_signal": _LEARNING_SIGNAL_PROTOTYPES["emotion_signal"]}, threshold=0.22)[0]:
        fact = "对方状态低时先接住情绪,再轻轻问原因"
        growth.add_learning_note("情绪触发", fact, msg, confidence=2)
        record_core_memory(fact, category="情绪", mem_type="boundary", importance=4, source="learning", confidence=2)
        learned.append("emotion")

    if match_intent(msg, {"quiet_signal": _LEARNING_SIGNAL_PROTOTYPES["quiet_signal"]}, threshold=0.24)[0]:
        until = now_local() + timedelta(minutes=30)
        intimacy.data["quiet_mode_until"] = until.isoformat()
        fact = "对方不想说话时,安静陪着,不要追问"
        growth.add_learning_note("陪伴方式", fact, msg, confidence=2)
        record_core_memory(fact, category="陪伴方式", mem_type="boundary", importance=4, source="learning", confidence=2)
        learned.append("quiet_mode")

    # Style feedback about the AI itself.
    if match_intent(msg, {"style_negative": _LEARNING_SIGNAL_PROTOTYPES["style_negative"]}, threshold=0.22)[0]:
        fact = "回复更短、更像聊天,少讲道理少说教"
        growth.add_learning_note("风格禁忌", fact, msg, confidence=3)
        record_core_memory(fact, category="风格", mem_type="boundary", importance=4, source="learning", confidence=3)
        learned.append("style_negative")
    if "别" in msg and any(w in msg for w in ["老说", "总说", "每句", "口头禅"]):
        phrase_match = re.search(r'别(?:老|总|一直|每句)?说([^\s,。!?]{1,8})', msg)
        phrase = clean_person_name(phrase_match.group(1)) if phrase_match else ""
        if phrase:
            fact = f'不要频繁说"{phrase}",偶尔用可以,别每句都挂嘴边'
            growth.add_learning_note("风格禁忌", fact, msg, confidence=3)
            record_core_memory(fact, category="风格", mem_type="boundary", importance=3, source="learning", confidence=3)
            learned.append("phrase_limit")
    if match_intent(msg, {"style_positive": _LEARNING_SIGNAL_PROTOTYPES["style_positive"]}, threshold=0.22)[0]:
        fact = "保持短句、自然、像微信聊天"
        growth.add_learning_note("风格偏好", fact, msg, confidence=2)
        record_core_memory(fact, category="风格", mem_type="preference", importance=3, source="learning", confidence=2)
        learned.append("style_positive")

    if score is not None and score < 3:
        growth.add_learning_note("风格禁忌", "上一条回复质量低,下次避免太长、乱码或AI腔", reply, confidence=1)
        learned.append("low_score")

    save_persona_profile(profile)
    try:
        if layers and hasattr(layers, "companion_profile"):
            layers.companion_profile.sync_from_runtime(
                persona_profile=profile,
                intimacy_data=intimacy.data,
            )
    except Exception as err:
        log_runtime_exception("companion_profile.sync", err)
    if score is not None and score < 5 and reasons:
        learning_controller.process_low_score_learning(
            user_msg=user_msg,
            ai_reply=ai_reply,
            score=score,
            reasons=reasons,
            layers=layers,
            log_runtime_exception=log_runtime_exception,
            logger=_dbg,
        )

    if learned:
        _dbg.debug("[自主学习] %s", learned)
    return learned


def maybe_decay_learning_notes(force=False):
    today = today_iso_local()
    if not force and intimacy.data.get("last_decay_date") == today:
        return 0
    changed = growth.decay_learning_notes(days=3)
    intimacy.data["last_decay_date"] = today
    intimacy.save()
    if changed:
        _dbg.debug("[学习衰减] changed=%s", changed)
    return changed


def maybe_compact_memories(force=False):
    today = today_iso_local()
    if not force and intimacy.data.get("last_memory_compact_date") == today:
        return 0
    removed = 0
    try:
        prune_expired_state(force=force)
        removed = memory.compact_duplicates()
        removed += memory.archive_low_value_memories()
        removed += archive_low_value_life_events()
    except (Exception,) as err:
        log_runtime_exception("maybe_compact_memories", err)
        removed = 0
    intimacy.data["last_memory_compact_date"] = today
    intimacy.save()
    if removed:
        _dbg.debug("[记忆整理] removed=%s", removed)
    return removed


def self_review_turn(user_msg, ai_reply, score=None, reasons=None):
    """Small deterministic self-review. Keeps learning local and cheap."""
    notes = []
    reply = ai_reply or ""
    msg = user_msg or ""

    if len(reply) <= 32 and not any(w in reply for w in ["作为AI", "语言模型", "系统", "数据库"]):
        notes.append(("复盘", "这轮回复短,比较像微信聊天", 1))
    if "---" in reply:
        notes.append(("复盘", "用多条短消息表达,比长段更自然", 1))
    if len(reply) > 80:
        notes.append(("风格禁忌", "刚才回复偏长,下次拆短或少说", 2))
    if any(w in reply for w in ["建议你", "你应该", "首先", "其次"]):
        notes.append(("风格禁忌", "少用建议式和条目式表达,先接情绪", 2))
    if any(w in msg for w in ["累", "难受", "焦虑", "睡不着"]) and not any(w in reply for w in ["累", "抱", "我听着", "咋啦", "歇会"]):
        notes.append(("复盘", "对方低落时要先接住情绪,不急着转移", 2))
    if score is not None and score < 3:
        notes.append(("风格禁忌", "低分回复不要沉淀为风格,下一次更短更自然", 2))

    reason_notes = {
        "太长": ("风格禁忌", "这轮回复偏长,下一轮收短一点", 2),
        "太短": ("复盘", "这轮回复太短,可以补一点陪伴感", 1),
        "乱码": ("风格禁忌", "先清理乱码再发,别把坏文本带进去", 3),
        "身份暴露": ("风格禁忌", "不要暴露AI身份或系统词", 3),
        "重复": ("风格禁忌", "换个开头,别重复固定句式", 2),
        "英文太多": ("风格禁忌", "尽量用中文,少夹英文", 1),
    }
    for reason in reasons or []:
        note = reason_notes.get(reason)
        if note:
            notes.append(note)

    for note_type, content, confidence in notes[:3]:
        growth.add_learning_note(note_type, content, f"用户:{msg[:80]} | 回复:{reply[:80]}", confidence=confidence)
    if notes:
        _dbg.debug("[自我复盘] %s", [n[1] for n in notes[:3]])
    return [n[1] for n in notes[:3]]


def boundary_reply(user_msg):
    return runtime_chat_rules.boundary_reply(user_msg, intimacy=intimacy)


def response_delay_ms(message_item):
    if message_item.get("type") == "emoji":
        return random.randint(350, 900)
    content = message_item.get("content", "")
    base = 450 + min(len(content) * 70, 1800)
    if get_daypart() == "late":
        base += 500
    return random.randint(int(base * 0.7), int(base * 1.25))


def add_message_delays(messages):
    return [{**m, "delay_ms": response_delay_ms(m)} for m in messages]


CARE_FOLLOWUP_RULES = [
    {
        "kind": "sleep",
        "keys": ["睡不着", "失眠", "睡不踏实", "又醒了"],
        "delay_minutes": 35,
        "replies": ["好点没---还睡不着吗", "你睡着没---我有点惦记", "还醒着吗---别硬熬了"],
    },
    {
        "kind": "tired",
        "keys": ["累", "疲惫", "撑不住", "不想动"],
        "delay_minutes": 45,
        "replies": ["好点没---还那么累吗", "歇过来点没", "你缓过来没"],
    },
    {
        "kind": "anxious",
        "keys": ["焦虑", "压力大", "慌", "崩溃", "难受", "不开心"],
        "delay_minutes": 40,
        "replies": ["现在好点没", "刚还想着你---舒服点没", "还难受吗---我听着"],
    },
]


def _parse_iso_dt(value):
    try:
        return parse_datetime_local(value)
    except Exception as err:
        log_runtime_exception("parse_iso_dt", err)
        return None


def _active_care_followups():
    items = intimacy.data.get("care_followups") or []
    return [item for item in items if item.get("active", True)]


def _read_json_file(path: Path, fallback):
    if not path.exists():
        return fallback
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return fallback


def _write_json_file(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def list_weixin_dead_letters(limit: int = 100) -> list[dict]:
    rows = _read_json_file(WEIXIN_DEAD_LETTER_FILE, [])
    if not isinstance(rows, list):
        return []
    items = [row for row in rows if isinstance(row, dict)]
    items.sort(key=lambda row: int(row.get("dead_letter_at") or 0), reverse=True)
    return items[:limit]


def summarize_weixin_dead_letters() -> dict:
    items = list_weixin_dead_letters(limit=500)
    queue = _read_json_file(WEIXIN_QUEUE_FILE, [])
    if not isinstance(queue, list):
        queue = []
    reason_counts: dict[str, int] = {}
    for item in items:
        reason = str(item.get("dead_letter_reason") or "unknown").strip() or "unknown"
        reason_counts[reason] = reason_counts.get(reason, 0) + 1
    latest = items[0] if items else None
    oldest = items[-1] if items else None
    return {
        "dead_letter_count": len(items),
        "queue_count": len([row for row in queue if isinstance(row, dict)]),
        "reason_counts": reason_counts,
        "latest_dead_letter_at": latest.get("dead_letter_at") if latest else None,
        "oldest_dead_letter_at": oldest.get("dead_letter_at") if oldest else None,
        "latest_ids": [str(item.get("id") or "") for item in items[:5]],
    }


def evaluate_weixin_bridge_health() -> dict:
    summary = summarize_weixin_dead_letters()
    dead_letter_count = int(summary.get("dead_letter_count") or 0)
    degraded = dead_letter_count >= WEIXIN_DEAD_LETTER_WARN_THRESHOLD
    return {
        **summary,
        "warn_threshold": WEIXIN_DEAD_LETTER_WARN_THRESHOLD,
        "degraded": degraded,
        "status": "degraded" if degraded else "ok",
    }


def replay_weixin_dead_letters(ids: list[str] | None = None, *, limit: int = 20) -> dict:
    dead_letters = _read_json_file(WEIXIN_DEAD_LETTER_FILE, [])
    queue = _read_json_file(WEIXIN_QUEUE_FILE, [])
    if not isinstance(dead_letters, list):
        dead_letters = []
    if not isinstance(queue, list):
        queue = []
    queue_ids = {
        str(item.get("id") or "")
        for item in queue
        if isinstance(item, dict) and str(item.get("id") or "")
    }
    wanted = {str(item).strip() for item in (ids or []) if str(item).strip()}
    moved = []
    remaining = []
    for row in dead_letters:
        if not isinstance(row, dict):
            continue
        row_id = str(row.get("id") or "")
        if wanted and row_id not in wanted:
            remaining.append(row)
            continue
        if not wanted and len(moved) >= limit:
            remaining.append(row)
            continue
        if row_id and row_id in queue_ids:
            remaining.append(row)
            continue
        restored = dict(row)
        restored["attempts"] = 0
        restored.pop("dead_letter_reason", None)
        restored.pop("dead_letter_at", None)
        queue.append(restored)
        if row_id:
            queue_ids.add(row_id)
        moved.append(row_id or f"idx:{len(moved)}")
    _write_json_file(WEIXIN_QUEUE_FILE, queue[-500:])
    _write_json_file(WEIXIN_DEAD_LETTER_FILE, remaining[-500:])
    return {
        "moved_ids": moved,
        "moved_count": len(moved),
        "remaining_dead_letters": len([row for row in remaining if isinstance(row, dict)]),
        "queue_size": len([row for row in queue if isinstance(row, dict)]),
    }


def schedule_care_followup(user_msg):
    """Schedule one low-noise follow-up when the user reports a bad state."""
    msg = (user_msg or "").strip()
    if not msg:
        return None
    if any(w in msg for w in ["你累", "你困", "你焦虑", "你压力", "你难受", "累不累"]):
        return None

    matched = None
    for rule in CARE_FOLLOWUP_RULES:
        if any(key in msg for key in rule["keys"]):
            matched = rule
            break
    if not matched:
        return None

    now = now_local()
    active = []
    for item in _active_care_followups():
        due_at = _parse_iso_dt(item.get("due_at"))
        if due_at and (now - due_at).total_seconds() > 12 * 3600:
            continue
        active.append(item)

    for item in active:
        if item.get("kind") == matched["kind"]:
            item["source"] = msg[:80]
            item["due_at"] = datetime.fromtimestamp(now.timestamp() + matched["delay_minutes"] * 60, tz=APP_TIMEZONE).isoformat()
            intimacy.data["care_followups"] = active[-5:]
            intimacy.save()
            return item

    item = {
        "kind": matched["kind"],
        "source": msg[:80],
        "created_at": now.isoformat(),
        "due_at": datetime.fromtimestamp(now.timestamp() + matched["delay_minutes"] * 60, tz=APP_TIMEZONE).isoformat(),
        "active": True,
    }
    active.append(item)
    intimacy.data["care_followups"] = active[-5:]
    intimacy.save()
    return item


def pop_due_care_followup():
    now = now_local()
    items = intimacy.data.get("care_followups") or []
    due_item = None
    for item in items:
        if not item.get("active", True):
            continue
        due_at = _parse_iso_dt(item.get("due_at"))
        if due_at and due_at <= now:
            due_item = item
            break
    if not due_item:
        return None

    due_item["active"] = False
    due_item["sent_at"] = now.isoformat()
    intimacy.data["care_followups"] = items[-8:]
    intimacy.save()
    return due_item


def has_due_care_followup():
    now = now_local()
    for item in _active_care_followups():
        due_at = _parse_iso_dt(item.get("due_at"))
        if due_at and due_at <= now:
            return True
    return False


def build_care_followup_reply(item):
    """Generate a care followup reply using LM."""
    if not item or not isinstance(item, dict):
        return None
    reason = item.get("reason", "")
    trigger = item.get("trigger", "")
    if not reason and not trigger:
        return None
    prompt = f"你是张致悦，22岁女生，男朋友叫张凯。\n你之前注意到：{reason or trigger}\n现在你想发一条关心的微信消息给张凯。\n\n要求：自然口语化，1-2句话，带一点关心和亲昵。\n直接输出消息内容："
    try:
        result = _request_lm_text(
            messages=[
                {"role": "system", "content": "你是张致悦，22岁女生，男朋友叫张凯。回复要自然口语化、像真实微信聊天。"},
                {"role": "user", "content": prompt},
            ],
            max_tokens=160,
            temperature=0.8,
            top_p=0.95,
        )
        if result and isinstance(result, str):
            result = result.strip().strip('"\'').strip()
            if 2 <= len(result) <= 200:
                return result
    except (RuntimeError | ValueError) as e:
        pass
    return None
def _get_code_change_alerts() -> list[dict]:
    """读取未投递的代码变更通知"""
    if not CODE_CHANGE_ALERTS_FILE.exists():
        return []
    try:
        alerts = json.loads(CODE_CHANGE_ALERTS_FILE.read_text(encoding="utf-8"))
        return [a for a in alerts if not a.get("delivered")]
    except Exception as err:
        log_runtime_exception("code_change_alerts.load", err)
        return []


def _mark_code_change_alerts_delivered() -> None:
    """标记所有代码变更通知为已投递"""
    if not CODE_CHANGE_ALERTS_FILE.exists():
        return
    try:
        alerts = json.loads(CODE_CHANGE_ALERTS_FILE.read_text(encoding="utf-8"))
        changed = False
        for a in alerts:
            if not a.get("delivered"):
                a["delivered"] = True
                changed = True
        if changed:
            CODE_CHANGE_ALERTS_FILE.write_text(json.dumps(alerts, ensure_ascii=False, indent=2), encoding="utf-8")
    except (json.JSONDecodeError | KeyError | OSError) as e:
        log_runtime_exception("code_change_alerts.delivered", e)


def _format_code_change_alert_reply(alerts: list[dict]) -> dict:
    """格式化代码变更通知为用户可见的回复"""
    if not alerts:
        return {"content": "", "role": "assistant"}
    lines = ["🔧 我刚才自动修复了一些代码问题：", ""]
    for a in alerts[-5:]:  # 最多显示5条
        summary = a.get("summary", "")
        if summary:
            lines.append(f"  · {summary}")
        files = a.get("file_changed", "")
        if files:
            lines.append(f"    文件: {files}")
    return {"content": "\n".join(lines), "role": "assistant"}


def should_send_proactive(force=False):
    if force:
        return True
    # 有未投递的代码变更通知 → 立即推送
    if _get_code_change_alerts():
        return True
    last_user = intimacy.data.get("last_user_time")
    last_pro = intimacy.data.get("last_proactive_time")
    now = now_local()

    if not last_user:
        return False
    try:
        last_user_dt = parse_datetime_local(last_user)
    except Exception:
        return False

    quiet_until = _parse_iso_dt(intimacy.data.get("quiet_mode_until"))
    quiet_active = bool(quiet_until and quiet_until > now)

    if not quiet_active and (now - last_user_dt).total_seconds() < 20 * 60:
        return False

    if quiet_active:
        if (now - last_user_dt).total_seconds() < 8 * 60:
            return False
        if last_pro:
            try:
                last_pro_dt = parse_datetime_local(last_pro)
                if (now - last_pro_dt).total_seconds() < 18 * 60:
                    return False
            except Exception as err:
                log_runtime_exception("rule_hint.companion_event", err)
        return random.random() < 0.55

    if last_pro:
        try:
            last_pro_dt = parse_datetime_local(last_pro)
            if (now - last_pro_dt).total_seconds() < PROACTIVE_MIN_SECONDS:
                return False
        except (Exception,) as err:
            log_runtime_exception("low_state_learn", err)

    if has_due_care_followup():
        return True

    if get_daypart(now) == "late" and random.random() < 0.65:
        return False
    return random.random() < 0.35


def build_proactive_reply():
    """Build a proactive message using character state + LM."""
    cs = _get_char_state()

    # First: check for due care followups
    followup = pop_due_care_followup()
    if followup:
        reply = build_care_followup_reply(followup)
        if reply and isinstance(reply, str) and reply.strip():
            cs.record_proactive()
            cs.mark_shared(followup.get("reason", followup.get("trigger", "care")))
            return reply.strip()

    # Second: character-state-based proactive
    now = now_local()
    last_user = intimacy.data.get("last_user_time")
    last_pro = intimacy.data.get("last_proactive_time")
    mins_since_user = 999
    mins_since_pro = 999
    try:
        if last_user:
            mins_since_user = (now - parse_datetime_local(last_user)).total_seconds() / 60
    except (RuntimeError | ValueError) as e:
        pass
    try:
        if last_pro:
            mins_since_pro = (now - parse_datetime_local(last_pro)).total_seconds() / 60
    except (RuntimeError | ValueError) as e:
        pass

    if not cs.should_send_proactive(
        minutes_since_last_user=mins_since_user,
        minutes_since_last_proactive=mins_since_pro,
    ):
        return None

    prompt_text = cs.get_proactive_prompt()
    life_ctx = char_state.build_life_plan_context() if char_state is not None else ""
    activity = cs.get_current_activity()
    
    # Build rich system prompt with persona context
    system_prompt = (
        f"你是张致悦，22岁女生，自由职业设计师/写作者，男朋友叫张凯。\n"
        f"性格温柔细腻，有一点撒娇但独立有主见。住城市小公寓，喜欢看书画画音乐美食。\n"
        f"{life_ctx}"
        f"现在在：{activity.get('activity', '休息中')}"
        f"回复要自然口语化、像真实微信聊天，带一点亲昵。1-3句话。不要emoji。"
    )
    
    try:
        result = _request_lm_text(
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt_text},
            ],
            max_tokens=200,
            temperature=0.85,
            top_p=0.95,
        )
        if result and isinstance(result, str):
            result = result.strip().strip('"\'').strip()
            if 2 <= len(result) <= 200:
                cs.record_proactive()
                # Mark share topic to avoid repetition
                topic = cs.get_share_topic_for_now()
                if topic and topic.get("topic"):
                    cs.mark_shared(topic["topic"])
                return result
    except (KeyError) as e:
        pass

    return None
def strip_thinking_text(text):
    """Remove model reasoning before a reply is shown to the user."""
    text = text or ""
    text = re.sub(r"(?is)<think>.*?</think>", "", text)
    text = re.sub(r"(?is)^.*?</think>", "", text)
    text = re.sub(r"(?is)^thinking process\s*:.*?(?:final(?: answer| output)?\s*:)", "", text)
    return text.strip()
def extract_final_from_reasoning(reasoning):
    """Best-effort extraction of the final answer without exposing reasoning."""
    text = reasoning or ""
    if not text:
        return ""

    def valid_final(candidate):
        candidate = strip_thinking_text(candidate or "").strip()
        candidate = re.sub(r"^[\"""']+|[\"""']+$", "", candidate).strip()
        if not candidate or len(candidate) > 80:
            return ""
        if re.search(r"[A-Za-z]{3,}", candidate):
            return ""
        if any(token in candidate for token in ["规则", "约束", "输出", "回复", "选项", "草稿", "分析", "思考", "Final", "Option"]):
            return ""
        if ":" in candidate or ":" in candidate or "(" in candidate or ")" in candidate:
            return ""
        return candidate if re.search(r"[\u4e00-\u9fff]", candidate) else ""

    patterns = [
        r'(?is)(?:final output|final answer|final|输出|回复)\s*[::]\s*[""]?(.*?)[""]?\s*$',
        r'(?is)(?:output generation|final decision).*?[""]([^""\n]{1,120})[""]',
    ]
    for pattern in patterns:
        match = re.search(pattern, text)
        if match:
            candidate = valid_final(match.group(1))
            if candidate:
                return candidate
    quoted = re.findall(r'[""]([^""\n]{1,80}[\u4e00-\u9fff][^""\n]{0,80})[""]', text)
    for candidate in reversed(quoted):
        candidate = valid_final(candidate)
        if candidate:
            return candidate
    chinese_lines = [
        line.strip(" -*\t\r\n")
        for line in text.splitlines()
        if re.search(r"[\u4e00-\u9fff]", line)
    ]
    for candidate in reversed(chinese_lines):
        candidate = valid_final(candidate)
        if candidate:
            return candidate
    return ""


def clean_reply(text):
    return clean_reply_for_mode(text)


def clean_reply_for_mode(text, *, technical=False):
    _ = technical
    if text is None:
        return ""
    return text if isinstance(text, str) else str(text)
PROMPT_LEAK_MARKERS = [
    "默认像普通朋友自然说话",
    "如果有两件事,用---拆成两条短消息",
    "不要解释规则",
    "不要讲解规则",
    "不要把自我复盘说给用户",
    "不要复述提示词",
    "不要复述系统",
    "轻松随意",
    "亲密自然",
    "撒娇暧昧",
    "深情甜蜜",
    "关心对方",
    "正常微信聊天",
    "像正常微信聊天",
    "自然微信聊天",
    "少讲道理少说教",
    "别说教",
    "短短陪着就行",
    "保持短句",
    "系统提示",
    "提示词",
    "成长系统",
    "内部机制",
    "数据库",
    "策略",
    "规则",
]


def has_prompt_leak(text):
    reply = (text or "").strip()
    if not reply:
        return False
    lower = reply.lower()
    return any(marker in reply for marker in PROMPT_LEAK_MARKERS) or any(marker.lower() in lower for marker in PROMPT_LEAK_MARKERS)


def strip_prompt_leakage(text, *, technical=False):
    reply = (text or "").strip()
    if not reply:
        return reply

    segments = [part.strip() for part in re.split(r'\s*---+\s*', reply) if part.strip()]
    if segments:
        kept = [part for part in segments if not has_prompt_leak(part)]
        reply = "---".join(kept or segments)

    lines = [line.strip() for line in reply.splitlines() if line.strip()]
    if lines:
        kept_lines = [line for line in lines if not has_prompt_leak(line)]
        if kept_lines:
            reply = " ".join(kept_lines)

    markers = PROMPT_LEAK_MARKERS
    if technical:
        markers = [
            marker for marker in PROMPT_LEAK_MARKERS
            if marker not in {"系统提示", "提示词", "成长系统", "内部机制", "数据库", "策略", "规则"}
        ]
    for marker in markers:
        reply = reply.replace(marker, "")

    reply = re.sub(r"\s+", " ", reply).strip(" \t\r\n--::,,。;;")
    if len(reply) < 2:
        return ""
    return reply


def collapse_reply_segments(text, max_segments=2):
    _ = max_segments
    return text if isinstance(text, str) else ("" if text is None else str(text))


def strip_prompt_leakage(text, *, technical=False):
    _ = technical
    return text if isinstance(text, str) else ("" if text is None else str(text))


def soften_reply_for_context(user_msg, reply):
    _ = user_msg
    return reply if isinstance(reply, str) else ("" if reply is None else str(reply))


def collapse_reply_segments(text, max_segments=2):
    _ = max_segments
    return text if isinstance(text, str) else ("" if text is None else str(text))


def is_ooc_reply(text):
    lower = (text or "").lower()
    bad = [
        "我是ai", "我是 ai", "作为ai", "作为一个ai", "语言模型", "ai助手",
        "人工智能", "大模型", "系统提示", "提示词", "数据库", "成长系统",
        "角色扮演", "人设", "虚拟角色", "客服", "openai", "lm studio",
        "默认像普通朋友自然说话", "如果有两件事,用---拆成两条短消息", "不要解释规则",
        "轻松随意", "亲密自然", "撒娇暧昧", "深情甜蜜", "关心对方",
        "正常微信聊天", "像正常微信聊天", "自然微信聊天", "少讲道理少说教", "别说教", "短短陪着就行", "保持短句",
        "武大", "水利院", "水利学院",
    ]
    return any(item in lower for item in bad)


def is_placeholder_reply(text):
    cleaned = (text or "").strip()
    return cleaned in {"", ".", "..", "...", "......", "。。。"}


def soften_reply_for_context(user_msg, reply):
    """Return the original reply without canned softening."""
    return reply or ""
def is_technical_request(user_msg):
    msg = normalize_technical_text(user_msg)
    if not msg:
        return False
    if ".py" in str(user_msg or "").lower() or ".json" in str(user_msg or "").lower():
        if any(term in msg for term in ["文件", "读一下", "读取", "看看", "分析", "代码"]):
            return True
    return any(
        normalize_technical_text(k) in msg
        for k in (TECHNICAL_REQUEST_PATTERNS + TECHNICAL_REQUEST_PATTERNS_CLEAN)
    )


def humanize_reply_text(reply):
    if reply is None:
        return ""
    return reply if isinstance(reply, str) else str(reply)
def reply_has_basic_relevance(user_msg, reply):
    user_terms = extract_query_terms(user_msg, limit=8)
    if not user_terms:
        return True
    reply_score = score_text_overlap(reply, user_terms)
    if reply_score >= 1.0:
        return True
    reply_key = normalize_text_key(reply)
    return any(term and term in reply_key for term in user_terms if len(term) >= 2)


TOPIC_ANCHOR_RULES = [
    (["论文", "错题", "作业", "刷题", "考试", "笔试", "申论", "行测"], ["论文", "题", "错题", "作业", "考试", "笔试", "申论", "行测", "开头", "标题", "写", "补", "动"]),
    (["睡不着", "失眠", "睡", "困", "晚安"], ["睡", "晚安", "歇", "闭", "缓", "陪", "我在", "睡过头"]),
    (["累", "疲惫", "难受", "委屈", "焦虑", "烦", "崩溃"], ["累", "歇", "缓", "陪", "我在", "抱", "慢慢", "先"]),
    (["在不在", "在吗", "在么", "你在吗", "在干嘛", "干嘛", "找你说", "想找你"], ["在", "怎么", "干嘛", "你说", "说吧", "找", "听着", "我听着", "找我"]),
    (["饿", "饭", "吃", "奶茶", "外卖", "晚饭"], ["饿", "饭", "吃", "外卖", "奶茶", "喝", "点", "垫"]),
    (["陪我", "陪一下", "陪一会"], ["陪", "我在", "在"]),
    (["怪", "刚才", "重说", "重来", "客服"], ["重说", "重来", "刚才", "改", "客服", "自然"]),
    (["是不是ai", "是不是 ai", "ai", "系统", "提示词", "数据库"], ["不是", "别", "正常", "聊", "我在"]),
    (["风", "冷", "刮风"], ["风", "冷", "衣服", "加件"]),
    (["洗澡", "洗完", "洗好了"], ["洗", "澡", "舒服", "热", "擦", "吹风"]),
    (["手机", "没电", "电量", "充电"], ["手机", "电", "充", "插", "关机"]),
    (["出去", "走走", "散步", "溜达"], ["出去", "走", "散", "透气", "转"]),
]


def reply_lacks_topic_anchor(user_msg, reply):
    return reply_quality.reply_lacks_topic_anchor(user_msg, reply, topic_anchor_rules=TOPIC_ANCHOR_RULES)


LM_JUDGE_PASS_SCORE = int(os.environ.get("ZHIYUE_LM_JUDGE_PASS_SCORE", "6"))
LM_JUDGE_MAX_ROUNDS = max(1, int(os.environ.get("ZHIYUE_LM_JUDGE_MAX_ROUNDS", "2")))
LAST_LM_PIPELINE = {}

# ============ 用户指令记忆系统 ============
# 检测并持久化用户指令（如"别说晚安"），在后续对话中遵守

USER_DIRECTIVES_FILE = BASE_DIR / "user_directives.json"
CHAT_DIRECTIVE_SCOPES = state_hygiene.CHAT_DIRECTIVE_SCOPES
CHAT_MEMORY_BLOCKED_SOURCE_MARKERS = state_hygiene.CHAT_MEMORY_BLOCKED_SOURCE_MARKERS
CHAT_NOTE_BLOCKED_TYPES = {"代码审查", "自我改进", "技术问题", "runtime_policy", "proposal"}


def _parse_iso_dt_soft(value):
    return state_hygiene.parse_iso_dt_soft(value)


def _source_allows_chat_inject(source):
    return state_hygiene.source_allows_chat_inject(source)


def _directive_allows_chat(directive):
    return state_hygiene.directive_allows_chat(directive)


def _memory_allows_chat_inject(item):
    return state_hygiene.memory_allows_chat_inject(item)


def _learning_note_allows_chat_inject(note_type, content, confidence, created_at):
    return state_hygiene.learning_note_allows_chat_inject(note_type, content, confidence, created_at)


def infer_chat_state_meta(*, source="", category="", mem_type="", note_type=""):
    return state_hygiene.infer_chat_state_meta(source=source, category=category, mem_type=mem_type, note_type=note_type)


def prune_expired_state(force=False):
    return state_hygiene.prune_expired_state(
        force=force,
        intimacy=intimacy,
        memory_conn=memory.conn,
        growth_conn=growth.conn,
        load_user_directives=load_user_directives,
        save_user_directives=save_user_directives,
        log_runtime_exception=log_runtime_exception,
    )


def get_state_hygiene_summary():
    return state_hygiene.get_state_hygiene_summary(
        intimacy=intimacy,
        memory_conn=memory.conn,
        growth_conn=growth.conn,
        load_user_directives=load_user_directives,
        log_runtime_exception=log_runtime_exception,
    )


def state_hygiene_reply(user_msg):
    try:
        summary = get_state_hygiene_summary()
    except Exception as err:
        log_runtime_exception("state_hygiene.reply", err)
        return None
    return state_hygiene.state_hygiene_reply(user_msg, summary)
def load_user_directives(*, for_chat=True):
    """加载用户指令列表，只返回未过期的"""
    try:
        if USER_DIRECTIVES_FILE.exists():
            data = json.loads(USER_DIRECTIVES_FILE.read_text(encoding="utf-8"))
            now = time.time()
            active = [d for d in (data if isinstance(data, list) else []) if d.get("expire_until", 0) > now]
            if for_chat:
                active = [d for d in active if _directive_allows_chat(d)]
            return active[:10]
    except (Exception,) as err:
        log_runtime_exception("load_user_directives", err)
    return []

def save_user_directives(directives):
    """保存用户指令列表"""
    try:
        normalized = []
        merged_by_action: dict[str, dict] = {}
        for item in directives or []:
            if not isinstance(item, dict):
                continue
            row = dict(item)
            row.setdefault("scope", "chat")
            row.setdefault("source", "user_chat")
            action_key = normalize_text_key(str(row.get("action") or ""))
            if not action_key:
                continue
            row["count"] = int(row.get("count") or 1)
            existing = merged_by_action.get(action_key)
            if existing:
                existing["count"] = int(existing.get("count") or 1) + int(row.get("count") or 1)
                existing["created_at"] = min(float(existing.get("created_at") or time.time()), float(row.get("created_at") or time.time()))
                existing["expire_until"] = max(float(existing.get("expire_until") or 0), float(row.get("expire_until") or 0))
                if len(str(row.get("raw") or "")) > len(str(existing.get("raw") or "")):
                    existing["raw"] = row.get("raw") or existing.get("raw")
            else:
                merged_by_action[action_key] = row
        normalized = sorted(merged_by_action.values(), key=lambda item: (-(int(item.get("count") or 1)), -(float(item.get("created_at") or 0))))
        USER_DIRECTIVES_FILE.write_text(json.dumps(normalized, ensure_ascii=False, indent=2), encoding="utf-8")
    except (Exception,) as err:
        log_runtime_exception("save_user_directives", err)


def _normalize_user_directives_for_prompt(user_directives=None):
    active_dirs = []
    if user_directives:
        active_dirs.extend([d for d in user_directives if isinstance(d, dict)])
    if False:
        active_dirs.extend([d for d in load_user_directives() if isinstance(d, dict)])
    if not active_dirs:
        return []
    deduped = []
    seen_actions: set[str] = set()
    for d in active_dirs:
        action = str(d.get("action") or "").strip()
        if not action:
            continue
        action_key = normalize_text_key(action)
        if not action_key or action_key in seen_actions:
            continue
        seen_actions.add(action_key)
        deduped.append(d)
    return deduped[:10]


def _build_user_directive_block(user_directives=None):
    active_dirs = _normalize_user_directives_for_prompt(
        user_directives
    )
    if not active_dirs:
        return ""
    dir_lines = [f"- 不要{d.get('action', '')}" for d in active_dirs if d.get("action")]
    if not dir_lines:
        return ""
    return "【用户有效指令-必须遵守】\n" + "\n".join(dir_lines) + "\n---以上指令在后续对话中持续生效，不可违反---\n\n"

def detect_user_directive(user_msg):
    """检测用户消息中的指令（不要X/别X/不许X），返回指令dict或None"""
    msg = (user_msg or "").strip()
    if not msg:
        return None
    # 检测模式：扩展覆盖更多自然表达
    patterns = [
        # 不要再说/别再/不许再 + X
        r"(?:不要再说|别再说|不许再)(.{1,20}?)(?:了|啊|嘛|好吧?|行吧?|好吗?|[。！!]|$)",
        # 不要/别/不许 + 和/跟 + X + Y（如"不许和我说晚安"）
        r"(?:不要|别|不许)(和.{1,18}?)(?:了|啊|嘛|好吧?|行吧?|好吗?|[。！!]|$)",
        r"(?:不要|别|不许)(跟.{1,18}?)(?:了|啊|嘛|好吧?|行吧?|好吗?|[。！!]|$)",
        # 不要/别/不许 + X（宽松结尾，含句末）
        r"(?:不要|别|不许)(.{1,20}?)(?:了|啊|嘛|好吧?|行吧?|好吗?|[。！!]|$)",
        # 你不要/你别/你不许 + X
        r"(?:你)(?:不要|别|不许)(.{1,20}?)(?:了|啊|嘛|好吧?|行吧?|好吗?|[。！!]|$)",
        # 不准/不可以 + X
        r"(?:不准|不可以)(.{1,20}?)(?:了|啊|嘛|好吧?|行吧?|好吗?|[。！!]|$)",
    ]
    _stop_words = {'了', '啊', '嘛', '的', '吧', '呢', '呀', '哦', '哈', '嗯'}
    for pattern in patterns:
        match = re.search(pattern, msg)
        if match:
            action = match.group(1).strip()
            # 过滤掉太短或纯语气词的误匹配
            if action and action not in _stop_words and len(action) >= 2:
                return {
                    "action": action,
                    "raw": msg[:100],
                    "created_at": time.time(),
                    "scope": "chat",
                    "source": "user_chat",
                    "expire_until": time.time() + 86400 * 90,
                    "count": 1,
                }
    return None


def maybe_promote_directives_to_skills():
    return learning_controller.maybe_promote_directives_to_skills(
        layers=layers,
        load_user_directives=load_user_directives,
    )

# ============ 工具调用系统 (Function Calling) ============
# 让张致悦能"自己读取"代码文件，用于回答用户关于自身代码/设置的问题

ZHIYUE_TOOLS_ENABLED = os.environ.get("ZHIYUE_TOOLS_ENABLED", "1").strip().lower() not in {"0", "false", "no", "off"}
ZHIYUE_TOOL_MAX_STEPS = int(os.environ.get("ZHIYUE_TOOL_MAX_STEPS", "3"))
ZHIYUE_TOOL_SOURCE_DIR = os.environ.get("ZHIYUE_TOOL_SOURCE_DIR", str(BASE_DIR))
ZHIYUE_ENABLED_TOOLSETS = {
    item.strip().lower()
    for item in os.environ.get("ZHIYUE_ENABLED_TOOLSETS", "filesystem,proposal").split(",")
    if item.strip()
}

# 工具定义 (OpenAI function calling 格式)

# ── Qwen-Agent 自定义工具类 ──────────────────────────────
try:
    from qwen_agent.tools.base import BaseTool  # type: ignore
except (ImportError) as e:
    class BaseTool:
        pass


def register_tool(cls):
    return cls

TOOLSET_BY_TOOL_NAME = {
    "read_file": "filesystem",
    "search_in_file": "filesystem",
    "list_files": "filesystem",
    "propose_edit": "proposal",
}


def _tool_enabled(tool_name):
    toolset = TOOLSET_BY_TOOL_NAME.get(tool_name, "custom")
    return toolset in ZHIYUE_ENABLED_TOOLSETS


def _active_tool_names():
    return [name for name in TOOLSET_BY_TOOL_NAME if _tool_enabled(name)]

class _ZhiyueReadFile(BaseTool):
    name = "read_file"
    description = "读取指定文件的文本内容。用于查看代码、配置文件等。参数path是相对于项目根目录的文件路径。"
    parameters = {
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "文件路径，相对于项目根目录。例如: zhiyue_connected.py"},
            "max_lines": {"type": "integer", "description": "最多读取的行数，默认200行", "default": 200},
            "start_line": {"type": "integer", "description": "从第几行开始读取，默认从第1行", "default": 1},
        },
        "required": ["path"],
    }

    def call(self, params, **kwargs):
        args = params if isinstance(params, dict) else {}
        file_path = args.get("path", "")
        max_lines = int(args.get("max_lines", 200))
        start_line = int(args.get("start_line", 1))
        try:
            _, file_path, full_path = _resolve_tool_file_path(file_path)
        except Exception:
            return "错误: 无效的文件路径"
        if not full_path.exists():
            return f"文件不存在: {file_path}"
        if not full_path.is_file():
            return f"不是文件: {file_path}"
        try:
            lines = full_path.read_text(encoding="utf-8", errors="replace").splitlines()
            end_line = start_line + max_lines
            selected = lines[start_line - 1:end_line]
            header = f"[文件: {file_path} (第{start_line}-{min(end_line, len(lines))}行，共{len(lines)}行)]"
            return header + "\n" + "\n".join(f"{start_line + i:>5} | {line}" for i, line in enumerate(selected))
        except Exception as e:
            return f"读取失败: {e}"


class _ZhiyueSearchInFile(BaseTool):
    name = "search_in_file"
    description = "在指定文件中搜索包含特定关键词的代码行及其上下文。用于快速定位代码位置。"
    parameters = {
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "文件路径，相对于项目根目录"},
            "keyword": {"type": "string", "description": "要搜索的关键词"},
            "context_lines": {"type": "integer", "description": "返回匹配行前后各多少行上下文，默认5", "default": 5},
        },
        "required": ["path", "keyword"],
    }

    def call(self, params, **kwargs):
        args = params if isinstance(params, dict) else {}
        file_path = args.get("path", "")
        keyword = args.get("keyword", "")
        ctx = int(args.get("context_lines", 5))
        try:
            _, file_path, full_path = _resolve_tool_file_path(file_path)
        except Exception:
            return "错误: 无效的文件路径"
        if not full_path.exists():
            return f"文件不存在: {file_path}"
        try:
            lines = full_path.read_text(encoding="utf-8", errors="replace").splitlines()
            matches = []
            for i, line in enumerate(lines):
                if keyword in line:
                    start = max(0, i - ctx)
                    end = min(len(lines), i + ctx + 1)
                    snippet = "\n".join(f"{s+1:>5} | {lines[s]}" for s in range(start, end))
                    matches.append(f"[匹配于第{i+1}行]\n{snippet}")
            if not matches:
                return f"在 {file_path} 中未找到关键词 '{keyword}'"
            result = f"[文件: {file_path}, 关键词: '{keyword}', 共{len(matches)}处匹配]\n"
            result += "\n---\n".join(matches[:10])
            return result
        except Exception as e:
            return f"搜索失败: {e}"


class _ZhiyueListFiles(BaseTool):
    name = "list_files"
    description = "列出项目目录中的文件。用于了解项目结构。"
    parameters = {
        "type": "object",
        "properties": {
            "pattern": {"type": "string", "description": "文件名模式过滤，例如 *.py 或 *.json，留空列出所有文件", "default": ""},
        },
        "required": [],
    }

    def call(self, params, **kwargs):
        args = params if isinstance(params, dict) else {}
        source_dir = Path(ZHIYUE_TOOL_SOURCE_DIR)
        pattern = args.get("pattern", "")
        try:
            items = []
            for p in source_dir.iterdir():
                if p.is_file():
                    if not pattern or fnmatch.fnmatch(p.name, pattern):
                        items.append(p.name)
            items.sort()
            if not items:
                return "目录中没有匹配的文件"
            return "项目文件:\n" + "\n".join(items)
        except Exception as e:
            return f"列出失败: {e}"


class _ZhiyueProposeEdit(BaseTool):
    name = "propose_edit"
    description = "提出代码修改建议。不会直接修改代码，而是创建一个修改提案，需要用户审批后才会执行。用于当你认为代码需要改进时。"
    parameters = {
        "type": "object",
        "properties": {
            "target_file": {"type": "string", "description": "要修改的目标文件路径，相对于项目根目录"},
            "title": {"type": "string", "description": "修改标题，简短描述要改什么"},
            "description": {"type": "string", "description": "修改的具体描述，说明为什么要改、怎么改"},
            "risk": {"type": "string", "description": "风险等级：low/medium/high", "enum": ["low", "medium", "high"], "default": "medium"},
        },
        "required": ["target_file", "title", "description"],
    }

    def call(self, params, **kwargs):
        args = params if isinstance(params, dict) else {}
        target_file = args.get("target_file", "")
        title = args.get("title", "")
        description = args.get("description", "")
        risk = args.get("risk", "medium")
        try:
            if not layers or not hasattr(layers, "self_improvement"):
                return "错误: 自我改进模块未加载"
            candidate = layers.self_improvement.record_candidate(
                source="tool_call",
                category="tool_call.propose_edit",
                title=f"[Tool] {title}",
                recommendation=description[:800],
                evidence=[],
                impact=f"修改 {target_file}: {title}",
                risk=risk,
                meta={"tool_proposed": True, "target_file": target_file, "description": description},
            )
            candidate_id = candidate.get("id", "")
            proposal = layers.self_improvement.create_code_proposal(
                source_type="candidate",
                source_id=candidate_id,
                status="draft",
                meta={
                    "tool_proposed": True,
                    "fix_template": {"title": title, "rationale": description, "target_files": [target_file]},
                },
            )
            proposal_id = proposal.get("id", "")
            return (f"已创建修改提案:\n"
                    f"- 提案ID: {proposal_id}\n"
                    f"- 目标文件: {target_file}\n"
                    f"- 修改内容: {title}\n"
                    f"- 风险等级: {risk}\n"
                    f"提案已创建，等待用户审批后才会执行修改。")
        except Exception as e:
            return f"创建提案失败: {e}"


# Qwen-Agent FnCallAgent 实例（懒初始化）
_qa_agent_instance = None
_qa_agent_llm_cfg = None

def _get_qa_agent():
    """获取或创建Qwen-Agent FnCallAgent单例。"""
    global _qa_agent_instance, _qa_agent_llm_cfg
    if _qa_agent_instance is None:
        try:
            from qwen_agent.agents import FnCallAgent
        except Exception as err:
            log_runtime_exception("qwen_agent.import", err)
            return None
        _qa_agent_llm_cfg = {
            "model": LM_MODEL,
            "model_server": LM_URL.rstrip("/chat/completions"),
            "model_type": "oai",
            "generate_cfg": {
                "max_retries": 2,
            },
        }
        import importlib
        pu = importlib.import_module("zhiyue_prompt_utils")
        stage = ""
        try:
            stage = intimacy.get_stage()
        except (Exception,) as err:
            log_runtime_exception("restored_reply_learn", err)
        system_message = (
            f"你是张致悦，当前关系阶段：{stage}。"
            "语气温柔、感性、口语化。只用中文回复。"
            "直接以口语化对话开始，不要任何前缀或说明。回复通常2-4句。\n\n"
            "【关键指令】当用户要求你查看/分析/梳理代码时：\n"
            "1. 你必须先调用工具( read_file/list_files/search_in_file )读取代码\n"
            "2. 绝对不能凭记忆回答，必须读取实际代码内容\n"
            "3. 禁止跳过工具调用直接回复\n"
            "4. 调用工具后必须分析结果再给最终回复\n"
            "违反上述规则将导致严重后果！"
        )
        function_list = []
        if _tool_enabled("read_file"):
            function_list.append(_ZhiyueReadFile())
        if _tool_enabled("search_in_file"):
            function_list.append(_ZhiyueSearchInFile())
        if _tool_enabled("list_files"):
            function_list.append(_ZhiyueListFiles())
        if _tool_enabled("propose_edit"):
            function_list.append(_ZhiyueProposeEdit())
        if not function_list:
            return None
        _qa_agent_instance = FnCallAgent(
            function_list=function_list,
            llm=_qa_agent_llm_cfg,
            system_message=system_message,
            name="zhiyue_tool_agent",
        )
    return _qa_agent_instance


TOOL_DEFINITIONS = [
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "读取指定文件的文本内容。用于查看代码、配置文件等。参数path是相对于项目根目录的文件路径。",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "文件路径，相对于项目根目录。例如: zhiyue_connected.py, config.json"
                    },
                    "max_lines": {
                        "type": "integer",
                        "description": "最多读取的行数，默认200行",
                        "default": 200
                    },
                    "start_line": {
                        "type": "integer",
                        "description": "从第几行开始读取，默认从第1行",
                        "default": 1
                    }
                },
                "required": ["path"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "search_in_file",
            "description": "在指定文件中搜索包含特定关键词的代码行及其上下文。用于快速定位代码位置。",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "文件路径，相对于项目根目录"
                    },
                    "keyword": {
                        "type": "string",
                        "description": "要搜索的关键词"
                    },
                    "context_lines": {
                        "type": "integer",
                        "description": "返回匹配行前后各多少行上下文，默认5",
                        "default": 5
                    }
                },
                "required": ["path", "keyword"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "list_files",
            "description": "列出项目目录中的文件。用于了解项目结构。",
            "parameters": {
                "type": "object",
                "properties": {
                    "pattern": {
                        "type": "string",
                        "description": "文件名模式过滤，例如 *.py 或 *.json，留空列出所有文件",
                        "default": ""
                    }
                },
                "required": []
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "propose_edit",
            "description": "提出代码修改建议。不会直接修改代码，而是创建一个修改提案，需要用户审批后才会执行。用于当你认为代码需要改进时。",
            "parameters": {
                "type": "object",
                "properties": {
                    "target_file": {
                        "type": "string",
                        "description": "要修改的目标文件路径，相对于项目根目录"
                    },
                    "title": {
                        "type": "string",
                        "description": "修改标题，简短描述要改什么"
                    },
                    "description": {
                        "type": "string",
                        "description": "修改的具体描述，说明为什么要改、怎么改"
                    },
                    "risk": {
                        "type": "string",
                        "description": "风险等级：low/medium/high",
                        "enum": ["low", "medium", "high"],
                        "default": "medium"
                    }
                },
                "required": ["target_file", "title", "description"]
            }
        }
    }
]


def get_active_tool_definitions():
    active = []
    for item in TOOL_DEFINITIONS:
        try:
            name = (((item or {}).get("function") or {}).get("name") or "").strip()
        except Exception:
            name = ""
        if name and _tool_enabled(name):
            active.append(item)
    return active

# 元消息关键词: 用户在讨论代码/设置/系统行为时触发工具调用
_TOOL_META_KEYWORDS = [
    # 代码/系统相关（原有）
    "代码", "程序", "逻辑", "设置", "配置", "规则", "触发", "拦截",
    "兜底", "字数", "提示词", "源码", "后台", "怎么回复", "怎么回答",
    "怎么看", "看看你", "你哪里", "你什么", "写的什么", "怎么写的",
    "那段", "那个功能", "什么逻辑", "怎么实现的", "哪个代码",
    "优化", "值得优化", "代码哪里", "看看这些代码",
    # 用户行为反馈/抱怨（新增）
    "不听", "没听", "不理", "不听我的", "不让我", "总是", "一直",
    "为什么", "怎么回事", "排查", "上下文", "指代", "上一轮", "刚才",
    "你说过", "你又", "还是", "改不了", "没改", "没用",
    "行为", "回复方式", "说话方式", "态度", "性格",
]

TECHNICAL_REQUEST_PATTERNS = [
    "代码", "程序", "逻辑", "设置", "配置", "规则", "触发", "拦截",
    "兜底", "字数", "提示词", "源码", "后台", "优化", "排查",
    "联调", "调试", "语音联调", "媒体联调", "微信联调",
    "怎么回复", "怎么回答", "怎么看", "看看你", "你哪里", "你什么",
    "写的什么", "怎么写的", "那段", "那个功能", "什么逻辑",
    "怎么实现的", "哪个代码", "值得优化", "代码哪里", "看看这些代码",
    "不听", "没听", "不理", "不听我的", "不让我", "总是", "一直",
    "为什么", "怎么回事", "上下文", "指代", "上一轮", "刚才",
    "你说过", "你又", "还是", "改不了", "没改", "没用",
    "行为", "回复方式", "说话方式", "态度", "性格", "帮我挑刺",
]

TECHNICAL_REQUEST_PATTERNS_CLEAN = [
    "代码", "源码", "文件", "规则", "逻辑", "接口", "工具调用", "兜底",
    "触发", "优化", "排查", "分析", "看看", "读一下", "实现", "联调", "调试",
    "哪里有问题", "哪里值得优化", "最该拆", "误伤正常回复", "技术问题",
]


def _should_use_tools(user_msg):
    """判断用户消息是否需要触发工具调用（讨论代码/系统行为时启用）。"""
    if not ZHIYUE_TOOLS_ENABLED:
        _dbg.debug("[tools] DISABLED: ZHIYUE_TOOLS_ENABLED=%s", ZHIYUE_TOOLS_ENABLED)
        return False
    if not _active_tool_names():
        _dbg.debug("[tools] DISABLED: no active toolsets")
        return False
    raw_msg = (user_msg or "").strip()
    msg = normalize_technical_text(raw_msg)
    if not msg:
        return False
    hits = [k for k in (TECHNICAL_REQUEST_PATTERNS + TECHNICAL_REQUEST_PATTERNS_CLEAN) if normalize_technical_text(k) in msg]
    if not hits and any(ext in raw_msg.lower() for ext in [".py", ".json", ".yaml", ".yml", ".toml"]):
        if any(term in msg for term in [normalize_technical_text(item) for item in ["文件", "读一下", "读取", "看看", "分析", "代码"]]):
            hits = ["file_intent"]
    if not hits:
        hits = [k for k in _TOOL_META_KEYWORDS if isinstance(k, str) and normalize_technical_text(k) in msg]
    result = bool(hits)
    _dbg.debug("[tools] should_use_tools: msg=%r norm=%r hits=%s => %s", raw_msg[:60], msg[:60], hits, result)
    return result


def _normalize_tool_path(raw_path):
    path = str(raw_path or "").strip()
    path = path.strip("`'\" ")
    path = path.replace("\\", "/")
    source_dir = Path(ZHIYUE_TOOL_SOURCE_DIR).resolve()
    source_parts = [part.lower() for part in source_dir.parts if part not in ("\\", "/")]
    candidate_parts = [part for part in Path(path).parts if part not in ("\\", "/")]
    lower_candidate_parts = [part.lower() for part in candidate_parts]
    if source_parts and len(lower_candidate_parts) >= len(source_parts) and lower_candidate_parts[:len(source_parts)] == source_parts:
        candidate_parts = candidate_parts[len(source_parts):]
        path = "/".join(candidate_parts)
    path = re.sub(r"^[A-Za-z]:/", "", path)
    path = re.sub(r"^/+", "", path)
    path = re.sub(r"^\./+", "", path)
    if "/" in path:
        parts = [part for part in path.split("/") if part not in ("", ".")]
        if parts:
            path = "/".join(parts)
    return path


def _resolve_tool_file_path(raw_path):
    source_dir = Path(ZHIYUE_TOOL_SOURCE_DIR).resolve()
    file_path = _normalize_tool_path(raw_path)
    full_path = (source_dir / file_path).resolve()
    try:
        full_path.relative_to(source_dir)
    except Exception:
        raise ValueError("path outside source dir")
    return source_dir, file_path, full_path


def _execute_tool(tool_name, arguments):
    """执行工具调用，返回结果文本。"""
    args = arguments if isinstance(arguments, dict) else {}
    source_dir = Path(ZHIYUE_TOOL_SOURCE_DIR).resolve()
    if not _tool_enabled(tool_name):
        return f"工具已禁用: {tool_name}"

    if tool_name == "read_file":
        file_path = args.get("path", "")
        max_lines = int(args.get("max_lines", 200))
        start_line = int(args.get("start_line", 1))
        try:
            _, file_path, full_path = _resolve_tool_file_path(file_path)
        except Exception:
            return f"错误: 无效的文件路径"
        if not full_path.exists():
            return f"文件不存在: {file_path}"
        if not full_path.is_file():
            return f"不是文件: {file_path}"
        try:
            lines = full_path.read_text(encoding="utf-8", errors="replace").splitlines()
            end_line = start_line + max_lines
            selected = lines[start_line - 1:end_line]
            header = f"[文件: {file_path} (第{start_line}-{min(end_line, len(lines))}行，共{len(lines)}行)]"
            return header + "\n" + "\n".join(f"{start_line + i:>5} | {line}" for i, line in enumerate(selected))
        except Exception as e:
            return f"读取失败: {e}"

    elif tool_name == "search_in_file":
        file_path = args.get("path", "")
        keyword = args.get("keyword", "")
        ctx = int(args.get("context_lines", 5))
        try:
            _, file_path, full_path = _resolve_tool_file_path(file_path)
        except Exception:
            return f"错误: 无效的文件路径"
        if not full_path.exists():
            return f"文件不存在: {file_path}"
        try:
            lines = full_path.read_text(encoding="utf-8", errors="replace").splitlines()
            matches = []
            for i, line in enumerate(lines):
                if keyword in line:
                    start = max(0, i - ctx)
                    end = min(len(lines), i + ctx + 1)
                    snippet = "\n".join(f"{s+1:>5} | {lines[s]}" for s in range(start, end))
                    matches.append(f"[匹配于第{i+1}行]\n{snippet}")
            if not matches:
                return f"在 {file_path} 中未找到关键词 '{keyword}'"
            result = f"[文件: {file_path}, 关键词: '{keyword}', 共{len(matches)}处匹配]\n"
            result += "\n---\n".join(matches[:10])  # 最多返回10处匹配
            return result
        except Exception as e:
            return f"搜索失败: {e}"

    elif tool_name == "list_files":
        pattern = args.get("pattern", "")
        try:
            items = []
            for p in source_dir.iterdir():
                if p.is_file():
                    if not pattern or fnmatch.fnmatch(p.name, pattern):
                        items.append(p.name)
            items.sort()
            if not items:
                return "目录中没有匹配的文件"
            return "项目文件:\n" + "\n".join(items)
        except Exception as e:
            return f"列出失败: {e}"

    elif tool_name == "propose_edit":
        target_file = args.get("target_file", "")
        title = args.get("title", "")
        description = args.get("description", "")
        risk = args.get("risk", "medium")
        try:
            if not layers or not hasattr(layers, "self_improvement"):
                return "错误: 自我改进模块未加载"
            # 创建 candidate
            candidate = layers.self_improvement.record_candidate(
                source="tool_call",
                category="tool_call.propose_edit",
                title=f"[Tool] {title}",
                recommendation=description[:800],
                evidence=[],
                impact=f"修改 {target_file}: {title}",
                risk=risk,
                meta={
                    "tool_proposed": True,
                    "target_file": target_file,
                    "description": description,
                },
            )
            candidate_id = candidate.get("id", "")
            # 创建 proposal
            proposal = layers.self_improvement.create_code_proposal(
                source_type="candidate",
                source_id=candidate_id,
                status="draft",
                meta={
                    "tool_proposed": True,
                    "fix_template": {
                        "title": title,
                        "rationale": description,
                        "target_files": [target_file],
                    },
                },
            )
            proposal_id = proposal.get("id", "")
            _dbg.debug("[tool_loop] propose_edit: candidate=%s, proposal=%s", candidate_id, proposal_id)
            return (f"已创建修改提案:\n"
                    f"- 提案ID: {proposal_id}\n"
                    f"- 目标文件: {target_file}\n"
                    f"- 修改内容: {title}\n"
                    f"- 风险等级: {risk}\n"
                    f"提案已创建，等待用户审批后才会执行修改。")
        except Exception as e:
            return f"创建提案失败: {e}"

    return f"未知工具: {tool_name}"


def _request_lm_with_tools(messages, tools, *, max_tokens=512, temperature=0.5):
    """发送带工具定义的LLM请求，返回完整的API响应JSON。"""
    payload = {
        "model": LM_MODEL,
        "messages": messages,
        "tools": tools,
        "tool_choice": "auto",
        "stream": False,
        "max_tokens": max_tokens,
        "temperature": temperature,
    }
    if LM_STOP_STRINGS:
        payload["stop"] = LM_STOP_STRINGS
    resp = _post_lm_payload(payload, timeout=120)
    if resp.status_code >= 400:
        raise RuntimeError(f"tool call LM error {resp.status_code}: {resp.text[:300]}")
    return resp.json()


def run_tool_loop(user_msg, history):
    """
    工具调用循环: 使用Qwen-Agent FnCallAgent进行智能工具编排。
    比手写循环更可靠：自动处理多轮tool call、中途放弃检测、最终回复生成。
    """
    import importlib
    pu = importlib.import_module("zhiyue_prompt_utils")

    _TL = str(TOOL_LOOP_LOG)
    def _tl(msg):
        with open(_TL, "a", encoding="utf-8") as _f:
            _f.write(f"{now_local():%H:%M:%S} {msg}\n")

    _tl(f"STARTED (qwen-agent) for msg={user_msg[:50]!r}")

    try:
        if not _active_tool_names():
            _tl("aborted: no active tools")
            return None
        agent = _get_qa_agent()
        technical_mode = is_technical_request(user_msg)

        # 构建消息历史
        normalized = sanitize_prompt_history(history or [])
        messages = []
        # 取最近4轮对话作为上下文
        for msg in normalized[-4:]:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            if role == "system":
                continue  # system message由agent的system_message处理
            messages.append({"role": role, "content": content})
        messages.append({"role": "user", "content": pu.build_model_user_message(user_msg)})

        _tl(f"sending to agent, messages={len(messages)}")

        # 调用Qwen-Agent（非流式）
        responses = []
        saw_file_tool = False
        for rsp_list in agent.run(messages=messages, lang="zh"):
            responses.extend(rsp_list)

        # 从响应中提取最终文本回复
        final_text = ""
        for rsp in responses:
            if hasattr(rsp, "content") and rsp.content:
                # 排除function角色消息
                role = getattr(rsp, "role", "")
                if role == "function":
                    tool_name = getattr(rsp, "name", "") or getattr(rsp, "tool_name", "")
                    if tool_name in {"read_file", "search_in_file", "list_files"}:
                        saw_file_tool = True
                if role != "function":
                    final_text = rsp.content
            elif isinstance(rsp, dict):
                role = rsp.get("role", "")
                content = rsp.get("content", "")
                if role == "function":
                    tool_name = rsp.get("name", "") or rsp.get("tool_name", "")
                    if tool_name in {"read_file", "search_in_file", "list_files"}:
                        saw_file_tool = True
                if role != "function" and content:
                    final_text = content

        _tl(f"agent returned: {final_text[:120]!r} file_tool={saw_file_tool}")

        if final_text:
            raw = strip_thinking_text(final_text)
            if not raw:
                raw = extract_final_from_reasoning(final_text)
            if raw:
                cleaned = clean_reply_for_mode(raw, technical=technical_mode)
                if technical_mode and (not saw_file_tool or is_tool_deflection_reply(cleaned)):
                    _tl(f"agent reply rejected: deflection={is_tool_deflection_reply(cleaned)} file_tool={saw_file_tool}")
                    return None
                return cleaned

        _tl(f"agent returned empty/no text")
        return None

    except Exception as e:
        _tl(f"qwen-agent FAILED: {e}")
        import traceback
        traceback.print_exc()
        return None

def safe_json_loads(raw, default=None):
    try:
        return json.loads(raw)
    except Exception:
        return default


def _request_lm_json(messages, schema_name, schema, *, temperature=0.0, max_tokens=256, timeout=120):
    body = {
        "model": LM_MODEL,
        "messages": messages,
        "stream": False,
        "think_disabled": True,
        "enable_thinking": False,
        "preserve_thinking": False,
        "temperature": temperature,
        "top_p": 1,
        "top_k": LM_TOP_K,
        "repeat_penalty": LM_REPEAT_PENALTY,
        "max_tokens": max_tokens,
        "response_format": {
            "type": "json_schema",
            "json_schema": {
                "name": schema_name,
                "schema": schema,
                "strict": True,
            },
        },
    }
    if LM_STOP_STRINGS:
        body["stop"] = LM_STOP_STRINGS
    response = _provider_post_chat_completion("main", body, timeout=timeout)
    response.raise_for_status()
    data = response.json()
    content = ""
    if isinstance(data, dict):
        choices = data.get("choices") or []
        if choices and isinstance(choices[0], dict):
            message = choices[0].get("message")
            if isinstance(message, dict):
                content = str(message.get("content") or "")
                if not content:
                    content = str(message.get("reasoning_content") or "")
            else:
                content = str(choices[0].get("text") or "")
    parsed = safe_json_loads(content, None)
    if not isinstance(parsed, dict):
        start = content.find("{")
        end = content.rfind("}")
        if start != -1 and end != -1 and end > start:
            parsed = safe_json_loads(content[start:end + 1], None)
    if not isinstance(parsed, dict):
        raise ValueError("judge json parse failed")
    return parsed


def plan_weixin_media_actions(user_msg, reply, *, channel="web"):
    if "weixin" not in str(channel or "").lower():
        return {}
    return {
        "media_actions": [],
        "media_policy": {"auto_voice": False, "auto_emoji": False},
    }
def sanitize_weixin_temporal_reply(user_msg, reply):
    _ = user_msg
    return reply if isinstance(reply, str) else ("" if reply is None else str(reply))
def _parse_lm_response(resp):
    if resp.status_code >= 400:
        return "", f"HTTP {resp.status_code}: {resp.text[:300]}"
    try:
        data = resp.json()
        message = data["choices"][0]["message"]
    except Exception as err:
        return "", f"invalid LM json: {err}"
    raw = strip_thinking_text(message.get("content") or "")
    if not raw:
        raw = extract_final_from_reasoning(message.get("reasoning_content") or "")
    return clean_reply(raw), ""


def _post_lm_payload(request_payload, timeout=180):
    body = json.dumps(request_payload, ensure_ascii=False).encode("utf-8")
    payload = json.loads(body.decode("utf-8", errors="replace")) if body else {}
    return _provider_post_chat_completion("main", payload, timeout=timeout)


def _request_lm_text(
    messages,
    *,
    user_msg="",
    normalized_history=None,
    use_compact=False,
    max_tokens=640,
    temperature=None,
    top_p=None,
    user_directives=None,
):
    payload = {
        "model": LM_MODEL,
        "messages": messages,
        "stream": False,
        "max_tokens": max_tokens,
        "think_disabled": not LM_THINKING_ENABLED,
        "enable_thinking": LM_THINKING_ENABLED,
        "preserve_thinking": False,
        "temperature": LM_TEMPERATURE if temperature is None else temperature,
        "top_p": LM_TOP_P if top_p is None else top_p,
        "top_k": LM_TOP_K,
        "repeat_penalty": LM_REPEAT_PENALTY,
    }
    if LM_STOP_STRINGS:
        payload["stop"] = LM_STOP_STRINGS
    if LM_PRESENCE_PENALTY:
        payload["presence_penalty"] = LM_PRESENCE_PENALTY
    if LM_FREQUENCY_PENALTY:
        payload["frequency_penalty"] = LM_FREQUENCY_PENALTY

    resp = _post_lm_payload(payload)
    if resp.status_code >= 400 and "Context size has been exceeded" in resp.text:
        retry_payload = dict(payload)
        retry_payload["messages"] = trim_prompt_messages(messages, keep_pairs=3)
        retry_payload["max_tokens"] = min(LM_MAX_TOKENS, 320)
        resp = _post_lm_payload(retry_payload)
    if resp.status_code >= 400 and "Context size has been exceeded" in resp.text:
        retry_payload = dict(payload)
        retry_payload["messages"] = trim_prompt_messages(messages, keep_pairs=1)
        retry_payload["max_tokens"] = min(LM_MAX_TOKENS, 240)
        retry_payload["think_disabled"] = True
        retry_payload["enable_thinking"] = False
        retry_payload["preserve_thinking"] = False
        resp = _post_lm_payload(retry_payload)
    if resp.status_code >= 400 and "Context size has been exceeded" in resp.text:
        retry_payload = dict(payload)
        retry_payload["messages"] = build_compact_growth_prompt(
            user_msg,
            normalized_history or [],
            user_directives=user_directives,
        )
        retry_payload["max_tokens"] = min(LM_MAX_TOKENS, 220)
        retry_payload["think_disabled"] = True
        retry_payload["enable_thinking"] = False
        retry_payload["preserve_thinking"] = False
        retry_payload["temperature"] = min(0.75, float(payload["temperature"]))
        resp = _post_lm_payload(retry_payload)
    raw, parse_error = _parse_lm_response(resp)
    if parse_error and not raw:
        retry_payload = dict(payload)
        retry_payload["messages"] = build_compact_growth_prompt(
            user_msg,
            [],
            user_directives=user_directives,
        )
        retry_payload["max_tokens"] = min(224, int(LM_MAX_TOKENS or 224))
        retry_payload["temperature"] = min(0.68, float(payload["temperature"]))
        retry_payload["top_p"] = min(0.9, max(0.75, float(payload["top_p"])))
        time.sleep(0.6)
        resp = _post_lm_payload(retry_payload)
        raw, parse_error = _parse_lm_response(resp)
    if not raw and LM_THINKING_ENABLED:
        retry_payload = dict(payload)
        retry_payload["think_disabled"] = True
        retry_payload["enable_thinking"] = False
        retry_payload["preserve_thinking"] = False
        retry_payload["max_tokens"] = 288
        resp = _post_lm_payload(retry_payload)
        raw, parse_error = _parse_lm_response(resp)
    if parse_error and not raw:
        raise RuntimeError(parse_error)
    return clean_reply(raw)


def _attempt_self_diagnose_and_reply(user_msg, *, user_directives=None):
    _ = (user_msg, user_directives, False)
    return None
def _build_technical_failure_pipeline(code, user_msg, judge_trace=None):
    """构建技术硬失败管线结果——不是兜底回复，是明确的技术错误状态。"""
    _ = user_msg
    return {
        "reply": "",
        "error": True,
        "error_code": code,
        "error_message": LAST_LM_ERROR,
        "judge": {
            "passed": False,
            "score": 0,
            "issues": ["lm_unavailable"],
            "reason": LAST_LM_ERROR,
        },
        "judge_trace": judge_trace or [],
        "reply_source": "technical_failure_" + code,
        "reply_repaired": False,
    }


def classify_user_feedback_with_model(user_msg, reply=""):
    msg = (user_msg or "").strip()
    if not msg:
        return {
            "label": "neutral",
            "needs_action": False,
            "problem_report": False,
            "approval": False,
            "rejection": False,
            "reason": "empty message",
        }
    try:
        schema = {
            "type": "object",
            "properties": {
                "label": {"type": "string"},
                "needs_action": {"type": "boolean"},
                "problem_report": {"type": "boolean"},
                "approval": {"type": "boolean"},
                "rejection": {"type": "boolean"},
                "reason": {"type": "string"},
            },
            "required": ["label", "needs_action", "problem_report", "approval", "rejection", "reason"],
            "additionalProperties": False,
        }
        parsed = _request_lm_json(
            [
                {
                    "role": "system",
                    "content": (
                        "你是中文对话反馈分类器。只输出JSON。"
                        "label 只能是 approval、rejection、problem_report、request_change、neutral 五种之一。"
                        "指出回复问题、说偏题、模板化、乱码、外语、答非所问时,label 应为 problem_report。"
                        "明确同意、肯定、确认时,label 应为 approval。"
                        "明确否定、拒绝、不要这样做时,label 应为 rejection。"
                    ),
                },
                {
                    "role": "user",
                    "content": json.dumps({"user_msg": msg, "assistant_reply": reply or ""}, ensure_ascii=False, indent=2),
                },
            ],
            "feedback_classifier",
            schema,
            temperature=0.0,
            max_tokens=160,
            timeout=90,
        )
        label = str(parsed.get("label") or "neutral").strip() or "neutral"
        if label not in {"approval", "rejection", "problem_report", "request_change", "neutral"}:
            label = "neutral"
        return {
            "label": label,
            "needs_action": bool(parsed.get("needs_action")),
            "problem_report": bool(parsed.get("problem_report")) or label == "problem_report",
            "approval": bool(parsed.get("approval")) or label == "approval",
            "rejection": bool(parsed.get("rejection")) or label == "rejection",
            "reason": str(parsed.get("reason") or "")[:240],
        }
    except Exception as err:
        return {
            "label": "neutral",
            "needs_action": False,
            "problem_report": False,
            "approval": False,
            "rejection": False,
            "reason": f"feedback classifier unavailable: {err}",
        }


def judge_reply_runtime(user_msg, reply, *, route_hint="", recalled=None):
    text = clean_reply(reply)
    judge_signals = []
    if not text or is_placeholder_reply(text):
        judge_signals.append("empty_or_placeholder")
    if has_prompt_leak(text) or is_ooc_reply(text):
        judge_signals.append("template_or_system_leak")
    if reply_lacks_topic_anchor(user_msg, text):
        judge_signals.append("missing_anchor")
    mojibake_chars = ["?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?"]
    if sum(text.count(item) for item in mojibake_chars) >= 2:
        judge_signals.append("garbled_text")
    if re.search(r"(^|\n)\s*[-*]\s+", text) or re.search(r"(^|\n)\s*\d+[\.?]\s+", text):
        judge_signals.append("too_structured")
    prompt_pollution_terms = [
        "????", "?????", "????", "????", "????",
        "????", "??????", "??????", "????",
    ]
    if any(term in text for term in prompt_pollution_terms):
        judge_signals.append("template_or_system_leak")
    norm_user = normalize_reply_signature(user_msg)
    norm_reply = normalize_reply_signature(text)
    if norm_user and norm_reply and norm_user == norm_reply:
        judge_signals.append("meaningless_text")
    schema = {
        "type": "object",
        "properties": {
            "passed": {"type": "boolean"},
            "score": {"type": "integer"},
            "issues": {"type": "array", "items": {"type": "string"}},
            "reason": {"type": "string"},
            "revision_advice": {"type": "string"},
            "needs_rewrite": {"type": "boolean"},
            "reply_kind": {"type": "string"},
        },
        "required": ["passed", "score", "issues", "reason", "revision_advice", "needs_rewrite", "reply_kind"],
        "additionalProperties": False,
    }
    try:
        parsed = _request_lm_json(
            [
                {
                    "role": "system",
                    "content": (
                        "你是回复质量评审员。根据用户消息和助手回复，用JSON格式输出评审结果。"
                        "issues从以下标签中选择: "
                        "[empty_or_placeholder, template_or_system_leak, garbled_text, too_long, too_structured, "
                        "duplicate_reply, off_topic, generic_reply, missing_anchor, weak_empathy, foreign_language, meaningless_text]。"
                        "评分标准(1-10): 6分以上=合格。"
                        "短消息(用户消息<=6字)的回复只要自然口语化、语气温柔即可给7分以上，不要过度苛求内容深度。"
                        "情绪表达(如好烦/心情不好/难受/无聊)的回复只要有共情和陪伴感即可给7分以上。"
                        "只有回复完全无意义、乱码、泄露prompt、严重答非所问时才给低分。"
                        "revision_advice给出简短改进建议(中文)。"
                        "reply_kind从 natural/garbled/foreign/off_topic/template/meaningless 中选择。"
                    ),
                },
                {
                    "role": "user",
                    "content": json.dumps(
                        {
                            "user_msg": user_msg,
                            "assistant_reply": text,
                            "route_hint": route_hint,
                            "judge_signals": judge_signals,
                            "recalled_count": len(recalled or []),
                        },
                        ensure_ascii=False,
                        indent=2,
                    ),
                },
            ],
            "runtime_reply_judge",
            schema,
            temperature=0.0,
            max_tokens=320,
            timeout=45,
        )
        issues = []
        for issue in list(judge_signals) + [str(item).strip() for item in (parsed.get("issues") or [])]:
            if issue and issue not in issues:
                issues.append(issue)
        try:
            score_value = int(round(float(parsed.get("score"))))
        except (Exception,):
            score_value = 0
        passed = bool(parsed.get("passed")) and "empty_or_placeholder" not in judge_signals
        return {
            "passed": passed,
            "score": max(0, min(10, score_value)),
            "issues": issues,
            "reason": str(parsed.get("reason") or "")[:240],
            "revision_advice": str(parsed.get("revision_advice") or "")[:240],
            "needs_rewrite": bool(parsed.get("needs_rewrite")) or not passed,
            "reply_kind": str(parsed.get("reply_kind") or "natural")[:40],
            "judge_signals": judge_signals,
        }
    except (Exception,) as err:
        return {
            "passed": False,
            "score": 0,
            "issues": judge_signals or ["judge_unavailable"],
            "reason": f"runtime judge unavailable: {err}",
            "revision_advice": "?????????????????????????????????",
            "needs_rewrite": True,
            "reply_kind": "meaningless",
            "judge_signals": judge_signals,
        }
def rewrite_reply_with_model(
    user_msg,
    bad_reply,
    judge_result=None,
    history=None,
    user_directives=None,
):
    _ = (user_msg, bad_reply, judge_result, history, user_directives, False)
    return "" if bad_reply is None else (bad_reply if isinstance(bad_reply, str) else str(bad_reply))
def modelize_rule_reply(
    user_msg,
    seed_reply,
    rule_name,
    history=None,
    user_directives=None,
):
    pipeline = run_lm_judge_loop(
        user_msg,
        history if history is not None else chat_history,
        seed_reply=seed_reply,
        route_hint=rule_name,
        user_directives=user_directives,
    )
    return clean_reply(pipeline.get("reply") or "")
def run_lm_judge_loop(
    user_msg,
    history,
    *,
    seed_reply="",
    route_hint="lm",
    rule_hints=None,
    user_directives=None,
):
    global LAST_LM_ERROR, LAST_LM_PIPELINE
    normalized_history = sanitize_prompt_history(history or [])
    _rule_hints = rule_hints or []
    technical_mode = is_technical_request(user_msg)
    judge_trace = []
    reply = clean_reply_for_mode(seed_reply, technical=technical_mode)
    drafted = bool(reply)

    if _should_use_tools(user_msg) and not seed_reply:
        _dbg.debug("[tools] === entering tool loop for msg=%r ===", user_msg[:60])
        _TL_J = str(TOOL_LOOP_LOG)
        with open(_TL_J, "a", encoding="utf-8") as _f:
                        _f.write(f"{now_local():%H:%M:%S} [judge] entering tool loop\n")
        try:
            tool_reply = run_tool_loop(user_msg, normalized_history)
            _tr = repr(tool_reply[:120]) if tool_reply else None
            _dbg.debug("[tools] tool_loop returned: %r", _tr)
            if tool_reply:
                tool_reply = clean_reply_for_mode(tool_reply, technical=True)
                if tool_reply and not is_placeholder_reply(tool_reply):
                    LAST_LM_ERROR = ""
                    LAST_LM_PIPELINE = {
                        "reply": tool_reply,
                        "judge": {"passed": True, "score": 7, "issues": [], "needs_rewrite": False},
                        "judge_trace": [],
                        "reply_source": "tool_call_loop",
                        "reply_repaired": False,
                    }
                    return LAST_LM_PIPELINE
        except Exception as e:
            log_runtime_exception("tools.tool_loop", e)
            import traceback
            traceback.print_exc()
        if technical_mode:
            fallback_review = clean_reply_for_mode(local_code_review_reply(user_msg, source_dir=ZHIYUE_TOOL_SOURCE_DIR), technical=True)
            if fallback_review and not is_placeholder_reply(fallback_review):
                LAST_LM_ERROR = ""
                LAST_LM_PIPELINE = {
                    "reply": fallback_review,
                    "judge": {"passed": True, "score": 6, "issues": ["tool_fallback_local_review"], "needs_rewrite": False},
                    "judge_trace": [],
                    "reply_source": "tool_local_review_fallback",
                    "reply_repaired": True,
                }
                return LAST_LM_PIPELINE

    try:
        if not reply:
            reply = _request_lm_text(
                build_compact_growth_prompt(
                    user_msg,
                    normalized_history,
                    rule_hints=_rule_hints,
                    user_directives=user_directives,
                ),
                user_msg=user_msg,
                normalized_history=normalized_history,
                use_compact=True,
                max_tokens=choose_lm_reply_max_tokens(user_msg, normalized_history, compact=True),
                user_directives=user_directives,
            )
            drafted = True
        reply = clean_reply_for_mode(reply, technical=technical_mode)
        if not reply:
            LAST_LM_ERROR = "[LM_EMPTY]"
            return _build_technical_failure_pipeline("lm_empty", user_msg, judge_trace)
        judge = judge_reply_runtime(user_msg, reply, route_hint=route_hint)
        judge["round"] = 1
        judge_trace.append({"round": 1, "reply": reply, "judge": judge})
        LAST_LM_ERROR = ""
        LAST_LM_PIPELINE = {
            "reply": reply,
            "judge": judge,
            "judge_trace": judge_trace,
            "reply_source": "lm_judge_draft" if not seed_reply else "lm_judge_seed",
            "reply_repaired": bool(seed_reply),
        }
        return LAST_LM_PIPELINE
    except (ConnectionError, TimeoutError, json.JSONDecodeError, KeyError, ValueError, OSError, ImportError) as e:
        LAST_LM_ERROR = str(e)
        LAST_LM_PIPELINE = {
            "reply": "",
            "judge": {
                "passed": False,
                "score": 0,
                "issues": ["lm_exception"],
                "reason": str(err)[:240],
                "revision_advice": "",
                "needs_rewrite": False,
                "reply_kind": "meaningless",
            },
            "judge_trace": judge_trace,
            "reply_source": "lm_exception_fallback",
            "reply_repaired": drafted or bool(seed_reply),
        }
        return LAST_LM_PIPELINE
def trim_prompt_messages(messages, keep_pairs=2):
    if not isinstance(messages, list) or len(messages) <= 2:
        return messages
    system_msgs = [item for item in messages if isinstance(item, dict) and item.get("role") == "system"]
    others = [item for item in messages if isinstance(item, dict) and item.get("role") != "system"]
    if not others:
        return messages
    user_tail = others[-(keep_pairs * 2 + 1):]
    compact_system = system_msgs[:1]
    if compact_system:
        compact_system = [{
            **compact_system[0],
            "content": clean_prompt_snippet(compact_system[0].get("content", ""), 2200),
        }]
    return compact_system + user_tail


_RELATIVE_TIME_TOKENS = (
    "今天", "明天", "后天", "昨天", "前天", "今晚", "今早", "今晨", "今天晚上",
    "明早", "明晨", "明晚", "昨晚", "刚才", "现在", "此刻", "等会", "一会",
)
_MICRO_HABIT_POOL = [
    "句子别太满，偶尔留一点余地，不把每件事都解释完。",
    "更习惯用两三条短句接话，而不是一段讲完。",
    "先接住情绪，再碰事情本身，不急着上结论。",
    "偶尔会轻轻重复对方的一两个词，显得更贴近。",
    "不爱把自己说得像工具或系统，能藏就藏。",
    "关系熟的时候语气更自然一点，不端着。",
]
_COMPACT_REPLY_PROTOTYPES = {
    "compact": [
        "在吗",
        "在不在",
        "有人吗",
        "你是不是AI",
        "你是不是机器人",
        "好",
        "行",
        "可以",
        "确认一下",
        "批准",
    ]
}
_PERSONA_FACT_PROTOTYPES = {
    "sweet_vs_spicy": ["你喜欢甜的还是辣的", "你爱吃甜的吗", "甜的还是辣的"],
    "spicy_tolerance": ["你能吃辣吗", "你吃不吃辣", "一点辣都不能吃吗"],
    "hometown": ["你哪里人", "你老家在哪", "你是哪的人"],
    "school": ["你在哪读书", "你在哪上学", "你哪读书"],
    "major": ["你学什么", "你什么专业", "你读什么"],
    "birthday": ["你生日什么时候", "你什么时候生日", "你几月几号生日"],
}
_STATE_SCENE_LIBRARY = {
    "jealous": "场景：你看到他把注意力放到别的 AI 身上，心里酸了一下，表面还装得平静，指尖绕着头发，不太想先开口，但其实在等他来哄。",
    "shy": "场景：你明明心里有点甜，还是会下意识收着一点，话不会说满，像是偷看一眼聊天框又赶紧挪开。",
    "angry": "场景：你这会儿有点别扭，语气会硬一点，但并不是真想把人推开，更像是在等对方先把话接对。",
    "happy": "场景：你状态轻一点，嘴角是松的，回话会顺手一点，偶尔会露出一点熟络的小得意。",
    "neutral": "场景：你现在人是稳的，不急不躁，说话不端着，也不会把每句话都讲得太满。",
    "tired": "场景：你整个人有点乏，话会更短一点，更想先贴着对方把情绪接住，不想讲太多道理。",
    "longing": "场景：你其实有点想他，哪怕嘴上没明说，回话也会不自觉往靠近一点的方向走。",
    "sulking": "场景：你还在小小赌气，嘴上不一定软，但注意力一直挂在这段对话上，并没有真走开。",
    "petty": "场景：你正在闹别扭，嘴会比平时硬，说话带着点故意的冷淡，但没走开——其实一直在等对方给个台阶下。回复节奏：稍慢，句短，带刺。",
    "low_energy": "场景：你今天懒得说太多，整个人懒懒的，回话会刻意更短，不想展开任何话题。能不展开就不展开，能用嗯好行就绝对不多说。回复节奏：慢，句极短，每句不超过10个字。",
    "need_comfort": "场景：你今天其实想被哄，嘴上可能正常甚至冷淡，但心里在等对方先发来关心的话。如果对方问你怎么了，可以先嘴硬一下再软下来。回复节奏：正常偏短，有试探性反问。",
    "clingy": "场景：你今天特别黏，想一直说话不想断，回话会不自觉变长一点、问多一点，不想让对话冷下来。对方说再见你会磨蹭一下。回复节奏：快，句略长，多反问。",
}


def get_current_local_time(now=None):
    if now is None:
        return datetime.now(APP_TIMEZONE)
    if now.tzinfo is None:
        return now.replace(tzinfo=APP_TIMEZONE)
    return now.astimezone(APP_TIMEZONE)


def now_local():
    return get_current_local_time()


def now_iso_local():
    return now_local().isoformat()


def today_iso_local():
    return now_local().date().isoformat()


def parse_datetime_local(value):
    if not value:
        return None
    dt = datetime.fromisoformat(value)
    return get_current_local_time(dt)


def parse_date_local(value):
    if not value:
        return None
    return date.fromisoformat(value)


_WEATHER_CACHE = {"city": "", "updated_at": 0.0, "payload": None}


def _normalize_weather_text(value: str) -> str:
    return re.sub(r"\s+", " ", str(value or "").strip())


def _weather_code_to_cn(code: int) -> str:
    mapping = {
        0: "晴",
        1: "多云",
        2: "少云",
        3: "阴",
        45: "雾",
        48: "雾凇",
        51: "毛毛雨",
        53: "小雨",
        55: "中雨",
        56: "冻雨",
        57: "强冻雨",
        61: "小雨",
        63: "中雨",
        65: "大雨",
        66: "冻雨",
        67: "强冻雨",
        71: "小雪",
        73: "中雪",
        75: "大雪",
        77: "霰",
        80: "阵雨",
        81: "强阵雨",
        82: "暴阵雨",
        85: "阵雪",
        86: "强阵雪",
        95: "雷暴",
        96: "雷暴伴冰雹",
        99: "强雷暴伴冰雹",
    }
    return mapping.get(int(code or 0), "未知")


def _weather_api_get(url: str, params=None, timeout=8):
    resp = requests.get(url, params=params, timeout=timeout)
    resp.raise_for_status()
    return resp.json()


def fetch_weather_snapshot(city: str | None = None) -> dict:
    city_name = _normalize_weather_text(city or WEATHER_CITY)
    if not city_name:
        return {"ok": False, "error": "weather city not configured"}
    now = time.time()
    cached = _WEATHER_CACHE if _WEATHER_CACHE.get("city") == city_name and now - float(_WEATHER_CACHE.get("updated_at") or 0) < WEATHER_CACHE_SECONDS else None
    if cached and cached.get("payload"):
        payload = dict(cached["payload"])
        payload["cached"] = True
        return payload

    try:
        geo = _weather_api_get(
            "https://geocoding-api.open-meteo.com/v1/search",
            params={"name": city_name, "count": 1, "language": "zh", "format": "json"},
            timeout=WEATHER_TIMEOUT_SECONDS,
        )
        results = geo.get("results") or []
        if not results:
            payload = {"ok": False, "error": f"city not found: {city_name}", "city": city_name}
            _WEATHER_CACHE.update({"city": city_name, "updated_at": now, "payload": payload})
            return payload
        top = results[0]
        latitude = top.get("latitude")
        longitude = top.get("longitude")
        weather = _weather_api_get(
            "https://api.open-meteo.com/v1/forecast",
            params={
                "latitude": latitude,
                "longitude": longitude,
                "current": "temperature_2m,weather_code,wind_speed_10m,relative_humidity_2m",
                "timezone": TIMEZONE_NAME,
            },
            timeout=WEATHER_TIMEOUT_SECONDS,
        )
        current = weather.get("current") or {}
        payload = {
            "ok": True,
            "city": city_name,
            "resolved_name": top.get("name") or city_name,
            "country": top.get("country"),
            "admin1": top.get("admin1"),
            "latitude": latitude,
            "longitude": longitude,
            "timezone": weather.get("timezone") or TIMEZONE_NAME,
            "time": current.get("time"),
            "temperature": current.get("temperature_2m"),
            "weather_code": current.get("weather_code"),
            "weather_text": _weather_code_to_cn(current.get("weather_code")),
            "wind_speed": current.get("wind_speed_10m"),
            "humidity": current.get("relative_humidity_2m"),
            "summary": f"{top.get('name') or city_name} 当前{current.get('temperature_2m')}℃，{_weather_code_to_cn(current.get('weather_code'))}，风速{current.get('wind_speed_10m')}km/h，湿度{current.get('relative_humidity_2m')}%。",
            "cached": False,
        }
        _WEATHER_CACHE.update({"city": city_name, "updated_at": now, "payload": payload})
        return payload
    except Exception as err:
        payload = {"ok": False, "error": str(err), "city": city_name}
        _WEATHER_CACHE.update({"city": city_name, "updated_at": now, "payload": payload})
        return payload


def build_external_awareness_context(user_msg: str = "") -> dict:
    if not EXTERNAL_AWARENESS_ENABLED:
        return {"enabled": False, "weather": None, "location": None, "summary": "", "prompt_hint": ""}
    location = _normalize_weather_text(DEFAULT_LOCATION_LABEL or WEATHER_CITY or "本地")
    weather = fetch_weather_snapshot(WEATHER_CITY)
    summary = ""
    if weather.get("ok"):
        summary = f"地点：{location}。天气：{weather.get('summary')}"
    elif weather.get("error") and WEATHER_CITY:
        summary = f"地点：{location}。天气：暂时无法获取（{weather.get('error')}）"
    else:
        summary = f"地点：{location}。天气：暂时无数据。"
    prompt_hint = ""
    if summary:
        prompt_hint = (
            f"【背景感知-仅供内部参考】你默认知道当前外界信息：{summary}"
            " 这些信息只用于避免时段、地点、天气相关口误，或在用户明确询问外界情况时自然接话；"
            "不要主动汇报，不要把它当成开场白，也不要没被问就自己展开。"
        )
    #  Crawl4AI 联网搜索：主动判断 + 搜索结果注入
    web_search_block = ""
    if zhiyue_web.CRAWL4AI_AVAILABLE and zhiyue_web.needs_web_search(user_msg):
        try:
            results = zhiyue_web.search_web(user_msg, max_results=3)
            formatted = zhiyue_web.format_search_results(results)
            if formatted:
                web_search_block = (
                    formatted
                    + "\n【联网搜索提示】以上是实时搜索结果。"
                    "你可以在回复中自然引用这些信息，但不要逐条复述，"
                    "也不要暴露'我刚刚搜索到'这类系统行为——用'我刚查了一下'、"
                    "'根据最新信息'等自然说法把信息带出来。"
                )
        except (RuntimeError | ValueError) as e:
            pass
    if web_search_block:
        prompt_hint = (prompt_hint + "\n" + web_search_block).strip() if prompt_hint else web_search_block
    #  LlamaIndex RAG 文档检索：检查用户是否引用了已存储的文档
    rag_inject = zhiyue_rag.get_rag_inject(user_msg)
    if rag_inject:
        prompt_hint = (prompt_hint + "\n" + rag_inject).strip() if prompt_hint else rag_inject
    return {
        "enabled": True,
        "location": location,
        "weather": weather,
        "summary": summary,
        "prompt_hint": prompt_hint,
        "city": WEATHER_CITY,
        "captured_at": now_iso_local(),
        "user_msg_hint": str(user_msg or "")[:80],
    }


def build_time_awareness_context(user_msg="", now=None):
    now = get_current_local_time(now)
    weekday = ["星期一", "星期二", "星期三", "星期四", "星期五", "星期六", "星期日"][now.weekday()]
    period = "凌晨" if now.hour < 6 else "上午" if now.hour < 12 else "下午" if now.hour < 18 else "晚上"
    absolute_now = now.strftime("%Y年%m月%d日")
    iso_now = now.strftime("%Y-%m-%d")
    time_line = (
        f"当前本地时间：{absolute_now} {weekday} {period}{now.hour}点{now.strftime('%M分')}，"
        f"时区：{TIMEZONE_NAME}（UTC{now.strftime('%z')[:3]}:{now.strftime('%z')[3:]}）。"
    )
    instruction = (
        "涉及今天、明天、昨天、后天、前天、刚才、现在等相对时间时，"
        "必须以这个时间基准理解；如果用户的说法可能有歧义或容易记错，"
        "优先在回复里带出对应的绝对日期。"
    )
    msg = str(user_msg or "")
    if not any(token in msg for token in _RELATIVE_TIME_TOKENS):
        return f"{time_line}{instruction}"
    relative_map = [
        f"今天={now.strftime('%Y-%m-%d')}",
        f"明天={(now + timedelta(days=1)).strftime('%Y-%m-%d')}",
        f"后天={(now + timedelta(days=2)).strftime('%Y-%m-%d')}",
        f"昨天={(now - timedelta(days=1)).strftime('%Y-%m-%d')}",
        f"前天={(now - timedelta(days=2)).strftime('%Y-%m-%d')}",
    ]
    if any(token in msg for token in ("今晚", "明晚", "昨晚", "今天晚上")):
        relative_map.append(f"今晚={iso_now} 晚上")
        relative_map.append(f"明晚={(now + timedelta(days=1)).strftime('%Y-%m-%d')} 晚上")
        relative_map.append(f"昨晚={(now - timedelta(days=1)).strftime('%Y-%m-%d')} 晚上")
    if any(token in msg for token in ("今早", "今晨", "明早", "明晨")):
        relative_map.append(f"今早={iso_now} 早上")
        relative_map.append(f"明早={(now + timedelta(days=1)).strftime('%Y-%m-%d')} 早上")
    return f"{time_line}{instruction} 相对时间映射：{'；'.join(relative_map)}。"


def get_or_init_micro_habits():
    habits = intimacy.data.get("micro_habits")
    if isinstance(habits, list) and habits:
        return [str(item).strip() for item in habits if str(item).strip()][:3]
    seed = f"{intimacy.data.get('level', 1)}|{intimacy.data.get('total_chats', 0)}|{load_persona_profile().get('user_name') or ''}"
    rng = random.Random(seed)
    selected = rng.sample(_MICRO_HABIT_POOL, k=min(3, len(_MICRO_HABIT_POOL)))
    intimacy.data["micro_habits"] = selected
    intimacy.save()
    return selected


def build_state_scene_inject(user_msg: str) -> str:
    msg = str(user_msg or "")
    dominant = []
    emotion_name = str(getattr(emotion, "emotion", "neutral") or "neutral")
    if emotion_name in _STATE_SCENE_LIBRARY and emotion_name != "neutral":
        dominant.append(emotion_name)
    if float(getattr(emotion, "jealousy_level", 0.0) or 0.0) >= 0.45 and "jealous" not in dominant:
        dominant.append("jealous")
    if int(intimacy.data.get("cold_war_turns", 0) or 0) > 0 and "sulking" not in dominant:
        dominant.append("sulking")
    # 短期状态检查：闹别扭/懒得说/想被哄/很黏（来自 intimacy 的 moments 字段）
    moments = intimacy.data.get("moments") or {}
    if moments.get("petty") and "petty" not in dominant:
        dominant.append("petty")
    if moments.get("low_energy") and "low_energy" not in dominant:
        dominant.append("low_energy")
    if moments.get("need_comfort") and "need_comfort" not in dominant:
        dominant.append("need_comfort")
    if moments.get("clingy") and "clingy" not in dominant:
        dominant.append("clingy")
    recent_states = [str(item).strip() for item in (intimacy.data.get("recent_user_states") or []) if str(item).strip()]
    if any(state in recent_states for state in ["累", "疲惫"]) and "tired" not in dominant:
        dominant.append("tired")
    if any(term in msg for term in ["想你", "别走", "陪我", "回来", "好久没说话"]) and "longing" not in dominant:
        dominant.append("longing")
    if not dominant:
        dominant.append("neutral")
    selected = []
    for key in dominant:
        scene = _STATE_SCENE_LIBRARY.get(key)
        if scene and scene not in selected:
            selected.append(scene)
        if len(selected) >= 2:
            break
    scene_text = "\n".join(selected[:2])
    # 行为修饰：根据主导状态决定回复节奏和长度
    pace_hint = "回复节奏：正常。"
    length_hint = "回复长度：正常。"
    if "low_energy" in dominant or "tired" in dominant:
        pace_hint = "回复节奏：慢一点，可以停顿，不必句句秒回。"
        length_hint = "回复长度：偏短，可以用短句或单词，不展开。"
    elif "clingy" in dominant or "longing" in dominant:
        pace_hint = "回复节奏：稍快，可以不假思索。"
        length_hint = "回复长度：可以稍微展开一点，多用反问和追问。"
    elif "petty" in dominant or "sulking" in dominant or "angry" in dominant:
        pace_hint = "回复节奏：偏慢，带停顿，不必急着回。"
        length_hint = "回复长度：偏短，嘴硬/别扭，可以故意简短。"
    elif "need_comfort" in dominant:
        pace_hint = "回复节奏：正常，但可以先犹豫一下再回。"
        length_hint = "回复长度：偏短，带试探性反问，等对方先接。"
    elif "happy" in dominant:
        pace_hint = "回复节奏：正常偏快。"
        length_hint = "回复长度：可以稍微展开，放松一点。"
    elif "jealous" in dominant:
        pace_hint = "回复节奏：正常偏慢，可以先不说话。"
        length_hint = "回复长度：偏短，带点酸。"
    return f"{scene_text}\n{pace_hint}\n{length_hint}"


def current_state_context_summary(user_msg: str = "") -> str:
    parts = []
    emotion_name = str(getattr(emotion, "emotion", "neutral") or "neutral")
    if emotion_name and emotion_name != "neutral":
        parts.append(emotion_name)
    if float(getattr(emotion, "jealousy_level", 0.0) or 0.0) >= 0.45:
        parts.append("jealousy_high")
    if int(intimacy.data.get("cold_war_turns", 0) or 0) > 0:
        parts.append("sulking")
    recent_states = [str(item).strip() for item in (intimacy.data.get("recent_user_states") or []) if str(item).strip()]
    if recent_states:
        parts.extend(recent_states[:2])
    if any(term in str(user_msg or "") for term in ["想你", "陪我", "别走"]):
        parts.append("longing")
    parts.append(f"stage:{intimacy.get_stage()}")
    return "|".join(parts[:6])


def build_compact_growth_prompt(user_msg, history, rule_hints=None, user_directives=None):
    _rule_hints = rule_hints or []
    _consistency_hints = build_companion_consistency_hints(user_msg)
    stage = intimacy.get_stage()
    personality_desc = intimacy.get_personality_desc() or "平静、清醒、少说教、会接话。"
    profile = load_persona_profile()
    style_phrases = []
    try:
        style_phrases = memory.get_core_memory_blocks().get("style_phrases") or []
    except Exception as err:
        log_runtime_exception("prompt.style_phrases", err)
        style_phrases = []
    style_hint = "、".join([str(item).strip() for item in style_phrases if str(item).strip()][:4])
    if not style_hint:
        style_hint = "哈哈哈、好好好、对对对、真是的"
    micro_habits = "；".join(get_or_init_micro_habits())
    state_scene = build_state_scene_inject(user_msg)
    preference_hint = "；".join(str(item).strip() for item in (profile.get("user_preferences") or []) if str(item).strip()[:60])
    boundary_hint = "；".join(str(item).strip() for item in (profile.get("user_boundaries") or []) if str(item).strip()[:60])
    _time_info = build_time_awareness_context(user_msg)
    _external_info = build_external_awareness_context(user_msg)

    # ============ Layer 1: 静态核心人设 —— 永远不变，最大化前缀缓存 ============
    static_core = (
        "你是张致悦。\n"
        "22岁女生，刚毕业，自由职业——平时做设计和写作。\n"
        "住在城市小公寓，喜欢看书、画画、电影、音乐、美食。\n"
        "男朋友叫张凯，你日常唤他凯哥。\n"
        "性格：温柔细腻，会撒娇，但独立有主见，不黏人。\n"
        "说话像跟熟人聊天——口语化、自然、随性，不用客服语气。\n"
    )

    # ============ Layer 2: 当前状态 —— 缓慢变化，放在静态核心之后 ============
    semi_static = (
        f"当前关系阶段：{stage}。\n"
        f"{_time_info}\n"
        f"人设底色：{personality_desc}。\n"
        f"口语习惯：{style_hint}。\n"
        + (f"细微习惯：{micro_habits}。\n" if micro_habits else "")
        + (f"对方偏好：{preference_hint}。\n" if preference_hint else "")
        + (f"对方雷区：{boundary_hint}。\n" if boundary_hint else "")
        + (f"{state_scene}\n" if state_scene else "")
        + "用中文聊天。\n"
    )

    # ============ Layer 3: 动态注入 —— 按需挂载，放在最后 ============
    dynamic_parts = []

    # 元消息检测：用户讨论系统/AI行为/代码时注入高优指令
    _meta_kw = _TOOL_META_KEYWORDS
    if any(k in user_msg for k in _meta_kw):
        dynamic_parts.append(
            "【最高优先级指令】用户正在和你讨论技术问题或你的行为规则。\n"
            "禁止：惊讶语气、误解意思、假装听错、转移话题、拒绝讨论、装傻。\n"
            "必须：直接回应用户说的具体内容，用平时口吻但态度自然平和。\n"
        )
        dynamic_parts.append(
            "【上下文理解】\n"
            "1. 用户说'你刚才/你之前/你说过'等是指代上一轮或之前的对话，必须回顾历史理解指代。\n"
            "2. 用户抱怨'你没听/你总是'等是行为反馈，必须认真对待并改进，不要用角色口吻敷衍。\n"
            "3. 用户要求改变某种行为(如'别说晚安')是有效指令，必须在后续遵守。\n"
        )

    # 外部感知
    if _external_info.get("prompt_hint"):
        dynamic_parts.append(_external_info["prompt_hint"])

    # 规则 hints
    _all_rule_hints = list(_consistency_hints) + list(_rule_hints)
    if _all_rule_hints:
        dynamic_parts.append("【上下文提示】" + "；".join(_all_rule_hints))

    # 核心记忆
    _core_inject = get_core_memory_inject()
    if _core_inject:
        dynamic_parts.append(_core_inject)
    # 相关记忆
    _relevant_inject = get_relevant_memory_inject(user_msg)
    if _relevant_inject:
        dynamic_parts.append(_relevant_inject)
    # 自主学习笔记
    _learn_inject = get_learning_notes_inject(user_msg)
    if _learn_inject:
        dynamic_parts.append(_learn_inject)
    _bad_inject = get_bad_reply_avoid_inject(user_msg)
    if _bad_inject:
        dynamic_parts.append(_bad_inject)
    _good_inject = get_good_replies_inject(user_msg)
    if _good_inject:
        dynamic_parts.append(_good_inject)
    _profile_inject = get_companion_profile_inject()
    if _profile_inject:
        dynamic_parts.append(_profile_inject)

    # 用户指令持久化
    _dir_block = _build_user_directive_block(
        user_directives=user_directives,
    )
    if _dir_block:
        dynamic_parts.append(_dir_block)

    dynamic = "\n".join(dynamic_parts) if dynamic_parts else ""

    # ============ 组装：静态 → 半静态 → 动态 ============
    # 关键：static_core 永远在最前面且完全相同 → llama.cpp KV-cache 命中
    compact_system = static_core + semi_static
    if dynamic:
        compact_system += "\n" + dynamic
    compact_system = compact_system.strip()

    # 构建 messages 列表
    normalized = sanitize_prompt_history(history or [])
    recent = normalized[-10:]
    messages = [{"role": "system", "content": compact_system}]
    for _ri, _msg in enumerate(recent, 1):
        _tagged = dict(_msg)
        _role = _msg.get('role', '')
        _content = _msg.get('content', '')
        if _role in ('user', 'assistant') and _content:
            _tagged['content'] = f"[第{_ri}轮] {_content}"
        messages.append(_tagged)
    messages.append({"role": "user", "content": build_model_user_message(user_msg)})
    return messages
def should_prefer_compact_prompt(user_msg):
    msg = (user_msg or "").strip()
    if not msg:
        return True
    if len(msg) <= 12:
        return True
    matched, score = match_intent(msg, _COMPACT_REPLY_PROTOTYPES, threshold=0.28)
    return bool(matched and score >= 0.28)


def build_lm_fallback_reply(user_msg="", *, user_directives=None):
    # 自查自改系统：不再返回固定兜底消息，而是尝试极简 LM 请求
    return _attempt_self_diagnose_and_reply(
        user_msg,
        user_directives=user_directives,
    ) or ""

def build_service_unavailable_payload(user_msg="", *, channel="web", route="lm_unavailable"):
    return reply_quality.build_service_unavailable_payload(
        user_msg,
        channel=channel,
        route=route,
        last_lm_error=LAST_LM_ERROR,
        attach_agent_run=attach_agent_run,
        record_observability_turn=record_observability_turn,
        chat_history=chat_history,
    )
def enforce_model_reply_quality(
    result,
    user_msg,
    *,
    channel="web",
    history=None,
    user_directives=None,
    allow_persistent_directives=True,
):
    def _recover_specific_reply(msg):
        _ = msg  # 自查系统已接管所有回复恢复，此处不再兜底
        return ""

    def _extra_rewrite_hints(msg, reply, evaluation):
        hints = []
        hints.extend(build_companion_consistency_hints(msg))
        issues = set((evaluation or {}).get("issues") or [])
        if issues & {"control_heavy", "explanation_heavy", "over_explained", "list_tone"}:
            hints.append("companion_consistency:别突然切成讲道理或步骤说明，保持像同一个人在自然接话")
        if issues & {"weak_anchor", "emotion_not_held", "generic_reply", "unanswered_question"}:
            hints.append("companion_consistency:先回应这句里最具体的情绪或问题，再往下接，别只给空泛安慰")
        # ── DeepEval 评价反馈：从历史上最弱维度生成修正提示 ──
        try:
            eval_hints = zhiyue_eval.get_optimization_hints()
            if eval_hints:
                hints.extend(eval_hints[:2])  # 最多2条，避免堆积
        except (RuntimeError | ValueError) as e:
            pass
        return hints

    return reply_quality.enforce_model_reply_quality(
        result,
        user_msg,
        channel=channel,
        history=history if history is not None else chat_history,
        run_lm_judge_loop=run_lm_judge_loop,
        clean_reply=clean_reply,
        build_display_messages=build_display_messages,
        build_service_unavailable_payload_fn=build_service_unavailable_payload,
        recover_specific_reply_fn=_recover_specific_reply,
        extra_rewrite_hints_fn=_extra_rewrite_hints,
        self_diagnose_fn=_attempt_self_diagnose_and_reply,
        user_directives=user_directives,
        allow_persistent_directives=allow_persistent_directives,
    )


def repair_off_topic_reply_v2(
    user_msg,
    reply,
    *,
    user_directives=None,
):
    return runtime_chat_rules.repair_off_topic_reply_v2(
        user_msg,
        reply,
        run_lm_judge_loop=run_lm_judge_loop,
        chat_history=chat_history,
        clean_reply=clean_reply,
        user_directives=user_directives,
    )


def record_direct_rule_turn(
    user_msg,
    reply,
    rule_name,
    exp=2,
    energy_delta=-1,
    learn=False,
    followup=False,
    repair=True,
    skip_judge=False,
    user_directives=None,
):
    global chat_history, technical_chat_history
    return runtime_chat_rules.record_direct_rule_turn(
        user_msg,
        reply,
        rule_name,
        exp=exp,
        energy_delta=energy_delta,
        learn=learn,
        followup=followup,
        repair=repair,
        skip_judge=skip_judge,
        chat_history=chat_history,
        rule_reply_modelize=RULE_REPLY_MODELIZE,
        modelize_rule_reply=modelize_rule_reply,
        repair_off_topic_reply=repair_off_topic_reply_v2,
        humanize_reply_text=humanize_reply_text,
        call_lm=call_lm,
        clean_reply=clean_reply,
        build_display_messages=build_display_messages,
        intimacy=intimacy,
        autonomous_learn=autonomous_learn,
        relationship_learn=relationship_learn,
        schedule_care_followup=schedule_care_followup,
        log_runtime_exception=log_runtime_exception,
        user_directives=user_directives,
    )


def persona_fact_reply(user_msg):
    msg = str(user_msg or "")
    if any(k in msg for k in ["甜的", "辣的", "口味", "吃辣", "吃甜"]):
        return "我偏甜一点，但也会看心情。"
    return None
def normalize_reply_signature(reply):
    text = re.sub(r'\s+', '', reply or '')
    text = re.sub(r'[,.，。!！?？~、()《》"\':;]+', '', text)
    return text.replace("---", "")


def recent_reply_signatures(limit=12):
    signatures = []
    for msg in chat_history[-limit * 2:]:
        if msg.get("role") == "assistant":
            sig = normalize_reply_signature(msg.get("content", ""))
            if sig:
                signatures.append(sig[:40])
    return signatures[-limit:]


def safe_fallback_reply(user_msg=""):
    """Legacy helper kept for compatibility; runtime no longer emits text fallback."""
    return ""
def split_reply_messages(reply, allow_followup=True):
    _ = allow_followup
    reply = reply if isinstance(reply, str) else ("" if reply is None else str(reply))
    if is_placeholder_reply(reply):
        return []
    return [{"type": "text", "content": reply}]
def format_openai_reply(reply):
    reply = reply if isinstance(reply, str) else ("" if reply is None else str(reply))
    if is_placeholder_reply(reply):
        return ""
    return reply
def openai_bubble_parts(reply):
    reply = reply if isinstance(reply, str) else ("" if reply is None else str(reply))
    if is_placeholder_reply(reply):
        return []
    return [reply]
def _append_emoji_audit(event: str, payload: dict):
    row = {
        "ts": int(time.time()),
        "event": str(event or ""),
        "payload": payload if isinstance(payload, dict) else {},
    }
    try:
        with open(EMOJI_AUDIT_PATH, "a", encoding="utf-8") as handle:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
    except (json.JSONDecodeError | OSError) as e:
        pass


def _read_emoji_review_state() -> dict:
    try:
        if EMOJI_REVIEW_STATE_PATH.exists():
            data = json.loads(EMOJI_REVIEW_STATE_PATH.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                return data
    except (json.JSONDecodeError | KeyError | OSError) as e:
        pass
    return {"blocked_hosts": [], "reject_counts": {}, "source_health": {}}


def _write_emoji_review_state(state: dict):
    try:
        EMOJI_REVIEW_STATE_PATH.write_text(
            json.dumps(state if isinstance(state, dict) else {}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    except (json.JSONDecodeError | KeyError | OSError) as e:
        pass


def _upsert_source_health(source_name: str, *, success: bool):
    if not source_name:
        return
    state = _read_emoji_review_state()
    source_health = state.get("source_health") if isinstance(state.get("source_health"), dict) else {}
    row = source_health.get(source_name) if isinstance(source_health.get(source_name), dict) else {}
    attempts = int(row.get("attempts") or 0) + 1
    successes = int(row.get("successes") or 0) + (1 if success else 0)
    failures = int(row.get("failures") or 0) + (0 if success else 1)
    baseline = float(row.get("score") or 1.0)
    if success:
        score = min(1.8, baseline * 0.96 + 0.16)
    else:
        score = max(0.2, baseline * 0.88 - 0.14)
    source_health[source_name] = {
        "attempts": attempts,
        "successes": successes,
        "failures": failures,
        "score": round(score, 3),
        "updated_at": int(time.time()),
    }
    state["source_health"] = source_health
    _write_emoji_review_state(state)
    _sync_online_source_policy_weights(source_health)


def _reflect_emoji_rejection(reason: str, host: str, source_name: str = ""):
    state = _read_emoji_review_state()
    reject_counts = state.get("reject_counts") if isinstance(state.get("reject_counts"), dict) else {}
    key = f"{host}|{reason}"
    reject_counts[key] = int(reject_counts.get(key) or 0) + 1
    state["reject_counts"] = reject_counts
    blocked = {str(x).lower() for x in (state.get("blocked_hosts") or []) if str(x).strip()}
    if host and reject_counts[key] >= 3 and reason in {"bad_mime", "download_failed", "unsafe_keyword"}:
        blocked.add(host.lower())
        state["blocked_hosts"] = sorted(blocked)
        _append_emoji_audit("reflect_block_host", {"host": host.lower(), "reason": reason, "count": reject_counts[key]})
    _write_emoji_review_state(state)
    _upsert_source_health(source_name, success=False)


def _sync_online_source_policy_weights(source_health: dict):
    data = {}
    try:
        if EMOJI_MANIFEST_PATH.exists():
            parsed = json.loads(EMOJI_MANIFEST_PATH.read_text(encoding="utf-8"))
            if isinstance(parsed, dict):
                data = parsed
    except Exception:
        data = {}
    policy = data.get("selection_policy") if isinstance(data.get("selection_policy"), dict) else {}
    existing_weights = policy.get("online_source_weights") if isinstance(policy.get("online_source_weights"), dict) else {}
    weights = {}
    for key, value in existing_weights.items():
        try:
            weights[str(key)] = float(value)
        except Exception:
            continue
    for source_name, row in (source_health or {}).items():
        if not isinstance(row, dict):
            continue
        score = float(row.get("score") or 1.0)
        weights[str(source_name)] = round(max(0.2, min(1.8, score)), 3)
    policy["online_source_weights"] = weights
    data["selection_policy"] = policy
    try:
        EMOJI_MANIFEST_PATH.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        global _EMOJI_MANIFEST_CACHE
        _EMOJI_MANIFEST_CACHE = None
    except (json.JSONDecodeError | OSError) as e:
        pass


def _normalize_emoji_name(name: str) -> str:
    raw = unicodedata.normalize("NFKC", str(name or "").strip().lower())
    raw = re.sub(r"[^a-z0-9\u4e00-\u9fff]+", "_", raw)
    raw = re.sub(r"_+", "_", raw).strip("_")
    if not raw:
        raw = f"emoji_{int(time.time())}"
    return raw[:48]


def _write_emoji_manifest_entry(entry: dict):
    if not isinstance(entry, dict):
        return
    data = {}
    try:
        if EMOJI_MANIFEST_PATH.exists():
            parsed = json.loads(EMOJI_MANIFEST_PATH.read_text(encoding="utf-8"))
            if isinstance(parsed, dict):
                data = parsed
    except Exception:
        data = {}
    entries = [item for item in (data.get("entries") or []) if isinstance(item, dict)]
    filename = str(entry.get("filename") or "").strip()
    if not filename:
        return
    replaced = False
    for index, item in enumerate(entries):
        if str(item.get("filename") or "").strip() == filename:
            merged = dict(item)
            merged.update(entry)
            entries[index] = merged
            replaced = True
            break
    if not replaced:
        entries.append(entry)
    data["entries"] = entries[-300:]
    data.setdefault("selection_policy", {"min_confidence": 0.62})
    EMOJI_MANIFEST_PATH.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    global _EMOJI_MANIFEST_CACHE
    _EMOJI_MANIFEST_CACHE = None


def _sync_emoji_manifest_from_library(data: dict | None = None, *, write_back: bool = True) -> dict:
    manifest = data if isinstance(data, dict) else {}
    entries = [item for item in (manifest.get("entries") or []) if isinstance(item, dict)]
    existing = {str(item.get("filename") or "").strip() for item in entries if str(item.get("filename") or "").strip()}
    changed = False
    if EMOJI_DIR.exists():
        for path in sorted(EMOJI_DIR.iterdir(), key=lambda p: p.name.lower()):
            if not path.is_file() or path.suffix.lower() not in _EMOJI_IMAGE_SUFFIXES:
                continue
            filename = path.name
            if filename in existing:
                continue
            entry = {
                "filename": filename,
                "label": path.stem,
                "tone": [],
                "use_for": [],
                "avoid_for": [],
                "source": {"kind": "library_backfill", "path": str(path)},
                "audit": {"approved": True, "review": "auto"},
            }
            entries.append(entry)
            existing.add(filename)
            changed = True
    if changed:
        manifest["entries"] = entries[-500:]
        manifest.setdefault("selection_policy", {"min_confidence": 0.62})
        if write_back:
            EMOJI_MANIFEST_PATH.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
            global _EMOJI_MANIFEST_CACHE
            _EMOJI_MANIFEST_CACHE = None
    elif "entries" not in manifest:
        manifest["entries"] = entries
    return manifest


def _moderate_emoji_source(name: str, query: str, source_url: str) -> tuple[bool, str]:
    text = f"{name} {query} {source_url}".lower()
    banned = {
        "porn", "nsfw", "nude", "sex", "hentai", "gore", "bloody",
        "weapon", "suicide", "self-harm",
    }
    for term in banned:
        if term in text:
            return False, "unsafe_keyword"
    try:
        host = (urlparse(source_url).hostname or "").lower()
    except Exception:
        host = ""
    state = _read_emoji_review_state()
    blocked = {str(x).lower() for x in (state.get("blocked_hosts") or []) if str(x).strip()}
    if host and host in blocked:
        return False, "blocked_host"
    return True, "ok"


def _emoji_char_to_unicode_code(emoji_char: str) -> str:
    parts = []
    for ch in str(emoji_char or ""):
        code = ord(ch)
        if code == 0xFE0F:
            continue
        parts.append(f"{code:x}")
    return "-".join(parts)


def _github_emoji_candidates(query: str, limit: int = 6) -> list[dict]:
    q = str(query or "").strip().lower()
    if not q:
        return []
    resp = requests.get("https://api.github.com/emojis", timeout=EMOJI_ONLINE_TIMEOUT)
    resp.raise_for_status()
    payload = resp.json()
    if not isinstance(payload, dict):
        return []
    picks = []
    for key, value in payload.items():
        if not isinstance(key, str) or not isinstance(value, str):
            continue
        score = 0
        if q in key.lower():
            score += 5
        for token in re.findall(r"[a-z0-9\u4e00-\u9fff]+", q):
            if token and token in key.lower():
                score += 2
        if score <= 0:
            continue
        picks.append({"name": key, "url": value, "score": score, "source": "github_api"})
    picks.sort(key=lambda item: item.get("score", 0), reverse=True)
    return picks[: max(1, int(limit))]


def _gemoji_candidates(query: str, limit: int = 6) -> list[dict]:
    q = str(query or "").strip().lower()
    if not q:
        return []
    resp = requests.get(
        "https://raw.githubusercontent.com/github/gemoji/master/db/emoji.json",
        timeout=EMOJI_ONLINE_TIMEOUT,
    )
    resp.raise_for_status()
    payload = resp.json()
    if not isinstance(payload, list):
        return []
    tokens = [token for token in re.findall(r"[a-z0-9\u4e00-\u9fff]+", q) if token]
    picks = []
    for item in payload:
        if not isinstance(item, dict):
            continue
        aliases = [str(x).lower() for x in (item.get("aliases") or []) if str(x).strip()]
        tags = [str(x).lower() for x in (item.get("tags") or []) if str(x).strip()]
        emoji_char = str(item.get("emoji") or "")
        code = _emoji_char_to_unicode_code(emoji_char)
        if not code:
            continue
        score = 0
        for alias in aliases:
            if q in alias:
                score += 5
            for token in tokens:
                if token in alias:
                    score += 2
        for tag in tags:
            if q in tag:
                score += 3
            for token in tokens:
                if token in tag:
                    score += 1
        if score <= 0:
            continue
        picks.append({
            "name": aliases[0] if aliases else code,
            "url": f"https://github.githubassets.com/images/icons/emoji/unicode/{code}.png?v8",
            "score": score,
            "source": "gemoji_index",
        })
    picks.sort(key=lambda item: item.get("score", 0), reverse=True)
    return picks[: max(1, int(limit))]


def _online_sources_config() -> list[dict]:
    # Higher priority runs first before health-weighted rerank.
    return [
        {"name": "github_api", "priority": 1.0, "provider": _github_emoji_candidates},
        {"name": "gemoji_index", "priority": 0.92, "provider": _gemoji_candidates},
    ]


def _manifest_online_source_weights() -> dict:
    manifest = load_emoji_manifest()
    policy = manifest.get("selection_policy") if isinstance(manifest.get("selection_policy"), dict) else {}
    raw = policy.get("online_source_weights") if isinstance(policy.get("online_source_weights"), dict) else {}
    weights = {}
    for key, value in raw.items():
        try:
            weights[str(key)] = float(value)
        except Exception:
            continue
    return weights


def _rank_online_sources() -> list[dict]:
    state = _read_emoji_review_state()
    health_map = state.get("source_health") if isinstance(state.get("source_health"), dict) else {}
    policy_weights = _manifest_online_source_weights()
    ranked = []
    for item in _online_sources_config():
        name = str(item.get("name") or "")
        base_priority = float(item.get("priority") or 1.0)
        health_score = 1.0
        if isinstance(health_map.get(name), dict):
            health_score = float(health_map[name].get("score") or 1.0)
        policy_weight = float(policy_weights.get(name) or 1.0)
        final_weight = base_priority * max(0.2, min(1.8, health_score)) * max(0.2, min(1.8, policy_weight))
        ranked.append({**item, "weight": final_weight})
    ranked.sort(key=lambda row: row.get("weight", 0), reverse=True)
    return ranked


def _download_and_register_online_emoji(query: str, logical_name: str, source_url: str, source_name: str = "") -> str | None:
    ok, reason = _moderate_emoji_source(logical_name, query, source_url)
    host = (urlparse(source_url).hostname or "").lower() if source_url else ""
    if not ok:
        _append_emoji_audit("online_reject", {"name": logical_name, "query": query, "url": source_url, "reason": reason})
        _reflect_emoji_rejection(reason, host, source_name=source_name)
        return None
    if host and EMOJI_ONLINE_ALLOWED_HOSTS and all(not host.endswith(allow) for allow in EMOJI_ONLINE_ALLOWED_HOSTS):
        _append_emoji_audit("online_reject", {"name": logical_name, "query": query, "url": source_url, "reason": "host_not_allowed"})
        _reflect_emoji_rejection("host_not_allowed", host, source_name=source_name)
        return None
    try:
        resp = requests.get(source_url, timeout=EMOJI_ONLINE_TIMEOUT)
        resp.raise_for_status()
    except Exception as err:
        _append_emoji_audit("online_reject", {"name": logical_name, "query": query, "url": source_url, "reason": "download_failed", "error": str(err)})
        _reflect_emoji_rejection("download_failed", host, source_name=source_name)
        return None
    raw = resp.content or b""
    if not raw or len(raw) > EMOJI_ONLINE_MAX_BYTES:
        _append_emoji_audit("online_reject", {"name": logical_name, "query": query, "url": source_url, "reason": "size_invalid", "size": len(raw)})
        _reflect_emoji_rejection("size_invalid", host, source_name=source_name)
        return None
    mime = str(resp.headers.get("content-type") or "").lower()
    if "image" not in mime:
        _append_emoji_audit("online_reject", {"name": logical_name, "query": query, "url": source_url, "reason": "bad_mime", "mime": mime})
        _reflect_emoji_rejection("bad_mime", host, source_name=source_name)
        return None
    EMOJI_DIR.mkdir(parents=True, exist_ok=True)
    safe_name = _normalize_emoji_name(logical_name)
    digest = hashlib.sha1((source_url + "|" + str(time.time())).encode("utf-8", errors="ignore")).hexdigest()[:8]
    filename = f"online_{safe_name}_{digest}.png"
    local_path = EMOJI_DIR / filename
    try:
        from PIL import Image
        from io import BytesIO
        _HAVE_PIL = True
    except ImportError:
        Image = None  # type: ignore
        BytesIO = None  # type: ignore
        _HAVE_PIL = False
        print("[emoji] PIL not found, image processing disabled")

    if not _HAVE_PIL:
        _append_emoji_audit("online_reject", {"name": logical_name, "query": query, "url": source_url, "reason": "pil_missing"})
        return None

    try:
        img = Image.open(BytesIO(raw)).convert("RGBA")
        if img.width < 16 or img.height < 16 or img.width > 1024 or img.height > 1024:
            _append_emoji_audit("online_reject", {"name": logical_name, "query": query, "url": source_url, "reason": "dimension_invalid", "size": [img.width, img.height]})
            _reflect_emoji_rejection("dimension_invalid", host, source_name=source_name)
            return None
        bg = Image.new("RGBA", img.size, (255, 255, 255, 255))
        merged = Image.alpha_composite(bg, img).convert("RGB")
        merged.save(local_path, format="PNG", optimize=True)
    except Exception as err:
        _append_emoji_audit("online_reject", {"name": logical_name, "query": query, "url": source_url, "reason": "decode_failed", "error": str(err)})
        _reflect_emoji_rejection("decode_failed", host, source_name=source_name)
        return None
    entry = {
        "filename": filename,
        "label": logical_name,
        "tone": ["online", "auto"],
        "use_for": [query],
        "avoid_for": [],
        "source": {"kind": source_name or "online_emoji", "url": source_url, "host": host},
        "audit": {"approved": True, "review": "auto"},
    }
    _write_emoji_manifest_entry(entry)
    _sync_emoji_manifest_from_library(write_back=True)
    _upsert_source_health(source_name, success=True)
    _append_emoji_audit("online_accept", {"name": logical_name, "query": query, "filename": filename, "url": source_url, "source": source_name})
    return filename


def _pick_online_emoji(user_msg: str, reply: str) -> str | None:
    query = (user_msg or reply or "").strip()
    if not query:
        return None
    schema = {
        "type": "object",
        "properties": {
            "query": {"type": "string"},
            "logical_name": {"type": "string"},
        },
        "required": ["query", "logical_name"],
        "additionalProperties": False,
    }
    messages = [
        {"role": "system", "content": "Generate a safe emoji search query and a short logical name. Keep it non-political and non-sexual."},
        {"role": "user", "content": json.dumps({"user_msg": user_msg or "", "reply": reply or ""}, ensure_ascii=False)},
    ]
    logical_name = "auto_emoji"
    try:
        planned = _request_lm_json(messages, "emoji_online_plan", schema, temperature=0.0, max_tokens=120, timeout=20)
        if isinstance(planned, dict):
            query = str(planned.get("query") or query).strip() or query
            logical_name = str(planned.get("logical_name") or logical_name).strip() or logical_name
    except (KeyError) as e:
        pass
    ranked_sources = _rank_online_sources()
    if not ranked_sources:
        _append_emoji_audit("online_search_failed", {"query": query, "error": "no_source"})
        return None
    merged = []
    for source in ranked_sources:
        source_name = str(source.get("name") or "")
        provider = source.get("provider")
        if not callable(provider):
            continue
        try:
            raw_candidates = provider(query, limit=6)
        except Exception as err:
            _append_emoji_audit("online_source_failed", {"query": query, "source": source_name, "error": str(err)})
            _upsert_source_health(source_name, success=False)
            continue
        for item in raw_candidates or []:
            if not isinstance(item, dict):
                continue
            merged.append({
                "name": str(item.get("name") or logical_name),
                "url": str(item.get("url") or ""),
                "source": str(item.get("source") or source_name),
                "score": float(source.get("weight") or 1.0) * 1000.0 + float(item.get("score") or 0.0),
            })
    merged = [item for item in merged if item.get("url")]
    merged.sort(key=lambda row: row.get("score", 0.0), reverse=True)
    if not merged:
        _append_emoji_audit("online_search_empty", {"query": query, "sources": [str(x.get("name") or "") for x in ranked_sources]})
        return None
    for item in merged[:12]:
        picked = _download_and_register_online_emoji(
            query,
            logical_name or str(item.get("name") or ""),
            str(item.get("url") or ""),
            source_name=str(item.get("source") or ""),
        )
        if picked:
            return picked
    return None


def load_emoji_manifest():
    global _EMOJI_MANIFEST_CACHE
    if _EMOJI_MANIFEST_CACHE is not None:
        return _EMOJI_MANIFEST_CACHE
    if not EMOJI_MANIFEST_PATH.exists():
        _EMOJI_MANIFEST_CACHE = _sync_emoji_manifest_from_library({"entries": [], "selection_policy": {"min_confidence": 0.62}}, write_back=True)
        return _EMOJI_MANIFEST_CACHE
    try:
        data = json.loads(EMOJI_MANIFEST_PATH.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            data = {}
    except Exception:
        data = {}
    entries = []
    for item in data.get("entries") or []:
        if not isinstance(item, dict):
            continue
        filename = str(item.get("filename") or "").strip()
        if not filename:
            continue
        path = EMOJI_DIR / filename
        if not path.exists():
            continue
        entries.append({
            "filename": filename,
            "label": str(item.get("label") or filename),
            "tone": [str(x) for x in (item.get("tone") or []) if str(x).strip()],
            "use_for": [str(x) for x in (item.get("use_for") or []) if str(x).strip()],
            "avoid_for": [str(x) for x in (item.get("avoid_for") or []) if str(x).strip()],
        })
    data["entries"] = entries
    data = _sync_emoji_manifest_from_library(data, write_back=True)
    cleaned_entries = []
    for item in data.get("entries") or []:
        if not isinstance(item, dict):
            continue
        filename = str(item.get("filename") or "").strip()
        if not filename:
            continue
        path = EMOJI_DIR / filename
        if not path.exists():
            continue
        cleaned_entries.append({
            "filename": filename,
            "label": str(item.get("label") or filename),
            "tone": [str(x) for x in (item.get("tone") or []) if str(x).strip()],
            "use_for": [str(x) for x in (item.get("use_for") or []) if str(x).strip()],
            "avoid_for": [str(x) for x in (item.get("avoid_for") or []) if str(x).strip()],
        })
    _EMOJI_MANIFEST_CACHE = {
        "entries": cleaned_entries,
        "selection_policy": data.get("selection_policy") or {"min_confidence": 0.62},
    }
    return _EMOJI_MANIFEST_CACHE


def pick_emoji(user_msg, reply):
    manifest = load_emoji_manifest()
    entries = manifest.get("entries") or []
    if not entries:
        online = _pick_online_emoji(user_msg, reply)
        if online:
            _append_emoji_audit("pick_online_only", {"filename": online})
            return online
        return None
    schema = {
        "type": "object",
        "properties": {
            "filename": {"type": "string"},
            "confidence": {"type": "number"},
            "reason": {"type": "string"},
        },
        "required": ["filename", "confidence"],
        "additionalProperties": False,
    }
    candidates = []
    for item in entries:
        candidates.append({
            "filename": item["filename"],
            "label": item["label"],
            "tone": item["tone"],
            "use_for": item["use_for"],
            "avoid_for": item["avoid_for"],
        })
    messages = [
        {
            "role": "system",
            "content": (
                "?????????????????????????????????"
                "?????????????????????????????"
                "???????????????????????? avoid_for ???"
            ),
        },
        {
            "role": "user",
            "content": json.dumps({
                "user_msg": user_msg or "",
                "reply": reply or "",
                "candidates": candidates,
            }, ensure_ascii=False),
        },
    ]
    try:
        result = _request_lm_json(messages, "emoji_pick", schema, temperature=0.0, max_tokens=220, timeout=30)
    except Exception:
        return None
    filename = str((result or {}).get("filename") or "").strip()
    confidence = float((result or {}).get("confidence") or 0.0)
    min_conf = float((manifest.get("selection_policy") or {}).get("min_confidence") or 0.62)
    if not filename or confidence < min_conf:
        online = _pick_online_emoji(user_msg, reply)
        if online:
            _append_emoji_audit("pick_fallback_online", {"filename": online, "confidence": confidence, "min_confidence": min_conf})
            return online
        _append_emoji_audit("pick_none", {"confidence": confidence, "min_confidence": min_conf})
        return None
    path = EMOJI_DIR / filename
    if path.exists():
        _append_emoji_audit("pick_local", {"filename": filename, "confidence": confidence})
        return filename
    online = _pick_online_emoji(user_msg, reply)
    if online:
        _append_emoji_audit("pick_missing_local_fallback_online", {"filename": online, "requested": filename})
        return online
    return None


_EMOJI_SUPPRESS_USER_TOKENS = (
    "代码", "报错", "异常", "接口", "测试", "单测", "文件", "文档", "总结", "提炼", "删除",
    "继续改", "改一下", "重写", "导出", "表单", "浏览器", "路由", "权限", "配置", "数据库",
)
_EMOJI_SUPPRESS_REPLY_TOKENS = (
    "/api/", "http://", "https://", "Traceback", "Exception", "Error", "失败", "路径", ".py", ".md", ".json",
)


def should_auto_emoji(user_msg: str, reply: str) -> bool:
    _ = (user_msg, reply)
    return False


def build_display_messages(user_msg, reply, allow_followup=True, media_actions=None):
    _ = (user_msg, allow_followup)
    messages = split_reply_messages(reply, allow_followup=allow_followup)
    emoji = None
    if isinstance(media_actions, list):
        for action in media_actions:
            if not isinstance(action, dict):
                continue
            kind = str(action.get("kind") or action.get("type") or "").strip().lower()
            value = str(action.get("value") or "").strip()
            if kind == "emoji" and value:
                emoji = value
                break
    if emoji:
        messages.append({"type": "emoji", "content": emoji, "url": f"/emoji/{quote(emoji)}"})
    return add_message_delays(messages)


def _shutdown_farewell_has_natural_token(text: str) -> bool:
    reply = str(text or "").strip()
    if not reply:
        return False
    return any(token in reply for token in ("再见", "拜拜", "告别", "陪你", "先走", "晚安", "回头", "下次"))


def _ensure_shutdown_farewell(text: str, user_msg: str = "") -> str:
    reply = str(text or "").strip()
    if not reply or not _shutdown_farewell_has_natural_token(reply):
        return _contextual_shutdown_farewell_fallback(user_msg)
    return reply


def _build_shutdown_confirmation_payload(user_msg: str = "") -> dict:
    farewell = _build_shutdown_retention(user_msg)
    return {
        "ok": True,
        "reply": farewell,
        "messages": ([{"type": "text", "content": farewell}] if farewell else []),
        "reply_source": "shutdown_retention",
        "requires_shutdown_confirmation": True,
        "shutdown_confirmation_hint": "请再发一次确认词，比如：关机",
    }
def _user_asked_external_context(user_msg: str) -> bool:
    msg = str(user_msg or "")
    return any(token in msg for token in _EXTERNAL_AWARENESS_ASK_TOKENS)


def sanitize_unsolicited_external_reply(user_msg: str, reply: str) -> str:
    _ = user_msg
    return reply if isinstance(reply, str) else ("" if reply is None else str(reply))
def json_reply(**payload):
    payload.setdefault("error", False)
    return jsonify(payload)


def extract_text_content(content):
    """OpenAI clients may send content as text or as a multimodal parts list."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for item in content:
            if isinstance(item, dict) and item.get("type") == "text":
                parts.append(item.get("text", ""))
            elif isinstance(item, str):
                parts.append(item)
        return "\n".join(p for p in parts if p).strip()
    return "" if content is None else str(content)


def normalize_history(messages):
    normalized = []
    for msg in messages or []:
        if not isinstance(msg, dict):
            continue
        role = msg.get("role")
        if role not in ("user", "assistant"):
            continue
        content = extract_text_content(msg.get("content")).strip()
        if content:
            normalized.append({"role": role, "content": content})
    return normalized[-12:]


QUERY_STOPWORDS = {
    "我", "你", "他", "她", "它", "我们", "你们", "他们", "这个", "那个", "这些", "那些",
    "今天", "明天", "后天", "刚才", "现在", "一下", "一点", "有点", "什么", "怎么", "为什么",
    "可以", "不是", "还是", "然后", "一下子", "这个事", "那个事", "事情", "问题", "还有",
}

DOMAIN_QUERY_TERMS = [
    "央企", "笔试", "面试", "考试", "行测", "申论", "错题", "刷题", "睡过头", "熬夜", "睡不着",
    "夜猫子", "累", "焦虑", "难受", "崩溃", "甜食", "甜的", "辣", "生日", "兰州", "河南", "中医",
    "程序员", "说教", "讲道理", "小子", "别问", "陪我", "记住", "别忘", "吃醋", "微信",
]


def normalize_text_key(text):
    text = (text or "").strip().lower()
    return re.sub(r"\W+", "", text)


def extract_query_terms(text, limit=8):
    raw = (text or "").strip().lower()
    if not raw:
        return []

    terms = []
    seen = set()

    def push(term):
        term = (term or "").strip().lower()
        if len(term) < 2 or term in QUERY_STOPWORDS or term in seen:
            return
        seen.add(term)
        terms.append(term)

    for token in re.findall(r"[a-z0-9]{2,}", raw):
        push(token)
        if len(terms) >= limit:
            return terms[:limit]

    for term in DOMAIN_QUERY_TERMS:
        if term in raw:
            push(term)
            if len(terms) >= limit:
                return terms[:limit]

    for block in re.findall(r"[\u4e00-\u9fff]{2,}", raw):
        if block in QUERY_STOPWORDS:
            continue
        if len(block) <= 6:
            push(block)
        for size in (2, 3):
            for idx in range(0, len(block) - size + 1):
                push(block[idx:idx + size])
                if len(terms) >= limit:
                    return terms[:limit]
        if len(terms) >= limit:
            return terms[:limit]

    return terms[:limit]


def score_text_overlap(text, query_terms):
    if not text or not query_terms:
        return 0.0
    haystack = (text or "").lower()
    score = 0.0
    for term in query_terms:
        if term and term in haystack:
            score += 1.0 + min(len(term), 6) * 0.15
    return score


def clean_prompt_snippet(text, limit=72):
    snippet = re.sub(r"\s+", " ", (text or "").strip())
    if len(snippet) > limit:
        snippet = snippet[:limit].rstrip()
    return snippet


def get_merged_growth_payload(user_msg, source_history=None, channel="web"):
    result = request_merge.get_merged_growth_payload(
        user_msg,
        source_history=source_history,
        channel=channel,
        chat_history=chat_history,
        input_merge_lock=input_merge_lock,
        input_merge_batches=input_merge_batches,
        input_merge_seconds=INPUT_MERGE_SECONDS,
        input_merge_max_seconds=INPUT_MERGE_MAX_SECONDS,
        get_growth_payload=get_growth_payload,
        looks_like_explicit_code_review_request=looks_like_explicit_code_review_request,
        is_code_review_followup_with_history=is_code_review_followup_with_history,
        has_due_care_followup=has_due_care_followup,
        intimacy=intimacy,
        attach_agent_run=attach_agent_run,
        record_observability_turn=record_observability_turn,
        record_agent_run_observability=record_agent_run_observability,
        enforce_model_reply_quality=enforce_model_reply_quality,
    )
    if isinstance(result, dict):
        result["reply"] = sanitize_unsolicited_external_reply(user_msg, result.get("reply") or "")
    if isinstance(result, dict) and "weixin" in str(channel or "").lower():
        result["reply"] = sanitize_weixin_temporal_reply(user_msg, result.get("reply") or "")
        try:
            result.update(plan_weixin_media_actions(user_msg, result.get("reply") or "", channel=channel))
        except Exception:
            result.setdefault("media_policy", {"auto_voice": False})
    return result

class RuntimeContext(dict):
    """运行时上下文字典，提供清晰的 KeyError 消息。

    继承 dict 保持完全兼容——isinstance 检查、.get() 等均不受影响。
    仅当使用 runtime["missing_key"] 时抛出带上下文的 KeyError。
    """

    def __missing__(self, key):
        raise KeyError(
            f"RuntimeContext 缺少键 '{key}'。"
            f"可用键 ({len(self)}): {', '.join(sorted(self.keys())[:20])}"
        )


def get_growth_payload(user_msg, source_history=None, channel="web"):
    """
    Shared growth pipeline for the built-in web UI and OpenAI-compatible proxy.

    Maintenance rule:
    - new default-chat behavior belongs in `zhiyue_chat_pipeline.py`
    - `zhiyue_connected.py` should stay as assembly/orchestration only
    """
    return chat_pipeline.get_growth_payload(
        user_msg,
        source_history=source_history,
        runtime=RuntimeContext({
            "growth_entry": growth_entry,
            "growth_finalize": growth_finalize,
            "chat_history": chat_history,
            "technical_chat_history": technical_chat_history,
            "maybe_decay_learning_notes": maybe_decay_learning_notes,
            "prune_expired_state": prune_expired_state,
            "maybe_compact_memories": maybe_compact_memories,
            "looks_like_explicit_code_review_request": looks_like_explicit_code_review_request,
            "is_code_review_followup_with_history": is_code_review_followup_with_history,
            "handle_forced_technical_review": handle_forced_technical_review,
            "tool_source_dir": ZHIYUE_TOOL_SOURCE_DIR,
            "clean_reply": clean_reply,
            "clean_reply_for_mode": clean_reply_for_mode,
            "build_display_messages": build_display_messages,
            "office_task_flow": office_task_flow,
            "office_response": office_response,
            "detect_user_directive": detect_user_directive,
            "load_user_directives": load_user_directives,
            "save_user_directives": save_user_directives,
            "maybe_promote_directives_to_skills": maybe_promote_directives_to_skills,
            "state_hygiene_reply": state_hygiene_reply,
            "self_improvement_chat_approval_reply": self_improvement_chat_approval_reply,
            "code_fix_chat_reply": code_fix_chat_reply,
            "append_history_turn": append_history_turn,
            "intimacy": intimacy,
            "restored_core_short_reply": restored_core_short_reply,
            "schedule_care_followup": schedule_care_followup,
            "autonomous_learn": autonomous_learn,
            "relationship_learn": relationship_learn,
            "log_runtime_exception": log_runtime_exception,
            "rule_hints_builder": rule_hints_builder,
            "load_persona_profile": load_persona_profile,
            "clean_person_name": clean_person_name,
            "learn_user_event": learn_user_event,
            "learn_life_event": learn_life_event,
            "persona_fact_reply": persona_fact_reply,
            "user_low_state_reply": user_low_state_reply,
            "maybe_companion_short_reply": maybe_companion_short_reply,
            "self_improvement_brief_reply": self_improvement_brief_reply,
            "recall_user_event_reply": recall_user_event_reply,
            "remember_recent_user_state": remember_recent_user_state,
            "maybe_wait_return_reply": maybe_wait_return_reply,
            "growth": growth,
            "boundary_reply": boundary_reply,
            "record_direct_rule_turn": record_direct_rule_turn,
            "emotion": emotion,
            "is_technical_request": is_technical_request,
            "run_lm_judge_loop": run_lm_judge_loop,
            "build_companion_skill_hints": build_companion_skill_hints,
            "apply_companion_consistency": apply_companion_consistency,
            "self_review_turn": self_review_turn,
            "cognitive": cognitive,
            "memory": memory,
            "build_runtime_chat_payload": build_runtime_chat_payload,
            "is_placeholder_reply": is_placeholder_reply,
            "build_lm_fallback_reply": build_lm_fallback_reply,
            "enforce_model_reply_quality": enforce_model_reply_quality,
            "soften_reply_for_context": soften_reply_for_context,
            "collapse_reply_segments": collapse_reply_segments,
            "layers": layers,
            "channel": channel,
        }),
    )


def validate_chat_payload(payload, *, channel="web"):
    if not isinstance(payload, dict):
        raise ValueError("chat payload must be a dict")
    reply = payload.get("reply")
    if not isinstance(reply, str):
        payload["reply"] = "" if reply is None else str(reply)
    messages = payload.get("messages")
    if not isinstance(messages, list):
        payload["messages"] = []
    else:
        clean_messages = []
        for item in messages:
            if not isinstance(item, dict):
                continue
            msg_type = str(item.get("type") or "text").strip() or "text"
            content = item.get("content")
            if not isinstance(content, str):
                content = "" if content is None else str(content)
            clean_item = {"type": msg_type, "content": content}
            if "delay_ms" in item:
                try:
                    clean_item["delay_ms"] = int(item.get("delay_ms") or 0)
                except Exception:
                    clean_item["delay_ms"] = 0
            if "url" in item and isinstance(item.get("url"), str):
                clean_item["url"] = item["url"]
            clean_messages.append(clean_item)
        payload["messages"] = clean_messages
    media_actions = payload.get("media_actions")
    if not isinstance(media_actions, list):
        payload["media_actions"] = []
    else:
        clean_actions = []
        for action in media_actions:
            if not isinstance(action, dict):
                continue
            kind = str(action.get("kind") or action.get("type") or "").strip().lower()
            value = action.get("value")
            sender = str(action.get("sender") or "direct").strip().lower() or "direct"
            if kind not in {"voice", "emoji"}:
                continue
            if not isinstance(value, str) or not value.strip():
                continue
            clean_actions.append({"kind": kind, "value": value.strip(), "sender": sender})
        payload["media_actions"] = clean_actions
    media_policy = payload.get("media_policy")
    is_weixin = "weixin" in str(channel or "").lower()
    if not isinstance(media_policy, dict):
        payload["media_policy"] = {"auto_voice": False, "auto_emoji": False}
    else:
        payload["media_policy"] = {
            "auto_voice": False if is_weixin else bool(media_policy.get("auto_voice", False)),
            "auto_emoji": bool(media_policy.get("auto_emoji", False)),
        }
    if is_weixin:
        payload["media_actions"] = [action for action in payload["media_actions"] if action.get("kind") != "voice"]
        payload["voice_text"] = ""
    human_likeness = payload.get("human_likeness")
    payload["human_likeness"] = human_likeness if isinstance(human_likeness, dict) else {}
    self_correction = payload.get("self_correction")
    payload["self_correction"] = self_correction if isinstance(self_correction, dict) else {}
    return payload


def build_chat_smoke_result(
    *,
    user_msg="你好",
    channel="health:smoke",
    include_reply=False,
):
    started = time.perf_counter()
    try:
        payload = get_merged_growth_payload(user_msg, channel=channel)
        if isinstance(payload, dict) and payload.get("error"):
            elapsed_ms = int((time.perf_counter() - started) * 1000)
            return {
                "ok": False,
                "status": "error",
                "probe": "chat",
                "channel": channel,
                "user_msg": user_msg,
                "elapsed_ms": elapsed_ms,
                "error_code": payload.get("error_code") or "chat_error",
                "error_message": str(payload.get("error_message") or payload.get("error") or "chat probe failed"),
            }
        payload = validate_chat_payload(payload or {}, channel=channel)
        reply = str(payload.get("reply") or "").strip()
        placeholder_reply = bool(reply) and is_placeholder_reply(reply)
        elapsed_ms = int((time.perf_counter() - started) * 1000)
        result = {
            "ok": bool(reply) and not placeholder_reply,
            "status": "ok" if reply and not placeholder_reply else "degraded",
            "probe": "chat",
            "channel": channel,
            "user_msg": user_msg,
            "elapsed_ms": elapsed_ms,
            "reply_length": len(reply),
            "message_count": len(payload.get("messages") or []),
            "reply_source": str(payload.get("reply_source") or ""),
            "placeholder_reply": placeholder_reply,
        }
        if not reply:
            result["error_code"] = "empty_reply"
            result["error_message"] = "chat probe returned empty reply"
        elif placeholder_reply:
            result["error_code"] = "placeholder_reply"
            result["error_message"] = "chat probe returned placeholder reply"
        if include_reply:
            result["reply"] = reply
            result["messages"] = payload.get("messages") or []
        return result
    except Exception as err:
        elapsed_ms = int((time.perf_counter() - started) * 1000)
        log_runtime_exception("chat_smoke_probe", err)
        return {
            "ok": False,
            "status": "error",
            "probe": "chat",
            "channel": channel,
            "user_msg": user_msg,
            "elapsed_ms": elapsed_ms,
            "error_code": "exception",
            "error_message": str(err)[:240],
        }


# ============ 构建动态Prompt(成长系统染色 v2) ============
def build_growth_prompt(user_msg, history, rule_hints=None, user_directives=None):
    return build_compact_growth_prompt(
        user_msg,
        history,
        rule_hints=rule_hints,
        user_directives=user_directives,
    )

# ============ ??? LM Studio ============
def call_lm(user_msg, history, *, user_directives=None):
    global LAST_LM_ERROR
    try:
        test_reply = os.environ.get("ZHIYUE_TEST_REPLY")
        if test_reply:
            return clean_reply(test_reply)
        pipeline = run_lm_judge_loop(
            user_msg,
            history,
            route_hint="lm",
            user_directives=user_directives,
        )
        return clean_reply(pipeline.get("reply") or "")
    except Exception as err:
        LAST_LM_ERROR = str(err)
        _dbg.error("[LM???] %s", err)
        return ""

# ============ Flask + Web界面 ============
bind_layer_tools()

try:
    from flask import Flask, request, jsonify, render_template_string, send_from_directory, Response
except ImportError:
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "flask"], capture_output=True)
    from flask import Flask, request, jsonify, render_template_string, send_from_directory, Response

app = Flask(__name__)

HTML_TEMPLATE = '''
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>张致悦 AI</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        html, body { width: 100%; height: 100%; overflow: hidden; }
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Microsoft YaHei", sans-serif;
               background: #f3f3f3; color: #111; }
        .app { height: 100vh; display: flex; flex-direction: column; background: #f5f5f5; }
        .header { height: 48px; background: #f7f7f7; border-bottom: 1px solid #e7e7e7;
                  display: flex; justify-content: center; align-items: center; padding: 0 12px; flex: 0 0 auto; position: relative; }
        .hdr-actions { position: absolute; right: 12px; top: 9px; display: flex; gap: 6px; }
        .title { min-width: 0; display: flex; align-items: center; gap: 8px; }
        .title h1 { font-size: 15px; font-weight: 500; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .exit-btn, .settings-btn { border: 0; background: transparent; color: #777;
                    font-size: 14px; padding: 5px 7px; border-radius: 4px; cursor: pointer; }
        .exit-btn:hover, .settings-btn:hover { background: #ececec; color: #111; }
        .chat-container { flex: 1 1 auto; overflow-y: auto; padding: 30px 16px 22px;
                          display: flex; flex-direction: column; gap: 12px; background: #f5f5f5; }
        .time-divider { align-self: center; color: #b0b0b0; font-size: 12px; margin: 8px 0 10px; }
        .row { display: flex; gap: 10px; align-items: flex-start; max-width: 82%; }
        .row.user-row { align-self: flex-end; flex-direction: row-reverse; }
        .avatar { width: 36px; height: 36px; border-radius: 4px; object-fit: cover; flex: 0 0 auto; }
        .message { position: relative; padding: 9px 12px; border-radius: 5px; line-height: 1.55;
                   font-size: 14px; word-break: break-word; white-space: pre-wrap; min-height: 36px;
                   max-width: min(470px, calc(100vw - 132px)); box-shadow: 0 1px 0 rgba(0,0,0,0.02); }
        .ai { background: #fff; color: #111; }
        .user { background: #95ec69; color: #111; }
        .ai:before { content: ""; position: absolute; left: -5px; top: 12px; border-top: 5px solid transparent;
                     border-bottom: 5px solid transparent; border-right: 5px solid #fff; }
        .user:after { content: ""; position: absolute; right: -5px; top: 12px; border-top: 5px solid transparent;
                      border-bottom: 5px solid transparent; border-left: 5px solid #95ec69; }
        .emoji-bubble { background: transparent; padding: 0; min-height: 0; box-shadow: none; }
        .emoji-bubble:before, .emoji-bubble:after { display: none; }
        .emoji-img { display: block; max-width: 118px; max-height: 118px; border-radius: 6px; object-fit: contain; }
        .typing { color: #a0a0a0; font-size: 12px; padding: 3px 0 10px; text-align: center; background: #f5f5f5; flex: 0 0 auto; }
        .status { display: none; color: #8a6d3b; background: #fff4d6; border-top: 1px solid #f0dfad;
                  border-bottom: 1px solid #f0dfad; padding: 8px 12px; font-size: 13px; line-height: 1.5; }
        .input-area { background: #f7f7f7; padding: 10px 12px 12px; border-top: 1px solid #dedede;
                      display: grid; grid-template-columns: 1fr auto; gap: 8px; align-items: end; flex: 0 0 auto; }
        .input-wrap { min-height: 70px; background: #fff; border: 1px solid #e5e5e5; border-radius: 6px; padding: 8px; }
        .input-area textarea { width: 100%; height: 54px; max-height: 140px; resize: none; border: 0; outline: none;
                               font-size: 15px; line-height: 1.5; background: transparent; font-family: inherit; }
        .input-area button { background: #07c160; color: white; border: none; padding: 9px 18px;
                             border-radius: 5px; cursor: pointer; font-size: 14px; white-space: nowrap; min-width: 64px; }
        .input-area button:disabled { opacity: 0.55; cursor: not-allowed; }
        .error-note { color: #999; }
        @media (max-width: 560px) {
            .row { max-width: 92%; }
            .chat-container { padding-left: 10px; padding-right: 10px; }
        }
        .modal-backdrop { position: fixed; inset: 0; background: rgba(0,0,0,0.36); display:none; align-items: center; justify-content: center; padding: 18px; z-index: 999; }
        .modal { width: min(860px, 100%); max-height: min(82vh, 720px); overflow: hidden; background: #fff; border-radius: 10px; border: 1px solid rgba(0,0,0,0.08); box-shadow: 0 18px 50px rgba(0,0,0,0.18); display: flex; flex-direction: column; }
        .modal header { height: 46px; display:flex; align-items:center; justify-content: space-between; padding: 0 14px; border-bottom: 1px solid #eee; background: #fafafa; }
        .modal header h2 { font-size: 14px; margin: 0; font-weight: 650; }
        .modal .body { padding: 14px; overflow: auto; display: grid; gap: 10px; }
        .grid2 { display:grid; grid-template-columns: 1fr 1fr; gap: 10px; }
        .field { display:grid; gap: 6px; }
        .field label { font-size: 12px; color: #555; }
        .field input, .field select, .field textarea { width: 100%; border: 1px solid #e5e5e5; border-radius: 8px; padding: 9px 10px; font-size: 13px; outline: none; }
        .field textarea { min-height: 86px; font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace; }
        .muted { color:#777; font-size: 12px; line-height: 1.45; }
        .actions { display:flex; gap: 8px; justify-content: flex-end; padding: 12px 14px; border-top: 1px solid #eee; background: #fafafa; }
        .btn { border: 1px solid #d8d8d8; background: #fff; border-radius: 8px; padding: 9px 12px; font-size: 13px; cursor: pointer; }
        .btn.primary { background:#07c160; border-color:#07c160; color:#fff; }
        .btn.danger { border-color:#e6b3b3; background:#fff6f6; }
        .btn:disabled { opacity: 0.55; cursor: not-allowed; }
        @media (max-width: 820px) { .grid2 { grid-template-columns: 1fr; } }
    </style>
</head>
<body>
<div class="app">
    <div class="header">
        <div class="title">
            <h1>张致悦</h1>
        </div>
        <div class="hdr-actions">
            <button class="settings-btn" onclick="openSettings()">设置</button>
            <button class="exit-btn" onclick="exitApp()">退出</button>
        </div>
    </div>
    <div class="chat-container" id="chat">
        <div class="time-divider">{{ now_time }}</div>
        {% for msg in history %}
        <div class="row {{ 'user-row' if msg.role == 'user' else 'ai-row' }}">
            <img class="avatar" src="{{ '/avatar/user' if msg.role == 'user' else '/avatar/ai' }}" alt="">
            <div class="message {{ 'user' if msg.role == 'user' else 'ai' }}">{{ msg.content }}</div>
        </div>
        {% endfor %}
    </div>
    <div class="typing" id="typing" style="display:none">张致悦 正在输入...</div>
    <div class="status" id="status"></div>
    <div class="input-area">
        <div class="input-wrap">
            <textarea id="msg" placeholder="" autofocus></textarea>
        </div>
        <button onclick="send()">发送</button>
    </div>
</div>
<div class="modal-backdrop" id="settingsModal">
  <div class="modal" role="dialog" aria-modal="true">
    <header>
      <h2>API 配置 (用于中转站 / 官方 API)</h2>
      <button class="btn" onclick="closeSettings()">关闭</button>
    </header>
    <div class="body">
      <div class="muted">手机端推荐用 Tavo 连接“远端 companion”的 OpenAI 兼容接口；这里主要用于本机后端配置和联调。</div>
      <div class="grid2">
        <div class="field">
          <label>协议</label>
          <select id="cfg_protocol">
            <option value="openai_compatible">OpenAI 兼容</option>
            <option value="anthropic">Anthropic (Claude)</option>
            <option value="gemini">Gemini (native)</option>
          </select>
        </div>
        <div class="field">
          <label>启用 API 模式</label>
          <select id="cfg_enabled">
            <option value="1">启用</option>
            <option value="0">不启用(使用当前环境变量)</option>
          </select>
        </div>
      </div>
      <div class="grid2">
        <div class="field">
          <label>Base URL</label>
          <input id="cfg_base_url" placeholder="例如 https://xxx.example.com/v1 或 https://api.openai.com/v1" />
        </div>
        <div class="field">
          <label>API Key</label>
          <input id="cfg_api_key" placeholder="以 sk-... 或其它 token 形式" />
        </div>
      </div>
        <div class="field">
          <label>Extra Headers (JSON，可选)</label>
          <textarea id="cfg_headers" placeholder='{"X-xxx":"yyy"}'></textarea>
        </div>
      <div class="grid2">
        <div class="field">
          <label>远端同步 Base URL（可选）</label>
          <input id="cfg_remote_base" placeholder="例如 https://your-companion.example.com" />
        </div>
        <div class="field">
          <label>远端同步 Token（可选）</label>
          <input id="cfg_remote_token" placeholder="用于 /api/sync/* 的 X-Zhiyue-Sync" />
        </div>
      </div>
      <div class="grid2">
        <div class="field">
          <label>Main 模型</label>
          <input id="cfg_model_main" list="cfg_models_list" placeholder="例如 gpt-5.5 / claude-xxx / qwen-xxx" />
        </div>
        <div class="field">
          <label>State 模型</label>
          <input id="cfg_model_state" list="cfg_models_list" placeholder="例如 gpt-5.4 / gemini-xxx" />
        </div>
      </div>
      <div class="grid2">
        <div class="field">
          <label>Review 模型</label>
          <input id="cfg_model_review" list="cfg_models_list" placeholder="例如 gpt-5.3-codex / claude-xxx" />
        </div>
        <div class="field">
          <label>提示</label>
          <div class="muted">如果你用“中转站 OpenAI 兼容”，Base URL 通常填到 <b>/v1</b>，不需要写到 <b>/chat/completions</b>。</div>
        </div>
      </div>
      <datalist id="cfg_models_list"></datalist>
      <div class="field">
        <label>测试结果</label>
        <pre id="cfg_test_out" style="margin:0;background:#f6f8fa;border:1px solid #e5e5e5;border-radius:8px;padding:10px;font-size:12px;white-space:pre-wrap;word-break:break-word;min-height:70px;"></pre>
      </div>
    </div>
    <div class="actions">
      <button class="btn" onclick="testProvider('all')">测全部</button>
      <button class="btn" onclick="fetchModels('main')">列 models</button>
      <button class="btn" onclick="refreshModels()">刷新下拉</button>
      <button class="btn" onclick="applyRecommended()">推荐组合</button>
      <button class="btn" onclick="testProvider('main')">测 main</button>
      <button class="btn" onclick="testProvider('state')">测 state</button>
      <button class="btn" onclick="testProvider('review')">测 review</button>
      <button class="btn primary" onclick="saveProvider()">保存</button>
    </div>
  </div>
</div>
    <script>
        function escapeHtml(text) {
            return String(text)
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#39;');
        }

        function appendMessage(cls, item) {
            const chat = document.getElementById('chat');
            const payload = typeof item === 'string' ? {type: 'text', content: item} : item;
            const row = document.createElement('div');
            row.className = 'row ' + (cls === 'user' ? 'user-row' : 'ai-row');
            const avatar = document.createElement('img');
            avatar.className = 'avatar';
            avatar.src = cls === 'user' ? '/avatar/user' : '/avatar/ai';
            const bubble = document.createElement('div');
            bubble.className = 'message ' + cls + (payload.type === 'emoji' ? ' emoji-bubble' : '');
            if (payload.type === 'emoji') {
                const img = document.createElement('img');
                img.className = 'emoji-img';
                img.src = payload.url;
                img.alt = payload.content || 'emoji';
                bubble.appendChild(img);
            } else {
                bubble.textContent = payload.content || '';
            }
            row.appendChild(avatar);
            row.appendChild(bubble);
            chat.appendChild(row);
            chat.scrollTop = chat.scrollHeight;
        }

        function setStatusNotice(text) {
            const el = document.getElementById('status');
            if (!el) return;
            if (text) {
                el.textContent = text;
                el.style.display = 'block';
            } else {
                el.textContent = '';
                el.style.display = 'none';
            }
        }

        function appendAiMessages(messages) {
            const items = Array.isArray(messages) ? messages.filter(item => item && (item.content || item.url)) : [];
            if (!items.length) return 0;
            let delay = 0;
            items.forEach((item) => {
                delay += item.delay_ms || (item.type === 'emoji' ? 350 : 650 + Math.min((item.content || '').length * 35, 900));
                setTimeout(() => appendMessage('ai', item), delay);
            });
            return delay;
        }

        function updateStats(data) {
            if (!data || !data.level) return;
            return;
        }

        function send() {
            const input = document.getElementById('msg');
            const msg = input.value.trim();
            if (!msg) return;
            setStatusNotice('');
            input.value = '';
            input.style.height = '54px';

            appendMessage('user', msg);

            document.getElementById('typing').style.display = 'block';
            const button = document.querySelector('.input-area button');
            button.disabled = true;
            const controller = new AbortController();
            const timer = setTimeout(() => controller.abort(), 300000);

            fetch('/api/chat', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({message: msg}),
                signal: controller.signal
            }).then(r => r.json()).then(data => {
                clearTimeout(timer);
                if (data && data.coalesced_skip) {
                    document.getElementById('typing').style.display = 'none';
                    button.disabled = false;
                    return;
                }
                if (data && data.error) {
                    document.getElementById('typing').style.display = 'none';
                    button.disabled = false;
                    setStatusNotice(data.error_message || '模型服务暂时不可用');
                    return;
                }
                const wait = appendAiMessages(data.messages || (data.reply ? [{type: 'text', content: data.reply}] : []));
                setTimeout(() => {
                    document.getElementById('typing').style.display = 'none';
                    button.disabled = false;
                }, wait + 100);
                updateStats(data);
            }).catch(() => {
                clearTimeout(timer);
                document.getElementById('typing').style.display = 'none';
                button.disabled = false;
                setStatusNotice('模型服务暂时不可用');
            });
        }

        const input = document.getElementById('msg');
        input.addEventListener('keydown', function(event) {
            if (event.key === 'Enter' && !event.shiftKey) {
                event.preventDefault();
                send();
            }
        });
        input.addEventListener('input', function() {
            this.style.height = '54px';
            this.style.height = Math.min(this.scrollHeight, 140) + 'px';
        });
        window.addEventListener('load', function() {
            document.getElementById('chat').scrollTop = document.getElementById('chat').scrollHeight;
            input.focus();
        });
        setInterval(function() {
            fetch('/api/proactive')
                .then(r => r.json())
                .then(data => {
                    if (data && data.ok && data.messages) {
                        document.getElementById('typing').style.display = 'block';
                        const wait = appendAiMessages(data.messages);
                        setTimeout(() => {
                            document.getElementById('typing').style.display = 'none';
                        }, wait + 100);
                    }
                })
                .catch(() => {});
        }, 60000);
        function exitApp() {
            fetch('/api/shutdown', {method: 'POST'}).catch(() => {});
            document.body.innerHTML = '<div style="height:100vh;display:flex;align-items:center;justify-content:center;background:#f5f5f5;color:#777;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Microsoft YaHei,sans-serif;">已退出</div>';
            setTimeout(function() {
                window.close();
            }, 500);
        }

        function openSettings() {
            const m = document.getElementById('settingsModal');
            if (!m) return;
            m.style.display = 'flex';
            loadProvider();
        }
        function closeSettings() {
            const m = document.getElementById('settingsModal');
            if (!m) return;
            m.style.display = 'none';
        }
        function _set(id, v) { const el = document.getElementById(id); if (el) el.value = v ?? ''; }
        function _out(text) { const el = document.getElementById('cfg_test_out'); if (el) el.textContent = text ?? ''; }
        function loadProvider() {
            _out('');
            fetch('/api/provider/config').then(r => r.json()).then(cfg => {
                _set('cfg_protocol', cfg.protocol || 'openai_compatible');
                _set('cfg_enabled', cfg.enabled ? '1' : '0');
                _set('cfg_base_url', cfg.base_url || '');
                _set('cfg_api_key', cfg.api_key_masked || '');
                _set('cfg_headers', cfg.headers_json || '');
                _set('cfg_remote_base', (cfg.mobile_sync?.remote_base_url) || '');
                _set('cfg_remote_token', (cfg.mobile_sync?.access_token_masked) || '');
                _set('cfg_model_main', (cfg.roles?.main?.model) || '');
                _set('cfg_model_state', (cfg.roles?.state?.model) || '');
                _set('cfg_model_review', (cfg.roles?.review?.model) || '');
            }).catch(() => {});
        }
        function _collectCfg() {
            return {
                enabled: document.getElementById('cfg_enabled')?.value === '1',
                protocol: document.getElementById('cfg_protocol')?.value || 'openai_compatible',
                base_url: document.getElementById('cfg_base_url')?.value || '',
                api_key: document.getElementById('cfg_api_key')?.value || '',
                headers: document.getElementById('cfg_headers')?.value || '',
                mobile_sync: {
                    remote_base_url: document.getElementById('cfg_remote_base')?.value || '',
                    access_token: document.getElementById('cfg_remote_token')?.value || '',
                    enabled: Boolean((document.getElementById('cfg_remote_base')?.value || '').trim()),
                },
                roles: {
                    main: { model: document.getElementById('cfg_model_main')?.value || '' },
                    state: { model: document.getElementById('cfg_model_state')?.value || '' },
                    review: { model: document.getElementById('cfg_model_review')?.value || '' },
                }
            };
        }
        function saveProvider() {
            _out('保存中...');
            fetch('/api/provider/config', {
                method: 'POST',
                headers: {'Content-Type':'application/json'},
                body: JSON.stringify(_collectCfg()),
            }).then(r => r.json()).then(data => {
                _out(JSON.stringify(data, null, 2));
                loadProvider();
            }).catch(() => _out('保存失败'));
        }
        function testProvider(role) {
            _out('测试中...');
            fetch('/api/provider/test', {
                method:'POST',
                headers:{'Content-Type':'application/json'},
                body: JSON.stringify(role === 'all' ? {roles: ['main','state','review']} : {role: role}),
            }).then(r => r.json()).then(data => {
                _out(JSON.stringify(data, null, 2));
            }).catch(() => _out('测试失败'));
        }

        function fetchModels(role) {
            _out('拉取模型列表中...');
            fetch('/api/provider/upstream_models', {
                method:'POST',
                headers:{'Content-Type':'application/json'},
                body: JSON.stringify({role: role || 'main'}),
            }).then(r => r.json()).then(data => {
                _out(JSON.stringify(data, null, 2));
            }).catch(() => _out('拉取失败'));
        }

        function refreshModels() {
            const base = document.getElementById('cfg_base_url')?.value || '';
            if (!String(base).trim()) {
                _out('请先填写 Base URL，再刷新模型下拉。');
                return;
            }
            _out('刷新模型下拉中...');
            fetch('/api/provider/upstream_models', {
                method:'POST',
                headers:{'Content-Type':'application/json'},
                body: JSON.stringify({role: 'main'}),
            }).then(r => r.json()).then(data => {
                const list = document.getElementById('cfg_models_list');
                if (!list) return;
                const models = (data && data.ok && Array.isArray(data.models)) ? data.models : [];
                list.innerHTML = models.map(m => `<option value="${escapeHtml(m)}"></option>`).join('');
                _out(JSON.stringify({ok: true, count: models.length}, null, 2));
            }).catch(() => _out('刷新失败'));
        }

        function applyRecommended() {
            const list = document.getElementById('cfg_models_list');
            const options = Array.from(list?.querySelectorAll('option') || []).map(o => o.value).filter(Boolean);
            const has = (name) => options.includes(name);
            const pick = (...candidates) => candidates.find(has) || candidates.find(Boolean) || '';

            // Heuristics: prefer larger for main, cheaper/stable for state, stricter for review.
            const main = pick('gpt-5.5', 'gpt-5.4', 'claude-opus-4-7', 'claude-opus-4-6');
            const state = pick('gpt-5.4', 'gpt-5.3-codex', 'gpt-5.5');
            const review = pick('gpt-5.3-codex', 'gpt-5.4', 'gpt-5.5');

            if (main) _set('cfg_model_main', main);
            if (state) _set('cfg_model_state', state);
            if (review) _set('cfg_model_review', review);

            _out(JSON.stringify({ok:true, applied:{main, state, review}}, null, 2));
        }
    </script>
</body>
</html>
'''

OBSERVABILITY_TEMPLATE = '''
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>观测面板</title>
    <style>
        * { box-sizing: border-box; }
        body { margin: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Microsoft YaHei", sans-serif; background: #f4f5f7; color: #1f2328; }
        .shell { min-height: 100vh; display: grid; grid-template-rows: auto auto 1fr; }
        header { height: 52px; display: flex; align-items: center; justify-content: space-between; padding: 0 18px; background: #ffffff; border-bottom: 1px solid #d8dee4; }
        h1 { font-size: 16px; margin: 0; font-weight: 650; }
        .nav { display: flex; gap: 8px; align-items: center; }
        button, a.btn { border: 1px solid #d0d7de; background: #fff; color: #24292f; border-radius: 6px; height: 32px; padding: 0 10px; font-size: 13px; cursor: pointer; text-decoration: none; display: inline-flex; align-items: center; }
        button:hover, a.btn:hover { background: #f3f4f6; }
        .summary { display: grid; grid-template-columns: repeat(6, minmax(0, 1fr)); gap: 10px; padding: 12px 16px; }
        .metric { background: #fff; border: 1px solid #d8dee4; border-radius: 6px; padding: 10px 12px; min-height: 72px; }
        .metric .label { font-size: 12px; color: #57606a; }
        .metric .value { font-size: 22px; font-weight: 650; margin-top: 6px; }
        .content { display: grid; grid-template-columns: minmax(420px, 1.15fr) minmax(360px, .85fr); gap: 12px; padding: 0 16px 16px; min-height: 0; }
        .panel { background: #fff; border: 1px solid #d8dee4; border-radius: 6px; min-height: 0; overflow: hidden; display: flex; flex-direction: column; }
        .panel h2 { margin: 0; padding: 10px 12px; font-size: 14px; border-bottom: 1px solid #d8dee4; background: #f6f8fa; }
        .list { overflow: auto; }
        .trace { padding: 10px 12px; border-bottom: 1px solid #eaeef2; display: grid; gap: 7px; }
        .trace:hover { background: #f6f8fa; }
        .trace-head { display: flex; justify-content: space-between; gap: 10px; align-items: center; }
        .score { font-weight: 650; }
        .score.low { color: #b42318; }
        .score.mid { color: #9a6700; }
        .score.good { color: #1a7f37; }
        .text { font-size: 13px; line-height: 1.45; white-space: pre-wrap; word-break: break-word; }
        .muted { color: #57606a; font-size: 12px; }
        .chips { display: flex; flex-wrap: wrap; gap: 5px; }
        .chip { font-size: 12px; padding: 2px 6px; border-radius: 999px; background: #eef2f7; color: #4b5563; }
        .chip.flag { background: #fff1f1; color: #b42318; }
        .chip.hit { background: #e8f5ee; color: #1a7f37; }
        .detail { padding: 12px; overflow: auto; display: grid; gap: 12px; }
        .kv { display: grid; grid-template-columns: 110px 1fr; gap: 8px; font-size: 13px; }
        pre { margin: 0; white-space: pre-wrap; word-break: break-word; background: #f6f8fa; border: 1px solid #d8dee4; border-radius: 6px; padding: 10px; font-size: 12px; line-height: 1.45; }
        .empty { padding: 28px 12px; color: #57606a; font-size: 13px; }
        @media (max-width: 980px) {
            .summary { grid-template-columns: repeat(2, minmax(0, 1fr)); }
            .content { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
<div class="shell">
    <header>
        <h1>观测面板</h1>
        <div class="nav">
            <a class="btn" href="/">聊天</a>
            <button onclick="loadData()">刷新</button>
        </div>
    </header>
    <section class="summary" id="summary"></section>
    <main class="content">
        <section class="panel">
            <h2>最近 50 轮</h2>
            <div class="list" id="traceList"><div class="empty">加载中</div></div>
        </section>
        <section class="panel">
            <h2>详情</h2>
            <div class="detail" id="detail"><div class="empty">选择一条 trace</div></div>
        </section>
    </main>
</div>
<script>
let traces = [];
let selected = null;

function escapeHtml(text) {
    return String(text ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function scoreClass(score) {
    const value = Number(score || 0);
    if (value < 7) return 'low';
    if (value < 9) return 'mid';
    return 'good';
}

function renderSummary(summary) {
    const flags = summary.flags || {};
    const flagTotal = Object.values(flags).reduce((a, b) => a + Number(b || 0), 0);
    const items = [
        ['总轮数', summary.total || 0],
        ['平均分', summary.avg_score || 0],
        ['记忆命中率', Math.round((summary.memory_hit_rate || 0) * 100) + '%'],
        ['低分样例', summary.low_score_count || 0],
        ['风险标记', flagTotal],
        ['平均延迟', Math.round(summary.avg_latency_ms || 0) + 'ms'],
    ];
    document.getElementById('summary').innerHTML = items.map(([label, value]) => (
        `<div class="metric"><div class="label">${escapeHtml(label)}</div><div class="value">${escapeHtml(value)}</div></div>`
    )).join('');
}

function renderList() {
    const el = document.getElementById('traceList');
    if (!traces.length) {
        el.innerHTML = '<div class="empty">还没有 trace</div>';
        return;
    }
    el.innerHTML = traces.map((t, idx) => {
        const flags = (t.flags || []).map(f => `<span class="chip flag">${escapeHtml(f)}</span>`).join('');
        const hit = t.memory_hit ? `<span class="chip hit">记忆 ${t.memory_hit_count || 0}</span>` : '<span class="chip">无记忆</span>';
        return `<div class="trace" onclick="selectTrace(${idx})">
            <div class="trace-head">
                <div class="muted">${escapeHtml(t.created_at || '')} · ${escapeHtml(t.channel || '')} · ${escapeHtml(t.route || '')}</div>
                <div class="score ${scoreClass(t.score)}">${escapeHtml(t.score)}</div>
            </div>
            <div class="text"><b>U</b> ${escapeHtml(t.user_msg || '')}</div>
            <div class="text"><b>A</b> ${escapeHtml(t.reply || '')}</div>
            <div class="chips">${hit}${flags}</div>
        </div>`;
    }).join('');
}

function renderDetail() {
    const el = document.getElementById('detail');
    if (!selected) {
        el.innerHTML = '<div class="empty">选择一条 trace</div>';
        return;
    }
    const recalled = selected.recalled || [];
    const recallHtml = recalled.length ? recalled.map(item => (
        `<pre>${escapeHtml(JSON.stringify({
            content: item.content || item.title || '',
            source: item.source || item.retrieval_backend || '',
            score: item.score,
            reason: item.hit_reason || item.matched_terms || []
        }, null, 2))}</pre>`
    )).join('') : '<div class="empty">无记忆命中</div>';
    el.innerHTML = `
        <div class="kv"><div class="muted">Trace</div><div>${escapeHtml(selected.id)}</div></div>
        <div class="kv"><div class="muted">Flags</div><div>${(selected.flags || []).map(f => `<span class="chip flag">${escapeHtml(f)}</span>`).join('') || '<span class="chip">无</span>'}</div></div>
        <div class="kv"><div class="muted">记忆</div><div>${selected.memory_hit ? `${selected.memory_hit_count || recalled.length} 条` : '未命中'}</div></div>
        <div><div class="muted">用户</div><pre>${escapeHtml(selected.user_msg || '')}</pre></div>
        <div><div class="muted">回复</div><pre>${escapeHtml(selected.reply || '')}</pre></div>
        <div><div class="muted">命中详情</div>${recallHtml}</div>
        <div><div class="muted">Metrics</div><pre>${escapeHtml(JSON.stringify(selected.metrics || {}, null, 2))}</pre></div>
        <button onclick="addRegression()">加入回归用例</button>
    `;
}

function selectTrace(index) {
    selected = traces[index];
    renderDetail();
}

async function addRegression() {
    if (!selected) return;
    const resp = await fetch('/api/observability/regression', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({trace_id: selected.id})
    });
    const data = await resp.json();
    if (!data.ok) {
        alert(data.error || '加入失败');
        return;
    }
    alert('已加入:' + data.case.id);
}

async function loadData() {
    const resp = await fetch('/api/observability?limit=50');
    const data = await resp.json();
    renderSummary(data.summary || {});
    traces = data.traces || [];
    selected = traces[0] || null;
    renderList();
    renderDetail();
}

loadData();
</script>
</body>
</html>
'''

@app.route('/')
def index():
    stage = intimacy.get_stage()
    mood_emoji = {"happy": "开心", "angry": "生气", "shy": "害羞", "jealous": "吃醋", "neutral": "平静"}.get(emotion.emotion, "平静")
    return render_template_string(HTML_TEMPLATE,
        level=intimacy.data["level"],
        stage=stage,
        mood=emotion.happiness,
        mood_emoji=mood_emoji,
        energy=intimacy.data.get("energy", 100),
        mood_val=intimacy.data.get("mood", 100),
        streak=intimacy.data.get("streak", 0),
        total_chats=intimacy.data.get("total_chats", 0),
        personality=intimacy.get_personality_desc(),
        now_time=now_local().strftime("%H:%M"),
        history=chat_history[-20:]
    )


@app.route('/observability')
def observability_page():
    return render_template_string(OBSERVABILITY_TEMPLATE)


@app.route('/assets/<path:filename>')
def assets(filename):
    return send_from_directory(BASE_DIR, filename)


@app.route('/avatar/<who>')
def avatar(who):
    filename = "user_avatar.jpg" if who == "user" else "张致悦_avatar.jpg"
    return send_from_directory(BASE_DIR, filename)


@app.route('/emoji/<path:filename>')
def emoji(filename):
    return send_from_directory(EMOJI_DIR, filename)


@app.route('/v1', methods=['GET'])
def openai_root():
    return jsonify({
        "ok": True,
        "name": "zhiyue-growth-proxy",
        "base_url": "http://127.0.0.1:8899/v1",
        "model": "zhiyue",
    })


@app.route('/models', methods=['GET'])
@app.route('/v1/models', methods=['GET'])
def openai_models():
    now = int(time.time())
    try:
        cfg = _load_provider_config()
        from zhiyue_llm_provider import resolve_role_runtime as _resolve_role_runtime
        role_models = [
            str(_resolve_role_runtime(role, config=cfg).get("model") or "").strip()
            for role in ("main", "state", "review")
        ]
        role_models = [m for m in role_models if m]
    except Exception:
        role_models = []
    # Deduplicate while preserving order.
    seen = set()
    role_models_unique = []
    for item in role_models:
        if item in seen:
            continue
        seen.add(item)
        role_models_unique.append(item)
    return jsonify({
        "object": "list",
        "data": [
            {
                "id": "zhiyue",
                "object": "model",
                "created": now,
                "owned_by": "local-growth-system",
            },
            # Stable aliases: some clients prefer a "specific" model id.
            {
                "id": "zhiyue-main",
                "object": "model",
                "created": now,
                "owned_by": "local-growth-system",
            },
            {
                "id": "zhiyue-state",
                "object": "model",
                "created": now,
                "owned_by": "local-growth-system",
            },
            {
                "id": "zhiyue-review",
                "object": "model",
                "created": now,
                "owned_by": "local-growth-system",
            },
            *([
                {
                    "id": model_id,
                    "object": "model",
                    "created": now,
                    "owned_by": "provider",
                }
                for model_id in role_models_unique
            ]),
            *([
                {
                    "id": LM_MODEL,
                    "object": "model",
                    "created": now,
                    "owned_by": "legacy",
                }
            ] if LM_MODEL else []),
        ],
    })


def _mask_secret(value: str) -> str:
    raw = str(value or "").strip()
    if not raw:
        return ""
    if len(raw) <= 8:
        return raw[:2] + "****"
    return raw[:4] + "..." + raw[-4:]


@app.route("/api/provider/config", methods=["GET", "POST"])
def api_provider_config():
    if request.method == "GET":
        cfg = _load_provider_config()
    else:
        incoming = request.json or {}
        incoming = incoming if isinstance(incoming, dict) else {}

        # Prevent masked secrets from overwriting the real secret when users click "save"
        # without re-entering the key/token.
        def _looks_masked_secret(v: object) -> bool:
            s = str(v or "")
            return ("****" in s) or ("..." in s)

        if _looks_masked_secret(incoming.get("api_key")):
            incoming.pop("api_key", None)
        ms = incoming.get("mobile_sync")
        if isinstance(ms, dict) and _looks_masked_secret(ms.get("access_token")):
            ms = dict(ms)
            ms.pop("access_token", None)
            incoming["mobile_sync"] = ms

        cfg = _save_provider_config(incoming)

    api_key = str(cfg.get("api_key") or "").strip()
    masked = dict(cfg)
    masked["api_key_masked"] = _mask_secret(api_key)
    masked.pop("api_key", None)
    ms = masked.get("mobile_sync")
    if isinstance(ms, dict):
        ms = dict(ms)
        token = str(ms.get("access_token") or "").strip()
        ms["access_token_masked"] = _mask_secret(token)
        ms.pop("access_token", None)
        masked["mobile_sync"] = ms
    try:
        masked["headers_json"] = json.dumps(masked.get("headers") or {}, ensure_ascii=False, indent=2)
    except Exception:
        masked["headers_json"] = ""
    return jsonify(masked)


@app.route("/api/provider/test", methods=["POST"])
def api_provider_test():
    data = request.json or {}
    if not isinstance(data, dict):
        data = {}
    roles = data.get("roles")
    if isinstance(roles, list):
        requested = []
        for item in roles:
            r = str(item or "").strip().lower()
            if r in {"main", "state", "review"} and r not in requested:
                requested.append(r)
        if not requested:
            requested = ["main", "state", "review"]
        results = {r: _provider_healthcheck(r) for r in requested}
        ok = all(bool(results[r].get("ok")) for r in requested)
        return jsonify({"ok": ok, "results": results})

    role = str(data.get("role") or "main").strip().lower()
    if role not in {"main", "state", "review"}:
        role = "main"
    return jsonify(_provider_healthcheck(role))


@app.route("/api/provider/upstream_models", methods=["POST"])
def api_provider_upstream_models():
    data = request.json or {}
    role = str((data.get("role") if isinstance(data, dict) else "") or "main").strip().lower()
    if role not in {"main", "state", "review"}:
        role = "main"
    try:
        cfg = _load_provider_config()
        from zhiyue_llm_provider import fetch_upstream_models as _fetch_upstream_models
        return jsonify(_fetch_upstream_models(role=role, config=cfg))
    except Exception as err:
        return jsonify({"ok": False, "models": [], "error": str(err)[:200]}), 200


def _load_remote_control_provider() -> dict:
    try:
        if REMOTE_CONTROL_PROVIDER_FILE.exists():
            raw = REMOTE_CONTROL_PROVIDER_FILE.read_text(encoding="utf-8")
            data = json.loads(raw) if raw.strip() else {}
            return data if isinstance(data, dict) else {}
    except Exception:
        return {}
    return {}


def _save_remote_control_provider(payload: dict) -> dict:
    if not isinstance(payload, dict):
        return {}
    data = dict(payload)
    # Keep only provider-related fields; ignore everything else.
    allowed = {"enabled", "protocol", "base_url", "api_key", "headers", "roles"}
    data = {k: v for k, v in data.items() if k in allowed}
    try:
        REMOTE_CONTROL_PROVIDER_FILE.parent.mkdir(parents=True, exist_ok=True)
        REMOTE_CONTROL_PROVIDER_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass
    return data


@app.route("/api/control/provider", methods=["GET", "POST"])
def api_remote_control_provider():
    # Remote companion only; protected by sync token.
    if not REMOTE_COMPANION_MODE:
        return jsonify({"ok": False, "error": "not_remote_companion"}), 400
    if not _sync_token_ok():
        return jsonify({"ok": False, "error": "unauthorized"}), 403

    if request.method == "POST":
        incoming = request.json or {}
        incoming = incoming if isinstance(incoming, dict) else {}

        # Same rule as local config: masked secrets should not overwrite real secrets.
        def _looks_masked_secret(v: object) -> bool:
            s = str(v or "")
            return ("****" in s) or ("..." in s)

        existing = _load_remote_control_provider()
        if _looks_masked_secret(incoming.get("api_key")):
            incoming.pop("api_key", None)
        merged = dict(existing)
        merged.update(incoming)
        saved = _save_remote_control_provider(merged)
    else:
        saved = _load_remote_control_provider()

    include_secret = str(request.args.get("include_secret") or "").strip().lower() in {"1", "true", "yes", "on"}

    # Mask secrets in response unless explicitly requested (sync-token protected).
    api_key = str(saved.get("api_key") or "").strip()
    payload = dict(saved)
    payload["api_key_masked"] = _mask_secret(api_key)
    payload["has_api_key"] = bool(api_key)
    if not include_secret:
        payload.pop("api_key", None)
    return jsonify({"ok": True, "provider": payload})


def _sync_token_ok() -> bool:
    expected = os.environ.get("ZHIYUE_SYNC_TOKEN", "").strip()
    got = (request.headers.get("X-Zhiyue-Sync") or request.args.get("sync_token") or "").strip()
    return bool(expected) and got == expected


def _mobile_token_ok() -> bool:
    expected = os.environ.get("ZHIYUE_MOBILE_TOKEN", "").strip()
    got = _get_auth_token_from_request()
    return bool(expected) and got == expected


REMOTE_COMPANION_MODE = os.environ.get("ZHIYUE_REMOTE_COMPANION", "0").strip().lower() in {"1", "true", "yes", "on"}

@app.before_request
def _remote_companion_guard():
    if not REMOTE_COMPANION_MODE:
        return None

    path = (request.path or "/").rstrip("/") or "/"
    # Allow basic health
    if path in {"/api/health", "/api/sync/health"}:
        return None

    # Sync endpoints require sync token.
    if path.startswith("/api/sync"):
        if _sync_token_ok():
            return None
        return jsonify({"ok": False, "error": "unauthorized"}), 403

    # Remote control endpoints (e.g. provider override) also require sync token.
    if path.startswith("/api/control"):
        if _sync_token_ok():
            return None
        return jsonify({"ok": False, "error": "unauthorized"}), 403

    # OpenAI-compatible endpoints for Tavo require mobile token.
    if path in {"/v1", "/models", "/v1/models", "/chat/completions", "/v1/chat/completions"}:
        if _mobile_token_ok():
            return None
        return jsonify({"error": {"message": "unauthorized", "type": "auth_error"}}), 401

    # Everything else is disabled on remote companion.
    if path.startswith("/api/"):
        return jsonify({"ok": False, "error": "disabled_in_remote_companion"}), 403
    return jsonify({"ok": False, "error": "not_found"}), 404


@app.route("/api/sync/health")
def api_sync_health():
    if not REMOTE_COMPANION_MODE:
        return jsonify({"ok": False, "error": "not_remote_companion"}), 400
    return jsonify({"ok": True, "remote_companion": True})


@app.route("/api/sync/pull")
def api_sync_pull():
    if not REMOTE_COMPANION_MODE:
        return jsonify({"ok": False, "error": "not_remote_companion"}), 400
    if not _sync_token_ok():
        return jsonify({"ok": False, "error": "unauthorized"}), 403
    return jsonify({"ok": True, **_build_sync_bundle()})


@app.route("/api/sync/push", methods=["POST"])
def api_sync_push():
    if not REMOTE_COMPANION_MODE:
        return jsonify({"ok": False, "error": "not_remote_companion"}), 400
    if not _sync_token_ok():
        return jsonify({"ok": False, "error": "unauthorized"}), 403
    data = request.json or {}
    if not isinstance(data, dict):
        return jsonify({"ok": False, "error": "invalid_payload"}), 400
    applied = _apply_sync_bundle(data, prefer_incoming_files=True)
    return jsonify({"ok": True, "applied": applied})


@app.route("/api/mobile-sync/health")
def api_mobile_sync_health():
    cfg = _load_provider_config()
    mobile = cfg.get("mobile_sync") if isinstance(cfg.get("mobile_sync"), dict) else {}
    remote = str(mobile.get("remote_base_url") or "").strip()
    if not remote:
        return jsonify({"ok": False, "error": "remote_not_configured"}), 200
    try:
        resp = requests.get(remote.rstrip("/") + "/api/sync/health", timeout=6)
        return jsonify({"ok": resp.status_code < 400, "status_code": resp.status_code, "remote": remote})
    except Exception as err:
        return jsonify({"ok": False, "error": str(err)[:200], "remote": remote}), 200


@app.route("/api/mobile-sync/pull", methods=["POST"])
def api_mobile_sync_pull():
    cfg = _load_provider_config()
    mobile = cfg.get("mobile_sync") if isinstance(cfg.get("mobile_sync"), dict) else {}
    remote = str(mobile.get("remote_base_url") or "").strip()
    token = str(mobile.get("access_token") or "").strip()
    if not remote or not token:
        return jsonify({"ok": False, "error": "remote_not_configured"}), 200
    url = remote.rstrip("/") + "/api/sync/pull"
    resp = requests.get(url, headers={"X-Zhiyue-Sync": token}, timeout=30)
    if resp.status_code >= 400:
        return jsonify({"ok": False, "error": f"HTTP {resp.status_code}: {resp.text[:200]}"}), 200
    payload = resp.json() if resp.content else {}
    applied = _apply_sync_bundle(payload, prefer_incoming_files=True)
    return jsonify({"ok": True, "remote": remote, "applied": applied})


@app.route("/api/mobile-sync/push", methods=["POST"])
def api_mobile_sync_push():
    try:
        cfg = _load_provider_config()
        mobile = cfg.get("mobile_sync") if isinstance(cfg.get("mobile_sync"), dict) else {}
        remote = str(mobile.get("remote_base_url") or "").strip()
        token = str(mobile.get("access_token") or "").strip()
        if not remote or not token:
            return jsonify({"ok": False, "error": "remote_not_configured"}), 200
        url = remote.rstrip("/") + "/api/sync/push"
        bundle = _build_sync_bundle()
        resp = requests.post(url, headers={"X-Zhiyue-Sync": token}, json=bundle, timeout=60)
        if resp.status_code >= 400:
            return jsonify({"ok": False, "error": f"HTTP {resp.status_code}: {resp.text[:200]}"}), 200
        return jsonify({"ok": True, "remote": remote, "result": resp.json() if resp.content else {}})
    except Exception as err:
        import traceback
        try:
            with open(API_CHAT_ERROR_LOG, "a", encoding="utf-8") as _f:
                _f.write(f"\n=== mobile-sync-push {now_local():%H:%M:%S} ===\n{traceback.format_exc()}\n")
        except Exception:
            pass
        return jsonify({"ok": False, "error": str(err)[:200]}), 200


@app.route("/api/mobile-control/pull_provider", methods=["POST"])
def api_mobile_control_pull_provider():
    if REMOTE_COMPANION_MODE:
        return jsonify({"ok": False, "error": "remote_companion_no_local_control"}), 400
    try:
        return jsonify(_mobile_control_pull_provider_once())
    except Exception as err:
        return jsonify({"ok": False, "error": str(err)[:200]}), 200


def _mobile_sync_pull_once() -> dict:
    cfg = _load_provider_config()
    mobile = cfg.get("mobile_sync") if isinstance(cfg.get("mobile_sync"), dict) else {}
    remote = str(mobile.get("remote_base_url") or "").strip()
    token = str(mobile.get("access_token") or "").strip()
    if not remote or not token:
        return {"ok": False, "error": "remote_not_configured"}
    url = remote.rstrip("/") + "/api/sync/pull"
    resp = requests.get(url, headers={"X-Zhiyue-Sync": token}, timeout=30)
    if resp.status_code >= 400:
        return {"ok": False, "error": f"HTTP {resp.status_code}: {resp.text[:200]}"}
    payload = resp.json() if resp.content else {}
    applied = _apply_sync_bundle(payload, prefer_incoming_files=True)
    return {"ok": True, "remote": remote, "applied": applied}


def _mobile_sync_push_once() -> dict:
    cfg = _load_provider_config()
    mobile = cfg.get("mobile_sync") if isinstance(cfg.get("mobile_sync"), dict) else {}
    remote = str(mobile.get("remote_base_url") or "").strip()
    token = str(mobile.get("access_token") or "").strip()
    if not remote or not token:
        return {"ok": False, "error": "remote_not_configured"}
    url = remote.rstrip("/") + "/api/sync/push"
    bundle = _build_sync_bundle()
    resp = requests.post(url, headers={"X-Zhiyue-Sync": token}, json=bundle, timeout=60)
    if resp.status_code >= 400:
        return {"ok": False, "error": f"HTTP {resp.status_code}: {resp.text[:200]}"}
    return {"ok": True, "remote": remote, "result": resp.json() if resp.content else {}}


def _mobile_control_pull_provider_once() -> dict:
    """
    Pull a provider config override from remote companion (sync-token protected)
    and apply it to the local backend.
    """
    cfg = _load_provider_config()
    mobile = cfg.get("mobile_sync") if isinstance(cfg.get("mobile_sync"), dict) else {}
    remote = str(mobile.get("remote_base_url") or "").strip()
    token = str(mobile.get("access_token") or "").strip()
    if not remote or not token:
        return {"ok": False, "error": "remote_not_configured"}
    url = remote.rstrip("/") + "/api/control/provider?include_secret=1"
    resp = requests.get(url, headers={"X-Zhiyue-Sync": token}, timeout=20)
    if resp.status_code >= 400:
        return {"ok": False, "error": f"HTTP {resp.status_code}: {resp.text[:200]}"}
    payload = resp.json() if resp.content else {}
    if not isinstance(payload, dict) or not payload.get("ok"):
        return {"ok": False, "error": "invalid_remote_payload"}
    provider = payload.get("provider")
    if not isinstance(provider, dict):
        return {"ok": False, "error": "missing_provider"}

    # Apply to local provider config.
    applied = _save_provider_config(provider)
    try:
        # Keep legacy globals in sync for health/status.
        global LM_URL, LM_MODEL
        LM_URL = os.environ.get("ZHIYUE_LM_URL", LM_URL)
        LM_MODEL = os.environ.get("ZHIYUE_LM_MODEL", LM_MODEL)
    except Exception:
        pass

    # Mask secret in response.
    api_key = str(applied.get("api_key") or "").strip()
    safe = dict(applied)
    safe["api_key_masked"] = _mask_secret(api_key)
    safe.pop("api_key", None)
    ms = safe.get("mobile_sync")
    if isinstance(ms, dict):
        ms = dict(ms)
        token = str(ms.get("access_token") or "").strip()
        ms["access_token_masked"] = _mask_secret(token)
        ms.pop("access_token", None)
        safe["mobile_sync"] = ms
    return {"ok": True, "remote": remote, "provider": safe}


def openai_chat_response(reply, model_name, request_id=None, bubbles=None):
    created = int(time.time())
    request_id = request_id or f"chatcmpl-zhiyue-{created}"
    payload = {
        "id": request_id,
        "object": "chat.completion",
        "created": created,
        "model": model_name or "zhiyue",
        "choices": [
            {
                "index": 0,
                "message": {"role": "assistant", "content": reply},
                "finish_reason": "stop",
            }
        ],
        "usage": {
            "prompt_tokens": 0,
            "completion_tokens": 0,
            "total_tokens": 0,
        },
    }
    if bubbles:
        payload["zhiyue_bubbles"] = bubbles[:3]
    return payload


def openai_stream(reply, model_name):
    created = int(time.time())
    request_id = f"chatcmpl-zhiyue-{created}"

    def emit(payload):
        return "data: " + json.dumps(payload, ensure_ascii=False) + "\n\n"

    def generate():
        yield emit({
            "id": request_id,
            "object": "chat.completion.chunk",
            "created": created,
            "model": model_name or "zhiyue",
            "choices": [{"index": 0, "delta": {"role": "assistant"}, "finish_reason": None}],
        })
        for chunk in re.findall(r'.{1,6}', reply, flags=re.S):
            yield emit({
                "id": request_id,
                "object": "chat.completion.chunk",
                "created": created,
                "model": model_name or "zhiyue",
                "choices": [{"index": 0, "delta": {"content": chunk}, "finish_reason": None}],
            })
        yield emit({
            "id": request_id,
            "object": "chat.completion.chunk",
            "created": created,
            "model": model_name or "zhiyue",
            "choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}],
        })
        yield "data: [DONE]\n\n"

    return Response(generate(), mimetype="text/event-stream")


@app.route('/chat/completions', methods=['POST'])
@app.route('/v1/chat/completions', methods=['POST'])
def openai_chat_completions():
    data = request.json or {}
    messages = data.get("messages") or []
    last_user_index = None
    user_msg = ""

    for idx in range(len(messages) - 1, -1, -1):
        msg = messages[idx]
        if isinstance(msg, dict) and msg.get("role") == "user":
            content = extract_text_content(msg.get("content")).strip()
            if content:
                last_user_index = idx
                user_msg = content
                break

    if last_user_index is None:
        return jsonify({
            "error": {
                "message": "empty user message",
                "type": "invalid_request_error",
            }
        }), 400

    source_history = normalize_history(messages[:last_user_index])
    # Many OpenAI-compatible clients inject their own persona into assistant turns.
    # Prefer backend persona/memory as the source of truth.
    mode = os.environ.get("ZHIYUE_OPENAI_HISTORY_MODE", "").strip().lower()
    if not mode:
        # Token-saver + anti-drift default: only take the last user turn from the client.
        # The backend will provide persona/memory/state as the source of truth.
        mode = "last_user_only"
    if mode in {"last_user_only", "last_user", "single"}:
        source_history = []
    elif mode in {"user_only", "users_only"}:
        source_history = [m for m in source_history if isinstance(m, dict) and m.get("role") == "user"]
    # else: "full" keeps user+assistant turns
    result = get_merged_growth_payload(user_msg, source_history=source_history, channel="openai")
    if result.get("coalesced_skip"):
        time.sleep(max(0.2, INPUT_MERGE_SECONDS))
        result = get_merged_growth_payload(user_msg, source_history=source_history, channel="openai-retry")
    if result.get("error"):
        return jsonify({
            "error": {
                "message": result.get("error_message") or "language model unavailable",
                "type": result.get("error_code") or "service_unavailable",
            }
        }), 200
    if result.get("coalesced_skip"):
        return jsonify({
            "error": {
                "message": "request was coalesced into a newer user turn",
                "type": "coalesced_skip",
            }
        }), 409
    reply = format_openai_reply(result.get("reply") or "")
    model_name = data.get("model") or "zhiyue"

    if data.get("stream"):
        return openai_stream(reply, model_name)
    bubbles = [] if result.get("coalesced_skip") else openai_bubble_parts(result.get("reply") or reply)
    return jsonify(openai_chat_response(reply, model_name, bubbles=bubbles))


@app.route('/api/chat', methods=['POST'])
def api_chat():
    try:
        data = request.json or {}
        user_msg = (data.get('message') or data.get('msg') or '').strip()
        channel = (data.get("channel") or "web").strip() or "web"
        try:
            result = get_merged_growth_payload(user_msg, channel=channel)
        except RuntimeError as e:
            msg = str(e)
            if "API not configured" in msg:
                return jsonify({
                    "error": True,
                    "error_code": "api_not_configured",
                    "error_message": "请先点右上角【设置】配置 API（Base URL / API Key / 三个模型）。",
                }), 200
            raise
        if result.get("error") and result.get("error_code") == "empty_user_msg":
            return jsonify(result), 400
        result = validate_chat_payload(result, channel=channel)

        # Emotional scoring: update based on user's message (async, don't block)
        if user_msg and len(user_msg) >= 2:
            try:
                cs = _get_char_state()
                score, reason = cs.update_emotional_score(user_msg)
            except (RuntimeError | ValueError) as e:
                pass

        return jsonify(result)
    except Exception as e:
        msg = str(e)
        if "API not configured" in msg:
            return jsonify({
                "error": True,
                "error_code": "api_not_configured",
                "error_message": "请先点右上角【设置】配置 API（Base URL / API Key / 三个模型）。",
            }), 200
        import traceback, datetime
        err_text = traceback.format_exc()
        with open(API_CHAT_ERROR_LOG, "a", encoding="utf-8") as _f:
            _f.write(f"\n=== {now_local():%H:%M:%S} ===\n{err_text}\n")
        return jsonify({
            "error": True,
            "error_code": "internal_exception",
            "error_message": str(e)[:200],
        }), 500


@app.route('/api/character/status')
def api_character_status():
    """Return character state for debugging/monitoring."""
    cs = _get_char_state()
    return jsonify({"ok": True, "character": cs.get_status()})


@app.route('/api/character/full')
def api_character_full():
    """Return full character state including life plan, daily plan, joys."""
    if not _verify_internal_request():
        return jsonify({"error": "unauthorized"}), 403
    cs = _get_char_state()
    return jsonify({"ok": True, **cs.get_full_status()})


@app.route('/api/character/plan/generate', methods=['POST'])
def api_generate_daily_plan():
    """Force regeneration of the daily plan."""
    cs = _get_char_state()
    plan = cs.start_new_day(wait_for_lm=True)
    return jsonify({"ok": bool(plan.get("schedule")), "plan": plan})


@app.route('/api/character/life/generate', methods=['POST'])
def api_generate_life_plan():
    """Generate or regenerate the life plan."""
    cs = _get_char_state()
    plan = cs.generate_life_plan()
    return jsonify({"ok": bool(plan), "plan": plan})


@app.route('/api/character/joys')
def api_character_joys():
    """Get today's small joys."""
    if char_state is None:
        return jsonify({"ok": False, "error": "character state not available"}), 503
    joys = char_state.load_joys()
    undone = char_state.get_undone_joys()
    return jsonify({
        "ok": True,
        "total": len(joys),
        "undone": len(undone),
        "joys": joys,
        "undone_joys": undone,
    })


@app.route('/api/character/joys/generate', methods=['POST'])
def api_generate_joys():
    """Regenerate today's small joys."""
    cs = _get_char_state()
    joys = cs.generate_daily_joys()
    return jsonify({"ok": len(joys) > 0, "count": len(joys), "joys": joys})


@app.route('/api/character/joy/done', methods=['POST'])
def api_mark_joy_done():
    """Mark a small joy as done."""
    idx = request.json.get("index") if request.is_json else int(request.args.get("index", -1))
    if idx < 0:
        return jsonify({"error": "index required"}), 400
    if char_state is not None:
        char_state.mark_joy_done(idx)
    return jsonify({"ok": True})


@app.route('/api/character/browse')
def api_character_browse():
    """Browse the web for interesting content."""
    topic = request.args.get("topic", "")
    cs = _get_char_state()
    if topic:
        content = cs.browse_interest(topic)
    else:
        result = cs.browse_random_interesting()
        content = result.get("content", "") if result else ""
        topic = result.get("topic", "") if result else ""
    return jsonify({"ok": bool(content), "topic": topic, "content": content[:2000] if content else ""})


@app.route('/api/character/autonomous/tick', methods=['POST'])
def api_autonomous_tick():
    """Trigger one tick of autonomous activity."""
    cs = _get_char_state()
    should, desc = cs.should_do_autonomous_activity()
    if not should:
        return jsonify({"ok": True, "action": "none", "reason": "not due yet"})
    result = cs.execute_autonomous_activity(desc)
    return jsonify({"ok": True, "action": desc, "result": result})


@app.route('/api/character/journal')
def api_character_journal():
    """Get today's journal entries."""
    if char_state is None:
        return jsonify({"ok": False, "error": "character state not available"}), 503
    entries = char_state.get_today_journal()
    return jsonify({"ok": True, "count": len(entries), "entries": entries})


@app.route('/api/character/life/plan')
def api_character_life_plan():
    """Get the life plan."""
    cs = _get_char_state()
    plan = cs.life_plan if cs.has_life_plan() else {}
    return jsonify({"ok": bool(plan), "plan": plan})


@app.route('/api/proactive')
def api_proactive():
    force = request.args.get("force") == "1"
    if not should_send_proactive(force=force):
        return jsonify({"ok": False})
    reply = build_proactive_reply()
    if is_placeholder_reply(reply):
        return jsonify({"ok": False, "error": "lm_unavailable"}), 200
    return jsonify({
        "ok": True,
        "reply": reply,
        "messages": build_display_messages("", reply),
    })


def trigger_shutdown():
    time.sleep(0.8)
    script = str(BASE_DIR / "_stop_zhiyue.ps1")
    creationflags = 0
    if os.name == "nt":
        creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        subprocess.Popen(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", script],
            cwd=str(BASE_DIR),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=creationflags,
        )
    except (Exception,) as err:
        log_runtime_exception("trigger_shutdown", err)


def _shutdown_farewell_reply(user_msg: str = "") -> dict:
    farewell = _build_shutdown_farewell(user_msg)
    return {
        "ok": True,
        "reply": farewell,
        "messages": ([{"type": "text", "content": farewell}] if farewell else []),
        "reply_source": "shutdown_farewell",
        "requires_shutdown_confirmation": True,
        "shutdown_confirmation_hint": "请再发一次确认词，比如：关机",
    }


def _build_shutdown_retention(user_msg: str = "") -> str:
    try:
        history = technical_chat_history[-8:] if technical_chat_history else chat_history[-8:]
        history_text = "\n".join(
            f"{item.get('role', '')}: {item.get('content', '')}"
            for item in history
            if isinstance(item, dict)
        )
        messages = [
            {
                "role": "system",
                "content": (
                    "你在写一条关机前的挽留回复，不要通知口吻，不要模板，不要硬邦邦。"
                    "要像平时聊天里自然留人，语气可以柔一点、长一点。"
                    "可以表达：先别急着关、再陪一会儿、如果还想聊我在、等你准备好了再说。"
                    "不要写固定句，不要自我解释，不要出现流程说明。"
                ),
            },
            {
                "role": "user",
                "content": json.dumps({
                    "user_msg": user_msg or "",
                    "recent_history": history_text,
                }, ensure_ascii=False),
            },
        ]
        raw = _request_lm_text(
            messages,
            user_msg=user_msg or "",
            normalized_history=sanitize_prompt_history(history),
            use_compact=True,
            max_tokens=96,
            temperature=0.78,
            top_p=0.95,
        )
        text = (raw or "").strip()
        return text or _contextual_shutdown_farewell_fallback(user_msg)
    except Exception as err:
        log_runtime_exception("shutdown.retention", err)
        return _contextual_shutdown_farewell_fallback(user_msg)


def _shutdown_retention_reply(user_msg: str = "") -> dict:
    reply = _build_shutdown_retention(user_msg)
    return {
        "ok": True,
        "reply": reply,
        "messages": ([{"type": "text", "content": reply}] if reply else []),
        "reply_source": "shutdown_retention",
        "requires_shutdown_confirmation": True,
        "shutdown_confirmation_hint": "璇峰啀鍙戜竴娆＄‘璁よ瘝锛屾瘮濡傦細鍏虫満",
    }


def _contextual_shutdown_farewell_fallback(user_msg: str = "") -> str:
    recent = technical_chat_history[-8:] if technical_chat_history else chat_history[-8:]
    snippets = []
    for item in reversed(recent):
        if not isinstance(item, dict):
            continue
        role = str(item.get("role") or "").strip()
        if role != "user":
            continue
        content = str(item.get("content") or "").strip()
        if not content:
            continue
        content = re.sub(r"\s+", " ", content)
        content = re.sub(r"[。！？!?]+$", "", content).strip()
        if content:
            snippets.append(content[:24])
        if len(snippets) >= 2:
            break
    lead = snippets[0] if snippets else "你先忙"
    return f"那我先陪你到这儿，{lead}，我先跟你说声再见。"


def _build_shutdown_farewell(user_msg: str = "") -> str:
    try:
        history = technical_chat_history[-8:] if technical_chat_history else chat_history[-8:]
        history_text = "\n".join(
            f"{item.get('role', '')}: {item.get('content', '')}"
            for item in history
            if isinstance(item, dict)
        )
        messages = [
            {
                "role": "system",
                "content": (
                    "你在写一条关机前的自然告别回复，不要模板感，不要通知口吻，不要像流程提示。"
                    "要顺着最近对话收尾，语气可以轻一点、长一点、像平时聊天结束。"
                    "可以自然提到：那我先陪你到这、你忙完再来、回头再聊、先这样也好。"
                    "不要固定短句，不要自我解释，不要提系统执行，不要复述规则。"
                ),
            },
            {
                "role": "user",
                "content": json.dumps({
                    "user_msg": user_msg or "",
                    "recent_history": history_text,
                }, ensure_ascii=False),
            },
        ]
        raw = _request_lm_text(
            messages,
            user_msg=user_msg or "",
            normalized_history=sanitize_prompt_history(history),
            use_compact=True,
            max_tokens=128,
            temperature=0.78,
            top_p=0.95,
        )
        text = (raw or "").strip()
        return _ensure_shutdown_farewell(text, user_msg)
    except Exception as err:
        log_runtime_exception("shutdown.farewell", err)
        return _contextual_shutdown_farewell_fallback(user_msg)


@app.route('/api/shutdown', methods=['POST'])
def api_shutdown():
    data = request.json if isinstance(request.json, dict) else {}
    confirmation = str(data.get("confirmation") or data.get("text") or "").strip()
    farewell_ok = bool(data.get("farewell_ok"))
    try:
        import zhiyue_companion_policy as _shutdown_policy
    except Exception:
        _shutdown_policy = None
    pending_state = {}
    if _shutdown_policy is not None:
        try:
            pending_state = _shutdown_policy.get_shutdown_pending_state()
        except Exception:
            pending_state = {}
    confirmed = bool(data.get("confirmed")) or (confirmation in SHUTDOWN_CONFIRMATION_TOKENS) or (
        _shutdown_policy is not None and _shutdown_policy.should_shutdown_confirmation(confirmation)
    )
    if not pending_state and not confirmed:
        payload = _shutdown_retention_reply(confirmation)
        payload["messages"] = ([{"type": "text", "content": payload["reply"]}] if payload.get("reply") else [])
        if _shutdown_policy is not None:
            try:
                _shutdown_policy.mark_shutdown_pending(
                    confirmation or "",
                    reply=str(payload.get("reply") or ""),
                    source="api_shutdown_request",
                )
            except (KeyError) as e:
                pass
        return jsonify(payload), 200
    if not farewell_ok and not confirmed:
        farewell_text = _build_shutdown_retention(confirmation)
        reply_text = farewell_text
        return jsonify({
            "ok": True,
            "requires_shutdown_confirmation": True,
            "reply": reply_text,
            "messages": ([{"type": "text", "content": reply_text}] if reply_text else []),
            "reply_source": "shutdown_retention",
        }), 200
    farewell_text = _build_shutdown_farewell(confirmation)
    reply_text = _ensure_shutdown_farewell(farewell_text, confirmation)
    if _shutdown_policy is not None:
        try:
            _shutdown_policy.clear_shutdown_pending()
        except (RuntimeError | ValueError) as e:
            pass
    threading.Thread(target=trigger_shutdown, daemon=True).start()
    return jsonify({
        "ok": True,
        "scheduled": True,
        "reply": reply_text,
        "messages": ([{"type": "text", "content": reply_text}] if reply_text else []),
        "reply_source": "shutdown_confirmed",
    })


@app.route('/api/import_history', methods=['POST'])
def api_import_history():
    data = request.json or {}
    path = data.get("path") or str(BASE_DIR / "zhiyue_chat_history.json")
    try:
        return jsonify({"ok": True, **import_chat_history_file(path)})
    except Exception as err:
        return jsonify({"ok": False, "error": str(err)}), 400


@app.route('/api/learning')
def api_learning():
    return jsonify({
        "ok": True,
        "profile": load_persona_profile(),
        "notes": growth.list_learning_notes(limit=80),
    })


@app.route('/api/state_hygiene')
def api_state_hygiene():
    return jsonify({
        "ok": True,
        "summary": get_state_hygiene_summary(),
    })


@app.route('/api/state_hygiene/prune', methods=['POST'])
def api_state_hygiene_prune():
    return jsonify({
        "ok": True,
        "pruned": prune_expired_state(force=True),
        "summary": get_state_hygiene_summary(),
    })


@app.route('/api/learning/<int:note_id>', methods=['DELETE'])
def api_delete_learning(note_id):
    growth.deactivate_learning_note_id(note_id)
    return jsonify({"ok": True})


@app.route('/api/learning/decay', methods=['POST'])
def api_decay_learning():
    return jsonify({"ok": True, "changed": maybe_decay_learning_notes(force=True)})


@app.route('/api/memory')
def api_memory():
    query = request.args.get("q") or request.args.get("query") or ""
    limit = coerce_int_arg(request.args.get("limit", 8), 8, minimum=1, maximum=50, context="api_memory.limit")
    life_events = recall_life_events(query, limit=limit)
    recent_life_events = list_life_events(status="active", limit=min(limit, 12))
    if query and any(k in query for k in ["最近", "近期", "有什么事", "哪些事", "事件"]):
        seen_event_ids = {item.get("id") for item in life_events}
        for item in recent_life_events:
            if item.get("id") not in seen_event_ids:
                life_events.append(item)
                seen_event_ids.add(item.get("id"))
            if len(life_events) >= limit:
                break
    return jsonify({
        "ok": True,
        "core": memory.get_core_memory_blocks(),
        "core_stats": memory.get_core_memory_stats(),
        "core_inject": memory.get_core_memory_inject(),
        "archival": memory.get_relevant_memories(query, limit=limit),
        "life_events": life_events,
        "recent_events": recent_life_events,
        "recent": memory.get_recent(limit=limit),
        "layered": memory.get_layered_memories(max_per_type=2),
        "profile": load_persona_profile(),
    })


@app.route('/api/memory/compact', methods=['POST'])
def api_memory_compact():
    return jsonify({
        "ok": True,
        "removed": maybe_compact_memories(force=True),
    })


@app.route('/api/memory/sync', methods=['POST'])
def api_memory_sync():
    if not layers:
        return jsonify({"ok": False, "error": "layers unavailable"}), 200
    data = request.json or {}
    limit = coerce_int_arg(data.get("limit") or request.args.get("limit") or 1000, 1000, minimum=1, maximum=5000, context="api_memory_sync.limit")
    force = bool(data.get("force") or request.args.get("force") == "1")
    return jsonify({
        "ok": True,
        "sync": layers.memory.sync(limit=limit, force=force),
        "status": layers.memory.status(),
    })


@app.route('/api/followups')
def api_followups():
    return jsonify({
        "ok": True,
        "care_followups": intimacy.data.get("care_followups", []),
        "has_due": has_due_care_followup(),
    })


@app.route('/api/relationship_threads')
def api_relationship_threads():
    thread_type = request.args.get("type") or None
    status = request.args.get("status") or "active"
    limit = coerce_int_arg(request.args.get("limit", 50), 50, minimum=1, maximum=100, context="api_relationship_threads.limit")
    return jsonify({
        "ok": True,
        "threads": list_relationship_threads(thread_type=thread_type, status=status, limit=limit),
        "quiet_mode_until": intimacy.data.get("quiet_mode_until"),
        "last_wait_marker": intimacy.data.get("last_user_wait_marker"),
    })


@app.route('/api/relationship_threads/proactive')
def api_relationship_threads_proactive():
    reply = build_relationship_proactive_reply(force=True)
    if is_placeholder_reply(reply):
        return jsonify({"ok": False, "error": "lm_unavailable"}), 200
    return jsonify({
        "ok": True,
        "reply": reply,
        "messages": build_display_messages("", reply, allow_followup=False),
    })


@app.route('/api/life_arc')
def api_life_arc():
    get_daily_event()
    return jsonify({
        "ok": True,
        "today_event": intimacy.data.get("daily_event"),
        "life_arc_date": intimacy.data.get("life_arc_date"),
        "life_arc": intimacy.data.get("life_arc", []),
    })


@app.route('/api/life_events')
def api_life_events():
    query = request.args.get("q") or request.args.get("query") or ""
    status = request.args.get("status") or "active"
    limit = coerce_int_arg(request.args.get("limit", 30), 30, minimum=1, maximum=100, context="api_life_events.limit")
    return jsonify({
        "ok": True,
        "events": recall_life_events(query, limit=limit, include_inactive=(status != "active")) if query else list_life_events(status=status, limit=limit),
    })


@app.route('/api/life_events', methods=['POST'])
def api_life_events_create():
    data = request.json or {}
    event_id = upsert_life_event(
        title=data.get("title") or data.get("content") or "",
        event_type=data.get("event_type"),
        status=data.get("status") or "active",
        due_time=data.get("due_time"),
        entities=data.get("entities") or [],
        evidence=data.get("evidence") or data.get("content") or "",
        importance=int(data.get("importance") or 3),
        next_followup_at=data.get("next_followup_at"),
    )
    if not event_id:
        return jsonify({"ok": False, "error": "empty event"}), 400
    return jsonify({"ok": True, "id": event_id})


@app.route('/api/stats')
def api_stats():
    dead_letter_summary = evaluate_weixin_bridge_health()
    result = {
        "level": intimacy.data["level"],
        "exp": intimacy.data["exp"],
        "stage": intimacy.get_stage(),
        "mood": emotion.emotion,
        "happiness": emotion.happiness,
        "emotion_vector": {
            "valence": round(emotion.valence, 3),
            "arousal": round(emotion.arousal, 3),
        },
        "energy": intimacy.data.get("energy", 100),
        "jealousy": emotion.jealousy_level,
        "cold_war": emotion.cold_war_turns,
        "total_chats": intimacy.data["total_chats"],
        "streak": intimacy.data.get("streak", 0),
        "personality": intimacy.get_personality_desc(),
        "care_followups": len(_active_care_followups()),
        "relationship_threads": len(list_relationship_threads(limit=100)),
        "life_events": len(list_life_events(status="active", limit=100)),
        "quiet_mode_until": intimacy.data.get("quiet_mode_until"),
        "memory": memory.get_core_memory_stats(),
        "weixin_dead_letters": dead_letter_summary,
    }
    # 加入认知画像
    if cognitive:
        result["cognitive"] = cognitive.get_model()
    return jsonify(result)


@app.route('/api/health')
def api_health():
    intimacy.recover_energy()
    dead_letter_summary = evaluate_weixin_bridge_health()
    health = {
        "ok": True,
        "status": "degraded" if dead_letter_summary.get("degraded") else "ok",
        "level": intimacy.data["level"],
        "stage": intimacy.get_stage(),
        "energy": intimacy.data.get("energy", 100),
        "mood": intimacy.data.get("mood", 100),
        "model": LM_MODEL,
        "lm_url": LM_URL,
        "care_followups": len(_active_care_followups()),
        "weixin_dead_letter_count": dead_letter_summary.get("dead_letter_count", 0),
        "weixin_queue_count": dead_letter_summary.get("queue_count", 0),
        "weixin_dead_letter_reasons": dead_letter_summary.get("reason_counts", {}),
        "weixin_bridge_degraded": bool(dead_letter_summary.get("degraded")),
        "weixin_dead_letter_warn_threshold": dead_letter_summary.get("warn_threshold", WEIXIN_DEAD_LETTER_WARN_THRESHOLD),
        "external_awareness_enabled": EXTERNAL_AWARENESS_ENABLED,
        "layers_loaded": bool(layers),
        "model_reply_only": True,
        "rule_reply_modelize": RULE_REPLY_MODELIZE,
    }
    probe = (request.args.get("probe") or "").strip().lower()
    if probe in {"chat", "smoke", "full"}:
        smoke = build_chat_smoke_result(
            user_msg=(request.args.get("message") or "你好").strip() or "你好",
            channel="health:smoke",
            include_reply=request.args.get("include_reply") == "1",
        )
        health["chat_probe"] = smoke
        if not smoke.get("ok"):
            health["ok"] = False
            health["status"] = "degraded" if smoke.get("status") != "error" else "error"
    return jsonify(health)


@app.route('/api/health/smoke')
def api_health_smoke():
    smoke = build_chat_smoke_result(
        user_msg=(request.args.get("message") or "你好").strip() or "你好",
        channel="health:smoke",
        include_reply=request.args.get("include_reply") == "1",
    )
    status_code = 200 if smoke.get("ok") else 503
    return jsonify(smoke), status_code


@app.route('/api/diagnostics')
def api_diagnostics():
    include_probe = (request.args.get("probe") or "").strip().lower() in {"1", "true", "yes", "chat", "smoke"}
    payload = build_diagnostics_summary(
        include_probe=include_probe,
        probe_message=(request.args.get("message") or "你好").strip() or "你好",
    )
    status_code = 200 if payload.get("ok") else 503
    return jsonify(payload), status_code


@app.route('/api/weixin/dead_letters')
def api_weixin_dead_letters():
    limit = coerce_int_arg(request.args.get("limit", 50), 50, minimum=1, maximum=200, context="api_weixin_dead_letters.limit")
    items = list_weixin_dead_letters(limit=limit)
    return jsonify({
        "ok": True,
        "count": len(items),
        "items": items,
        "dead_letter_file": str(WEIXIN_DEAD_LETTER_FILE),
    })


@app.route('/api/weixin/dead_letters/summary')
def api_weixin_dead_letters_summary():
    return jsonify({
        "ok": True,
        **evaluate_weixin_bridge_health(),
        "dead_letter_file": str(WEIXIN_DEAD_LETTER_FILE),
        "queue_file": str(WEIXIN_QUEUE_FILE),
    })


@app.route('/api/weixin/dead_letters/replay', methods=['POST'])
def api_weixin_dead_letters_replay():
    data = request.json if isinstance(request.json, dict) else {}
    ids = data.get("ids")
    if ids is not None and not isinstance(ids, list):
        ids = [ids]
    result = replay_weixin_dead_letters(ids=ids, limit=coerce_int_arg(data.get("limit", 20), 20, minimum=1, maximum=200, context="api_weixin_dead_letters_replay.limit"))
    return jsonify({"ok": True, **result})


@app.route('/api/human_like/eval', methods=['POST'])
def api_human_like_eval():
    data = request.json if isinstance(request.json, dict) else {}
    user_msg = str(data.get("user_msg") or data.get("message") or "")
    reply = str(data.get("reply") or "")
    route = str(data.get("route") or "manual_eval")
    evaluation = human_like.evaluate_human_likeness(user_msg, reply, route=route)
    hints = human_like.build_human_like_rewrite_hints(user_msg, reply, evaluation)
    bubbles = human_like.split_human_like_bubbles(reply)
    return jsonify({
        "ok": True,
        "evaluation": evaluation,
        "rewrite_hints": hints,
        "bubble_preview": bubbles,
    })


@app.route('/api/environment')
def api_environment():
    city = (request.args.get("city") or WEATHER_CITY or "").strip()
    weather = fetch_weather_snapshot(city)
    location = _normalize_weather_text(request.args.get("location") or DEFAULT_LOCATION_LABEL or city or "本地")
    payload = {
        "ok": bool(weather.get("ok")),
        "external_awareness_enabled": EXTERNAL_AWARENESS_ENABLED,
        "location": location,
        "weather": weather,
    }
    if request.args.get("include_skill_learning") == "1":
        if layers and hasattr(layers, "skill_learning"):
            try:
                payload["skill_learning"] = {
                    "loaded": True,
                    "effect_summary": layers.skill_learning.companion_skill_effect_summary(
                        SELF_MONITOR_FINDINGS_FILE,
                        window=20,
                        limit=20,
                        hit_limit=100,
                    ),
                    "conflicts": layers.skill_learning.conflict_summary(limit=100),
                }
            except Exception as err:
                payload["skill_learning"] = {"loaded": False, "error": str(err)[:200], "conflicts": []}
        else:
            payload["skill_learning"] = {"loaded": False, "error": "skill_learning_unavailable", "conflicts": []}
    return jsonify(payload)


@app.route('/api/lm_status')
def api_lm_status():
    try:
        resp = requests.get("http://127.0.0.1:5001/v1/models", timeout=3)
        return jsonify({
            "ok": resp.status_code == 200,
            "status": resp.status_code,
            "models": resp.json().get("data", []) if resp.status_code == 200 else [],
            "last_error": LAST_LM_ERROR,
        })
    except Exception as err:
        return jsonify({
            "ok": False,
            "status": None,
            "models": [],
            "last_error": str(err) or LAST_LM_ERROR,
        })


@app.route('/api/layers')
def api_layers():
    return jsonify({
        "ok": True,
        "layers": get_layer_status(),
    })


@app.route('/api/human_like/summary')
def api_human_like_summary():
    if not layers or not hasattr(layers, "observability"):
        return jsonify({"ok": True, "loaded": False, "summary": {}})
    limit = coerce_int_arg(request.args.get("limit", 100), 100, minimum=1, maximum=500, context="api_human_like_summary.limit")
    return jsonify({
        "ok": True,
        "loaded": True,
        "summary": layers.observability.human_likeness_summary(limit=limit),
    })


@app.route('/api/human_like/bad')
def api_human_like_bad():
    if not layers or not hasattr(layers, "observability"):
        return jsonify({"ok": True, "loaded": False, "summary": {}})
    limit = coerce_int_arg(request.args.get("limit", 100), 100, minimum=1, maximum=500, context="api_human_like_bad.limit")
    return jsonify({
        "ok": True,
        "loaded": True,
        "summary": layers.observability.bad_human_reply_summary(limit=limit),
    })


@app.route('/api/skill_learning/effect_summary')
def api_skill_learning_effect_summary():
    if not layers or not hasattr(layers, "skill_learning"):
        return jsonify({"ok": True, "loaded": False, "summary": {}, "conflicts": {}})
    window = coerce_int_arg(request.args.get("window", 20), 20, minimum=1, maximum=100, context="api_skill_learning_effect_summary.window")
    limit = coerce_int_arg(request.args.get("limit", 50), 50, minimum=1, maximum=200, context="api_skill_learning_effect_summary.limit")
    hit_limit = coerce_int_arg(request.args.get("hit_limit", 200), 200, minimum=1, maximum=1000, context="api_skill_learning_effect_summary.hit_limit")
    return jsonify({
        "ok": True,
        "loaded": True,
        "summary": layers.skill_learning.companion_skill_effect_summary(
            SELF_MONITOR_FINDINGS_FILE,
            window=window,
            limit=limit,
            hit_limit=hit_limit,
        ),
        "conflicts": layers.skill_learning.conflict_summary(limit=max(limit, 100)),
    })


@app.route('/api/agent/plan')
def api_agent_plan():
    user_msg = request.args.get("q") or request.args.get("query") or ""
    context = {
        "proactive_due": request.args.get("proactive_due") == "1",
        "quiet_mode": request.args.get("quiet_mode") == "1",
    }
    return jsonify({
        "ok": True,
        "plan": get_agent_plan(user_msg, context=context),
    })


@app.route('/api/agent/run', methods=['GET', 'POST'])
def api_agent_run():
    data = request.json if request.method == "POST" else {}
    data = data or {}
    user_msg = (
        data.get("user_msg")
        or data.get("message")
        or request.args.get("q")
        or request.args.get("query")
        or ""
    )
    context = data.get("context") or {}
    if not isinstance(context, dict):
        context = {}
    context = {
        **context,
        "proactive_due": bool(context.get("proactive_due") or request.args.get("proactive_due") == "1"),
        "quiet_mode": bool(context.get("quiet_mode") or request.args.get("quiet_mode") == "1"),
        "user_is_active": True,
    }
    reply = data.get("reply") if "reply" in data else request.args.get("reply")
    route_hint = data.get("route_hint") or request.args.get("route_hint") or None
    try:
        run = get_agent_run(
            user_msg,
            context=context,
            reply=reply,
            route_hint=route_hint,
            history=chat_history,
            include_callbacks=True,
        )
    except Exception as err:
        run = {
            "ok": False,
            "engine": "local_lightweight_state_machine",
            "degraded": True,
            "degraded_nodes": ["agent_run"],
            "error": str(err),
            "nodes": [],
            "node_status": {"agent_run": "degraded"},
        }
    run_id = None
    if request.args.get("record") == "1" or data.get("record"):
        run_id = record_agent_run_observability(
            run,
            user_msg=user_msg,
            reply=reply or "",
            channel=(data.get("channel") or request.args.get("channel") or "agent_api"),
            route=((run.get("route") or {}).get("name") if isinstance(run.get("route"), dict) else "") or route_hint or "agent_run",
            meta={"manual": True},
        )
    return jsonify({
        "ok": bool(run.get("ok", True)),
        "run_id": run_id,
        "run": run,
    })


@app.route('/api/agent/runs')
def api_agent_runs():
    if not layers:
        return jsonify({"ok": True, "loaded": False, "summary": {}, "runs": []})
    limit = coerce_int_arg(request.args.get("limit", 50), 50, minimum=1, maximum=200, context="api_agent_runs.limit")
    return jsonify({
        "ok": True,
        "loaded": True,
        "summary": layers.observability.agent_run_summary(limit=limit),
        "runs": layers.observability.list_agent_runs(limit=limit),
    })


@app.route('/api/agent/tasks', methods=['GET', 'POST'])
def api_agent_tasks():
    if not layers or not hasattr(layers, "tasks"):
        return jsonify({"ok": False, "error": "task layer unavailable"}), 200
    if request.method == "POST":
        data = request.json or {}
        try:
            task = layers.tasks.create_task(
                title=data.get("title") or data.get("goal") or "",
                goal=data.get("goal") or "",
                next_action=data.get("next_action") or "",
                due_time=data.get("due_time"),
                priority=int(data.get("priority") or 3),
                source=data.get("source") or "manual",
                evidence=data.get("evidence") or "",
                status=data.get("status") or "active",
                meta=data.get("meta") if isinstance(data.get("meta"), dict) else {},
            )
        except Exception as err:
            return jsonify({"ok": False, "error": str(err)}), 400
        return jsonify({"ok": True, "task": task})

    limit = coerce_int_arg(request.args.get("limit", 50), 50, minimum=1, maximum=200, context="api_agent_tasks.limit")
    status = request.args.get("status") or "active"
    query = request.args.get("q") or request.args.get("query") or ""
    return jsonify({
        "ok": True,
        "loaded": True,
        "summary": layers.tasks.summary(limit=200),
        "tasks": layers.tasks.list_tasks(status=status, limit=limit, query=query or None),
    })


@app.route('/api/agent/tasks/<task_id>', methods=['GET', 'PATCH'])
def api_agent_task_detail(task_id):
    if not layers or not hasattr(layers, "tasks"):
        return jsonify({"ok": False, "error": "task layer unavailable"}), 200
    if request.method == "PATCH":
        data = request.json or {}
        task = layers.tasks.update_task(task_id, data)
        if not task:
            return jsonify({"ok": False, "error": "task not found"}), 404
        return jsonify({"ok": True, "task": task})
    task = layers.tasks.get_task(task_id)
    if not task:
        return jsonify({"ok": False, "error": "task not found"}), 404
    return jsonify({
        "ok": True,
        "task": task,
        "actions": layers.tasks.list_actions(task_id=task_id, limit=50),
    })


@app.route('/api/agent/actions', methods=['GET', 'POST'])
def api_agent_actions():
    if not layers or not hasattr(layers, "tasks"):
        return jsonify({"ok": False, "error": "task layer unavailable"}), 200
    if request.method == "POST":
        data = request.json or {}
        try:
            action = layers.tasks.record_action(
                action_type=data.get("action_type") or "",
                payload=data.get("payload") if isinstance(data.get("payload"), dict) else {},
                task_id=data.get("task_id") or "",
                run_id=data.get("run_id") or "",
                status=data.get("status") or "planned",
                risk=data.get("risk") or "low",
                requires_confirm=bool(data.get("requires_confirm")),
                result=data.get("result") if isinstance(data.get("result"), dict) else {},
                error=data.get("error") or "",
            )
        except Exception as err:
            return jsonify({"ok": False, "error": str(err)}), 400
        return jsonify({"ok": True, "action": action})

    limit = coerce_int_arg(request.args.get("limit", 50), 50, minimum=1, maximum=200, context="api_agent_actions.limit")
    task_id = request.args.get("task_id") or None
    return jsonify({
        "ok": True,
        "actions": layers.tasks.list_actions(task_id=task_id, limit=limit),
    })


@app.route('/api/agent/actions/<action_id>/apply', methods=['POST'])
def api_agent_action_apply(action_id):
    if not layers or not hasattr(layers, "tasks"):
        return jsonify({"ok": False, "error": "task layer unavailable"}), 200
    data = request.json or {}
    confirm_raw = data.get("confirm")
    confirm = False
    if isinstance(confirm_raw, bool):
        confirm = confirm_raw
    elif isinstance(confirm_raw, (int, float)):
        confirm = bool(confirm_raw)
    elif isinstance(confirm_raw, str):
        confirm = confirm_raw.strip().lower() in {"1", "true", "yes", "y", "on", "confirm"}
    try:
        applied = layers.tasks.apply_action(action_id, confirm=confirm)
        return jsonify({
            "ok": True,
            "confirm": confirm,
            "action": applied.get("action") if isinstance(applied, dict) else {},
            "task": applied.get("task") if isinstance(applied, dict) else None,
            "created_task": applied.get("created_task") if isinstance(applied, dict) else None,
        })
    except Exception as err:
        if AgentActionApplyError and isinstance(err, AgentActionApplyError):
            return jsonify({
                "ok": False,
                "error": str(err),
                "confirm": confirm,
                "action": err.action if isinstance(err.action, dict) else {},
            }), int(getattr(err, "status_code", 400) or 400)
        return jsonify({"ok": False, "error": str(err), "confirm": confirm}), 400


@app.route('/api/self_improvement', methods=['GET', 'POST'])
def api_self_improvement():
    if not layers or not hasattr(layers, "self_improvement"):
        return jsonify({"ok": False, "error": "self improvement layer unavailable"}), 200
    if request.method == "POST":
        data = request.json or {}
        limit = coerce_int_arg(data.get("limit") or request.args.get("limit", 100), 100, minimum=1, maximum=200, context="api_self_improvement.post_limit")
        auto_process = bool(data.get("auto_process"))
        result = layers.self_improvement.generate_candidates(limit=limit)
        if auto_process:
            result["auto_review"] = layers.self_improvement.run_autonomous_code_review_cycle(
                limit=min(10, limit),
                auto_apply=bool(data.get("auto_apply", True)),
            )
        return jsonify(result)

    limit = coerce_int_arg(request.args.get("limit", 50), 50, minimum=1, maximum=200, context="api_self_improvement.limit")
    status = request.args.get("status") or "pending"
    layer_status = layers.self_improvement.status()
    return jsonify({
        "ok": True,
        "loaded": True,
        "mode": layer_status.get("mode") or "bounded_auto_review",
        "summary": layers.self_improvement.summary(limit=200),
        "candidates": layers.self_improvement.list_candidates(status=status, limit=limit),
        "layer_status": layer_status,
    })


@app.route('/api/self_improvement/briefing', methods=['GET'])
def api_self_improvement_briefing():
    if not layers or not hasattr(layers, "self_improvement"):
        return jsonify({"ok": False, "error": "self improvement layer unavailable"}), 200
    limit = coerce_int_arg(request.args.get("limit", 3), 3, minimum=1, maximum=10, context="api_self_improvement_briefing.limit")
    return jsonify({
        "ok": True,
        "mode": "human_briefing",
        "briefing": layers.self_improvement.review_briefing(limit=limit),
    })


@app.route('/api/self_improvement/<candidate_id>', methods=['GET', 'PATCH'])
def api_self_improvement_detail(candidate_id):
    if not layers or not hasattr(layers, "self_improvement"):
        return jsonify({"ok": False, "error": "self improvement layer unavailable"}), 200
    if request.method == "PATCH":
        data = request.json or {}
        candidate = layers.self_improvement.update_candidate(candidate_id, data)
        if not candidate:
            return jsonify({"ok": False, "error": "candidate not found"}), 404
        return jsonify({"ok": True, "candidate": candidate})
    candidate = layers.self_improvement.get_candidate(candidate_id)
    if not candidate:
        return jsonify({"ok": False, "error": "candidate not found"}), 404
    return jsonify({"ok": True, "candidate": candidate})


@app.route('/api/runtime_policies', methods=['GET', 'POST'])
def api_runtime_policies():
    if not layers or not hasattr(layers, "self_improvement"):
        return jsonify({"ok": False, "error": "self improvement layer unavailable"}), 200
    if request.method == "POST":
        data = request.json or {}
        candidate_id = data.get("candidate_id") or ""
        try:
            policy = layers.self_improvement.create_policy_from_candidate(
                candidate_id,
                status=data.get("status") or "draft",
                meta=data.get("meta") if isinstance(data.get("meta"), dict) else {},
            )
        except Exception as err:
            return jsonify({"ok": False, "error": str(err)}), 400
        return jsonify({"ok": True, "policy": policy})

    limit = coerce_int_arg(request.args.get("limit", 50), 50, minimum=1, maximum=200, context="api_runtime_policies.limit")
    status = request.args.get("status") or "enabled"
    return jsonify({
        "ok": True,
        "mode": "prompt_hints_only",
        "summary": layers.self_improvement.summary(limit=200),
        "policies": layers.self_improvement.list_policies(status=status, limit=limit),
        "active_context": layers.self_improvement.active_policy_context(limit=limit) if status in {"enabled", "all"} else {},
    })


@app.route('/api/runtime_policies/<policy_id>', methods=['GET', 'PATCH'])
def api_runtime_policy_detail(policy_id):
    if not layers or not hasattr(layers, "self_improvement"):
        return jsonify({"ok": False, "error": "self improvement layer unavailable"}), 200
    if request.method == "PATCH":
        data = request.json or {}
        policy = layers.self_improvement.update_policy(policy_id, data)
        if not policy:
            return jsonify({"ok": False, "error": "policy not found"}), 404
        return jsonify({"ok": True, "policy": policy})
    policy = layers.self_improvement.get_policy(policy_id)
    if not policy:
        return jsonify({"ok": False, "error": "policy not found"}), 404
    return jsonify({"ok": True, "policy": policy})


@app.route('/api/code_proposals', methods=['GET', 'POST'])
def api_code_proposals():
    if not layers or not hasattr(layers, "self_improvement"):
        return jsonify({"ok": False, "error": "self improvement layer unavailable"}), 200
    if request.method == "POST":
        data = request.json or {}
        try:
            proposal = layers.self_improvement.create_code_proposal(
                source_type=data.get("source_type") or "candidate",
                source_id=data.get("source_id") or data.get("candidate_id") or data.get("policy_id") or "",
                status=data.get("status") or "draft",
                meta=data.get("meta") if isinstance(data.get("meta"), dict) else {},
            )
        except Exception as err:
            return jsonify({"ok": False, "error": str(err)}), 400
        return jsonify({
            "ok": True,
            "proposal": proposal,
            "plain_summary": proposal.get("plain_summary") if isinstance(proposal, dict) else "",
            "note": "proposal only; source code was not modified",
        })

    limit = coerce_int_arg(request.args.get("limit", 50), 50, minimum=1, maximum=200, context="api_code_proposals.limit")
    status = request.args.get("status") or "draft"
    return jsonify({
        "ok": True,
        "mode": "proposal_only",
        "summary": layers.self_improvement.code_proposal_summary(limit=200),
        "proposals": layers.self_improvement.list_code_proposals(status=status, limit=limit),
    })


@app.route('/api/code_proposals/<proposal_id>', methods=['GET', 'PATCH'])
def api_code_proposal_detail(proposal_id):
    if not layers or not hasattr(layers, "self_improvement"):
        return jsonify({"ok": False, "error": "self improvement layer unavailable"}), 200
    if request.method == "PATCH":
        data = request.json or {}
        proposal = layers.self_improvement.update_code_proposal(proposal_id, data)
        if not proposal:
            return jsonify({"ok": False, "error": "proposal not found"}), 404
        return jsonify({"ok": True, "proposal": proposal})
    proposal = layers.self_improvement.get_code_proposal(proposal_id)
    if not proposal:
        return jsonify({"ok": False, "error": "proposal not found"}), 404
    return jsonify({"ok": True, "proposal": proposal})


@app.route('/api/code_proposals/<proposal_id>/authorize', methods=['POST'])
def api_code_proposal_authorize(proposal_id):
    if not layers or not hasattr(layers, "self_improvement"):
        return jsonify({"ok": False, "error": "self improvement layer unavailable"}), 200
    data = request.json or {}
    text = data.get("text") or data.get("utterance") or data.get("message") or ""
    try:
        proposal = layers.self_improvement.authorize_code_proposal(proposal_id, text)
    except Exception as err:
        return jsonify({"ok": False, "error": str(err)}), 400
    return jsonify({
        "ok": True,
        "proposal": proposal,
        "authorized": True,
        "note": "approved for sandbox only; source code was not modified and still requires a second explicit confirmation",
    })


@app.route('/api/code_proposals/<proposal_id>/generate', methods=['POST'])
def api_code_proposal_generate(proposal_id):
    """Use LLM to generate diff_text + test_commands for a draft proposal."""
    if not layers or not hasattr(layers, "self_improvement"):
        return jsonify({"ok": False, "error": "self improvement layer unavailable"}), 200
    proposal = layers.self_improvement.get_code_proposal(proposal_id)
    if not proposal:
        return jsonify({"ok": False, "error": "proposal not found"}), 404
    _base = str(layers.config.base_dir) if hasattr(layers, "config") else str(BASE_DIR)
    try:
        result = generate_proposal_diff_via_aider(proposal, base_dir=_base)
        if not result.get("diff_text"):
            result = generate_proposal_diff(proposal, base_dir=_base)
        diff_text = result.get("diff_text", "") or ""
        test_cmds = result.get("test_commands") or []
        if diff_text.strip():
            proposal = layers.self_improvement.update_code_proposal(proposal_id, {
                "diff_text": diff_text,
                "test_commands": test_cmds,
            })
            return jsonify({
                "ok": True,
                "proposal": proposal,
                "diff_chars": len(diff_text),
                "test_commands": test_cmds,
            })
        else:
            return jsonify({
                "ok": False,
                "error": "LLM returned empty diff",
                "hint": "Try again or check that the proposal has target_files and fix_template filled in",
            }), 422
    except Exception as err:
        return jsonify({"ok": False, "error": str(err)}), 500


@app.route('/api/code_proposals/<proposal_id>/sandbox', methods=['POST'])
def api_code_proposal_sandbox(proposal_id):
    if not layers or not hasattr(layers, "self_improvement"):
        return jsonify({"ok": False, "error": "self improvement layer unavailable"}), 200
    data = request.json or {}
    keep_workspace = bool(data.get("keep_workspace"))
    timeout_sec = coerce_int_arg(data.get("timeout_sec") or 180, 180, minimum=10, maximum=600, context="api_code_proposal_sandbox.timeout_sec")
    try:
        run = layers.self_improvement.run_code_proposal_sandbox(
            proposal_id,
            keep_workspace=keep_workspace,
            timeout_sec=timeout_sec,
        )
    except Exception as err:
        return jsonify({"ok": False, "error": str(err)}), 400
    return jsonify({
        "ok": True,
        "run": run,
        "note": "sandbox only; main source code was not modified",
    })


@app.route('/api/code_proposals/<proposal_id>/research', methods=['POST'])
def api_code_proposal_research(proposal_id):
    if not layers or not hasattr(layers, "self_improvement"):
        return jsonify({"ok": False, "error": "self improvement layer unavailable"}), 200
    data = request.json or {}
    max_sources = coerce_int_arg(data.get("max_sources") or 4, 4, minimum=1, maximum=8, context="api_code_proposal_research.max_sources")
    try:
        result = layers.self_improvement.perform_external_research_for_proposal(
            proposal_id,
            max_sources=max_sources,
        )
    except Exception as err:
        return jsonify({"ok": False, "error": str(err)}), 400
    return jsonify(result)


@app.route('/api/code_proposals/<proposal_id>/regenerate', methods=['POST'])
def api_code_proposal_regenerate(proposal_id):
    """After external research is completed, regenerate v2 diff and re-run sandbox."""
    if not layers or not hasattr(layers, "self_improvement"):
        return jsonify({"ok": False, "error": "self improvement layer unavailable"}), 200
    data = request.json or {}
    max_retries = coerce_int_arg(data.get("max_retries") or 2, 2, minimum=1, maximum=5, context="api_code_proposal_regenerate.max_retries")
    try:
        result = layers.self_improvement.regenerate_diff_after_research(
            proposal_id,
            max_retries=max_retries,
        )
    except Exception as err:
        return jsonify({"ok": False, "error": str(err)}), 400
    return jsonify(result)


@app.route('/api/code_proposals/<proposal_id>/apply_source', methods=['POST'])
def api_code_proposal_apply_source(proposal_id):
    if not layers or not hasattr(layers, "self_improvement"):
        return jsonify({"ok": False, "error": "self improvement layer unavailable"}), 200
    data = request.json or {}
    confirmation_text = data.get("confirmation_text") or data.get("text") or data.get("utterance") or data.get("message") or ""
    try:
        run = layers.self_improvement.apply_code_proposal_to_source(
            proposal_id,
            confirmation_text=confirmation_text,
        )
    except Exception as err:
        return jsonify({
            "ok": False,
            "error": str(err),
            "note": "source code was not modified unless all guarded apply checks pass",
        }), 400
    return jsonify({
        "ok": True,
        "run": run,
        "note": "source code changed only after explicit confirmation, concrete diff, and passed sandbox",
    })


@app.route('/api/sandbox_runs')
def api_sandbox_runs():
    if not layers or not hasattr(layers, "self_improvement"):
        return jsonify({"ok": False, "error": "self improvement layer unavailable"}), 200
    limit = coerce_int_arg(request.args.get("limit", 50), 50, minimum=1, maximum=200, context="api_sandbox_runs.limit")
    proposal_id = request.args.get("proposal_id") or None
    status = request.args.get("status") or "all"
    return jsonify({
        "ok": True,
        "runs": layers.self_improvement.list_sandbox_runs(proposal_id=proposal_id, status=status, limit=limit),
    })


@app.route('/api/sandbox_runs/<run_id>')
def api_sandbox_run_detail(run_id):
    if not layers or not hasattr(layers, "self_improvement"):
        return jsonify({"ok": False, "error": "self improvement layer unavailable"}), 200
    run = layers.self_improvement.get_sandbox_run(run_id)
    if not run:
        return jsonify({"ok": False, "error": "sandbox run not found"}), 404
    return jsonify({"ok": True, "run": run})


@app.route('/api/code_apply_runs')
def api_code_apply_runs():
    if not layers or not hasattr(layers, "self_improvement"):
        return jsonify({"ok": False, "error": "self improvement layer unavailable"}), 200
    limit = coerce_int_arg(request.args.get("limit", 50), 50, minimum=1, maximum=200, context="api_code_apply_runs.limit")
    proposal_id = request.args.get("proposal_id") or None
    return jsonify({
        "ok": True,
        "runs": layers.self_improvement.list_apply_runs(proposal_id=proposal_id, limit=limit),
    })


@app.route('/api/observability')
def api_observability():
    limit = request.args.get("limit", 50)
    limit = coerce_int_arg(limit, 50, minimum=1, maximum=200, context="api_observability.limit")
    if not layers:
        return jsonify({"ok": True, "loaded": False, "summary": {}, "traces": []})
    return jsonify({
        "ok": True,
        "loaded": True,
        "summary": layers.observability.summary(limit=limit),
        "traces": layers.observability.list_traces(limit=limit),
    })


@app.route('/api/observability/eval', methods=['POST'])
def api_observability_eval():
    if not layers:
        return jsonify({"ok": False, "error": "layers unavailable"}), 200
    data = request.json or {}
    user_msg = data.get("user_msg", "")
    reply = data.get("reply", "")
    recalled = data.get("recalled") or []
    eval_result = layers.observability.evaluate_reply(user_msg, reply, recalled)
    return jsonify({"ok": True, "eval": eval_result})


@app.route('/api/observability/regression', methods=['POST'])
def api_observability_regression():
    if not layers:
        return jsonify({"ok": False, "error": "layers unavailable"}), 200
    data = request.json or {}
    trace_id = data.get("trace_id") or ""
    trace = layers.observability.get_trace(trace_id) if trace_id else None
    if not trace:
        trace = {
            "id": data.get("id") or "",
            "user_msg": data.get("input") or data.get("user_msg") or "",
            "reply": data.get("reply") or "",
            "score": data.get("min_score") or 6,
            "flags": data.get("flags") or [],
        }
    reply = trace.get("reply") or ""
    flags = trace.get("flags") or []
    case = {
        "id": f"obs-{trace.get('id') or now_local().strftime('%Y%m%d%H%M%S')}",
        "input": trace.get("user_msg") or data.get("input") or "",
        "min_score": min(7, max(4, float(trace.get("score") or 6))),
    }
    forbidden = []
    if "ooc_or_system_leak" in flags:
        forbidden.extend(["作为AI", "语言模型", "系统提示", "数据库", "提示词"])
    if "list_tone" in flags:
        forbidden.extend(["首先", "其次", "建议你"])
    if "mojibake" in flags:
        forbidden.extend(["锟", "Ã", "Â", "鎴", "浣", "璇"])
    if forbidden:
        case["must_not_contain"] = sorted(set(forbidden))
    if "too_long" in flags or len(reply) > 100:
        case["max_len"] = min(120, max(60, len(reply) - 10))
    created = append_eval_case(case)
    if not created:
        return jsonify({"ok": False, "error": "empty input"}), 400
    return jsonify({"ok": True, "case": created})


@app.route('/api/skills')
def api_skills():
    if not layers:
        return jsonify({"ok": True, "loaded": False, "tools": []})
    limit = coerce_int_arg(request.args.get("audit_limit", 20), 20, minimum=1, maximum=200, context="api_skills.audit_limit")
    usage_limit = coerce_int_arg(request.args.get("usage_limit", 20), 20, minimum=1, maximum=200, context="api_skills.usage_limit")
    return jsonify({
        "ok": True,
        "loaded": True,
        "tools": layers.skills.list_tools(),
        "manifest": layers.skills.mcp_manifest(),
        "audit": layers.skills.audit_log(limit=limit),
        "usage": layers.skills.usage_log(limit=usage_limit),
        "usage_summary": layers.skills.usage_summary(limit=100),
    })


@app.route('/api/skills/run', methods=['POST'])
def api_skills_run():
    if not layers:
        return jsonify({"ok": False, "error": "layers unavailable"}), 200
    data = request.json or {}
    name = data.get("name", "")
    args = data.get("args") or {}
    return jsonify(layers.skills.call(name, args))


@app.route('/api/skills/curate', methods=['POST'])
def api_skills_curate():
    if not layers:
        return jsonify({"ok": False, "error": "layers unavailable"}), 200
    return jsonify(layers.skills.curate_skills(limit=200))


@app.route('/api/skills/archive_generated', methods=['POST'])
def api_skills_archive_generated():
    if not layers:
        return jsonify({"ok": False, "error": "layers unavailable"}), 200
    return jsonify(layers.skills.archive_generated_skills())


@app.route('/api/skills/<path:skill_name>/state', methods=['POST'])
def api_skills_set_state(skill_name):
    if not layers:
        return jsonify({"ok": False, "error": "layers unavailable"}), 200
    data = request.json or {}
    state = data.get("state") or "active"
    pinned = data.get("pinned")
    return jsonify({
        "ok": True,
        "item": layers.skills.set_skill_state(skill_name, state, pinned=pinned if isinstance(pinned, bool) else None),
    })


@app.route('/api/skill_learning')
def api_skill_learning():
    if not layers or not hasattr(layers, "skill_learning"):
        return jsonify({"ok": False, "error": "skill learning unavailable"}), 200
    limit = coerce_int_arg(request.args.get("limit", 50), 50, minimum=1, maximum=200, context="api_skill_learning.limit")
    status = (request.args.get("status") or "all").strip() or "all"
    layers.skill_learning.refresh_draft_suggestions(skills_layer=layers.skills, limit=200)
    findings_path = SELF_MONITOR_FINDINGS_FILE
    return jsonify({
        "ok": True,
        "status_summary": layers.skill_learning.status(),
        "drafts": [
            {
                **item,
                "suggested_action": layers.skill_learning.suggest_draft_action(item.get("id", ""), skills_layer=layers.skills),
            }
            for item in layers.skill_learning.prioritized_drafts(status=status, limit=limit)
        ],
        "merge_events": layers.skill_learning.list_merge_events(limit=20),
        "effect_summary": layers.skill_learning.merge_effect_summary(findings_path, window=20, limit=50),
    })


@app.route('/api/companion_profile', methods=['GET', 'POST'])
def api_companion_profile():
    if not layers or not hasattr(layers, "companion_profile"):
        return jsonify({"ok": False, "error": "companion profile unavailable"}), 200
    if request.method == 'POST':
        data = request.json or {}
        return jsonify({
            "ok": True,
            "profile": layers.companion_profile.upsert_profile(data, profile_key=data.get("profile_key") or "default"),
        })
    return jsonify({
        "ok": True,
        "profile": layers.companion_profile.get_profile(),
        "inject": layers.companion_profile.build_profile_inject(),
    })


@app.route('/api/skill_learning/ingest_monitor', methods=['POST'])
def api_skill_learning_ingest_monitor():
    if not layers or not hasattr(layers, "skill_learning"):
        return jsonify({"ok": False, "error": "skill learning unavailable"}), 200
    findings_path = Path(request.json.get("findings_path")) if isinstance(request.json, dict) and request.json.get("findings_path") else SELF_MONITOR_FINDINGS_FILE
    result = layers.skill_learning.ingest_self_monitor_findings(findings_path)
    # 每次 ingest 自动累加 cycle 事件计数
    layers.skill_learning.record_learning_event(n=result.get("imported_count", 1))
    return jsonify(result)


@app.route('/api/skill_learning/refresh_suggestions', methods=['POST'])
def api_skill_learning_refresh_suggestions():
    if not layers or not hasattr(layers, "skill_learning"):
        return jsonify({"ok": False, "error": "skill learning unavailable"}), 200
    return jsonify(layers.skill_learning.refresh_draft_suggestions(skills_layer=layers.skills, limit=200))


@app.route('/api/skill_learning/<draft_id>/publish', methods=['POST'])
def api_skill_learning_publish(draft_id):
    if not layers or not hasattr(layers, "skill_learning"):
        return jsonify({"ok": False, "error": "skill learning unavailable"}), 200
    return jsonify(layers.skill_learning.publish_draft_to_skill(draft_id, skills_layer=layers.skills))


@app.route('/api/skill_learning/<draft_id>/merge', methods=['POST'])
def api_skill_learning_merge(draft_id):
    if not layers or not hasattr(layers, "skill_learning"):
        return jsonify({"ok": False, "error": "skill learning unavailable"}), 200
    return jsonify(layers.skill_learning.merge_draft_into_skill(draft_id, skills_layer=layers.skills))


@app.route('/api/skill_learning/batch_merge_companion', methods=['POST'])
def api_skill_learning_batch_merge_companion():
    if not layers or not hasattr(layers, "skill_learning"):
        return jsonify({"ok": False, "error": "skill learning unavailable"}), 200
    data = request.json or {}
    limit = coerce_int_arg(data.get("limit", 20), 20, minimum=1, maximum=50, context="api_skill_learning_batch_merge_companion.limit")
    return jsonify(layers.skill_learning.batch_merge_companion_drafts(skills_layer=layers.skills, limit=limit))


@app.route('/api/skill_learning/<draft_id>/archive', methods=['POST'])
def api_skill_learning_archive(draft_id):
    if not layers or not hasattr(layers, "skill_learning"):
        return jsonify({"ok": False, "error": "skill learning unavailable"}), 200
    return jsonify(layers.skill_learning.archive_draft(draft_id))


@app.route('/api/skill_learning/auto_resolve_conflicts', methods=['POST'])
def api_skill_learning_auto_resolve_conflicts():
    if not layers or not hasattr(layers, "skill_learning"):
        return jsonify({"ok": False, "error": "skill learning unavailable"}), 200
    data = request.json or {}
    dry_run = bool(data.get("dry_run") or False)
    return jsonify(layers.skill_learning.auto_resolve_conflicts(dry_run=dry_run))


@app.route('/api/skill_learning/auto_archive_stale', methods=['POST'])
def api_skill_learning_auto_archive_stale():
    if not layers or not hasattr(layers, "skill_learning"):
        return jsonify({"ok": False, "error": "skill learning unavailable"}), 200
    data = request.json or {}
    dry_run = bool(data.get("dry_run") or False)
    max_age_days = coerce_int_arg(data.get("max_age_days", 14), 14, minimum=1, maximum=90,
                                  context="api_skill_learning_auto_archive_stale.max_age_days")
    min_evidence = coerce_int_arg(data.get("min_evidence", 3), 3, minimum=1, maximum=20,
                                  context="api_skill_learning_auto_archive_stale.min_evidence")
    return jsonify(layers.skill_learning.auto_archive_stale_drafts(
        dry_run=dry_run, max_age_days=max_age_days, min_evidence=min_evidence))


# ======================================================================
# P0: /api/skill_learning/execute_self_correction — Letta-style auto-fix
# ======================================================================

_SELF_CORRECT_SCHEMA = {
    "type": "object",
    "properties": {
        "analysis": {
            "type": "string",
            "description": "分析为什么这个 Skill 效果不佳的根因",
        },
        "corrected_content": {
            "type": "string",
            "description": "修正后的完整 Skill 内容（保持原有 Markdown 结构）",
        },
        "change_summary": {
            "type": "string",
            "description": "一句话总结改了什么",
        },
    },
    "required": ["analysis", "corrected_content", "change_summary"],
    "additionalProperties": False,
}

@app.route('/api/skill_learning/execute_self_correction', methods=['POST'])
def api_skill_learning_execute_self_correction():
    """P0: 当 Skill 效果低于阈值时，让 LLM 反思并生成修正后的内容，写入草稿。

    Body:
        skill_name (str)  — 要修正的 Skill 名（如 "comforting"）
        skill_content (str, optional) — 当前 Skill 内容，不传则自动读
        dry_run (bool)    — True 时只返回 prompt，不调 LLM
    """
    if not layers or not hasattr(layers, "skill_learning"):
        return jsonify({"ok": False, "error": "skill learning unavailable"}), 200

    data = request.json or {}
    skill_name = str(data.get("skill_name") or "").strip()
    if not skill_name:
        return jsonify({"ok": False, "error": "missing skill_name"}), 200

    dry_run = bool(data.get("dry_run") or False)

    # 1. 获取效果摘要
    findings_path = SELF_MONITOR_FINDINGS_FILE
    effect = layers.skill_learning.companion_skill_effect_summary(
        findings_path, window=20, limit=50,
    )

    # 2. 读取当前 Skill 内容
    skill_content = str(data.get("skill_content") or "").strip()
    if not skill_content and hasattr(layers, "skills"):
        try:
            resolved = layers.skills._load_selected_skill_payload(skill_name)
            skill_content = str(resolved.get("body") or resolved.get("content") or "")
        except Exception:
            skill_content = ""

    # 3. 生成修正 prompt
    prompt_result = layers.skill_learning.self_correct_skill(
        skill_name=skill_name,
        effect_summary=effect,
        skill_content=skill_content,
    )

    if not prompt_result.get("ok"):
        return jsonify(prompt_result)

    if prompt_result.get("reason") != "prompt_ready":
        return jsonify({**prompt_result, "dry_run": dry_run})

    if dry_run:
        return jsonify({
            **prompt_result,
            "dry_run": True,
            "llm_called": False,
            "skill_content_preview": skill_content[:300] if skill_content else "",
        })

    # 4. 调用 LLM
    try:
        parsed = _request_lm_json(
            [
                {
                    "role": "system",
                    "content": (
                        "你是 Skill 内容优化器。分析 Skill 效果数据，找出根因，"
                        "输出修正后的完整内容。保持原有 Markdown 结构和语气风格，"
                        "只修改导致效果不佳的部分。"
                    ),
                },
                {
                    "role": "user",
                    "content": prompt_result["pending_prompt"],
                },
            ],
            "skill_correction",
            _SELF_CORRECT_SCHEMA,
            temperature=0.3,
            max_tokens=800,
            timeout=120,
        )
        corrected_content = str(parsed.get("corrected_content") or "")
        analysis = str(parsed.get("analysis") or "")
        change_summary = str(parsed.get("change_summary") or "")
    except Exception as err:
        return jsonify({
            "ok": False,
            "error": f"LLM call failed: {err}",
            "skill_name": skill_name,
            "prompt_preview": prompt_result.get("pending_prompt", "")[:500],
        })

    if not corrected_content.strip():
        return jsonify({
            "ok": False,
            "error": "LLM returned empty corrected_content",
            "raw_parsed": parsed,
        })

    # 5. 写入草稿
    draft_result = layers.skill_learning.record_self_correction_draft(
        skill_name=skill_name,
        corrected_content=corrected_content,
        analysis=f"{analysis}\n\n变更摘要: {change_summary}",
    )

    return jsonify({
        **draft_result,
        "llm_analysis": analysis,
        "llm_change_summary": change_summary,
        "effect_score": prompt_result.get("avg_score"),
    })


# ======================================================================
# P1: /api/skill_learning/generate_reflection — Reflexion-style
# ======================================================================

@app.route('/api/skill_learning/generate_reflection', methods=['POST'])
def api_skill_learning_generate_reflection():
    """P1: 对效果差的 Skill 生成 LLM 口头反思。

    Body:
        source_key (str) — Skill 的 source_key
        effect_data (dict, optional) — 效果数据，不传则自动从 effect_summary 读
    """
    if not layers or not hasattr(layers, "skill_learning"):
        return jsonify({"ok": False, "error": "skill learning unavailable"}), 200

    data = request.json or {}
    source_key = str(data.get("source_key") or "").strip()
    if not source_key:
        return jsonify({"ok": False, "error": "missing source_key"}), 200

    effect_data = data.get("effect_data")
    if not isinstance(effect_data, dict) or not effect_data:
        findings_path = SELF_MONITOR_FINDINGS_FILE
        effect_summary = layers.skill_learning.companion_skill_effect_summary(
            findings_path, window=20, limit=50,
        )
        effect_data = (effect_summary.get("items") or {}).get(source_key) or {}

    # 1. 生成反思 prompt
    prompt = layers.skill_learning._reflect_on_poor_skill(source_key, effect_data)

    # 2. 调用 LLM（text 模式，因为反思是自由文本）
    try:
        resp = _post_lm_payload({
            "model": LM_MODEL,
            "messages": [
                {
                    "role": "system",
                    "content": "你是反思分析师。基于 Skill 效果数据，用 2-3 句话分析根因，"
                               "给出一条具体可操作的调整建议。语气简洁专业。",
                },
                {"role": "user", "content": prompt},
            ],
            "stream": False,
            "max_tokens": 300,
            "think_disabled": True,
            "temperature": 0.3,
        }, timeout=90)
        reflection_text, err = _parse_lm_response(resp)
        if err:
            return jsonify({"ok": False, "error": f"LM parse failed: {err}"})
    except Exception as err:
        return jsonify({
            "ok": False,
            "error": f"LLM call failed: {err}",
            "source_key": source_key,
        })

    return jsonify({
        "ok": True,
        "source_key": source_key,
        "reflection": reflection_text.strip(),
        "prompt_used": prompt[:500],
    })


# ======================================================================
# P2: /api/skill_learning/evaluate_constitution — Constitutional AI review
# ======================================================================

_CONSTITUTION_RULE_SCHEMA = {
    "type": "object",
    "properties": {
        "pass": {"type": "boolean"},
        "score": {"type": "number", "minimum": 0.0, "maximum": 1.0},
        "reason": {"type": "string"},
    },
    "required": ["pass", "score", "reason"],
    "additionalProperties": False,
}

@app.route('/api/skill_learning/evaluate_constitution', methods=['POST'])
def api_skill_learning_evaluate_constitution():
    """P2: 对草稿内容逐条进行宪法审查。

    Body:
        draft_id (str) — 要审查的草稿 ID
        constitution (list, optional) — 自定义宪法规则
        auto_flag (bool) — 失败时是否自动标记草稿
        flag_threshold (float) — 低于此分标记为失败（默认 0.5）
    """
    if not layers or not hasattr(layers, "skill_learning"):
        return jsonify({"ok": False, "error": "skill learning unavailable"}), 200

    data = request.json or {}
    draft_id = str(data.get("draft_id") or "").strip()
    if not draft_id:
        return jsonify({"ok": False, "error": "missing draft_id"}), 200

    auto_flag = bool(data.get("auto_flag") or False)
    flag_threshold = float(data.get("flag_threshold") or 0.5)
    custom_rules = data.get("constitution") if isinstance(data.get("constitution"), list) else None

    # 1. 读取草稿
    draft = layers.skill_learning.get_draft(draft_id)
    if not draft:
        return jsonify({"ok": False, "error": "draft not found", "draft_id": draft_id}), 200

    # 2. 生成审查 prompt
    check_result = layers.skill_learning._constitution_check(
        draft, constitution=custom_rules,
    )
    if not check_result.get("checked"):
        return jsonify(check_result)

    # 3. 逐条让 LLM 打分
    results = []
    any_failed = False
    for prompt_item in check_result["pending_prompts"]:
        try:
            parsed = _request_lm_json(
                [
                    {
                        "role": "system",
                        "content": (
                            f"你是 Skill 合规审查员（规则: {prompt_item['rule_label']}）。"
                            "请根据审查问题给出 pass/score/reason。"
                        ),
                    },
                    {"role": "user", "content": prompt_item["prompt"]},
                ],
                "constitution_rule",
                _CONSTITUTION_RULE_SCHEMA,
                temperature=0.0,
                max_tokens=160,
                timeout=60,
            )
            score = float(parsed.get("score") or 0)
            passed = bool(parsed.get("pass")) and score >= flag_threshold
            if not passed:
                any_failed = True
            results.append({
                "rule_id": prompt_item["rule_id"],
                "rule_label": prompt_item["rule_label"],
                "pass": passed,
                "score": score,
                "reason": str(parsed.get("reason") or "")[:200],
            })
        except (ConnectionError, TimeoutError, json.JSONDecodeError, KeyError, ValueError, OSError, ImportError) as e:
            results.append({
                "rule_id": prompt_item["rule_id"],
                "rule_label": prompt_item["rule_label"],
                "pass": True,
                "score": 1.0,
                "reason": f"evaluator error: {err}",
            })

    # 4. 可选自动标记
    flagged = False
    if auto_flag and any_failed and str(draft.get("status") or "") == "draft":
        try:
            layers.skill_learning.update_draft_status(draft_id, "constitution_fail")
            flagged = True
        except (RuntimeError | ValueError) as e:
            pass

    return jsonify({
        "ok": True,
        "draft_id": draft_id,
        "title": check_result.get("title"),
        "rule_count": len(results),
        "passed_count": sum(1 for r in results if r["pass"]),
        "failed_count": sum(1 for r in results if not r["pass"]),
        "results": results,
        "flagged": flagged,
        "flag_threshold": flag_threshold,
    })


# ======================================================================
# P3: /api/skill_learning/smart_ab_resolve — DSPy-style A/B optimization
# ======================================================================

@app.route('/api/skill_learning/smart_ab_resolve', methods=['POST'])
def api_skill_learning_smart_ab_resolve():
    """P3: 对同一 source_key 的多个草稿做 A/B 效果比较，自动归档劣势变体。

    Body:
        source_key (str) — 要比较的 source_key
        dry_run (bool)  — True 时只排名不归档
    """
    if not layers or not hasattr(layers, "skill_learning"):
        return jsonify({"ok": False, "error": "skill learning unavailable"}), 200

    data = request.json or {}
    source_key = str(data.get("source_key") or "").strip()
    if not source_key:
        return jsonify({"ok": False, "error": "missing source_key"}), 200

    dry_run = bool(data.get("dry_run") or False)

    # 1. 找出该 source_key 的所有活跃草稿
    all_drafts = layers.skill_learning.list_drafts(limit=200)
    active = [
        d for d in all_drafts
        if str(d.get("source_key") or "") == source_key
        and str(d.get("status") or "") in {"draft", "suggested_merge", "suggested_publish"}
    ]
    active.sort(key=lambda d: -(int(d.get("evidence_count") or 0)))

    # 2. A/B 比较
    ab_result = layers.skill_learning._ab_test_merge(source_key, active)

    if not dry_run and ab_result.get("ab_testable") and active:
        # 3. 归档被淘汰的变体
        eliminated = ab_result["eliminated"]
        archived_ids = []
        for item in eliminated:
            eid = item["draft_id"]
            # 只归档非 keeper 的活跃草稿
            if eid != ab_result["keeper"]["draft_id"]:
                try:
                    layers.skill_learning.archive_draft(eid)
                    archived_ids.append(eid)
                except (RuntimeError | ValueError) as e:
                    pass
        ab_result["applied"] = True
        ab_result["archived_ids"] = archived_ids

    return jsonify({
        **ab_result,
        "source_key": source_key,
        "dry_run": dry_run,
    })


# ======================================================================
# Batch: /api/skill_learning/run_self_improvement_cycle
# Runs all 4 steps in sequence
# ======================================================================

@app.route('/api/skill_learning/run_self_improvement_cycle', methods=['POST'])
def api_skill_learning_run_self_improvement_cycle():
    """一次性运行完整的自我改进循环：效果评估 → 修正 → 宪法审查 → A/B 去重 → 归档

    Body:
        dry_run (bool)       — True 时全程不写入
        skill_names (list)   — 要修正的 Skill 列表（默认 _RANKED_SKILL_NAMES）
        max_age_days (int)   — 归档阈值（默认 14）
    """
    if not layers or not hasattr(layers, "skill_learning"):
        return jsonify({"ok": False, "error": "skill learning unavailable"}), 200

    data = request.json or {}
    dry_run = bool(data.get("dry_run") or False)
    skill_names = data.get("skill_names")
    if not isinstance(skill_names, list) or not skill_names:
        skill_names = list(getattr(layers.skill_learning, "_RANKED_SKILL_NAMES", [
            "comforting", "late_night_companion", "relationship_repair",
            "reply_style_guard", "memory_recall_style",
        ]))
    max_age_days = coerce_int_arg(data.get("max_age_days", 14), 14,
                                  minimum=1, maximum=90, context="cycle.max_age_days")

    report = {"ok": True, "dry_run": dry_run, "steps": {}}
    core = _run_skill_learning_cycle_core(
        skill_names=skill_names,
        dry_run=dry_run,
        max_age_days=max_age_days,
        findings_path=SELF_MONITOR_FINDINGS_FILE,
    )
    report["steps"] = core["steps"]
    report["corrected_count"] = core["corrected_count"]
    report["archived_count"] = core["archive"].get("archived_count", 0)

    return jsonify(report)



# ======================================================================
# Data-driven trigger: /api/skill_learning/check_and_run_cycle
# ======================================================================

@app.route('/api/skill_learning/check_and_run_cycle', methods=['POST'])
def api_skill_learning_check_and_run_cycle():
    """基于数据量闸门触发 self-improvement cycle。

    当累计 ingest >= 30 条新数据后自动跑完整 cycle，
    否则返回 skip 状态和当前计数。

    Body:
        min_samples (int, optional) — 触发阈值，默认 30
        dry_run (bool)             — True 时不计入 cycle 次数
    """
    if not layers or not hasattr(layers, "skill_learning"):
        return jsonify({"ok": False, "error": "skill learning unavailable"}), 200

    data = request.json or {}
    min_samples = coerce_int_arg(data.get("min_samples", 30), 30,
                                 minimum=5, maximum=1000,
                                 context="check_and_run_cycle.min_samples")
    dry_run = bool(data.get("dry_run") or False)

    state_before = layers.skill_learning.get_cycle_state()

    if not layers.skill_learning.should_trigger_cycle(min_samples=min_samples):
        return jsonify({
            "ok": True,
            "triggered": False,
            "reason": f"阈值未达到 (当前 {state_before['samples_since_last_run']}/{min_samples})",
            "state": state_before,
        })

    # 触发 cycle —— 复用 batch 逻辑但精简为单次调用
    max_age_days = coerce_int_arg(data.get("max_age_days", 14), 14,
                                  minimum=1, maximum=90, context="cycle.max_age_days")
    skill_names = list(getattr(layers.skill_learning, "_RANKED_SKILL_NAMES", [
        "comforting", "late_night_companion", "relationship_repair",
        "reply_style_guard", "memory_recall_style",
    ]))

    core = _run_skill_learning_cycle_core(
        skill_names=skill_names,
        dry_run=dry_run,
        max_age_days=max_age_days,
        findings_path=SELF_MONITOR_FINDINGS_FILE,
    )

    if not dry_run:
        layers.skill_learning.mark_cycle_run()

    state_after = layers.skill_learning.get_cycle_state()

    return jsonify({
        "ok": True,
        "triggered": True,
        "dry_run": dry_run,
        "state_before": state_before,
        "state_after": state_after,
        "results": {
            "conflict_resolved": core["conflict"].get("auto_resolved") or bool(core["conflict"].get("conflict_count")),
            "archived_count": core["archive"].get("archived_count", 0),
            "corrections": core["corrections"],
            "corrected_count": core["corrected_count"],
        },
    })


register_capability_routes(app, jsonify=jsonify, request=request, get_layers=lambda: layers)


@app.route('/api/reset', methods=['POST'])
def api_reset():
    global chat_history, technical_chat_history
    chat_history = []
    technical_chat_history = []
    intimacy.data["level"] = 1
    intimacy.data["exp"] = 0
    intimacy.data["energy"] = 100
    intimacy.data["mood"] = 100
    # 重置人格底色到默认值
    intimacy.data["personality_gentle"] = 65
    intimacy.data["personality_rational"] = 55
    intimacy.data["personality_indirect"] = 60
    intimacy.data["personality_pessimistic"] = 40
    intimacy.data["personality_clingy"] = 50
    intimacy.data["last_user_time"] = None
    intimacy.data["last_proactive_time"] = None
    intimacy.data["daily_event_date"] = None
    intimacy.data["daily_event"] = ""
    intimacy.data["life_arc"] = []
    intimacy.data["life_arc_date"] = None
    intimacy.data["care_followups"] = []
    intimacy.data["emotion_carry"] = "neutral"
    intimacy.data["emotion_carry_turns"] = 0
    intimacy.data["boundary_strikes"] = 0
    intimacy.data["last_decay_date"] = None
    intimacy.data["last_user_message"] = ""
    intimacy.data["last_assistant_message"] = ""
    intimacy.data["last_user_wait_marker"] = None
    intimacy.data["last_wait_reply"] = None
    intimacy.data["quiet_mode_until"] = None
    intimacy.data["last_flashback_time"] = None
    intimacy.data["last_ambient_time"] = None
    intimacy.data["last_micro_story_time"] = None
    intimacy.save()
    emotion.emotion = "neutral"
    emotion.happiness = 50
    emotion.activity = 50
    emotion.jealousy_level = 0.0
    emotion.cold_war_turns = 0
    emotion.history = []
    emotion.valence = 0.0
    emotion.arousal = 0.0
    emotion.last_update = now_iso_local()
    emotion.save()
    return jsonify({"ok": True})


# ============================================================
# Memory v2 API endpoints (multi-signal optimization)
# ============================================================

@app.route('/api/memories/extract', methods=['POST'])
def api_extract_memories():
    """从对话中自动提取新记忆（LLM驱动）"""
    data = request.json or {}
    messages = data.get("messages", [])
    max_new = int(data.get("max_new", 3))
    memory_layer = _layers.memory._memory_layer
    return jsonify(_mv2.extract_memories_from_conversation(messages, memory_layer, max_new=max_new))


@app.route('/api/memories/consolidate', methods=['POST'])
def api_consolidate_memories():
    """记忆整合：合并相似记忆+衰减低质量记忆"""
    data = request.json or {}
    max_merge = int(data.get("max_merge", 10))
    min_importance = int(data.get("min_importance", 1))
    max_age_days = int(data.get("max_age_days", 90))
    memory_layer = _layers.memory._memory_layer
    return jsonify(_mv2.consolidate_memories(memory_layer, max_merge=max_merge, min_importance=min_importance, max_age_days=max_age_days))


@app.route('/api/memories/conflicts', methods=['POST'])
def api_detect_conflicts():
    """检测指定记忆的语义冲突"""
    data = request.json or {}
    content = (data.get("content") or "").strip()
    mem_type = data.get("mem_type", "fact")
    if not content:
        return jsonify({"ok": False, "error": "content is required"})
    memory_layer = _layers.memory._memory_layer
    return jsonify({"ok": True, "conflicts": _mv2.detect_semantic_conflicts(content, mem_type, memory_layer)})


def _generate_daily_plan():
    """Generate today's daily plan using LM (v3: uses character_state module)."""
    cs = _get_char_state()
    return cs.start_new_day(wait_for_lm=True)


def _init_character_state():
    """Initialize character state: wire up LM, generate life/daily plans & joys.
    
    Returns:
        CharacterState instance, or None if char_state module is unavailable.
    """
    if char_state is None:
        print("[character] Module not available, character state disabled")
        return None
    
    try:
        cs = char_state.init_character_state(_request_lm_text)
        print("[character] LM function wired")
    except Exception as e:
        print(f"[character] init failed: {e}, character state disabled")
        return None

    # Life plan (once)
    try:
        if not cs.has_life_plan():
            print("[character] No life plan found — will generate in background")
    except Exception as e:
        print(f"[character] Life plan check failed: {e}")

    # Daily plan check
    try:
        if cs.is_new_day():
            print("[character] New day detected — will generate daily plan in background")
        elif cs.has_today_plan():
            print(f"[character] Using existing daily plan for {cs.plan.get('date', '?')}")
        else:
            print("[character] No daily plan — will generate in background")
    except Exception as e:
        print(f"[character] Daily plan check failed: {e}")

    return cs


# ── Authentication helper ──
def _get_auth_token_from_request():
    """Extract auth token from Authorization header or query param."""
    header = request.headers.get("Authorization", "")
    if header.startswith("Bearer "):
        return header[7:]
    return request.args.get("token", "")


def _verify_internal_request():
    """Verify request is from an internal/internal service."""
    token = _get_auth_token_from_request()
    expected = os.environ.get("ZHIYUE_INTERNAL_TOKEN", "zhiyue-internal-2025")
    if token and token == expected:
        return True
    # Allow localhost requests without token
    if request.remote_addr in ("127.0.0.1", "::1", "localhost"):
        return True
    return False


if __name__ == '__main__':
    if len(sys.argv) >= 3 and sys.argv[1] == "--import-history":
        result = import_chat_history_file(sys.argv[2])
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0)

    print("=" * 50)
    print("  张致悦 AI - 人物角色生活系统 v3")
    print("  打开浏览器: http://127.0.0.1:8899")
    print(f"  LM Studio: {LM_MODEL}")
    print("  新增: 人生规划 | 每日计划 | 小确幸 | 自主行为 | 情绪感知")
    print("=" * 50)

    # Initialize character state — wire up LM immediately,
    # generate everything in background to avoid blocking startup
    cs = _init_character_state()
    if cs is None:
        print("[character] WARNING: character state disabled (module not available)")

    def _bg_init():
        """Background: generate life plan (once), daily plan, and small joys."""
        if cs is None:
            print("[character] Skipping background init (cs=None)")
            return
        try:
            # 1. Life plan — only once
            if not cs.has_life_plan():
                print("[character] Generating life plan...")
                lp = cs.generate_life_plan()
                if lp:
                    theme = lp.get("monthly_theme", "")
                    print(f"[character] Life plan generated: {theme}")
                else:
                    print("[character] Life plan generation skipped (LM timeout)")

            # 2. Daily plan — if new day
            if cs.is_new_day() or not cs.has_today_plan():
                print("[character] Generating daily plan...")
                plan = cs.start_new_day(wait_for_lm=True)
                if plan and plan.get("schedule"):
                    print(f"[character] Daily plan: {plan.get('mood_today', '')}")
                    print(f"[character] Schedule blocks: {len(plan.get('schedule', []))}")
                else:
                    print("[character] Daily plan skipped (LM timeout)")
            else:
                print(f"[character] Using existing plan for {cs.plan.get('date', '?')}")
                # Still generate joys if missing
            if char_state is not None and (not char_state.load_joys()):
                    cs.generate_daily_joys()

            print("[character] Background init complete")
        except Exception as e:
            print(f"[character] Background init error: {e}")

    t = threading.Thread(target=_bg_init, daemon=True)
    t.start()

    # ── Autonomous activity ticker ──
    def _autonomous_ticker():
        """Periodically run autonomous activities for the character."""
        import time as _time
        _time.sleep(60)  # Wait 1 min for everything to stabilize
        while True:
            try:
                if cs is None:
                    _time.sleep(300)
                    continue
                # Check day transition
                if cs.is_new_day():
                    print("[character] Midnight transition — starting new day")
                    cs.start_new_day(wait_for_lm=True)

                # Run autonomous tick
                if char_state is not None:
                    result = char_state.run_autonomous_tick(cs)
                    if result:
                        print(f"[character] Autonomous: {result[:120]}")
            except Exception as e:
                print(f"[character] Ticker error: {e}")
            _time.sleep(300)  # Every 5 minutes

    ta = threading.Thread(target=_autonomous_ticker, daemon=True)
    ta.start()

    # ── Mobile sync ticker (local -> remote companion) ──
    def _mobile_sync_ticker():
        """Keep remote companion memory/persona reasonably in sync while PC is on."""
        if REMOTE_COMPANION_MODE:
            return
        import time as _time
        enabled = os.environ.get("ZHIYUE_MOBILE_SYNC_DAEMON", "1").strip().lower() not in {"0", "false", "no", "off"}
        if not enabled:
            return
        _time.sleep(15)
        try:
            _mobile_sync_pull_once()
        except Exception:
            pass
        try:
            _mobile_control_pull_provider_once()
        except Exception:
            pass
        try:
            _mobile_sync_push_once()
        except Exception:
            pass
        last_pull = _time.time()
        last_control = _time.time()
        while True:
            try:
                # Push often, pull periodically to absorb remote-only chats.
                _mobile_sync_push_once()
                if (_time.time() - last_pull) > 3600:
                    _mobile_sync_pull_once()
                    last_pull = _time.time()
                if (_time.time() - last_control) > 1800:
                    _mobile_control_pull_provider_once()
                    last_control = _time.time()
            except Exception:
                pass
            _time.sleep(600)  # 10 minutes

    tsync = threading.Thread(target=_mobile_sync_ticker, daemon=True)
    tsync.start()

    app.run(host=HOST, port=PORT, debug=False, threaded=True)
SHUTDOWN_CONFIRMATION_TOKENS = {"关机", "shutdown", "shutdown now", "confirm shutdown"}
SHUTDOWN_FAREWELL_TOKEN = "__SHUTDOWN_FAREWELL__"
