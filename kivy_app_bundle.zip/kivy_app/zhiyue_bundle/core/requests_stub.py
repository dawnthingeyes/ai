# -*- coding: utf-8 -*-
"""
requests_stub.py — stdlib-only fallback for `import requests`
Provides minimal requests-compatible get()/post() using urllib.request.
Used when the real `requests` package is not installed.
"""
from __future__ import annotations
import json as _json
import urllib.request as _request
import urllib.error as _error
import socket as _socket
from typing import Optional, Dict, Any


class _MockResponse:
    """Minimal requests.Response-like object."""
    def __init__(self, status_code: int, text: str, headers: Optional[Dict] = None):
        self.status_code = status_code
        self.text = text
        self.headers = headers or {}
        self._content = text.encode("utf-8", errors="replace")

    def json(self) -> Any:
        return _json.loads(self.text)

    @property
    def content(self) -> bytes:
        return self._content

    def raise_for_status(self) -> None:
        if self.status_code >= 400:
            raise _error.HTTPError(
                url="", code=self.status_code, msg="", hdrs=None, fp=None
            )


def get(url: str, params: Optional[Dict] = None, timeout: float = 10, **_kw) -> _MockResponse:
    """Stub for requests.get() using urllib."""
    try:
        if params:
            from urllib.parse import urlencode
            url = url + "?" + urlencode(params)
        req = _request.Request(url, headers={"User-Agent": "zhiyue/requests-stub"})
        with _request.urlopen(req, timeout=timeout) as resp:
            body = resp.read().decode("utf-8", errors="replace")
            return _MockResponse(resp.status or 200, body, dict(resp.headers))
    except _error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace") if hasattr(e, "read") else ""
        return _MockResponse(e.code or 500, body)
    except (_socket.timeout, TimeoutError, _error.URLError) as e:
        # Return a 503-ish response instead of raising
        return _MockResponse(503, f"timeout: {e}")


def post(url: str, json: Optional[Any] = None, data: Optional[Any] = None,
         headers: Optional[Dict] = None, timeout: float = 30, **_kw) -> _MockResponse:
    """Stub for requests.post() using urllib."""
    try:
        if json is not None:
            body = _json.dumps(json).encode("utf-8")
            hdrs = {"Content-Type": "application/json; charset=utf-8"}
        elif data is not None:
            body = data if isinstance(data, bytes) else str(data).encode("utf-8")
            hdrs = {}
        else:
            body = b""
            hdrs = {}
        if headers:
            hdrs.update(headers)
        req = _request.Request(url, data=body, headers=hdrs, method="POST")
        with _request.urlopen(req, timeout=timeout) as resp:
            body = resp.read().decode("utf-8", errors="replace")
            return _MockResponse(resp.status or 200, body, dict(resp.headers))
    except _error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace") if hasattr(e, "read") else ""
        return _MockResponse(e.code or 500, body)
    except (_socket.timeout, TimeoutError, _error.URLError) as e:
        return _MockResponse(503, f"timeout: {e}")


# Minimally mimic the requests module
def request(method: str, url: str, **kw) -> _MockResponse:
    method = method.upper()
    if method == "GET":
        return get(url, **kw)
    if method == "POST":
        return post(url, **kw)
    return _MockResponse(405, f"method {method} not implemented in stub")


class _SessionStub:
    def get(self, *a, **kw): return get(*a, **kw)
    def post(self, *a, **kw): return post(*a, **kw)
    def request(self, *a, **kw): return request(*a, **kw)

def session() -> _SessionStub:
    return _SessionStub()


__all__ = ["get", "post", "request", "session"]
