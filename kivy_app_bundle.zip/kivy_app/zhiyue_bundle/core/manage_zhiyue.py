from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path
from urllib.error import URLError
from urllib.request import urlopen

import _bootstrap_runtime  # noqa: F401
from zhiyue_runtime_health import self_monitor_snapshot


BASE_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = BASE_DIR.parent.resolve()
PYTHONW = BASE_DIR / ".." / ".venv" / "Scripts" / "pythonw.exe"
if not PYTHONW.exists():
    PYTHONW = Path(sys.executable).parent / "pythonw.exe"
PYTHON = os.environ.get("ZHIYUE_PYTHON") or str(sys.executable or (PYTHONW if PYTHONW.exists() else "python"))

SERVICE_SCRIPTS = {
    "gateway": BASE_DIR / "_gateway_zhiyue.py",
    "backend": BASE_DIR / "zhiyue_connected.py",
    "weixin_direct": BASE_DIR / "zhiyue_weixin_direct.py",
    "self_monitor": BASE_DIR / "zhiyue_self_monitor.py",
    "wechat_bridge": BASE_DIR / "zhiyue_wechat_bridge.py",
    "watchdog": BASE_DIR / "cycle_watchdog.py",
}

SERVICE_HEALTH_URLS = {
    "gateway": "http://127.0.0.1:8899/api/gateway/health",
    "backend": "http://127.0.0.1:8898/api/health",
}

START_PLANS = {
    "core": ["backend", "gateway"],
    "wechat": ["wechat_bridge"],
    "weixin": ["weixin_direct"],
    "monitor": ["self_monitor"],
    "local_weixin": ["backend", "gateway", "weixin_direct"],
    "full": ["backend", "gateway", "weixin_direct", "wechat_bridge"],
}

STOP_PLANS = {
    "core": ["backend", "gateway"],
    "wechat": ["wechat_bridge"],
    "weixin": ["weixin_direct"],
    "monitor": ["self_monitor"],
    "all": ["wechat_bridge", "weixin_direct", "self_monitor", "watchdog", "backend", "gateway"],
}

DIAGNOSTICS_URL = "http://127.0.0.1:8898/api/diagnostics"
WEIXIN_CONFIG_FILE = PROJECT_ROOT / "data" / "zhiyue_weixin_config.json"


def _load_weixin_options() -> dict:
    if not WEIXIN_CONFIG_FILE.exists():
        return {}
    try:
        data = json.loads(WEIXIN_CONFIG_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def _service_expectation(service_name: str) -> dict:
    if service_name != "weixin_direct":
        return {"expected": True, "reason": "required"}
    options = _load_weixin_options()
    enabled_raw = str(options.get("enabled", True)).strip().lower()
    enabled = enabled_raw not in {"0", "false", "no", "off"}
    token = os.environ.get("ZHIYUE_ILINK_TOKEN", str(options.get("token") or "")).strip()
    if token == "SETUP_REQUIRED":
        token = ""
    if not enabled:
        return {"expected": False, "reason": "disabled_in_config"}
    if not token:
        return {"expected": False, "reason": "missing_token"}
    return {"expected": True, "reason": "configured"}


def http_ready(url: str) -> bool:
    try:
        with urlopen(url, timeout=3) as resp:
            code = int(getattr(resp, "status", 200) or 200)
            return 200 <= code < 300
    except (URLError, OSError, ValueError):
        return False


def wait_service_ready(service_name: str, timeout_seconds: float = 20.0) -> bool:
    expectation = _service_expectation(service_name)
    if not expectation.get("expected", True):
        return True
    deadline = time.time() + max(1.0, timeout_seconds)
    health_url = SERVICE_HEALTH_URLS.get(service_name)
    while time.time() < deadline:
        if service_running(service_name):
            if not health_url or http_ready(health_url):
                return True
        time.sleep(0.5)
    if not service_running(service_name):
        return False
    return not health_url or http_ready(health_url)


def _service_ready_details(service_name: str) -> dict:
    pids = service_running(service_name)
    expectation = _service_expectation(service_name)
    details = {
        "name": service_name,
        "running": bool(pids),
        "pids": pids,
        "ready": bool(pids),
        "expected": bool(expectation.get("expected", True)),
        "expectation_reason": str(expectation.get("reason") or ""),
    }
    if not details["expected"]:
        details["ready"] = True
        details["skipped"] = True
        return details
    health_url = SERVICE_HEALTH_URLS.get(service_name)
    if health_url:
        details["health_url"] = health_url
        details["health_ok"] = http_ready(health_url)
        details["ready"] = bool(pids) and details["health_ok"]
    elif service_name == "self_monitor":
        monitor = self_monitor_snapshot()
        details["monitor"] = monitor
        details["ready"] = bool(pids) and monitor.get("exists") and not monitor.get("stale")
    return details


def target_status(target: str) -> dict:
    services = START_PLANS[target]
    items = [_service_ready_details(name) for name in services]
    return {
        "target": target,
        "services": items,
        "ready": all(bool(item.get("ready")) for item in items),
    }


def fetch_backend_diagnostics(timeout: float = 3.0) -> dict:
    try:
        with urlopen(DIAGNOSTICS_URL, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8", errors="replace"))
    except Exception as err:
        return {"ok": False, "error": str(err)}


def iter_process_rows():
    try:
        script = (
            "Get-CimInstance Win32_Process | "
            "Where-Object { $_.Name -in @('pythonw.exe','python.exe') } | "
            "Select-Object ProcessId, CommandLine | ConvertTo-Json -Compress"
        )
        output = subprocess.check_output(
            ["powershell", "-NoProfile", "-Command", script],
            text=True,
            encoding="utf-8",
            errors="replace",
            cwd=str(BASE_DIR),
        )
    except Exception:
        return []
    try:
        data = __import__("json").loads(output)
    except Exception:
        return []
    rows = []
    if isinstance(data, dict):
        data = [data]
    for item in data or []:
        if not isinstance(item, dict):
            continue
        pid = item.get("ProcessId")
        cmdline = str(item.get("CommandLine") or "")
        try:
            pid = int(pid)
        except Exception:
            continue
        rows.append((pid, cmdline))
    return rows


def service_running(service_name: str) -> list[int]:
    script = str(SERVICE_SCRIPTS[service_name]).lower()
    script_name = SERVICE_SCRIPTS[service_name].name.lower()
    hits = []
    for pid, cmdline in iter_process_rows():
        lowered = (cmdline or "").lower()
        if script in lowered or script_name in lowered:
            hits.append(pid)
    return hits


def start_service(service_name: str) -> bool:
    if service_running(service_name):
        return False
    script = SERVICE_SCRIPTS[service_name]
    if not script.exists():
        raise FileNotFoundError(str(script))
    creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    env = os.environ.copy()
    if service_name == "backend":
        env["ZHIYUE_PORT"] = "8898"
    elif service_name == "gateway":
        env["ZHIYUE_PORT"] = "8899"
    subprocess.Popen(
        [PYTHON, str(script)],
        cwd=str(BASE_DIR),
        env=env,
        creationflags=creationflags,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    return True


def stop_service(service_name: str) -> int:
    count = 0
    for pid in service_running(service_name):
        try:
            subprocess.run(
                ["taskkill", "/F", "/PID", str(pid)],
                cwd=str(BASE_DIR),
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=False,
            )
            count += 1
        except Exception:
            pass
    return count


def command_start(target: str) -> int:
    started = []
    already_on = []
    skipped = []
    failed = []
    for name in START_PLANS[target]:
        expectation = _service_expectation(name)
        if not expectation.get("expected", True):
            skipped.append(name)
            continue
        before = service_running(name)
        if before:
            ready = wait_service_ready(name, timeout_seconds=10.0)
            if ready:
                already_on.append(name)
                continue
        start_service(name)
        ready = wait_service_ready(name, timeout_seconds=25.0)
        if ready:
            started.append(name)
        else:
            failed.append(name)
    status = target_status(target)
    if not status["ready"]:
        retry_failed = [
            item["name"]
            for item in status["services"]
            if not item.get("ready")
        ]
        for name in retry_failed:
            stop_service(name)
            time.sleep(0.5)
            start_service(name)
            wait_service_ready(name, timeout_seconds=25.0)
        status = target_status(target)
        failed = [item["name"] for item in status["services"] if not item.get("ready")]
    print("started:" + ",".join(started))
    print("already_on:" + ",".join(already_on))
    print("skipped:" + ",".join(skipped))
    print("failed:" + ",".join(failed))
    print("ready:" + str(status["ready"]).lower())
    return 1 if failed else 0


def command_stop(target: str) -> int:
    stopped = []
    already_off = []
    failed = []
    for name in STOP_PLANS[target]:
        before = service_running(name)
        if not before:
            already_off.append(name)
            continue
        stop_service(name)
        cleared = False
        for _ in range(30):
            time.sleep(0.2)
            if not service_running(name):
                cleared = True
                break
        if cleared:
            stopped.append(name)
        else:
            failed.append(name)
    print("stopped:" + ",".join(stopped))
    print("already_off:" + ",".join(already_off))
    print("failed:" + ",".join(failed))
    return 1 if failed else 0


def command_status() -> int:
    for name in ["gateway", "backend", "weixin_direct", "self_monitor", "wechat_bridge"]:
        snapshot = _service_ready_details(name)
        extra = ""
        if name == "self_monitor":
            monitor = snapshot.get("monitor") or {}
            extra = f" stale={monitor.get('stale')} last_run_at={monitor.get('last_run_at') or ''}"
        elif "health_ok" in snapshot:
            extra = f" health_ok={snapshot.get('health_ok')}"
        print(f"{name}={'on' if snapshot['running'] else 'off'} ready={snapshot.get('ready')} pids={snapshot['pids']}{extra}")
    return 0


def command_doctor() -> int:
    payload = {
        "status": [_service_ready_details(name) for name in ["gateway", "backend", "weixin_direct", "self_monitor", "wechat_bridge"]],
        "backend_diagnostics": fetch_backend_diagnostics(),
    }
    print(json.dumps(payload, ensure_ascii=True, indent=2))
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="cmd", required=True)

    start = sub.add_parser("start")
    start.add_argument("target", choices=["core", "wechat", "weixin", "monitor", "local_weixin", "full"])

    stop = sub.add_parser("stop")
    stop.add_argument("target", choices=["core", "wechat", "weixin", "monitor", "all"])

    sub.add_parser("status")
    sub.add_parser("doctor")

    args = parser.parse_args()
    if args.cmd == "start":
        return command_start(args.target)
    if args.cmd == "stop":
        return command_stop(args.target)
    if args.cmd == "doctor":
        return command_doctor()
    return command_status()


if __name__ == "__main__":
    raise SystemExit(main())
