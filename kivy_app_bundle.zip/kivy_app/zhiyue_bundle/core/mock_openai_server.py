from __future__ import annotations

import json
import os
import time
from flask import Flask, jsonify, request


app = Flask(__name__)


def _json_reply(obj: dict) -> str:
    return json.dumps(obj, ensure_ascii=False)


@app.get("/v1/models")
@app.get("/models")
def models():
    now = int(time.time())
    return jsonify(
        {
            "object": "list",
            "data": [
                {"id": "mock-chat", "object": "model", "created": now, "owned_by": "mock"},
                {"id": "mock-json", "object": "model", "created": now, "owned_by": "mock"},
            ],
        }
    )


@app.post("/v1/chat/completions")
@app.post("/chat/completions")
def chat_completions():
    data = request.json or {}
    model = data.get("model") or "mock-chat"
    messages = data.get("messages") or []
    last_user = ""
    for msg in reversed(messages):
        if isinstance(msg, dict) and msg.get("role") == "user":
            last_user = str(msg.get("content") or "")
            break

    response_format = data.get("response_format") if isinstance(data, dict) else None
    if isinstance(response_format, dict):
        kind = str(response_format.get("type") or "").lower()
        if kind in {"json_object", "json_schema"}:
            # Return a minimal JSON object to keep parsers moving.
            content = _json_reply({"ok": True, "note": "mock-json", "echo": last_user[:80]})
        else:
            content = f"(mock:{model}) {last_user[:140]}"
    else:
        content = f"(mock:{model}) {last_user[:140]}"

    created = int(time.time())
    return jsonify(
        {
            "id": f"chatcmpl-mock-{created}",
            "object": "chat.completion",
            "created": created,
            "model": model,
            "choices": [{"index": 0, "message": {"role": "assistant", "content": content}, "finish_reason": "stop"}],
            "usage": {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
        }
    )


if __name__ == "__main__":
    host = os.environ.get("MOCK_HOST", "127.0.0.1")
    port = int(os.environ.get("MOCK_PORT", "9010"))
    app.run(host=host, port=port, debug=False, threaded=True)

