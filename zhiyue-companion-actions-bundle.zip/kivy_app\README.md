# 独立 APK（Kivy + python-for-android / Buildozer）

这套工程会打出一个 **独立 APK**：
- App 内置一个前台服务，在手机上启动本机 `127.0.0.1:8908` 的 OpenAI 兼容接口
- Tavo 直接连 localhost
- App 自带一个配置 UI（上游 API、main/state/review 三模型、mobile/sync token）
- 支持一键导出备份（导出 zip 并调系统分享，便于换机/备份）
- 支持一键导入备份（从系统文件选择器选 zip 恢复）

## 1. 准备（Windows + WSL2 推荐）
Buildozer 基本需要 Linux 环境。推荐：
- Windows 11 + WSL2 Ubuntu 22.04/24.04
- 或者直接一台 Linux 机器

## 2. 准备 bundle（把项目核心代码拷进 APK 工程）
在 Windows 上先执行：

```powershell
powershell -ExecutionPolicy Bypass -File E:\chat-project\deploy\android_apk\kivy_app\prepare_bundle.ps1
```

它会把 `core/ modules/ config/` 拷贝到 `deploy/android_apk/kivy_app/zhiyue_bundle/`。

## 3. Build（在 WSL/Linux）
进入工程目录：

```bash
cd /mnt/e/chat-project/deploy/android_apk/kivy_app
```

安装 buildozer（示例）：

```bash
sudo apt update
sudo apt install -y python3 python3-pip git openjdk-17-jdk unzip zip
python3 -m pip install --upgrade pip
python3 -m pip install buildozer cython
```

第一次构建：

```bash
buildozer -v android debug
```

输出 APK 一般在 `bin/` 目录。

## 4. 小米/MIUI 适配建议（必做）
MIUI 对后台很凶，想“免维护/不掉线”，建议：
- 给 App 开启“自启动”
- 省电策略设为“不限制”
- 最近任务里把 App 锁住
- 允许通知（前台服务需要常驻通知才能更稳）

## 5. Tavo 配置
- Base URL: `http://127.0.0.1:8908/v1`
- API Key: 填你在 App 里设置的 `Mobile Token`
- Model: `zhiyue`
