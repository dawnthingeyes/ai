# MIUI Setup

After installing the APK:

1. Allow notifications.
2. Enable autostart.
3. Set battery optimization to "No restrictions".
4. Lock the app in recents.
5. If you use an external client, start the app first, then connect to `127.0.0.1:8908`.

If the chat screen says the API is not configured, go to Settings and fill in:

- protocol
- base URL
- API key
- main / state / review model names

