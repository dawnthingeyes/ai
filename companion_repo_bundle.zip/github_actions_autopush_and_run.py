from __future__ import annotations

import argparse
import base64
import json
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path


API_ROOT = "https://api.github.com"


def gh(method: str, url: str, token: str, *, data: bytes | None = None, extra_headers: dict[str, str] | None = None) -> tuple[int, bytes]:
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {token}",
        "X-GitHub-Api-Version": "2022-11-28",
        "User-Agent": "companion-uploader",
    }
    if extra_headers:
        headers.update(extra_headers)
    req = urllib.request.Request(url, data=data, headers=headers, method=method.upper())
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            return int(getattr(resp, "status", 200) or 200), resp.read()
    except urllib.error.HTTPError as exc:
        return int(exc.code), exc.read()


def jget(token: str, url: str) -> dict:
    code, raw = gh("GET", url, token)
    if code >= 400:
        raise RuntimeError(f"{url} -> HTTP {code}: {raw[:240].decode('utf-8', 'replace')}")
    return json.loads(raw.decode("utf-8") or "{}")


def repo_exists(owner: str, repo: str, token: str) -> bool:
    code, _ = gh("GET", f"{API_ROOT}/repos/{owner}/{repo}", token)
    if code == 404:
        return False
    if code >= 400:
        raise RuntimeError(f"GET repo failed: HTTP {code}")
    return True


def create_repo(token: str, name: str, private: bool) -> None:
    payload = {
        "name": name,
        "private": bool(private),
        "auto_init": False,
        "has_issues": False,
        "has_projects": False,
        "has_wiki": False,
    }
    code, raw = gh("POST", f"{API_ROOT}/user/repos", token, data=json.dumps(payload).encode("utf-8"), extra_headers={"Content-Type": "application/json"})
    if code not in {201}:
        raise RuntimeError(f"Create repo failed: HTTP {code}: {raw[:240].decode('utf-8', 'replace')}")


def put_file(owner: str, repo: str, token: str, branch: str, path: str, content: bytes, message: str) -> None:
    sha = None
    code, raw = gh("GET", f"{API_ROOT}/repos/{owner}/{repo}/contents/{urllib.parse.quote(path)}?ref={urllib.parse.quote(branch)}", token)
    if code == 200:
        data = json.loads(raw.decode("utf-8") or "{}")
        sha = data.get("sha")
    elif code != 404:
        raise RuntimeError(f"GET contents failed for {path}: HTTP {code}: {raw[:180].decode('utf-8', 'replace')}")
    payload = {
        "message": message,
        "content": base64.b64encode(content).decode("ascii"),
        "branch": branch,
    }
    if sha:
        payload["sha"] = sha
    code, raw = gh(
        "PUT",
        f"{API_ROOT}/repos/{owner}/{repo}/contents/{urllib.parse.quote(path)}",
        token,
        data=json.dumps(payload).encode("utf-8"),
        extra_headers={"Content-Type": "application/json"},
    )
    if code not in {200, 201}:
        raise RuntimeError(f"PUT contents failed for {path}: HTTP {code}: {raw[:240].decode('utf-8', 'replace')}")


def dispatch_workflow(owner: str, repo: str, token: str, workflow_file: str, ref: str) -> None:
    url = f"{API_ROOT}/repos/{owner}/{repo}/actions/workflows/{workflow_file}/dispatches"
    code, raw = gh("POST", url, token, data=json.dumps({"ref": ref}).encode("utf-8"), extra_headers={"Content-Type": "application/json"})
    if code != 204:
        raise RuntimeError(f"Dispatch failed: HTTP {code}: {raw[:240].decode('utf-8', 'replace')}")


def list_runs(owner: str, repo: str, token: str, workflow_file: str, branch: str) -> list[dict]:
    url = f"{API_ROOT}/repos/{owner}/{repo}/actions/workflows/{workflow_file}/runs?event=workflow_dispatch&branch={urllib.parse.quote(branch)}&per_page=10"
    data = jget(token, url)
    return data.get("workflow_runs") if isinstance(data.get("workflow_runs"), list) else []


def get_run(owner: str, repo: str, token: str, run_id: int) -> dict:
    return jget(token, f"{API_ROOT}/repos/{owner}/{repo}/actions/runs/{run_id}")


def list_artifacts(owner: str, repo: str, token: str, run_id: int) -> list[dict]:
    data = jget(token, f"{API_ROOT}/repos/{owner}/{repo}/actions/runs/{run_id}/artifacts")
    return data.get("artifacts") if isinstance(data.get("artifacts"), list) else []


def download_artifact(owner: str, repo: str, token: str, artifact_id: int, out_zip: Path) -> None:
    code, raw = gh("GET", f"{API_ROOT}/repos/{owner}/{repo}/actions/artifacts/{artifact_id}/zip", token)
    if code >= 400:
        raise RuntimeError(f"Download artifact failed: HTTP {code}: {raw[:240].decode('utf-8', 'replace')}")
    out_zip.parent.mkdir(parents=True, exist_ok=True)
    out_zip.write_bytes(raw)


def extract_apk(artifact_zip: Path, out_dir: Path) -> Path:
    with zipfile.ZipFile(artifact_zip, "r") as zf:
        names = [n for n in zf.namelist() if n.lower().endswith(".apk")]
        if not names:
            raise RuntimeError("Artifact zip contains no APK")
        apk_name = names[0]
        out_dir.mkdir(parents=True, exist_ok=True)
        out_path = out_dir / Path(apk_name).name
        out_path.write_bytes(zf.read(apk_name))
        return out_path


def main() -> int:
    ap = argparse.ArgumentParser(description="Upload the minimal repo bundle to GitHub, dispatch Actions, and optionally download APK.")
    ap.add_argument("--owner", required=True)
    ap.add_argument("--repo", required=True)
    ap.add_argument("--token", default=os.environ.get("GITHUB_TOKEN", ""))
    ap.add_argument("--branch", default="")
    ap.add_argument("--create-repo", action="store_true")
    ap.add_argument("--public", action="store_true")
    ap.add_argument("--wait", action="store_true")
    ap.add_argument("--bundle-zip", default=str(Path(__file__).resolve().parent / "companion_repo_bundle.zip"))
    ap.add_argument("--workflow", default=".github/workflows/build_android_apk.yml")
    args = ap.parse_args()

    token = str(args.token or "").strip()
    if not token:
        print("Missing token; pass --token or set GITHUB_TOKEN", file=sys.stderr)
        return 2

    owner = str(args.owner).strip()
    repo = str(args.repo).strip()
    branch = str(args.branch).strip()
    if not branch:
        repo_info = jget(token, f"{API_ROOT}/repos/{owner}/{repo}") if repo_exists(owner, repo, token) else {}
        branch = str(repo_info.get("default_branch") or "main").strip() or "main"
    if not repo_exists(owner, repo, token):
        if not args.create_repo:
            print(f"Repo {owner}/{repo} does not exist. Use --create-repo.", file=sys.stderr)
            return 2
        user = jget(token, f"{API_ROOT}/user").get("login")
        if str(user or "").lower() != owner.lower():
            print(f"Token belongs to {user}, not {owner}; cannot auto-create.", file=sys.stderr)
            return 2
        create_repo(token, repo, private=not args.public)
        time.sleep(2)

    bundle = Path(args.bundle_zip).resolve()
    if not bundle.is_file():
        print(f"Missing bundle zip: {bundle}", file=sys.stderr)
        return 2
    workflow = Path(args.workflow).resolve()
    if not workflow.is_file():
        print(f"Missing workflow file: {workflow}", file=sys.stderr)
        return 2

    print("Uploading workflow...")
    put_file(owner, repo, token, branch, ".github/workflows/build_android_apk.yml", workflow.read_bytes(), "Add Android APK workflow")
    print("Uploading bundle...")
    put_file(owner, repo, token, branch, "companion_repo_bundle.zip", bundle.read_bytes(), "Add companion repo bundle")
    print("Dispatching workflow...")
    dispatch_workflow(owner, repo, token, "build_android_apk.yml", branch)
    print("OK: workflow dispatched")

    if args.wait:
        deadline = time.time() + 40 * 60
        run_id = None
        while time.time() < deadline:
            runs = list_runs(owner, repo, token, "build_android_apk.yml", branch)
            if runs:
                run_id = int(runs[0]["id"])
                break
            time.sleep(3)
        if not run_id:
            raise RuntimeError("Timed out waiting for workflow run")
        while time.time() < deadline:
            run = get_run(owner, repo, token, run_id)
            if str(run.get("status") or "") == "completed":
                if str(run.get("conclusion") or "") != "success":
                    raise RuntimeError(f"Workflow finished with {run.get('conclusion')}")
                break
            time.sleep(8)
        artifacts = list_artifacts(owner, repo, token, run_id)
        artifact = next((item for item in artifacts if str(item.get("name") or "") == "companion-apk"), None)
        if not artifact:
            raise RuntimeError("No companion-apk artifact found")
        out_zip = Path(__file__).resolve().parent / f"companion-apk-run{run_id}.zip"
        download_artifact(owner, repo, token, int(artifact["id"]), out_zip)
        apk = extract_apk(out_zip, Path(__file__).resolve().parent)
        print(f"OK: APK downloaded -> {apk}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

