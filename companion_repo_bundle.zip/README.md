# Companion APK

这是一个面向安卓小米手机的独立 APK。

当前包含：
- 三角色 API 配置：`main / state / review`
- 私人聊天
- 主动聊天
- 存档与成长
- 朋友圈式动态和生图分享
- 设备感知与基础控制

使用方式：
1. 打开 `设置`
2. 填 `协议`、`Base URL`、`API Key` 和三个角色模型
3. 点 `测试三角色`
4. 回到聊天页开始使用

MIUI 建议：
- 开启通知权限
- 允许后台运行
- 把电池优化设为不限制
- 如需稳定主动消息，建议加入最近任务锁定

打包：
- GitHub Actions 会生成 `companion-apk`
- 工作流：`.github/workflows/build_android_apk.yml`
