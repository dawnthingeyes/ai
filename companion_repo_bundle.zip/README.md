# Companion APK

Android APK for a private local chat app.

What it provides:

- Chat UI on the phone
- Three independently configurable roles: main / state / review
- Separate profiles (saved archives)
- Clean initial profile with no prefilled persona or memory
- Local OpenAI-compatible API on `127.0.0.1:8908`

Files:

- `main.py` - mobile UI
- `service.py` - local API server
- `app_core.py` - shared config, profile, memory, provider logic
- `buildozer.spec` - Android packaging config
- `smoke_test_service.py` - local smoke test

Local smoke test:

```powershell
python mock_openai_server.py
python smoke_test_service.py
```

MIUI tips:

- Allow notifications
- Enable autostart
- Disable battery optimization
- Lock the app in recent tasks
- Start the app before connecting external clients to `127.0.0.1:8908`

