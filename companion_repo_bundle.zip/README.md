# Companion APK

这是一个面向安卓手机的本地独立 APK。

当前定位：

- 以 API 模式运行，不依赖本地 GGUF 主模型
- 支持三角色配置：main / state / review
- 支持分存档
- 支持主动聊天和后台推送
- 支持本机访问 Token
- 支持基础设备动作入口

主要文件：

- `main.py` - 手机 UI
- `service.py` - 本地 API 服务
- `app_core.py` - 配置、存档、记忆、主动节奏、provider 逻辑
- `buildozer.spec` - 打包配置
- `smoke_test_service.py` - 本地冒烟测试

快速说明：

- 先在“设置”里填 API Base URL、Key 和三个模型名
- 再点“测试三角色”
- 通过后即可聊天、主动聊、分存档
- 设备页可打开应用、回桌面和进入系统设置

MIUI 建议：

- 打开通知权限
- 开启自启动
- 关闭电池优化
- 把应用锁进最近任务
