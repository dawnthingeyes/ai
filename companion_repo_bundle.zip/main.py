from __future__ import annotations

import json
import threading
from pathlib import Path

from kivy.app import App
from kivy.clock import Clock
from kivy.core.text import LabelBase
from kivy.core.window import Window
from kivy.graphics import Color, RoundedRectangle
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.scrollview import ScrollView
from kivy.uix.screenmanager import NoTransition, Screen, ScreenManager
from kivy.uix.spinner import Spinner
from kivy.uix.togglebutton import ToggleButton
from kivy.uix.textinput import TextInput
from kivy.uix.switch import Switch
from kivy.uix.widget import Widget

import app_core as core
import device_actions as device
import service as backend_service


FONT_NAME = "/system/fonts/NotoSansCJK-Regular.ttc"
LabelBase.register(
    name="Roboto",
    fn_regular=FONT_NAME,
    fn_bold=FONT_NAME,
    fn_italic=FONT_NAME,
    fn_bolditalic=FONT_NAME,
)


BG = (0.965, 0.968, 0.975, 1)
CARD = (1, 1, 1, 1)
PRIMARY = (0.17, 0.48, 0.88, 1)
PRIMARY_DARK = (0.11, 0.31, 0.58, 1)
USER_BG = (0.81, 0.95, 0.81, 1)
BOT_BG = (1, 1, 1, 1)
TEXT = (0.12, 0.12, 0.14, 1)
MUTED = (0.45, 0.48, 0.53, 1)
SOFT_BORDER = (0.86, 0.87, 0.9, 1)
WARN = (0.95, 0.71, 0.27, 1)


def _as_bool(value) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes", "on", "y"}


def _request_android_permissions():
    try:
        from android.permissions import Permission, request_permissions  # type: ignore

        request_permissions(
            [
                Permission.POST_NOTIFICATIONS,
            ]
        )
    except Exception:
        pass


def _open_android_settings(kind: str):
    return device.perform_device_action(kind, dry_run=False).get("ok", False)


def _short(text: str, limit: int = 64) -> str:
    clean = " ".join(str(text or "").split())
    return clean if len(clean) <= limit else clean[: limit - 1] + "…"


def _spawn_async(fn, on_ok, on_err=None):
    def runner():
        try:
            result = fn()
        except Exception as exc:
            if on_err:
                Clock.schedule_once(lambda *_: on_err(exc))
            return
        Clock.schedule_once(lambda *_: on_ok(result))

    threading.Thread(target=runner, daemon=True).start()


class Card(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.padding = dp(12)
        self.spacing = dp(8)
        self.canvas.before.clear()
        with self.canvas.before:
            Color(*CARD)
            self._bg = RoundedRectangle(pos=self.pos, size=self.size, radius=[dp(18), dp(18), dp(18), dp(18)])
        self.bind(pos=self._sync_bg, size=self._sync_bg)

    def _sync_bg(self, *_):
        self._bg.pos = self.pos
        self._bg.size = self.size


class Field(BoxLayout):
    def __init__(self, label_text: str, widget: Widget, *, hint: str = "", **kwargs):
        super().__init__(orientation="vertical", size_hint_y=None, **kwargs)
        self.spacing = dp(6)
        self.padding = (0, 0)
        title = Label(text=label_text, size_hint_y=None, height=dp(18), color=MUTED, halign="left", valign="middle")
        title.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        self.label = title
        self.add_widget(title)
        self.add_widget(widget)
        if hint:
            tip = Label(text=hint, size_hint_y=None, height=dp(16), font_size="12sp", color=(0.55, 0.58, 0.63, 1), halign="left", valign="middle")
            tip.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
            self.add_widget(tip)
        self.widget = widget
        self.bind(minimum_height=self.setter("height"))


class Bubble(Card):
    def __init__(self, text: str, *, role: str = "assistant", width_hint: float = 0.78, **kwargs):
        super().__init__(orientation="vertical", size_hint=(None, None), **kwargs)
        self.role = role
        self.width_hint = width_hint
        self.size_hint_x = None
        self.padding = (dp(12), dp(10))
        self.spacing = 0
        self.width = max(dp(220), Window.width * width_hint)
        color = USER_BG if role == "user" else BOT_BG
        with self.canvas.before:
            Color(*color)
            self._bg = RoundedRectangle(pos=self.pos, size=self.size, radius=[dp(18), dp(18), dp(18), dp(18)])
        self.bind(pos=self._sync_bg, size=self._sync_bg)
        self.label = Label(
            text=text,
            markup=False,
            color=TEXT,
            size_hint=(1, None),
            halign="left",
            valign="top",
            font_size="15sp",
        )
        self.label.bind(texture_size=self._on_texture)
        self.add_widget(self.label)
        self.bind(width=self._sync_width)
        Clock.schedule_once(lambda *_: self._sync_width())

    def _sync_bg(self, *_):
        self._bg.pos = self.pos
        self._bg.size = self.size

    def _sync_width(self, *_):
        self.label.text_size = (max(dp(140), self.width - dp(24)), None)
        self.label.texture_update()

    def _on_texture(self, *_):
        self.height = self.label.texture_size[1] + dp(24)


class MessageRow(BoxLayout):
    def __init__(self, bubble: Bubble, *, role: str):
        super().__init__(orientation="horizontal", size_hint_y=None, height=bubble.height, spacing=dp(8))
        self.padding = (0, 0)
        self.bubble = bubble
        if role == "user":
            self.add_widget(Widget())
            self.add_widget(bubble)
        else:
            self.add_widget(bubble)
            self.add_widget(Widget())
        bubble.bind(height=self._sync_height)

    def _sync_height(self, *_):
        self.height = self.bubble.height


class ChatScreen(Screen):
    def __init__(self, app: "CompanionApp", **kwargs):
        super().__init__(name="chat", **kwargs)
        self.app = app
        root = BoxLayout(orientation="vertical", padding=dp(12), spacing=dp(10))
        self.banner = Label(text="", size_hint_y=None, height=0, color=(0.58, 0.17, 0.17, 1), halign="left", valign="middle")
        self.banner.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        root.add_widget(self.banner)

        header = Card(orientation="horizontal", size_hint_y=None, height=dp(76))
        left = BoxLayout(orientation="vertical", spacing=dp(2))
        title = Label(text="Companion", size_hint_y=None, height=dp(26), font_size="20sp", color=PRIMARY_DARK, halign="left", valign="middle")
        title.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        self.status_label = Label(text="未连接", size_hint_y=None, height=dp(18), font_size="12sp", color=MUTED, halign="left", valign="middle")
        self.status_label.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        left.add_widget(title)
        left.add_widget(self.status_label)
        header.add_widget(left)

        right = BoxLayout(orientation="vertical", size_hint_x=None, width=dp(182), spacing=dp(6))
        self.profile_hint = Label(text=f"当前：{core.DEFAULT_PROFILE}", size_hint_y=None, height=dp(18), font_size="12sp", color=MUTED, halign="right", valign="middle")
        self.profile_hint.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        self.refresh_button = Button(text="刷新", size_hint_y=None, height=dp(34), background_normal="", background_color=(0.92, 0.93, 0.95, 1), color=TEXT)
        self.refresh_button.bind(on_release=lambda *_: self.app.reload_all())
        right.add_widget(self.profile_hint)
        right.add_widget(self.refresh_button)
        header.add_widget(right)
        root.add_widget(header)

        self.history_wrap = ScrollView(do_scroll_x=False, bar_width=dp(4))
        self.history = BoxLayout(orientation="vertical", size_hint_y=None, spacing=dp(10), padding=(0, 0, 0, dp(10)))
        self.history.bind(minimum_height=self.history.setter("height"))
        self.history_wrap.add_widget(self.history)
        root.add_widget(self.history_wrap)

        composer = Card(orientation="vertical", size_hint_y=None, height=dp(132))
        self.input = TextInput(
            hint_text="输入消息，按发送即可",
            multiline=True,
            size_hint_y=None,
            height=dp(76),
            background_normal="",
            background_active="",
            background_color=(1, 1, 1, 0),
            foreground_color=TEXT,
            cursor_color=PRIMARY_DARK,
            padding=(dp(10), dp(10)),
        )
        composer.add_widget(self.input)
        actions = BoxLayout(size_hint_y=None, height=dp(40), spacing=dp(8))
        self.proactive_button = Button(text="主动聊", background_normal="", background_color=(0.92, 0.93, 0.95, 1), color=TEXT)
        self.proactive_button.bind(on_release=lambda *_: self.app.send_proactive_chat())
        self.send_button = Button(text="发送", background_normal="", background_color=PRIMARY, color=(1, 1, 1, 1))
        self.send_button.bind(on_release=lambda *_: self.app.send_chat())
        self.clear_button = Button(text="清空输入", background_normal="", background_color=(0.92, 0.93, 0.95, 1), color=TEXT)
        self.clear_button.bind(on_release=lambda *_: setattr(self.input, "text", ""))
        actions.add_widget(self.clear_button)
        actions.add_widget(self.proactive_button)
        actions.add_widget(self.send_button)
        composer.add_widget(actions)
        root.add_widget(composer)
        self.add_widget(root)

    def set_banner(self, text: str = "", visible: bool = False):
        self.banner.text = text
        self.banner.height = dp(26) if visible else 0

    def set_status(self, text: str):
        self.status_label.text = text

    def set_profiles(self, values: list[str], current: str):
        self.profile_hint.text = f"当前：{current or core.DEFAULT_PROFILE}"

    def clear_history(self):
        self.history.clear_widgets()

    def add_row(self, role: str, text: str):
        bubble = Bubble(text, role=role)
        row = MessageRow(bubble, role=role)
        self.history.add_widget(row)
        Clock.schedule_once(lambda *_: setattr(self.history_wrap, "scroll_y", 0), 0.05)


class ProfilesScreen(Screen):
    def __init__(self, app: "CompanionApp", **kwargs):
        super().__init__(name="profiles", **kwargs)
        self.app = app
        root = BoxLayout(orientation="vertical", padding=dp(12), spacing=dp(10))
        header = Card(orientation="horizontal", size_hint_y=None, height=dp(68))
        label_box = BoxLayout(orientation="vertical", spacing=dp(2))
        title = Label(text="存档", size_hint_y=None, height=dp(24), font_size="20sp", color=PRIMARY_DARK, halign="left", valign="middle")
        title.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        subtitle = Label(text="每个存档独立保存聊天、记忆和偏好", size_hint_y=None, height=dp(18), font_size="12sp", color=MUTED, halign="left", valign="middle")
        subtitle.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        label_box.add_widget(title)
        label_box.add_widget(subtitle)
        header.add_widget(label_box)
        create_btn = Button(text="+ 新建", size_hint_x=None, width=dp(96), background_normal="", background_color=PRIMARY, color=(1, 1, 1, 1))
        create_btn.bind(on_release=lambda *_: self.app.prompt_new_profile())
        header.add_widget(create_btn)
        root.add_widget(header)
        controls = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(8))
        clear_btn = Button(text="清空当前", background_normal="", background_color=(0.98, 0.92, 0.78, 1), color=TEXT)
        clear_btn.bind(on_release=lambda *_: self.app.prompt_clear_profile())
        delete_btn = Button(text="删除当前", background_normal="", background_color=(0.98, 0.85, 0.85, 1), color=TEXT)
        delete_btn.bind(on_release=lambda *_: self.app.prompt_delete_profile())
        controls.add_widget(clear_btn)
        controls.add_widget(delete_btn)
        root.add_widget(controls)
        self.scroll = ScrollView(do_scroll_x=False)
        self.list_box = BoxLayout(orientation="vertical", size_hint_y=None, spacing=dp(10), padding=(0, 0, 0, dp(10)))
        self.list_box.bind(minimum_height=self.list_box.setter("height"))
        self.scroll.add_widget(self.list_box)
        root.add_widget(self.scroll)
        self.add_widget(root)

    def rebuild(self, items: list[dict[str, object]], active: str):
        self.list_box.clear_widgets()
        if not items:
            empty = Card(size_hint_y=None, height=dp(88))
            label = Label(text="暂无存档，先创建一个吧。", color=MUTED)
            empty.add_widget(label)
            self.list_box.add_widget(empty)
            return
        for item in items:
            name = str(item.get("name") or "")
            display = str(item.get("display_name") or name)
            summary = _short(str(item.get("summary") or ""), 90)
            count = int(item.get("item_count") or 0)
            card = Button(
                text=f"{display}\n{name} · {count} 条记录\n{summary or '空白存档'}",
                halign="left",
                valign="middle",
                background_normal="",
                background_color=(0.92, 0.95, 0.99, 1) if name == active else CARD,
                color=TEXT,
                size_hint_y=None,
                height=dp(96),
            )
            card.bind(size=lambda inst, *_: setattr(inst, "text_size", (inst.width - dp(22), None)))
            card.bind(on_release=lambda inst, n=name: self.app.switch_profile(n))
            self.list_box.add_widget(card)


class DeviceScreen(Screen):
    def __init__(self, app: "CompanionApp", **kwargs):
        super().__init__(name="device", **kwargs)
        self.app = app
        root = BoxLayout(orientation="vertical", padding=dp(12), spacing=dp(10))
        header = Card(orientation="vertical", size_hint_y=None, height=dp(82))
        title = Label(text="设备设置", size_hint_y=None, height=dp(24), font_size="20sp", color=PRIMARY_DARK, halign="left", valign="middle")
        title.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        subtitle = Label(text="把小米常用权限入口集中在这里。", size_hint_y=None, height=dp(18), font_size="12sp", color=MUTED, halign="left", valign="middle")
        subtitle.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        header.add_widget(title)
        header.add_widget(subtitle)
        root.add_widget(header)
        self.status = Label(text="", size_hint_y=None, height=dp(20), color=MUTED, halign="left", valign="middle")
        self.status.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        root.add_widget(self.status)
        scroll = ScrollView(do_scroll_x=False)
        box = BoxLayout(orientation="vertical", size_hint_y=None, spacing=dp(10))
        box.bind(minimum_height=box.setter("height"))
        scroll.add_widget(box)
        root.add_widget(scroll)

        package_card = Card(orientation="vertical", size_hint_y=None, height=dp(132))
        pkg_label = Label(text="目标应用包名", size_hint_y=None, height=dp(20), color=PRIMARY_DARK, halign="left", valign="middle")
        pkg_label.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        self.package_input = TextInput(
            hint_text="例如 com.tencent.mm",
            multiline=False,
            size_hint_y=None,
            height=dp(42),
            background_normal="",
            background_active="",
            background_color=(1, 1, 1, 1),
            foreground_color=TEXT,
            cursor_color=PRIMARY_DARK,
            padding=(dp(10), dp(10)),
        )
        launch_btn = Button(text="打开应用", size_hint_y=None, height=dp(34), background_normal="", background_color=PRIMARY, color=(1, 1, 1, 1))
        launch_btn.bind(on_release=lambda *_args: self._open("app", self.package_input.text.strip()))
        detail_btn = Button(text="应用详情", size_hint_y=None, height=dp(34), background_normal="", background_color=(0.92, 0.93, 0.95, 1), color=TEXT)
        detail_btn.bind(on_release=lambda *_args: self._open("app_details", self.package_input.text.strip()))
        package_card.add_widget(pkg_label)
        package_card.add_widget(self.package_input)
        package_actions = BoxLayout(size_hint_y=None, height=dp(36), spacing=dp(8))
        package_actions.add_widget(detail_btn)
        package_actions.add_widget(launch_btn)
        package_card.add_widget(package_actions)
        box.add_widget(package_card)

        actions = (
            ("回到桌面", "home", "快速回到桌面"),
            ("打开应用详情", "app_details", "查看权限、自启动和通知开关"),
            ("打开通知设置", "notifications", "确认通知没有被系统拦截"),
            ("打开电池优化", "battery", "MIUI 上建议把它设为不优化"),
            ("打开无障碍设置", "accessibility", "如果后续接手机控制，需要在这里启用"),
        )
        for title_text, kind, hint in actions:
            card = Card(orientation="vertical", size_hint_y=None, height=dp(86))
            label = Label(text=title_text, size_hint_y=None, height=dp(24), font_size="16sp", color=PRIMARY_DARK, halign="left", valign="middle")
            label.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
            desc = Label(text=hint, size_hint_y=None, height=dp(18), font_size="12sp", color=MUTED, halign="left", valign="middle")
            desc.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
            btn = Button(text="打开", size_hint_y=None, height=dp(34), background_normal="", background_color=PRIMARY, color=(1, 1, 1, 1))
            btn.bind(on_release=lambda *_args, k=kind: self._open(k, self.package_input.text.strip()))
            card.add_widget(label)
            card.add_widget(desc)
            card.add_widget(btn)
            box.add_widget(card)

        tip = Card(size_hint_y=None, height=dp(118))
        tip.add_widget(Label(text="说明：现在支持打开应用、回到桌面和进入系统设置。真正的自动操作还需要无障碍动作层，后面可以继续补。", color=MUTED))
        root.add_widget(tip)
        self.add_widget(root)

    def _open(self, kind: str, target: str = ""):
        result = device.perform_device_action(kind, target=target, dry_run=False)
        if result.get("ok"):
            self.status.text = f"已执行：{result.get('detail') or kind}"
            self.status.color = PRIMARY_DARK
        else:
            self.status.text = f"失败：{result.get('error') or 'unknown'}"
            self.status.color = WARN


class SettingsScreen(Screen):
    def __init__(self, app: "CompanionApp", **kwargs):
        super().__init__(name="settings", **kwargs)
        self.app = app
        self.inputs: dict[str, Widget] = {}
        root = BoxLayout(orientation="vertical", padding=dp(12), spacing=dp(10))
        header = Card(orientation="vertical", size_hint_y=None, height=dp(82))
        title = Label(text="API 设置", size_hint_y=None, height=dp(24), font_size="20sp", color=PRIMARY_DARK, halign="left", valign="middle")
        title.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        subtitle = Label(text="三角色独立配置，默认尽量中性，维护模型只做纠偏。", size_hint_y=None, height=dp(18), font_size="12sp", color=MUTED, halign="left", valign="middle")
        subtitle.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        header.add_widget(title)
        header.add_widget(subtitle)
        root.add_widget(header)
        self.scroll = ScrollView(do_scroll_x=False)
        self.form = BoxLayout(orientation="vertical", size_hint_y=None, spacing=dp(10))
        self.form.bind(minimum_height=self.form.setter("height"))
        self.scroll.add_widget(self.form)
        root.add_widget(self.scroll)
        buttons = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(8))
        self.save_button = Button(text="保存", background_normal="", background_color=PRIMARY, color=(1, 1, 1, 1))
        self.save_button.bind(on_release=lambda *_: self.app.save_provider_settings())
        self.test_button = Button(text="测试三个角色", background_normal="", background_color=(0.92, 0.93, 0.95, 1), color=TEXT)
        self.test_button.bind(on_release=lambda *_: self.app.test_provider())
        buttons.add_widget(self.test_button)
        buttons.add_widget(self.save_button)
        root.add_widget(buttons)
        self.status = Label(text="", size_hint_y=None, height=dp(20), color=MUTED)
        root.add_widget(self.status)
        self.add_widget(root)
        self._build_form()

    def _build_form(self):
        self.form.clear_widgets()
        self.inputs.clear()
        cfg = self.app.provider_cfg

        def add_text(key: str, label: str, hint: str = "", multiline: bool = False, height: int = 44):
            initial = str(cfg.get(key) or "")
            if key == "headers_json":
                initial = json.dumps(cfg.get("headers") or {}, ensure_ascii=False, indent=2)
            elif key == "proactive_quiet_hours_json":
                initial = json.dumps(cfg.get("proactive_quiet_hours") or {"start": 23, "end": 8}, ensure_ascii=False, indent=2)
            ti = TextInput(
                text=initial,
                multiline=multiline,
                size_hint_y=None,
                height=dp(height),
                background_normal="",
                background_active="",
                background_color=(1, 1, 1, 1),
                foreground_color=TEXT,
                cursor_color=PRIMARY_DARK,
                padding=(dp(10), dp(10)),
            )
            self.inputs[key] = ti
            self.form.add_widget(Field(label, ti, hint=hint))
            return ti

        def add_spinner(key: str, label: str, values: list[str]):
            sp = Spinner(
                text=str(cfg.get(key) or values[0]),
                values=values,
                size_hint_y=None,
                height=dp(44),
                background_normal="",
                background_down="",
                background_color=PRIMARY,
                color=(1, 1, 1, 1),
            )
            self.inputs[key] = sp
            self.form.add_widget(Field(label, sp))
            return sp

        def add_switch(key: str, label: str, hint: str = ""):
            sw = Switch(active=_as_bool(cfg.get(key, True)), size_hint_y=None, height=dp(40))
            self.inputs[key] = sw
            self.form.add_widget(Field(label, sw, hint=hint))
            return sw

        add_spinner("protocol", "协议", ["openai_compatible", "anthropic", "gemini"])
        add_text("base_url", "全局 Base URL", hint="例如 https://api.example.com/v1")
        add_text("api_key", "全局 API Key", hint="保存后只存本机私有目录", height=44)
        add_text("headers_json", "全局额外 Headers(JSON)", multiline=True, height=96, hint='例如 {"X-Trace":"1"}')
        add_text("mobile_token", "本机访问 Token", hint="给 Tavo 或其他本机客户端使用")
        add_text("sync_token", "同步 Token", hint="给跨设备记忆同步预留")
        add_text("main_model", "主模型", hint="聊天主链")
        add_text("state_model", "状态模型", hint="状态 / 记忆编译")
        add_text("review_model", "维护模型", hint="仅在必要时纠偏")
        add_switch("proactive_enabled", "主动聊天开关", hint="关闭后只保留手动聊天")
        add_switch("proactive_background_enabled", "后台主动推送", hint="关闭后不会后台自动找你")
        add_switch("proactive_push_notifications", "通知推送", hint="关闭后只记录，不弹系统通知")
        add_text("proactive_check_interval_seconds", "后台检查间隔(秒)", hint="默认 120")
        add_text("proactive_min_idle_seconds", "最小空闲时长(秒)", hint="默认 900")
        add_text("proactive_min_gap_seconds", "主动最小间隔(秒)", hint="默认 1800")
        add_text("proactive_quiet_hours_json", "静默时段(JSON)", hint='例如 {"start":23,"end":8}', multiline=True, height=96)

        for role in ("main", "state", "review"):
            section = Card(orientation="vertical", size_hint_y=None, height=dp(290))
            section.add_widget(Label(text=f"{role.upper()} 角色覆盖", size_hint_y=None, height=dp(20), color=PRIMARY_DARK, halign="left", valign="middle"))
            section.bind(minimum_height=section.setter("height"))
            role_cfg = (cfg.get("roles") or {}).get(role, {}) if isinstance(cfg.get("roles"), dict) else {}
            role_fields = (
                ("model_override", "模型覆盖", "可留空，默认继承上方主模型名"),
                ("base_url", "Base URL", "单独地址时填写"),
                ("api_key", "API Key", "单独密钥时填写"),
                ("headers_json", "Headers(JSON)", "\u4f8b\u5982 {\"X-Trace\":\"1\"}"),
            )
            for suffix, title, hint in role_fields:
                key = f"{role}_{suffix}"
                if suffix == "headers_json":
                    initial = json.dumps(role_cfg.get("headers") or {}, ensure_ascii=False, indent=2)
                    ti = TextInput(
                        text=initial,
                        multiline=True,
                        size_hint_y=None,
                        height=dp(88),
                        background_normal="",
                        background_active="",
                        background_color=(1, 1, 1, 1),
                        foreground_color=TEXT,
                        cursor_color=PRIMARY_DARK,
                        padding=(dp(10), dp(10)),
                    )
                else:
                    initial = str(role_cfg.get("model") or role_cfg.get(suffix) or "")
                    ti = TextInput(
                        text=initial,
                        multiline=False,
                        size_hint_y=None,
                        height=dp(42),
                        background_normal="",
                        background_active="",
                        background_color=(1, 1, 1, 1),
                        foreground_color=TEXT,
                        cursor_color=PRIMARY_DARK,
                        padding=(dp(10), dp(10)),
                    )
                self.inputs[key] = ti
                section.add_widget(Field(f"{ {'main': '主', 'state': '状态', 'review': '维护'}.get(role, role) } {title}", ti, hint=hint))
            self.form.add_widget(section)

    def refresh_from_config(self, cfg: dict[str, object]):
        self.app.provider_cfg = cfg
        self._build_form()

    def set_status(self, text: str, color=MUTED):
        self.status.text = text
        self.status.color = color


class CompanionApp(App):
    def build(self):
        self.home = core.ensure_tree()
        self.provider_cfg = core.load_provider_config(self.home["root"])
        self.ui_state = core.load_ui_state(self.home["root"])
        self.active_profile = self.ui_state.get("active_profile") or core.DEFAULT_PROFILE
        self._profile_text_lock = False
        self._profile_stamp = ""
        self._profile_history_size = 0
        if not core.profile_state_path(self.active_profile, self.home["root"]).is_file():
            core.ensure_profile(self.active_profile, base_dir=self.home["root"])
        Window.clearcolor = BG
        Window.softinput_mode = "below_target"

        root = BoxLayout(orientation="vertical")
        self.topbar = Card(orientation="horizontal", size_hint_y=None, height=dp(66))
        title_box = BoxLayout(orientation="vertical", spacing=dp(2))
        title = Label(text="伴聊", size_hint_y=None, height=dp(24), font_size="20sp", color=PRIMARY_DARK, halign="left", valign="middle")
        title.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        subtitle = Label(text="本地聊天 · 存档 · API 设置", size_hint_y=None, height=dp(16), font_size="12sp", color=MUTED, halign="left", valign="middle")
        subtitle.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        title_box.add_widget(title)
        title_box.add_widget(subtitle)
        self.topbar.add_widget(title_box)
        self.profile_chip = Spinner(
            text=self.active_profile,
            values=[self.active_profile],
            size_hint_x=None,
            width=dp(170),
            size_hint_y=None,
            height=dp(38),
            background_normal="",
            background_down="",
            background_color=PRIMARY,
            color=(1, 1, 1, 1),
        )
        self.profile_chip.bind(text=self._on_profile_spinner)
        self.topbar.add_widget(self.profile_chip)
        root.add_widget(self.topbar)

        self.sm = ScreenManager(transition=NoTransition())
        self.chat_screen = ChatScreen(self)
        self.profiles_screen = ProfilesScreen(self)
        self.settings_screen = SettingsScreen(self)
        self.device_screen = DeviceScreen(self)
        self.sm.add_widget(self.chat_screen)
        self.sm.add_widget(self.profiles_screen)
        self.sm.add_widget(self.settings_screen)
        self.sm.add_widget(self.device_screen)
        root.add_widget(self.sm)

        self.nav = Card(orientation="horizontal", size_hint_y=None, height=dp(62))
        self.nav_buttons: dict[str, ToggleButton] = {}
        for name, label in (("chat", "聊天"), ("profiles", "存档"), ("settings", "设置"), ("device", "设备")):
            btn = ToggleButton(
                text=label,
                group="nav",
                background_normal="",
                background_down="",
                background_color=(0.92, 0.93, 0.95, 1),
                color=TEXT,
            )
            btn.bind(on_release=lambda inst, n=name: self.switch_screen(n))
            self.nav.add_widget(btn)
            self.nav_buttons[name] = btn
        root.add_widget(self.nav)

        Clock.schedule_once(lambda *_: (backend_service.ensure_running(), self.reload_all()), 0)
        Clock.schedule_interval(self._poll_profile_updates, 5)
        return root

    def on_start(self):
        _request_android_permissions(); backend_service.ensure_running(); self.switch_screen(self.ui_state.get("screen") or "chat", persist=False)
        self.switch_screen(self.ui_state.get("screen") or "chat", persist=False)

    def current_profile_state(self):
        return core.load_profile(self.active_profile, self.home["root"])

    def switch_screen(self, screen_name: str, *, persist: bool = True):
        if screen_name not in {"chat", "profiles", "settings", "device"}:
            screen_name = "chat"
        self.sm.current = screen_name
        for name, btn in self.nav_buttons.items():
            btn.state = "down" if name == screen_name else "normal"
            btn.background_color = PRIMARY if name == screen_name else (0.92, 0.93, 0.95, 1)
            btn.color = (1, 1, 1, 1) if name == screen_name else TEXT
        if persist:
            self.ui_state = core.save_ui_state({"active_profile": self.active_profile, "screen": screen_name}, self.home["root"])

    def _on_profile_spinner(self, *_):
        if self._profile_text_lock:
            return
        self.switch_profile(self.profile_chip.text)

    def _set_profile_chip_text(self, value: str):
        self._profile_text_lock = True
        try:
            self.profile_chip.text = value
        finally:
            self._profile_text_lock = False

    def switch_profile(self, profile_name: str):
        profile_name = core.safe_name(profile_name)
        if not core.profile_state_path(profile_name, self.home["root"]).is_file():
            core.ensure_profile(profile_name, base_dir=self.home["root"])
        self.active_profile = profile_name
        self.profile_chip.values = [item["name"] for item in core.list_profiles(self.home["root"])]
        self._set_profile_chip_text(profile_name)
        core.save_ui_state({"active_profile": profile_name, "screen": self.sm.current}, self.home["root"])
        self.reload_chat()
        self.reload_profiles()

    def reload_all(self):
        self.provider_cfg = core.load_provider_config(self.home["root"])
        self.ui_state = core.load_ui_state(self.home["root"])
        self.profile_chip.values = [item["name"] for item in core.list_profiles(self.home["root"])]
        if self.active_profile not in self.profile_chip.values:
            self.active_profile = self.ui_state.get("active_profile") or core.DEFAULT_PROFILE
        self._set_profile_chip_text(self.active_profile)
        self.reload_chat()
        self.reload_profiles()
        self.settings_screen.refresh_from_config(self.provider_cfg)
        self._update_status()

    def _update_status(self):
        cfg = self.provider_cfg
        configured = core.provider_ready(cfg)
        active = self.active_profile
        decision = core.proactive_decision(active, base_dir=self.home["root"], provider_cfg=cfg)
        if decision.get("eligible"):
            proactive_hint = "可主动聊"
        else:
            proactive_hint = f"原因：{decision.get('reason') or '冷却中'}"
            if decision.get("next_check_in_seconds"):
                proactive_hint += f" · {core.format_duration(decision.get('next_check_in_seconds'))} 后再看"
        self.chat_screen.set_status(f"存档：{active} · {'已配置 API' if configured else '尚未配置 API'} · {proactive_hint}")
        self.chat_screen.set_banner("" if configured else "先到【设置】填好 API 和模型，再回来聊天。", visible=not configured)

    def reload_chat(self):
        self.chat_screen.clear_history()
        profile = core.load_profile(self.active_profile, self.home["root"])
        for msg in profile.get("history") or []:
            role = str(msg.get("role") or "assistant")
            content = str(msg.get("content") or "").strip()
            if content:
                self.chat_screen.add_row(role, content)
        if not profile.get("history"):
            self.chat_screen.add_row("assistant", "这里会显示聊天记录。先在下面输入一句话试试。")
        self.chat_screen.set_profiles([item["name"] for item in core.list_profiles(self.home["root"])], self.active_profile)
        self._profile_stamp = str(profile.get("updated_at") or "")
        self._profile_history_size = len(profile.get("history") or [])
        self._update_status()

    def _poll_profile_updates(self, *_):
        profile = core.load_profile(self.active_profile, self.home["root"])
        stamp = str(profile.get("updated_at") or "")
        history_size = len(profile.get("history") or [])
        if stamp != self._profile_stamp or history_size != self._profile_history_size:
            self.reload_chat()
            self.reload_profiles()

    def reload_profiles(self):
        items = core.list_profiles(self.home["root"])
        self.profiles_screen.rebuild(items, self.active_profile)
        self.chat_screen.set_profiles([item["name"] for item in items], self.active_profile)

    def prompt_new_profile(self):
        input_box = BoxLayout(orientation="vertical", spacing=dp(10), padding=dp(10))
        name_input = TextInput(hint_text="存档名", multiline=False, size_hint_y=None, height=dp(42))
        display_input = TextInput(hint_text="显示名（可选）", multiline=False, size_hint_y=None, height=dp(42))
        input_box.add_widget(name_input)
        input_box.add_widget(display_input)
        popup = Popup(title="新建存档", content=input_box, size_hint=(0.9, 0.38))

        buttons = BoxLayout(size_hint_y=None, height=dp(42), spacing=dp(8))
        cancel = Button(text="取消", background_normal="", background_color=(0.92, 0.93, 0.95, 1), color=TEXT)
        ok = Button(text="创建", background_normal="", background_color=PRIMARY, color=(1, 1, 1, 1))
        buttons.add_widget(cancel)
        buttons.add_widget(ok)
        input_box.add_widget(buttons)
        cancel.bind(on_release=lambda *_: popup.dismiss())

        def _create(*_):
            name = name_input.text.strip() or core.DEFAULT_PROFILE
            display = display_input.text.strip() or name
            core.ensure_profile(name, base_dir=self.home["root"], display_name=display)
            self.switch_profile(name)
            popup.dismiss()

        ok.bind(on_release=_create)
        popup.open()

    def clear_current_profile(self):
        profile = core.default_profile_state(self.active_profile)
        profile["display_name"] = core.load_profile(self.active_profile, self.home["root"]).get("display_name") or self.active_profile
        core.save_profile(self.active_profile, profile, self.home["root"])
        self.reload_chat()
        self.reload_profiles()

    def delete_current_profile(self):
        if self.active_profile == core.DEFAULT_PROFILE:
            self.clear_current_profile()
            return
        core.delete_profile(self.active_profile, self.home["root"])
        self.active_profile = core.DEFAULT_PROFILE
        core.ensure_profile(core.DEFAULT_PROFILE, base_dir=self.home["root"])
        core.save_ui_state({"active_profile": self.active_profile, "screen": self.sm.current}, self.home["root"])
        self.reload_all()

    def _confirm(self, title: str, text: str, on_yes):
        body = BoxLayout(orientation="vertical", spacing=dp(10), padding=dp(12))
        body.add_widget(Label(text=text, color=TEXT))
        buttons = BoxLayout(size_hint_y=None, height=dp(42), spacing=dp(8))
        no_btn = Button(text="取消", background_normal="", background_color=(0.92, 0.93, 0.95, 1), color=TEXT)
        yes_btn = Button(text="确认", background_normal="", background_color=PRIMARY, color=(1, 1, 1, 1))
        buttons.add_widget(no_btn)
        buttons.add_widget(yes_btn)
        body.add_widget(buttons)
        popup = Popup(title=title, content=body, size_hint=(0.9, 0.32))
        no_btn.bind(on_release=lambda *_: popup.dismiss())
        yes_btn.bind(on_release=lambda *_: (popup.dismiss(), on_yes()))
        popup.open()

    def prompt_clear_profile(self):
        self._confirm("清空存档", f"确认清空「{self.active_profile}」的聊天和记忆吗？", self.clear_current_profile)

    def prompt_delete_profile(self):
        self._confirm("删除存档", f"确认删除「{self.active_profile}」吗？默认存档会保留。", self.delete_current_profile)

    def save_provider_settings(self):
        settings = json.loads(json.dumps(self.provider_cfg, ensure_ascii=False))
        for key, widget in self.settings_screen.inputs.items():
            value = getattr(widget, "text", "")
            if key == "headers_json":
                try:
                    settings["headers"] = json.loads(value) if value.strip() else {}
                except Exception as exc:
                    self.settings_screen.set_status(f"Headers JSON 解析失败：{exc}", WARN)
                    return
                continue
            if key == "proactive_quiet_hours_json":
                try:
                    settings["proactive_quiet_hours"] = json.loads(value) if value.strip() else {"start": 23, "end": 8}
                except Exception as exc:
                    self.settings_screen.set_status(f"静默时段 JSON 解析失败：{exc}", WARN)
                    return
                continue
            if isinstance(widget, Switch):
                settings[key] = bool(widget.active)
                continue
            if key.endswith("_headers_json"):
                role = key.split("_", 1)[0]
                try:
                    settings.setdefault("roles", {}).setdefault(role, {})
                    settings["roles"][role]["headers"] = json.loads(value) if value.strip() else {}
                except Exception as exc:
                    self.settings_screen.set_status(f"{role} Headers JSON 解析失败：{exc}", WARN)
                    return
                continue
            if key.endswith("_model_override"):
                role = key.split("_", 1)[0]
                settings.setdefault("roles", {}).setdefault(role, {})
                settings["roles"][role]["model"] = value.strip()
                continue
            if key in {"proactive_check_interval_seconds", "proactive_min_idle_seconds", "proactive_min_gap_seconds"}:
                try:
                    settings[key] = int(str(value).strip() or "0")
                except Exception as exc:
                    self.settings_screen.set_status(f"{key} 解析失败：{exc}", WARN)
                    return
                continue
            if key.endswith("_base_url") or key.endswith("_api_key"):
                role, suffix = key.split("_", 1)
                settings.setdefault("roles", {}).setdefault(role, {})
                settings["roles"][role][suffix] = value.strip()
                continue
            settings[key] = value.strip() if isinstance(value, str) else value
        if isinstance(settings.get("protocol"), str):
            settings["protocol"] = settings["protocol"].strip().lower()
        if "roles" not in settings:
            settings["roles"] = {}
        if "headers" not in settings:
            settings["headers"] = {}
        cfg = core.save_provider_config(settings, self.home["root"])
        self.provider_cfg = cfg
        self.settings_screen.set_status("已保存", PRIMARY_DARK)
        self._update_status()

    def test_provider(self):
        self.save_provider_settings()
        cfg = self.provider_cfg
        roles = ["main", "state", "review"]
        self.settings_screen.set_status("正在测试三个角色...", MUTED)

        def worker():
            results = {role: core.provider_health(cfg, role) for role in roles}
            return results

        def ok(results):
            lines = []
            all_ok = True
            for role, result in results.items():
                ok_flag = bool(result.get("ok"))
                all_ok = all_ok and ok_flag
                lines.append(f"{ {'main': '主', 'state': '状态', 'review': '维护'}.get(role, role) }: {'通过' if ok_flag else '失败'}")
            self.settings_screen.set_status(" · ".join(lines), PRIMARY if all_ok else WARN)

        def err(exc):
            self.settings_screen.set_status(f"测试失败：{exc}", WARN)

        _spawn_async(worker, ok, err)

    def send_chat(self):
        text = self.chat_screen.input.text.strip()
        if not text:
            return
        if not core.provider_ready(self.provider_cfg):
            self.chat_screen.add_row("assistant", "先到【设置】填好 API 和模型，再来聊天。")
            return
        self.chat_screen.input.text = ""
        self.chat_screen.add_row("user", text)
        self.chat_screen.add_row("assistant", "正在回复…")
        self.chat_screen.send_button.disabled = True
        self.chat_screen.send_button.text = "发送中"
        profile_name = self.active_profile
        cfg = self.provider_cfg

        def worker():
            return core.chat_turn(text, profile_name, base_dir=self.home["root"], provider_cfg=cfg)

        def ok(result):
            if self.chat_screen.history.children:
                self.chat_screen.history.remove_widget(self.chat_screen.history.children[0])
            reply = str(result.get("reply") or "").strip() or "（空回复）"
            self.chat_screen.add_row("assistant", reply)
            self.chat_screen.send_button.disabled = False
            self.chat_screen.send_button.text = "发送"
            self.reload_profiles()
            self._update_status()

        def err(exc):
            if self.chat_screen.history.children:
                self.chat_screen.history.remove_widget(self.chat_screen.history.children[0])
            self.chat_screen.add_row("assistant", f"出错：{exc}")
            self.chat_screen.send_button.disabled = False
            self.chat_screen.send_button.text = "发送"

        _spawn_async(worker, ok, err)

    def send_proactive_chat(self):
        if not core.provider_ready(self.provider_cfg):
            self.chat_screen.add_row("assistant", "先到【设置】填好 API 和模型，再点主动聊。")
            return
        self.chat_screen.add_row("assistant", "正在主动找话题…")
        self.chat_screen.send_button.disabled = True
        self.chat_screen.proactive_button.disabled = True
        self.chat_screen.send_button.text = "生成中"
        profile_name = self.active_profile
        cfg = self.provider_cfg

        def worker():
            return core.proactive_turn(profile_name, base_dir=self.home["root"], provider_cfg=cfg)

        def ok(result):
            if self.chat_screen.history.children:
                self.chat_screen.history.remove_widget(self.chat_screen.history.children[0])
            reply = str(result.get("reply") or "").strip() or "（空回复）"
            self.chat_screen.add_row("assistant", reply)
            self.chat_screen.send_button.disabled = False
            self.chat_screen.proactive_button.disabled = False
            self.chat_screen.send_button.text = "发送"
            self.reload_profiles()
            self._update_status()

        def err(exc):
            if self.chat_screen.history.children:
                self.chat_screen.history.remove_widget(self.chat_screen.history.children[0])
            self.chat_screen.add_row("assistant", f"出错：{exc}")
            self.chat_screen.send_button.disabled = False
            self.chat_screen.proactive_button.disabled = False
            self.chat_screen.send_button.text = "发送"

        _spawn_async(worker, ok, err)


if __name__ == "__main__":
    CompanionApp().run()
