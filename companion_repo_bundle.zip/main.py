from __future__ import annotations

import json
import threading
from pathlib import Path

from kivy.app import App
from kivy.clock import Clock
from kivy.core.text import LabelBase
from kivy.core.window import Window
from kivy.graphics import Color, Ellipse, RoundedRectangle
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.image import Image
from kivy.uix.scrollview import ScrollView
from kivy.uix.screenmanager import NoTransition, Screen, ScreenManager
from kivy.uix.spinner import Spinner
from kivy.uix.togglebutton import ToggleButton
from kivy.uix.textinput import TextInput
from kivy.uix.switch import Switch
from kivy.uix.widget import Widget

import app_core as core
import device_actions as device
import service as backend_service


APP_DIR = Path(__file__).resolve().parent
FONT_CANDIDATES = (
    APP_DIR / "assets" / "fonts" / "MiSansVF.ttf",
    APP_DIR / "assets" / "fonts" / "NotoSansCJK-Regular.ttc",
    Path("/system/fonts/MiSansVF.ttf"),
    Path("/system/fonts/NotoSansCJK-Regular.ttc"),
)


def _pick_font() -> str:
    for candidate in FONT_CANDIDATES:
        try:
            if candidate.is_file():
                return str(candidate)
        except Exception:
            continue
    return ""


FONT_NAME = _pick_font()
if FONT_NAME:
    LabelBase.register(
        name="Roboto",
        fn_regular=FONT_NAME,
        fn_bold=FONT_NAME,
        fn_italic=FONT_NAME,
        fn_bolditalic=FONT_NAME,
    )

    def _force_font_defaults():
        def wrap(cls):
            original_init = cls.__init__

            def patched_init(self, *args, **kwargs):
                kwargs.setdefault("font_name", FONT_NAME)
                original_init(self, *args, **kwargs)

            cls.__init__ = patched_init  # type: ignore[assignment]

        for widget_cls in (Label, Button, TextInput, Spinner, ToggleButton):
            try:
                wrap(widget_cls)
            except Exception:
                pass

    _force_font_defaults()


BG = (0.965, 0.968, 0.975, 1)
CARD = (1, 1, 1, 1)
PRIMARY = (0.17, 0.48, 0.88, 1)
PRIMARY_DARK = (0.11, 0.31, 0.58, 1)
USER_BG = (0.81, 0.95, 0.81, 1)
BOT_BG = (1, 1, 1, 1)
TEXT = (0.12, 0.12, 0.14, 1)
MUTED = (0.45, 0.48, 0.53, 1)
SOFT_BORDER = (0.86, 0.87, 0.9, 1)
WARN = (0.95, 0.71, 0.27, 1)


def _as_bool(value) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes", "on", "y"}


def _request_android_permissions():
    try:
        from android.permissions import Permission, request_permissions  # type: ignore

        request_permissions(
            [
                Permission.POST_NOTIFICATIONS,
            ]
        )
    except Exception:
        pass


def _open_android_settings(kind: str):
    return device.perform_device_action(kind, dry_run=False).get("ok", False)


def _short(text: str, limit: int = 64) -> str:
    clean = " ".join(str(text or "").split())
    return clean if len(clean) <= limit else clean[: limit - 1] + "…"


def _spawn_async(fn, on_ok, on_err=None):
    def runner():
        try:
            result = fn()
        except Exception as exc:
            if on_err:
                Clock.schedule_once(lambda *_: on_err(exc))
            return
        Clock.schedule_once(lambda *_: on_ok(result))

    threading.Thread(target=runner, daemon=True).start()


def _initials(text: str) -> str:
    clean = "".join(ch for ch in str(text or "").strip() if ch.isalnum() or "\u4e00" <= ch <= "\u9fff")
    if not clean:
        return "C"
    return clean[:2].upper()


def _moment_time(value: str) -> str:
    dt = core.parse_iso_datetime(value)
    if not dt:
        return "刚刚"
    return dt.strftime("%m-%d %H:%M")


def _moment_image_source(base_dir: str | Path, item: dict[str, object]) -> str:
    path = str(item.get("image_path") or "").strip()
    if not path:
        return ""
    resolved = core.resolve_media_path(path, base_dir)
    return str(resolved) if resolved.is_file() else ""


class Backdrop(FloatLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.canvas.before.clear()
        with self.canvas.before:
            Color(0.965, 0.968, 0.975, 1)
            self._base = RoundedRectangle(pos=self.pos, size=self.size, radius=[0, 0, 0, 0])
            Color(0.71, 0.82, 1.0, 0.28)
            self._blob1 = Ellipse(pos=(0, 0), size=(dp(220), dp(220)))
            Color(0.98, 0.84, 0.73, 0.24)
            self._blob2 = Ellipse(pos=(0, 0), size=(dp(180), dp(180)))
            Color(0.86, 0.76, 1.0, 0.16)
            self._blob3 = Ellipse(pos=(0, 0), size=(dp(260), dp(260)))
        self.bind(pos=self._sync, size=self._sync)
        self._sync()

    def _sync(self, *_):
        self._base.pos = self.pos
        self._base.size = self.size
        w, h = self.size
        self._blob1.pos = (w * 0.68, h * 0.86)
        self._blob2.pos = (-dp(34), h * 0.52)
        self._blob3.pos = (w * 0.12, -dp(76))


class AvatarBadge(BoxLayout):
    def __init__(self, text: str = "C", *, color=PRIMARY, size: int = 48, **kwargs):
        super().__init__(size_hint=(None, None), width=dp(size), height=dp(size), **kwargs)
        self.padding = 0
        self.spacing = 0
        self.canvas.before.clear()
        with self.canvas.before:
            Color(*color)
            self._bg = RoundedRectangle(pos=self.pos, size=self.size, radius=[dp(size / 2)] * 4)
        self.bind(pos=self._sync_bg, size=self._sync_bg)
        self.label = Label(text=text, color=(1, 1, 1, 1), font_size="18sp", bold=True)
        self.add_widget(self.label)

    def set_text(self, text: str):
        self.label.text = text

    def _sync_bg(self, *_):
        self._bg.pos = self.pos
        self._bg.size = self.size


class Card(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.padding = dp(12)
        self.spacing = dp(8)
        self.canvas.before.clear()
        with self.canvas.before:
            Color(*CARD)
            self._bg = RoundedRectangle(pos=self.pos, size=self.size, radius=[dp(18), dp(18), dp(18), dp(18)])
        self.bind(pos=self._sync_bg, size=self._sync_bg)

    def _sync_bg(self, *_):
        self._bg.pos = self.pos
        self._bg.size = self.size


class Field(BoxLayout):
    def __init__(self, label_text: str, widget: Widget, *, hint: str = "", **kwargs):
        super().__init__(orientation="vertical", size_hint_y=None, **kwargs)
        self.spacing = dp(6)
        self.padding = (0, 0)
        title = Label(text=label_text, size_hint_y=None, height=dp(18), color=MUTED, halign="left", valign="middle")
        title.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        self.label = title
        self.add_widget(title)
        self.add_widget(widget)
        if hint:
            tip = Label(text=hint, size_hint_y=None, height=dp(16), font_size="12sp", color=(0.55, 0.58, 0.63, 1), halign="left", valign="middle")
            tip.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
            self.add_widget(tip)
        self.widget = widget
        self.bind(minimum_height=self.setter("height"))


class Bubble(Card):
    def __init__(self, text: str, *, role: str = "assistant", width_hint: float = 0.78, **kwargs):
        super().__init__(orientation="vertical", size_hint=(None, None), **kwargs)
        self.role = role
        self.width_hint = width_hint
        self.size_hint_x = None
        self.padding = (dp(12), dp(10))
        self.spacing = 0
        self.width = max(dp(220), Window.width * width_hint)
        color = USER_BG if role == "user" else BOT_BG
        with self.canvas.before:
            Color(*color)
            self._bg = RoundedRectangle(pos=self.pos, size=self.size, radius=[dp(18), dp(18), dp(18), dp(18)])
        self.bind(pos=self._sync_bg, size=self._sync_bg)
        self.label = Label(
            text=text,
            markup=False,
            color=TEXT,
            size_hint=(1, None),
            halign="left",
            valign="top",
            font_size="15sp",
        )
        self.label.bind(texture_size=self._on_texture)
        self.add_widget(self.label)
        self.bind(width=self._sync_width)
        Clock.schedule_once(lambda *_: self._sync_width())

    def _sync_bg(self, *_):
        self._bg.pos = self.pos
        self._bg.size = self.size

    def _sync_width(self, *_):
        self.label.text_size = (max(dp(140), self.width - dp(24)), None)
        self.label.texture_update()

    def _on_texture(self, *_):
        self.height = self.label.texture_size[1] + dp(24)


class MessageRow(BoxLayout):
    def __init__(self, bubble: Bubble, *, role: str):
        super().__init__(orientation="horizontal", size_hint_y=None, height=bubble.height, spacing=dp(8))
        self.padding = (0, 0)
        self.bubble = bubble
        if role == "user":
            self.add_widget(Widget())
            self.add_widget(bubble)
        else:
            self.add_widget(bubble)
            self.add_widget(Widget())
        bubble.bind(height=self._sync_height)

    def _sync_height(self, *_):
        self.height = self.bubble.height


class ModernChatScreen(Screen):
    def __init__(self, app: "CompanionApp", **kwargs):
        super().__init__(name="chat", **kwargs)
        self.app = app
        root = BoxLayout(orientation="vertical", padding=dp(12), spacing=dp(10))
        self.banner = Label(text="", size_hint_y=None, height=0, color=(0.58, 0.17, 0.17, 1), halign="left", valign="middle")
        self.banner.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        root.add_widget(self.banner)

        header = Card(orientation="horizontal", size_hint_y=None, height=dp(78))
        left = BoxLayout(orientation="horizontal", spacing=dp(10))
        self.avatar = AvatarBadge(_initials(app.active_profile), size=48)
        left.add_widget(self.avatar)
        title_box = BoxLayout(orientation="vertical", spacing=dp(2))
        title = Label(text="Companion", size_hint_y=None, height=dp(26), font_size="20sp", color=PRIMARY_DARK, halign="left", valign="middle")
        title.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        self.status_label = Label(text="未连接", size_hint_y=None, height=dp(18), font_size="12sp", color=MUTED, halign="left", valign="middle")
        self.status_label.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        title_box.add_widget(title)
        title_box.add_widget(self.status_label)
        left.add_widget(title_box)
        header.add_widget(left)

        right = BoxLayout(orientation="vertical", size_hint_x=None, width=dp(182), spacing=dp(6))
        self.profile_hint = Label(text=f"当前：{core.DEFAULT_PROFILE}", size_hint_y=None, height=dp(18), font_size="12sp", color=MUTED, halign="right", valign="middle")
        self.profile_hint.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        self.refresh_button = Button(text="刷新", size_hint_y=None, height=dp(34), background_normal="", background_color=(0.92, 0.93, 0.95, 1), color=TEXT)
        self.refresh_button.bind(on_release=lambda *_: self.app.reload_all())
        right.add_widget(self.profile_hint)
        right.add_widget(self.refresh_button)
        header.add_widget(right)
        root.add_widget(header)

        self.history_wrap = ScrollView(do_scroll_x=False, bar_width=dp(4))
        self.history = BoxLayout(orientation="vertical", size_hint_y=None, spacing=dp(10), padding=(0, 0, 0, dp(10)))
        self.history.bind(minimum_height=self.history.setter("height"))
        self.history_wrap.add_widget(self.history)
        root.add_widget(self.history_wrap)

        composer = Card(orientation="vertical", size_hint_y=None, height=dp(132))
        self.input = TextInput(
            hint_text="输入消息，按发送即可",
            multiline=True,
            size_hint_y=None,
            height=dp(76),
            background_normal="",
            background_active="",
            background_color=(1, 1, 1, 0),
            foreground_color=TEXT,
            cursor_color=PRIMARY_DARK,
            padding=(dp(10), dp(10)),
        )
        composer.add_widget(self.input)
        actions = BoxLayout(size_hint_y=None, height=dp(40), spacing=dp(8))
        self.send_button = Button(text="发送", background_normal="", background_color=PRIMARY, color=(1, 1, 1, 1))
        self.send_button.bind(on_release=lambda *_: self.app.send_chat())
        self.clear_button = Button(text="清空输入", background_normal="", background_color=(0.92, 0.93, 0.95, 1), color=TEXT)
        self.clear_button.bind(on_release=lambda *_: setattr(self.input, "text", ""))
        actions.add_widget(self.clear_button)
        actions.add_widget(self.send_button)
        composer.add_widget(actions)
        root.add_widget(composer)
        self.add_widget(root)

    def set_banner(self, text: str = "", visible: bool = False):
        self.banner.text = text
        self.banner.height = dp(26) if visible else 0

    def set_status(self, text: str):
        self.status_label.text = text

    def set_profiles(self, values: list[str], current: str):
        current = current or core.DEFAULT_PROFILE
        self.profile_hint.text = f"当前：{current}"
        self.avatar.set_text(_initials(current))

    def clear_history(self):
        self.history.clear_widgets()

    def add_row(self, role: str, text: str):
        bubble = Bubble(text, role=role)
        row = MessageRow(bubble, role=role)
        self.history.add_widget(row)
        Clock.schedule_once(lambda *_: setattr(self.history_wrap, "scroll_y", 0), 0.05)




class ProfilesScreen(Screen):
    def __init__(self, app: "CompanionApp", **kwargs):
        super().__init__(name="profiles", **kwargs)
        self.app = app
        self.items: list[dict[str, object]] = []
        self.active_profile = core.DEFAULT_PROFILE

        root = BoxLayout(orientation="vertical", padding=dp(12), spacing=dp(10))
        header = Card(orientation="horizontal", size_hint_y=None, height=dp(82))
        left = BoxLayout(orientation="horizontal", spacing=dp(10))
        self.avatar = AvatarBadge("存", size=48, color=(0.45, 0.54, 0.84, 1))
        left.add_widget(self.avatar)
        title_box = BoxLayout(orientation="vertical", spacing=dp(2))
        title = Label(text="存档与成长", size_hint_y=None, height=dp(26), font_size="20sp", color=PRIMARY_DARK, halign="left", valign="middle")
        title.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        subtitle = Label(text="每个存档就是一个独立角色。这里管理记忆、摘要和生命周期。", size_hint_y=None, height=dp(18), font_size="12sp", color=MUTED, halign="left", valign="middle")
        subtitle.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        title_box.add_widget(title)
        title_box.add_widget(subtitle)
        left.add_widget(title_box)
        header.add_widget(left)
        self.new_button = Button(text="新建存档", size_hint_x=None, width=dp(110), background_normal="", background_color=PRIMARY, color=(1, 1, 1, 1))
        self.new_button.bind(on_release=lambda *_: self.app.prompt_new_profile())
        header.add_widget(self.new_button)
        root.add_widget(header)

        self.current_card = Card(orientation="vertical", size_hint_y=None, height=dp(182))
        self.current_title = Label(text="当前存档", size_hint_y=None, height=dp(20), color=MUTED, halign="left", valign="middle")
        self.current_title.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        self.current_name = Label(text="", size_hint_y=None, height=dp(24), font_size="18sp", color=PRIMARY_DARK, halign="left", valign="middle")
        self.current_name.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        self.current_summary = Label(text="", color=TEXT, halign="left", valign="top", size_hint_y=None)
        self.current_summary.bind(width=lambda inst, *_: setattr(inst, "text_size", (max(dp(220), inst.width - dp(6)), None)))
        self.current_summary.bind(texture_size=lambda inst, *_: setattr(inst, "height", inst.texture_size[1] + dp(8)))
        self.current_card.add_widget(self.current_title)
        self.current_card.add_widget(self.current_name)
        self.current_card.add_widget(self.current_summary)

        self.stats_row = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(8))
        self.current_card.add_widget(self.stats_row)

        actions = BoxLayout(size_hint_y=None, height=dp(40), spacing=dp(8))
        self.reset_button = Button(text="重置记忆", background_normal="", background_color=(0.93, 0.90, 0.80, 1), color=TEXT)
        self.reset_button.bind(on_release=lambda *_: self.app.confirm_reset_memory())
        self.clear_button = Button(text="清空聊天", background_normal="", background_color=(0.92, 0.93, 0.95, 1), color=TEXT)
        self.clear_button.bind(on_release=lambda *_: self.app.confirm_clear_history())
        self.delete_button = Button(text="删除存档", background_normal="", background_color=(0.96, 0.87, 0.87, 1), color=TEXT)
        self.delete_button.bind(on_release=lambda *_: self.app.confirm_delete_profile())
        actions.add_widget(self.reset_button)
        actions.add_widget(self.clear_button)
        actions.add_widget(self.delete_button)
        self.current_card.add_widget(actions)
        root.add_widget(self.current_card)

        self.scroll = ScrollView(do_scroll_x=False, bar_width=dp(4))
        self.list_box = BoxLayout(orientation="vertical", size_hint_y=None, spacing=dp(10), padding=(0, 0, 0, dp(10)))
        self.list_box.bind(minimum_height=self.list_box.setter("height"))
        self.scroll.add_widget(self.list_box)
        root.add_widget(self.scroll)

        self.status = Label(text="", size_hint_y=None, height=dp(20), color=MUTED, halign="left", valign="middle")
        self.status.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        root.add_widget(self.status)
        self.add_widget(root)

    def _stat_tile(self, title: str, value: str) -> Card:
        tile = Card(orientation="vertical", size_hint_x=1)
        tile.padding = (dp(8), dp(8))
        t = Label(text=title, size_hint_y=None, height=dp(16), font_size="11sp", color=MUTED, halign="left", valign="middle")
        t.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        v = Label(text=value, color=TEXT, halign="left", valign="middle")
        v.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        tile.add_widget(t)
        tile.add_widget(v)
        tile.value_label = v  # type: ignore[attr-defined]
        return tile

    def _profile_card(self, item: dict[str, object], active: str) -> Button:
        name = str(item.get("name") or "")
        display = str(item.get("display_name") or name)
        summary = _short(str(item.get("summary") or "暂无摘要"), 120)
        stats = core.profile_memory_stats(item)
        active_style = (0.92, 0.95, 0.99, 1) if name == active else CARD
        text = f"{display}\n{name} · 记忆 {stats['memories']} · 动态 {stats['moments']} · 聊天 {stats['history']}\n{summary}"
        card = Button(
            text=text,
            halign="left",
            valign="middle",
            background_normal="",
            background_color=active_style,
            color=TEXT,
            size_hint_y=None,
            height=dp(108),
        )
        card.bind(size=lambda inst, *_: setattr(inst, "text_size", (inst.width - dp(20), None)))
        card.bind(on_release=lambda *_: self.app.switch_profile(name))
        return card

    def rebuild(self, items: list[dict[str, object]], active: str):
        self.items = list(items or [])
        self.active_profile = active or core.DEFAULT_PROFILE
        self.list_box.clear_widgets()
        self._refresh_current()
        if not self.items:
            empty = Card(size_hint_y=None, height=dp(92))
            empty.add_widget(Label(text="暂时没有存档。先新建一个角色吧。", color=MUTED))
            self.list_box.add_widget(empty)
            self.status.text = "暂无存档"
            return
        for item in self.items:
            self.list_box.add_widget(self._profile_card(item, self.active_profile))
        self.status.text = f"共 {len(self.items)} 个存档 · 当前 {self.active_profile}"

    def _refresh_current(self):
        current = None
        for item in self.items:
            if str(item.get("name") or "") == self.active_profile:
                current = item
                break
        if current is None:
            current = core.load_profile(self.active_profile, self.app.home["root"])
        display = str(current.get("display_name") or current.get("name") or self.active_profile)
        stats = core.profile_memory_stats(current)
        self.avatar.set_text(_initials(display))
        self.current_title.text = "当前存档"
        self.current_name.text = f"{display} · {current.get('name') or self.active_profile}"
        summary = str(current.get("summary") or "").strip() or "还没有形成摘要。继续聊天后会自动累积。"
        self.current_summary.text = summary
        self.stats_row.clear_widgets()
        for title, value in (
            ("记忆", str(stats["memories"])),
            ("事实", str(stats["facts"])),
            ("偏好", str(stats["preferences"])),
            ("边界", str(stats["boundaries"])),
        ):
            self.stats_row.add_widget(self._stat_tile(title, value))


class MomentsScreen(Screen):
    def __init__(self, app: "CompanionApp", **kwargs):
        super().__init__(name="moments", **kwargs)
        self.app = app
        root = BoxLayout(orientation="vertical", padding=dp(12), spacing=dp(10))

        header = Card(orientation="horizontal", size_hint_y=None, height=dp(82))
        left = BoxLayout(orientation="horizontal", spacing=dp(10))
        self.avatar = AvatarBadge("动", size=48, color=(0.39, 0.57, 0.95, 1))
        left.add_widget(self.avatar)
        title_box = BoxLayout(orientation="vertical", spacing=dp(2))
        title = Label(text="朋友圈", size_hint_y=None, height=dp(26), font_size="20sp", color=PRIMARY_DARK, halign="left", valign="middle")
        title.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        subtitle = Label(text="记录文字、生图和生活片段", size_hint_y=None, height=dp(18), font_size="12sp", color=MUTED, halign="left", valign="middle")
        subtitle.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        title_box.add_widget(title)
        title_box.add_widget(subtitle)
        left.add_widget(title_box)
        header.add_widget(left)

        right = BoxLayout(orientation="vertical", size_hint_x=None, width=dp(122), spacing=dp(6))
        self.refresh_button = Button(text="刷新", size_hint_y=None, height=dp(34), background_normal="", background_color=(0.92, 0.93, 0.95, 1), color=TEXT)
        self.refresh_button.bind(on_release=lambda *_: self.refresh())
        self.new_button = Button(text="发动态", size_hint_y=None, height=dp(34), background_normal="", background_color=PRIMARY, color=(1, 1, 1, 1))
        self.new_button.bind(on_release=lambda *_: self.publish())
        right.add_widget(self.refresh_button)
        right.add_widget(self.new_button)
        header.add_widget(right)
        root.add_widget(header)

        text_card = Card(orientation="vertical", size_hint_y=None, height=dp(196))
        self.moment_input = TextInput(
            hint_text="写一点今天想分享的事",
            multiline=True,
            size_hint_y=None,
            height=dp(88),
            background_normal="",
            background_active="",
            background_color=(1, 1, 1, 0),
            foreground_color=TEXT,
            cursor_color=PRIMARY_DARK,
            padding=(dp(10), dp(10)),
        )
        text_card.add_widget(self.moment_input)
        row = BoxLayout(size_hint_y=None, height=dp(42), spacing=dp(8))
        self.visibility = Spinner(text="好友可见", values=["好友可见", "仅自己"], size_hint_x=0.42, background_normal="", background_down="", background_color=(0.92, 0.93, 0.95, 1), color=TEXT)
        self.mood = Spinner(text="平静", values=["平静", "开心", "温柔", "低落"], size_hint_x=0.32, background_normal="", background_down="", background_color=(0.92, 0.93, 0.95, 1), color=TEXT)
        self.save_button = Button(text="发布", background_normal="", background_color=PRIMARY, color=(1, 1, 1, 1))
        self.save_button.bind(on_release=lambda *_: self.publish())
        row.add_widget(self.visibility)
        row.add_widget(self.mood)
        row.add_widget(self.save_button)
        text_card.add_widget(row)
        root.add_widget(text_card)

        image_card = Card(orientation="vertical", size_hint_y=None, height=dp(222))
        image_title = Label(text="生图分享", size_hint_y=None, height=dp(22), color=PRIMARY_DARK, halign="left", valign="middle")
        image_title.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        image_card.add_widget(image_title)
        self.image_prompt = TextInput(
            hint_text="描述想生成的画面，留空则按当前状态自动补全",
            multiline=True,
            size_hint_y=None,
            height=dp(84),
            background_normal="",
            background_active="",
            background_color=(1, 1, 1, 0),
            foreground_color=TEXT,
            cursor_color=PRIMARY_DARK,
            padding=(dp(10), dp(10)),
        )
        image_card.add_widget(self.image_prompt)
        image_row = BoxLayout(size_hint_y=None, height=dp(42), spacing=dp(8))
        self.image_style = Spinner(text="朋友圈感", values=["朋友圈感", "电影感", "清新", "夜景", "日常"], size_hint_x=0.34, background_normal="", background_down="", background_color=(0.92, 0.93, 0.95, 1), color=TEXT)
        self.image_only = Button(text="只生成", background_normal="", background_color=(0.92, 0.93, 0.95, 1), color=TEXT)
        self.image_only.bind(on_release=lambda *_: self.generate_image(publish=False))
        self.image_publish = Button(text="生成并发动态", background_normal="", background_color=(0.18, 0.53, 0.88, 1), color=(1, 1, 1, 1))
        self.image_publish.bind(on_release=lambda *_: self.generate_image(publish=True))
        image_row.add_widget(self.image_style)
        image_row.add_widget(self.image_only)
        image_row.add_widget(self.image_publish)
        image_card.add_widget(image_row)
        root.add_widget(image_card)

        self.status = Label(text="", size_hint_y=None, height=dp(18), color=MUTED, halign="left", valign="middle")
        self.status.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        root.add_widget(self.status)

        self.scroll = ScrollView(do_scroll_x=False, bar_width=dp(4))
        self.feed = BoxLayout(orientation="vertical", size_hint_y=None, spacing=dp(10), padding=(0, 0, 0, dp(10)))
        self.feed.bind(minimum_height=self.feed.setter("height"))
        self.scroll.add_widget(self.feed)
        root.add_widget(self.scroll)
        self.add_widget(root)

    def refresh(self):
        profile = core.load_profile(self.app.active_profile, self.app.home["root"])
        self.avatar.set_text(_initials(str(profile.get("display_name") or profile.get("name") or self.app.active_profile)))
        items = core.list_moments(profile, limit=50)
        self.feed.clear_widgets()
        if not items:
            empty = Card(size_hint_y=None, height=dp(96))
            empty.add_widget(Label(text="还没有动态，先发一条吧。", color=MUTED))
            self.feed.add_widget(empty)
            self.status.text = f"当前存档：{self.app.active_profile} · 0 条动态"
            return
        for item in items:
            has_image = bool(str(item.get("image_path") or "").strip())
            card = Card(orientation="vertical", size_hint_y=None, height=dp(300 if has_image else 188))
            top = BoxLayout(orientation="horizontal", size_hint_y=None, height=dp(42), spacing=dp(10))
            badge = AvatarBadge(_initials(profile.get("display_name") or profile.get("name") or self.app.active_profile), size=38, color=(0.39, 0.57, 0.95, 1))
            top.add_widget(badge)
            meta = BoxLayout(orientation="vertical", spacing=dp(2))
            head = Label(text=f"{profile.get('display_name') or profile.get('name') or self.app.active_profile} · {_moment_time(str(item.get('ts') or ''))}", size_hint_y=None, height=dp(18), font_size="12sp", color=MUTED, halign="left", valign="middle")
            head.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
            mood = Label(text=f"{str(item.get('mood') or '平静')} · {str(item.get('visibility') or '好友可见')}", size_hint_y=None, height=dp(16), font_size="11sp", color=MUTED, halign="left", valign="middle")
            mood.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
            meta.add_widget(head)
            meta.add_widget(mood)
            top.add_widget(meta)
            card.add_widget(top)

            image_source = _moment_image_source(self.app.home["root"], item)
            if image_source:
                picture = Image(source=image_source, size_hint_y=None, height=dp(172), allow_stretch=True, keep_ratio=True)
                card.add_widget(picture)

            body_text = str(item.get("text") or "")
            if body_text:
                body = Label(text=body_text, color=TEXT, halign="left", valign="top", size_hint_y=None)
                body.bind(texture_size=lambda inst, *_: setattr(inst, "height", inst.texture_size[1] + dp(8)))
                body.bind(width=lambda inst, *_: setattr(inst, "text_size", (max(dp(200), inst.width - dp(2)), None)))
                card.add_widget(body)

            tags = [str(tag).strip() for tag in (item.get("tags") or []) if str(tag).strip()]
            if tags:
                tag_row = Label(text="  ".join(f"#{tag}" for tag in tags[:4]), size_hint_y=None, height=dp(18), font_size="12sp", color=MUTED, halign="left", valign="middle")
                tag_row.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
                card.add_widget(tag_row)
            del_btn = Button(text="删除", size_hint_y=None, height=dp(32), background_normal="", background_color=(0.95, 0.88, 0.88, 1), color=TEXT)
            del_btn.bind(on_release=lambda *_args, moment_id=str(item.get("id") or ""): self.delete_moment(moment_id))
            card.add_widget(del_btn)
            self.feed.add_widget(card)
        self.status.text = f"当前存档：{self.app.active_profile} · {len(items)} 条动态"

    def publish(self):
        text = self.moment_input.text.strip()
        if not text:
            self.status.text = "先写一点内容再发布。"
            return
        profile = core.load_profile(self.app.active_profile, self.app.home["root"])
        visibility = "friends" if self.visibility.text == "好友可见" else "private"
        mood = {"平静": "calm", "开心": "happy", "温柔": "warm", "低落": "low"}[self.mood.text]
        profile = core.record_moment(profile, text, visibility=visibility, mood=mood, source="manual", tags=["动态"])
        core.save_profile(self.app.active_profile, profile, self.app.home["root"])
        self.moment_input.text = ""
        self.refresh()

    def generate_image(self, *, publish: bool):
        prompt = self.image_prompt.text.strip()
        style = self.image_style.text.strip() or "朋友圈感"
        profile_name = self.app.active_profile
        self.status.text = "正在生成图片..."
        self.image_only.disabled = True
        self.image_publish.disabled = True

        def worker():
            return self.app.generate_share_image(profile_name, prompt, style=style, mood=self.mood.text.strip(), publish=publish)

        def ok(result):
            self.image_only.disabled = False
            self.image_publish.disabled = False
            image = result.get("image") or {}
            source = str(image.get("image_path") or "")
            self.status.text = f"图片已生成：{source}" if source else "图片已生成"
            self.refresh()

        def err(exc):
            self.image_only.disabled = False
            self.image_publish.disabled = False
            self.status.text = f"生成失败：{exc}"

        _spawn_async(worker, ok, err)

    def delete_moment(self, moment_id: str):
        self.app.delete_moment(moment_id)


class SenseScreen(Screen):
    def __init__(self, app: "CompanionApp", **kwargs):
        super().__init__(name="sense", **kwargs)
        self.app = app
        root = BoxLayout(orientation="vertical", padding=dp(12), spacing=dp(10))

        header = Card(orientation="horizontal", size_hint_y=None, height=dp(78))
        left = BoxLayout(orientation="horizontal", spacing=dp(10))
        self.avatar = AvatarBadge("感", size=48, color=(0.32, 0.62, 0.58, 1))
        left.add_widget(self.avatar)
        title_box = BoxLayout(orientation="vertical", spacing=dp(2))
        title = Label(text="感知与控制", size_hint_y=None, height=dp(26), font_size="20sp", color=PRIMARY_DARK, halign="left", valign="middle")
        title.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        subtitle = Label(text="联网状态、设备状态和快捷操作", size_hint_y=None, height=dp(18), font_size="12sp", color=MUTED, halign="left", valign="middle")
        subtitle.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        title_box.add_widget(title)
        title_box.add_widget(subtitle)
        left.add_widget(title_box)
        header.add_widget(left)
        self.refresh_button = Button(text="刷新", size_hint_x=None, width=dp(92), background_normal="", background_color=PRIMARY, color=(1, 1, 1, 1))
        self.refresh_button.bind(on_release=lambda *_: self.refresh())
        header.add_widget(self.refresh_button)
        root.add_widget(header)

        self.summary_card = Card(orientation="vertical", size_hint_y=None, height=dp(112))
        self.summary_label = Label(text="正在读取状态…", color=TEXT, halign="left", valign="middle")
        self.summary_label.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        self.summary_card.add_widget(self.summary_label)
        root.add_widget(self.summary_card)

        metrics = BoxLayout(size_hint_y=None, height=dp(84), spacing=dp(8))
        self.metric_network = self._metric_card("联网", "未知")
        self.metric_weather = self._metric_card("天气", "未知")
        self.metric_battery = self._metric_card("电量", "未知")
        metrics.add_widget(self.metric_network)
        metrics.add_widget(self.metric_weather)
        metrics.add_widget(self.metric_battery)
        root.add_widget(metrics)

        dpi_card = Card(orientation="horizontal", size_hint_y=None, height=dp(72))
        dpi_left = BoxLayout(orientation="vertical", spacing=dp(2))
        dpi_title = Label(text="屏幕 DPI", size_hint_y=None, height=dp(18), color=MUTED, halign="left", valign="middle")
        dpi_title.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        self.dpi_value = Label(text="未查询", color=TEXT, halign="left", valign="middle")
        self.dpi_value.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        dpi_left.add_widget(dpi_title)
        dpi_left.add_widget(self.dpi_value)
        dpi_card.add_widget(dpi_left)
        self.dpi_button = Button(text="查询 DPI", size_hint_x=None, width=dp(110), background_normal="", background_color=(0.92, 0.93, 0.95, 1), color=TEXT)
        self.dpi_button.bind(on_release=lambda *_: self.refresh())
        dpi_card.add_widget(self.dpi_button)
        root.add_widget(dpi_card)

        pkg_card = Card(orientation="vertical", size_hint_y=None, height=dp(132))
        pkg_label = Label(text="目标应用包名", size_hint_y=None, height=dp(20), color=PRIMARY_DARK, halign="left", valign="middle")
        pkg_label.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        self.package_input = TextInput(hint_text="例如 com.tencent.mm", multiline=False, size_hint_y=None, height=dp(42), background_normal="", background_active="", background_color=(1, 1, 1, 1), foreground_color=TEXT, cursor_color=PRIMARY_DARK, padding=(dp(10), dp(10)))
        action_row = BoxLayout(size_hint_y=None, height=dp(36), spacing=dp(8))
        launch_btn = Button(text="打开应用", background_normal="", background_color=PRIMARY, color=(1, 1, 1, 1))
        launch_btn.bind(on_release=lambda *_args: self._open("app", self.package_input.text.strip()))
        detail_btn = Button(text="应用详情", background_normal="", background_color=(0.92, 0.93, 0.95, 1), color=TEXT)
        detail_btn.bind(on_release=lambda *_args: self._open("app_details", self.package_input.text.strip()))
        action_row.add_widget(detail_btn)
        action_row.add_widget(launch_btn)
        pkg_card.add_widget(pkg_label)
        pkg_card.add_widget(self.package_input)
        pkg_card.add_widget(action_row)
        root.add_widget(pkg_card)

        quick = BoxLayout(size_hint_y=None, height=dp(170), spacing=dp(8))
        left_actions = Card(orientation="vertical")
        for title, kind, hint in (
            ("回到桌面", "home", "快速切回桌面"),
            ("打开通知设置", "notifications", "检查通知权限"),
            ("打开电池优化", "battery", "MIUI 建议加入白名单"),
            ("打开无障碍设置", "accessibility", "后续手机控制会用到"),
        ):
            card = BoxLayout(orientation="vertical", size_hint_y=None, height=dp(82), spacing=dp(2))
            t = Label(text=title, size_hint_y=None, height=dp(22), color=PRIMARY_DARK, halign="left", valign="middle")
            t.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
            d = Label(text=hint, size_hint_y=None, height=dp(18), font_size="12sp", color=MUTED, halign="left", valign="middle")
            d.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
            b = Button(text="打开", size_hint_y=None, height=dp(34), background_normal="", background_color=PRIMARY, color=(1, 1, 1, 1))
            b.bind(on_release=lambda *_args, k=kind: self._open(k, self.package_input.text.strip()))
            card.add_widget(t)
            card.add_widget(d)
            card.add_widget(b)
            left_actions.add_widget(card)
        quick.add_widget(left_actions)
        root.add_widget(quick)

        self.status = Label(text="", size_hint_y=None, height=dp(20), color=MUTED, halign="left", valign="middle")
        self.status.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        root.add_widget(self.status)
        self.add_widget(root)
        Clock.schedule_once(lambda *_: self.refresh(), 0.2)

    def _metric_card(self, title: str, value: str) -> Card:
        card = Card(orientation="vertical", size_hint_x=1)
        card.padding = (dp(10), dp(10))
        label_title = Label(text=title, size_hint_y=None, height=dp(18), font_size="12sp", color=MUTED, halign="left", valign="middle")
        label_title.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        label_value = Label(text=value, color=TEXT, halign="left", valign="middle")
        label_value.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        card.add_widget(label_title)
        card.add_widget(label_value)
        card.value_label = label_value  # type: ignore[attr-defined]
        return card

    def refresh(self):
        def worker():
            return {
                "external": core.build_external_awareness_context("", enabled=bool(self.app.provider_cfg.get("external_awareness_enabled", True))),
                "device": device.read_device_status(),
            }

        def ok(result):
            external = result.get("external") or {}
            device_state = result.get("device") or {}
            summary = str(external.get("summary") or "暂无外部感知数据")
            self.summary_label.text = summary
            self.metric_network.value_label.text = "在线" if device_state.get("online") else "离线" if device_state.get("online") is False else "未知"
            weather = str(external.get("weather") or "暂无")
            self.metric_weather.value_label.text = _short(weather, 18)
            battery = device_state.get("battery_level")
            self.metric_battery.value_label.text = f"{battery}%" if battery is not None else "未知"
            dpi = device_state.get("density_dpi")
            width = device_state.get("screen_width_px")
            height = device_state.get("screen_height_px")
            scale = device_state.get("screen_density")
            if dpi and dpi > 0:
                extra = f"{dpi} dpi"
                if scale is not None:
                    extra += f" · {scale}x"
                if width and height:
                    extra += f" · {width}x{height}"
                self.dpi_value.text = extra
            else:
                self.dpi_value.text = "未查询到"
            self.status.text = f"设备：{device_state.get('package') or '未知'}"

        def err(exc):
            self.summary_label.text = f"读取失败：{exc}"
            self.status.text = "外部感知暂不可用"

        _spawn_async(worker, ok, err)

    def _open(self, kind: str, target: str = ""):
        result = device.perform_device_action(kind, target=target, dry_run=False)
        if result.get("ok"):
            self.status.text = f"已执行：{result.get('detail') or kind}"
            self.status.color = PRIMARY_DARK
        else:
            self.status.text = f"失败：{result.get('error') or 'unknown'}"
            self.status.color = WARN


class SettingsScreen(Screen):
    def __init__(self, app: "CompanionApp", **kwargs):
        super().__init__(name="settings", **kwargs)
        self.app = app
        self.inputs: dict[str, Widget] = {}
        self.switch_keys: set[str] = set()

        root = BoxLayout(orientation="vertical", padding=dp(12), spacing=dp(10))
        header = Card(orientation="vertical", size_hint_y=None, height=dp(82))
        title = Label(text="API 设置", size_hint_y=None, height=dp(24), font_size="20sp", color=PRIMARY_DARK, halign="left", valign="middle")
        title.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        subtitle = Label(text="在这里配置三角色 API、后台主动聊和同步令牌。", size_hint_y=None, height=dp(18), font_size="12sp", color=MUTED, halign="left", valign="middle")
        subtitle.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        header.add_widget(title)
        header.add_widget(subtitle)
        root.add_widget(header)

        self.scroll = ScrollView(do_scroll_x=False)
        self.form = BoxLayout(orientation="vertical", size_hint_y=None, spacing=dp(10))
        self.form.bind(minimum_height=self.form.setter("height"))
        self.scroll.add_widget(self.form)
        root.add_widget(self.scroll)

        buttons = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(8))
        self.proactive_button = Button(text="立即主动聊", background_normal="", background_color=(0.92, 0.93, 0.95, 1), color=TEXT)
        self.proactive_button.bind(on_release=lambda *_: self.app.trigger_proactive_chat())
        self.test_button = Button(text="测试三角色", background_normal="", background_color=(0.92, 0.93, 0.95, 1), color=TEXT)
        self.test_button.bind(on_release=lambda *_: self.app.test_provider())
        self.save_button = Button(text="保存设置", background_normal="", background_color=PRIMARY, color=(1, 1, 1, 1))
        self.save_button.bind(on_release=lambda *_: self.app.save_provider_settings())
        buttons.add_widget(self.proactive_button)
        buttons.add_widget(self.test_button)
        buttons.add_widget(self.save_button)
        root.add_widget(buttons)

        self.status = Label(text="", size_hint_y=None, height=dp(20), color=MUTED, halign="left", valign="middle")
        self.status.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        root.add_widget(self.status)
        self.add_widget(root)
        self._build_form()

    def _build_form(self):
        self.form.clear_widgets()
        self.inputs.clear()
        self.switch_keys.clear()
        cfg = self.app.provider_cfg

        def add_text(key: str, label: str, *, hint: str = "", multiline: bool = False, height: int = 44):
            initial = str(cfg.get(key) or "")
            if key == "headers_json":
                initial = json.dumps(cfg.get("headers") or {}, ensure_ascii=False, indent=2)
            ti = TextInput(
                text=initial,
                multiline=multiline,
                size_hint_y=None,
                height=dp(height),
                background_normal="",
                background_active="",
                background_color=(1, 1, 1, 1),
                foreground_color=TEXT,
                cursor_color=PRIMARY_DARK,
                padding=(dp(10), dp(10)),
            )
            self.inputs[key] = ti
            self.form.add_widget(Field(label, ti, hint=hint))

        def add_spinner(key: str, label: str, values: list[str], *, hint: str = ""):
            sp = Spinner(
                text=str(cfg.get(key) or values[0]),
                values=values,
                size_hint_y=None,
                height=dp(44),
                background_normal="",
                background_down="",
                background_color=PRIMARY,
                color=(1, 1, 1, 1),
            )
            self.inputs[key] = sp
            self.form.add_widget(Field(label, sp, hint=hint))

        def add_switch(key: str, label: str, *, hint: str = ""):
            sw = Switch(active=bool(cfg.get(key, True)), size_hint_y=None, height=dp(40))
            self.inputs[key] = sw
            self.switch_keys.add(key)
            self.form.add_widget(Field(label, sw, hint=hint))

        add_spinner("protocol", "协议", ["openai_compatible", "anthropic", "gemini"], hint="选择上游协议")
        add_text("base_url", "全局 Base URL", hint="例如 https://api.example.com/v1")
        add_text("api_key", "全局 API Key", hint="保存后只存本机")
        add_text("headers_json", "全局额外 Headers(JSON)", multiline=True, height=96, hint='例如 {"X-Trace":"1"}')
        add_text("main_model", "主模型", hint="聊天主链")
        add_text("state_model", "状态模型", hint="记忆编译")
        add_text("review_model", "维护模型", hint="代码提案和维护")
        add_text("image_model", "生图模型", hint="可选")
        add_text("image_size", "生图尺寸", hint="例如 1024x1024")
        add_text("mobile_token", "本机访问 Token", hint="给 Tavo 或本机客户端用")
        add_text("sync_token", "同步 Token", hint="给远端同步用")
        add_switch("proactive_enabled", "主动聊总开关", hint="关闭后完全不走主动聊")
        add_switch("proactive_background_enabled", "后台主动聊", hint="关闭后只保留手动触发")
        add_switch("proactive_push_notifications", "主动消息推送", hint="后台触发后推送通知")

        for role in ("main", "state", "review"):
            section = Card(orientation="vertical", size_hint_y=None)
            section.padding = (dp(10), dp(10))
            section.spacing = dp(6)
            section.bind(minimum_height=section.setter("height"))
            section.add_widget(Label(text=f"{role.upper()} 角色覆盖", size_hint_y=None, height=dp(20), color=PRIMARY_DARK, halign="left", valign="middle"))
            for suffix, title in (("base_url", "Base URL"), ("api_key", "API Key"), ("headers_json", "Headers JSON")):
                key = f"{role}_{suffix}"
                role_cfg = (cfg.get("roles") or {}).get(role, {}) if isinstance(cfg.get("roles"), dict) else {}
                value = role_cfg.get(suffix) if isinstance(role_cfg, dict) else ""
                if suffix == "headers_json":
                    value = json.dumps(value or {}, ensure_ascii=False, indent=2)
                ti = TextInput(
                    text=str(value or ""),
                    multiline=suffix == "headers_json",
                    size_hint_y=None,
                    height=dp(96 if suffix == "headers_json" else 42),
                    background_normal="",
                    background_active="",
                    background_color=(1, 1, 1, 1),
                    foreground_color=TEXT,
                    cursor_color=PRIMARY_DARK,
                    padding=(dp(10), dp(10)),
                )
                self.inputs[key] = ti
                section.add_widget(Field(f"{role} {title}", ti, hint="留空表示继承全局配置" if suffix != "headers_json" else "JSON 格式，留空表示不覆盖"))
            self.form.add_widget(section)

    def refresh_from_config(self, cfg: dict[str, object]):
        self.app.provider_cfg = cfg
        self._build_form()

    def set_status(self, text: str, color=MUTED):
        self.status.text = text
        self.status.color = color


class CompanionApp(App):
    def build(self):
        self.home = core.ensure_tree()
        self.provider_cfg = core.load_provider_config(self.home["root"])
        self.ui_state = core.load_ui_state(self.home["root"])
        self.active_profile = self.ui_state.get("active_profile") or core.DEFAULT_PROFILE
        self._profile_text_lock = False
        self._profile_stamp = ""
        self._profile_history_size = 0
        if not core.profile_state_path(self.active_profile, self.home["root"]).is_file():
            core.ensure_profile(self.active_profile, base_dir=self.home["root"])

        Window.clearcolor = BG
        Window.softinput_mode = "below_target"

        root = FloatLayout()
        root.add_widget(Backdrop())
        content = BoxLayout(orientation="vertical", padding=dp(12), spacing=dp(10), size_hint=(1, 1))

        self.topbar = Card(orientation="horizontal", size_hint_y=None, height=dp(70))
        title_row = BoxLayout(orientation="horizontal", spacing=dp(10))
        self.app_avatar = AvatarBadge(_initials(self.active_profile), size=46)
        title_row.add_widget(self.app_avatar)
        title_box = BoxLayout(orientation="vertical", spacing=dp(2))
        title = Label(text="Companion", size_hint_y=None, height=dp(24), font_size="20sp", color=PRIMARY_DARK, halign="left", valign="middle")
        title.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        subtitle = Label(text="聊天 · 动态 · 存档 · 感知 · 设置", size_hint_y=None, height=dp(16), font_size="12sp", color=MUTED, halign="left", valign="middle")
        subtitle.bind(size=lambda inst, *_: setattr(inst, "text_size", inst.size))
        title_box.add_widget(title)
        title_box.add_widget(subtitle)
        title_row.add_widget(title_box)
        self.topbar.add_widget(title_row)
        self.profile_chip = Spinner(
            text=self.active_profile,
            values=[self.active_profile],
            size_hint_x=None,
            width=dp(170),
            size_hint_y=None,
            height=dp(38),
            background_normal="",
            background_down="",
            background_color=PRIMARY,
            color=(1, 1, 1, 1),
        )
        self.profile_chip.bind(text=self._on_profile_spinner)
        self.topbar.add_widget(self.profile_chip)
        content.add_widget(self.topbar)

        self.sm = ScreenManager(transition=NoTransition())
        self.chat_screen = ModernChatScreen(self)
        self.moments_screen = MomentsScreen(self)
        self.profiles_screen = ProfilesScreen(self)
        self.sense_screen = SenseScreen(self)
        self.settings_screen = SettingsScreen(self)
        for screen in (self.chat_screen, self.moments_screen, self.profiles_screen, self.sense_screen, self.settings_screen):
            self.sm.add_widget(screen)
        content.add_widget(self.sm)

        self.nav = Card(orientation="horizontal", size_hint_y=None, height=dp(62))
        self.nav_buttons = {}
        for name, label in (("chat", "聊天"), ("moments", "动态"), ("profiles", "存档"), ("sense", "感知"), ("settings", "设置")):
            btn = ToggleButton(
                text=label,
                group="nav",
                background_normal="",
                background_down="",
                background_color=(0.92, 0.93, 0.95, 1),
                color=TEXT,
            )
            btn.bind(on_release=lambda inst, n=name: self.switch_screen(n))
            self.nav.add_widget(btn)
            self.nav_buttons[name] = btn
        content.add_widget(self.nav)
        root.add_widget(content)

        Clock.schedule_once(lambda *_: (backend_service.ensure_running(), self.reload_all()), 0)
        Clock.schedule_interval(self._poll_profile_updates, 5)
        return root

    def on_start(self):
        _request_android_permissions()
        backend_service.ensure_running()
        screen_name = self.ui_state.get("screen") or "chat"
        if screen_name == "device":
            screen_name = "sense"
        self.switch_screen(screen_name, persist=False)

    def switch_screen(self, screen_name: str, *, persist: bool = True):
        if screen_name == "device":
            screen_name = "sense"
        if screen_name not in {"chat", "moments", "profiles", "sense", "settings"}:
            screen_name = "chat"
        self.sm.current = screen_name
        for name, btn in self.nav_buttons.items():
            btn.state = "down" if name == screen_name else "normal"
            btn.background_color = PRIMARY if name == screen_name else (0.92, 0.93, 0.95, 1)
            btn.color = (1, 1, 1, 1) if name == screen_name else TEXT
        if persist:
            self.ui_state = core.save_ui_state({"active_profile": self.active_profile, "screen": screen_name}, self.home["root"])

    def _on_profile_spinner(self, *_):
        if self._profile_text_lock:
            return
        self.switch_profile(self.profile_chip.text)

    def _set_profile_chip_text(self, value: str):
        self._profile_text_lock = True
        try:
            self.profile_chip.text = value
            self.app_avatar.set_text(_initials(value))
        finally:
            self._profile_text_lock = False

    def switch_profile(self, profile_name: str):
        profile_name = core.safe_name(profile_name)
        if not core.profile_state_path(profile_name, self.home["root"]).is_file():
            core.ensure_profile(profile_name, base_dir=self.home["root"])
        self.active_profile = profile_name
        self.profile_chip.values = [item["name"] for item in core.list_profiles(self.home["root"])]
        self._set_profile_chip_text(profile_name)
        core.save_ui_state({"active_profile": profile_name, "screen": self.sm.current}, self.home["root"])
        self.reload_chat()
        self.reload_profiles()
        self.moments_screen.refresh()
        self.sense_screen.refresh()

    def reload_all(self):
        self.provider_cfg = core.load_provider_config(self.home["root"])
        self.ui_state = core.load_ui_state(self.home["root"])
        self.profile_chip.values = [item["name"] for item in core.list_profiles(self.home["root"])]
        if self.active_profile not in self.profile_chip.values:
            self.active_profile = self.ui_state.get("active_profile") or core.DEFAULT_PROFILE
        self._set_profile_chip_text(self.active_profile)
        self.reload_chat()
        self.reload_profiles()
        self.moments_screen.refresh()
        self.sense_screen.refresh()
        self.settings_screen.refresh_from_config(self.provider_cfg)
        self._update_status()

    def _update_status(self):
        cfg = self.provider_cfg
        configured = core.provider_ready(cfg)
        active = self.active_profile
        decision = core.proactive_decision(active, base_dir=self.home["root"], provider_cfg=cfg)
        proactive_mode = "后台主动聊开" if bool(cfg.get("proactive_background_enabled", True)) else "后台主动聊关"
        if decision.get("eligible"):
            proactive_hint = "可主动聊"
        else:
            proactive_hint = f"原因：{decision.get('reason') or '冷却中'}"
            if decision.get("next_check_in_seconds"):
                proactive_hint += f" · {core.format_duration(decision.get('next_check_in_seconds'))} 后再看"
        self.chat_screen.set_status(f"存档：{active} · {'已配置 API' if configured else '尚未配置 API'} · {proactive_mode} · {proactive_hint}")
        self.chat_screen.set_banner("" if configured else "先到【设置】填好 API 和模型，再回来聊天。", visible=not configured)

    def reload_chat(self):
        self.chat_screen.clear_history()
        profile = core.load_profile(self.active_profile, self.home["root"])
        for msg in profile.get("history") or []:
            role = str(msg.get("role") or "assistant")
            content = str(msg.get("content") or "").strip()
            if content:
                self.chat_screen.add_row(role, content)
        if not profile.get("history"):
            self.chat_screen.add_row("assistant", "这里会显示聊天记录。先在下面输入一句话试试。")
        self.chat_screen.set_profiles([item["name"] for item in core.list_profiles(self.home["root"])], self.active_profile)
        self._profile_stamp = str(profile.get("updated_at") or "")
        self._profile_history_size = len(profile.get("history") or [])
        self._update_status()

    def _poll_profile_updates(self, *_):
        profile = core.load_profile(self.active_profile, self.home["root"])
        stamp = str(profile.get("updated_at") or "")
        history_size = len(profile.get("history") or [])
        if stamp != self._profile_stamp or history_size != self._profile_history_size:
            self.reload_chat()
            self.reload_profiles()
            self.moments_screen.refresh()

    def reload_profiles(self):
        items = core.list_profiles(self.home["root"])
        self.profiles_screen.rebuild(items, self.active_profile)
        self.chat_screen.set_profiles([item["name"] for item in items], self.active_profile)

    def _confirm(self, title: str, text: str, on_yes):
        body = BoxLayout(orientation="vertical", spacing=dp(10), padding=dp(12))
        body.add_widget(Label(text=text, color=TEXT, halign="left", valign="middle"))
        buttons = BoxLayout(size_hint_y=None, height=dp(42), spacing=dp(8))
        no_btn = Button(text="取消", background_normal="", background_color=(0.92, 0.93, 0.95, 1), color=TEXT)
        yes_btn = Button(text="确认", background_normal="", background_color=PRIMARY, color=(1, 1, 1, 1))
        buttons.add_widget(no_btn)
        buttons.add_widget(yes_btn)
        body.add_widget(buttons)
        popup = Popup(title=title, content=body, size_hint=(0.9, 0.36))
        no_btn.bind(on_release=lambda *_: popup.dismiss())
        yes_btn.bind(on_release=lambda *_: (popup.dismiss(), on_yes()))
        popup.open()

    def prompt_new_profile(self):
        body = BoxLayout(orientation="vertical", spacing=dp(10), padding=dp(12))
        name_input = TextInput(hint_text="存档名称", multiline=False, size_hint_y=None, height=dp(42))
        display_input = TextInput(hint_text="显示名称", multiline=False, size_hint_y=None, height=dp(42))
        body.add_widget(name_input)
        body.add_widget(display_input)
        buttons = BoxLayout(size_hint_y=None, height=dp(42), spacing=dp(8))
        cancel = Button(text="取消", background_normal="", background_color=(0.92, 0.93, 0.95, 1), color=TEXT)
        create = Button(text="创建", background_normal="", background_color=PRIMARY, color=(1, 1, 1, 1))
        buttons.add_widget(cancel)
        buttons.add_widget(create)
        body.add_widget(buttons)
        popup = Popup(title="新建存档", content=body, size_hint=(0.92, 0.4))
        cancel.bind(on_release=lambda *_: popup.dismiss())

        def _create(*_):
            name = core.safe_name(name_input.text.strip() or core.DEFAULT_PROFILE)
            display = display_input.text.strip() or name
            core.ensure_profile(name, base_dir=self.home["root"], display_name=display)
            self.switch_profile(name)
            self.reload_all()
            popup.dismiss()

        create.bind(on_release=_create)
        popup.open()

    def clear_active_profile_history(self):
        profile = core.load_profile(self.active_profile, self.home["root"])
        profile["history"] = []
        core.save_profile(self.active_profile, profile, self.home["root"])
        self.reload_all()

    def reset_active_profile_memory(self):
        core.reset_profile_memory(self.active_profile, base_dir=self.home["root"], keep_moments=True)
        self.reload_all()

    def delete_active_profile(self):
        if self.active_profile == core.DEFAULT_PROFILE:
            self.reset_active_profile_memory()
            return
        core.delete_profile(self.active_profile, self.home["root"])
        core.ensure_profile(core.DEFAULT_PROFILE, base_dir=self.home["root"])
        self.active_profile = core.DEFAULT_PROFILE
        core.save_ui_state({"active_profile": self.active_profile, "screen": self.sm.current}, self.home["root"])
        self.reload_all()

    def confirm_reset_memory(self):
        self._confirm("重置记忆", f"确认重置【{self.active_profile}】的记忆吗？", self.reset_active_profile_memory)

    def confirm_clear_history(self):
        self._confirm("清空聊天", f"确认清空【{self.active_profile}】的聊天记录吗？", self.clear_active_profile_history)

    def confirm_delete_profile(self):
        self._confirm("删除存档", f"确认删除【{self.active_profile}】吗？默认存档会改为重置记忆。", self.delete_active_profile)

    def save_provider_settings(self):
        settings = json.loads(json.dumps(self.provider_cfg, ensure_ascii=False))
        for key, widget in self.settings_screen.inputs.items():
            if key in self.settings_screen.switch_keys:
                settings[key] = bool(getattr(widget, "active", False))
                continue
            value = str(getattr(widget, "text", "") or "").strip()
            if key == "headers_json":
                try:
                    settings["headers"] = json.loads(value) if value else {}
                except Exception as exc:
                    self.settings_screen.set_status(f"Headers JSON 解析失败：{exc}", WARN)
                    return False
                continue
            if key.endswith("_headers_json"):
                role, _ = key.split("_", 1)
                try:
                    settings.setdefault("roles", {}).setdefault(role, {})
                    settings["roles"][role]["headers"] = json.loads(value) if value else {}
                except Exception as exc:
                    self.settings_screen.set_status(f"{role} Headers JSON 解析失败：{exc}", WARN)
                    return False
                continue
            if key.endswith("_base_url") or key.endswith("_api_key"):
                role, suffix = key.split("_", 1)
                settings.setdefault("roles", {}).setdefault(role, {})
                settings["roles"][role][suffix] = value
                continue
            settings[key] = value
        if isinstance(settings.get("protocol"), str):
            settings["protocol"] = settings["protocol"].strip().lower()
        cfg = core.save_provider_config(settings, self.home["root"])
        self.provider_cfg = cfg
        self.settings_screen.set_status("已保存", PRIMARY_DARK)
        self._update_status()
        return True

    def test_provider(self):
        if not self.save_provider_settings():
            return
        cfg = self.provider_cfg
        roles = ["main", "state", "review"]
        self.settings_screen.set_status("正在测试三角色...", MUTED)

        def worker():
            return {role: core.provider_health(cfg, role) for role in roles}

        def ok(results):
            parts = []
            all_ok = True
            for role, result in results.items():
                ok_flag = bool(result.get("ok"))
                all_ok = all_ok and ok_flag
                parts.append(f"{role}:{'OK' if ok_flag else 'FAIL'}")
            self.settings_screen.set_status(" · ".join(parts), PRIMARY if all_ok else WARN)

        def err(exc):
            self.settings_screen.set_status(f"测试失败：{exc}", WARN)

        _spawn_async(worker, ok, err)

    def trigger_proactive_chat(self):
        if not self.save_provider_settings():
            return
        if not core.provider_ready(self.provider_cfg):
            self.settings_screen.set_status("请先补全 API 和模型再触发主动聊。", WARN)
            return
        self.send_proactive_chat()

    def send_chat(self):
        text = self.chat_screen.input.text.strip()
        if not text:
            return
        if not core.provider_ready(self.provider_cfg):
            self.chat_screen.add_row("assistant", "先到【设置】填好 API 和模型，再来聊天。")
            return
        self.chat_screen.input.text = ""
        self.chat_screen.add_row("user", text)
        self.chat_screen.add_row("assistant", "正在回复…")
        self.chat_screen.send_button.disabled = True
        self.chat_screen.send_button.text = "发送中"
        profile_name = self.active_profile
        cfg = self.provider_cfg

        def worker():
            return core.chat_turn(text, profile_name, base_dir=self.home["root"], provider_cfg=cfg)

        def ok(result):
            if self.chat_screen.history.children:
                self.chat_screen.history.remove_widget(self.chat_screen.history.children[0])
            reply = str(result.get("reply") or "").strip() or "（空回复）"
            self.chat_screen.add_row("assistant", reply)
            self.chat_screen.send_button.disabled = False
            self.chat_screen.send_button.text = "发送"
            self.reload_profiles()
            self.moments_screen.refresh()
            self.sense_screen.refresh()
            self._update_status()

        def err(exc):
            if self.chat_screen.history.children:
                self.chat_screen.history.remove_widget(self.chat_screen.history.children[0])
            self.chat_screen.add_row("assistant", f"出错：{exc}")
            self.chat_screen.send_button.disabled = False
            self.chat_screen.send_button.text = "发送"

        _spawn_async(worker, ok, err)

    def send_proactive_chat(self):
        if not core.provider_ready(self.provider_cfg):
            self.chat_screen.add_row("assistant", "先到【设置】填好 API 和模型，再点主动聊。")
            return
        self.chat_screen.add_row("assistant", "正在主动找话题…")
        self.chat_screen.send_button.disabled = True
        self.chat_screen.send_button.text = "生成中"
        profile_name = self.active_profile
        cfg = self.provider_cfg

        def worker():
            return core.proactive_turn(profile_name, base_dir=self.home["root"], provider_cfg=cfg)

        def ok(result):
            if self.chat_screen.history.children:
                self.chat_screen.history.remove_widget(self.chat_screen.history.children[0])
            reply = str(result.get("reply") or "").strip() or "（空回复）"
            self.chat_screen.add_row("assistant", reply)
            self.chat_screen.send_button.disabled = False
            self.chat_screen.send_button.text = "发送"
            self.reload_profiles()
            self.moments_screen.refresh()
            self.sense_screen.refresh()
            self._update_status()

        def err(exc):
            if self.chat_screen.history.children:
                self.chat_screen.history.remove_widget(self.chat_screen.history.children[0])
            self.chat_screen.add_row("assistant", f"出错：{exc}")
            self.chat_screen.send_button.disabled = False
            self.chat_screen.send_button.text = "发送"

        _spawn_async(worker, ok, err)

    def generate_share_image(self, profile_name: str, prompt: str, *, style: str = "朋友圈感", mood: str = "平静", publish: bool = False):
        cfg = self.provider_cfg
        image = core.generate_share_image(profile_name, prompt, base_dir=self.home["root"], provider_cfg=cfg, style=style, mood=mood)
        profile = None
        if publish:
            profile = core.load_profile(profile_name, self.home["root"])
            caption = prompt.strip() or str(image.get("revised_prompt") or "分享图")
            profile = core.record_moment(
                profile,
                caption,
                visibility="friends",
                mood=mood,
                source="image",
                tags=["生图"],
                kind="image",
                image_path=str(image.get("image_path") or ""),
                image_prompt=str(image.get("refined_prompt") or prompt),
                image_mode=str(image.get("mode") or ""),
            )
            core.save_profile(profile_name, profile, self.home["root"])
        return {"image": image, "moment": profile}

    def delete_moment(self, moment_id: str):
        profile = core.delete_moment_asset(self.active_profile, moment_id, self.home["root"])
        self.reload_profiles()
        self.moments_screen.refresh()
        return profile

if __name__ == "__main__":
    CompanionApp().run()
