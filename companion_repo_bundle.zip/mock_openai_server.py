from __future__ import annotations

import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


class Handler(BaseHTTPRequestHandler):
    def _send(self, status: int, payload: dict):
        raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        if self.path == "/v1/models":
            self._send(200, {"object": "list", "data": [{"id": "mock-main"}, {"id": "mock-state"}, {"id": "mock-review"}]})
            return
        self._send(404, {"error": "not_found"})

    def do_POST(self):
        if self.path != "/v1/chat/completions":
            self._send(404, {"error": "not_found"})
            return
        length = int(self.headers.get("Content-Length") or 0)
        body = json.loads(self.rfile.read(length).decode("utf-8") or "{}")
        messages = body.get("messages") if isinstance(body.get("messages"), list) else []
        last_user = ""
        for msg in reversed(messages):
            if isinstance(msg, dict) and str(msg.get("role") or "").lower() == "user":
                last_user = str(msg.get("content") or "")
                break
        content = f"mock:{last_user or 'ok'}"
        self._send(
            200,
            {
                "id": "chatcmpl-mock",
                "object": "chat.completion",
                "created": 0,
                "model": str(body.get("model") or "mock-main"),
                "choices": [{"index": 0, "message": {"role": "assistant", "content": content}, "finish_reason": "stop"}],
            },
        )

    def log_message(self, *_):
        return


def main() -> int:
    server = ThreadingHTTPServer(("127.0.0.1", 9010), Handler)
    server.serve_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

