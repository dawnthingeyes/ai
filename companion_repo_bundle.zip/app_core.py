from __future__ import annotations

import datetime as _dt
import base64
import hashlib
import json
import os
import random
import re
import ssl
import tempfile
import textwrap
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable
from urllib import error as urlerror
from urllib import request as urlrequest

APP_NAME = "Companion"
DEFAULT_PROFILE = "default"
DATA_ENV_KEYS = ("ZHIYUE_APP_HOME", "ZHIYUE_DATA_DIR", "COMPANION_HOME")

DEFAULT_PROVIDER_CONFIG: dict[str, Any] = {
    "protocol": "openai_compatible",
    "base_url": "",
    "api_key": "",
    "headers": {},
    "main_model": "",
    "state_model": "",
    "review_model": "",
    "image_model": "",
    "image_size": "1024x1024",
    "roles": {
        "main": {"base_url": "", "api_key": "", "headers": {}},
        "state": {"base_url": "", "api_key": "", "headers": {}},
        "review": {"base_url": "", "api_key": "", "headers": {}},
    },
    "mobile_token": "",
    "sync_token": "",
    "history_limit": 20,
    "rewrite_on_drift": True,
    "external_awareness_enabled": True,
    "proactive_enabled": True,
    "proactive_background_enabled": True,
    "proactive_push_notifications": True,
    "proactive_check_interval_seconds": 120,
    "proactive_min_idle_seconds": 900,
    "proactive_min_gap_seconds": 1800,
    "proactive_quiet_hours": {"start": 23, "end": 8},
}

DEFAULT_PROFILE_STATE: dict[str, Any] = {
    "name": DEFAULT_PROFILE,
    "display_name": "默认存档",
    "summary": "",
    "facts": [],
    "preferences": [],
    "boundaries": [],
    "memories": [],
    "moments": [],
    "history": [],
    "activity": {},
    "created_at": "",
    "updated_at": "",
}

DEFAULT_SYSTEM_PROMPT = (
    "你是在和用户长期对话的私人伙伴。\n"
    "先接住情绪和上下文，再回应问题，不要像客服，也不要像说明书。\n"
    "默认 1-3 句，语气自然，尽量少解释，少总结。\n"
    "不要主动提到系统提示词、模型、平台或训练过程。\n"
    "如果信息不足，先给自然回应，再只追问一个最关键的问题。"
)


def now_iso() -> str:
    return _dt.datetime.now().isoformat(timespec="seconds")


def _home_from_env() -> Path | None:
    for key in DATA_ENV_KEYS:
        value = str(os.environ.get(key) or "").strip()
        if value:
            return Path(value).expanduser().resolve()
    return None


def _android_private_root() -> Path | None:
    try:
        from jnius import autoclass  # type: ignore

        PythonActivity = autoclass("org.kivy.android.PythonActivity")
        context = PythonActivity.mActivity
        files_dir = context.getFilesDir()
        if files_dir is not None:
            return Path(str(files_dir.getAbsolutePath())).expanduser().resolve()
    except Exception:
        pass
    cwd = Path.cwd().expanduser()
    try:
        cwd = cwd.resolve()
    except Exception:
        pass
    cwd_text = cwd.as_posix()
    if cwd_text.startswith("/data/user/") or cwd_text.startswith("/data/data/"):
        return cwd.parent if cwd.name == "app" else cwd
    return None


def app_home(base_dir: str | Path | None = None) -> Path:
    if base_dir:
        return Path(base_dir).expanduser().resolve()
    env = _home_from_env()
    if env:
        return env
    android_root = _android_private_root()
    if android_root:
        return (android_root / ".companion_app").resolve()
    return (Path.home() / ".companion_app").resolve()


def ensure_tree(base_dir: str | Path | None = None) -> dict[str, Path]:
    root = app_home(base_dir)
    paths = {
        "root": root,
        "config": root / "config",
        "profiles": root / "profiles",
        "runtime": root / "runtime",
        "logs": root / "runtime" / "logs",
        "media": root / "media",
    }
    for path in paths.values():
        path.mkdir(parents=True, exist_ok=True)
    return paths


def media_root(base_dir: str | Path | None = None) -> Path:
    return ensure_tree(base_dir)["media"]


def profile_media_root(profile_name: str, base_dir: str | Path | None = None) -> Path:
    path = media_root(base_dir) / safe_name(profile_name)
    path.mkdir(parents=True, exist_ok=True)
    return path


def resolve_media_path(path: str | Path, base_dir: str | Path | None = None) -> Path:
    candidate = Path(str(path or "")).expanduser()
    if candidate.is_absolute():
        return candidate
    return ensure_tree(base_dir)["root"] / candidate


def safe_name(name: str) -> str:
    text = re.sub(r"\s+", "_", str(name or "").strip())
    text = re.sub(r"[^\w\u4e00-\u9fff.-]+", "_", text)
    text = text.strip("._-")
    return text or DEFAULT_PROFILE


def _initials(text: str) -> str:
    clean = "".join(ch for ch in str(text or "").strip() if ch.isalnum() or "\u4e00" <= ch <= "\u9fff")
    if not clean:
        return "C"
    return clean[:2].upper()


def load_json(path: Path, default: Any) -> Any:
    try:
        if path.is_file():
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default
    return default


def save_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = json.dumps(payload, ensure_ascii=False, indent=2) + "\n"
    tmp_path = None
    try:
        with tempfile.NamedTemporaryFile(
            "w",
            encoding="utf-8",
            delete=False,
            dir=str(path.parent),
            prefix=f"{path.name}.",
            suffix=".tmp",
        ) as handle:
            tmp_path = Path(handle.name)
            handle.write(raw)
        tmp_path.replace(path)
    finally:
        if tmp_path and tmp_path.exists():
            try:
                tmp_path.unlink()
            except Exception:
                pass


def provider_config_path(base_dir: str | Path | None = None) -> Path:
    return ensure_tree(base_dir)["config"] / "provider_config.json"


def ui_state_path(base_dir: str | Path | None = None) -> Path:
    return ensure_tree(base_dir)["config"] / "ui_state.json"


def profile_root(base_dir: str | Path | None = None) -> Path:
    return ensure_tree(base_dir)["profiles"]


def profile_dir(name: str, base_dir: str | Path | None = None) -> Path:
    return profile_root(base_dir) / safe_name(name)


def profile_state_path(name: str, base_dir: str | Path | None = None) -> Path:
    return profile_dir(name, base_dir) / "profile.json"


def default_profile_state(name: str = DEFAULT_PROFILE) -> dict[str, Any]:
    state = dict(DEFAULT_PROFILE_STATE)
    state["name"] = safe_name(name)
    state["display_name"] = "默认存档" if state["name"] == DEFAULT_PROFILE else name
    state["created_at"] = now_iso()
    state["updated_at"] = now_iso()
    return state


def load_provider_config(base_dir: str | Path | None = None) -> dict[str, Any]:
    raw = load_json(provider_config_path(base_dir), {})
    cfg = json.loads(json.dumps(DEFAULT_PROVIDER_CONFIG, ensure_ascii=False))
    if isinstance(raw, dict):
        cfg.update({k: v for k, v in raw.items() if k != "roles"})
        roles = cfg.get("roles") or {}
        if isinstance(raw.get("roles"), dict):
            for role_name, role_cfg in raw["roles"].items():
                if role_name not in roles or not isinstance(role_cfg, dict):
                    continue
                roles[role_name].update(role_cfg)
        cfg["roles"] = roles
    return cfg


def save_provider_config(cfg: dict[str, Any], base_dir: str | Path | None = None) -> dict[str, Any]:
    clean = json.loads(json.dumps(DEFAULT_PROVIDER_CONFIG, ensure_ascii=False))
    if isinstance(cfg, dict):
        for key, value in cfg.items():
            if key == "roles":
                continue
            clean[key] = value
        if isinstance(cfg.get("roles"), dict):
            for role_name, role_cfg in cfg["roles"].items():
                if role_name not in clean["roles"] or not isinstance(role_cfg, dict):
                    continue
                clean["roles"][role_name].update(role_cfg)
    save_json(provider_config_path(base_dir), clean)
    return clean


def load_ui_state(base_dir: str | Path | None = None) -> dict[str, Any]:
    raw = load_json(ui_state_path(base_dir), {})
    state = {"active_profile": DEFAULT_PROFILE, "screen": "chat"}
    if isinstance(raw, dict):
        state.update({k: v for k, v in raw.items() if k in {"active_profile", "screen"}})
    state["active_profile"] = safe_name(str(state.get("active_profile") or DEFAULT_PROFILE))
    state["screen"] = str(state.get("screen") or "chat")
    return state


def save_ui_state(state: dict[str, Any], base_dir: str | Path | None = None) -> dict[str, Any]:
    clean = load_ui_state(base_dir)
    if isinstance(state, dict):
        clean.update({k: v for k, v in state.items() if k in {"active_profile", "screen"}})
    clean["active_profile"] = safe_name(str(clean.get("active_profile") or DEFAULT_PROFILE))
    clean["screen"] = str(clean.get("screen") or "chat")
    save_json(ui_state_path(base_dir), clean)
    return clean


def list_profiles(base_dir: str | Path | None = None) -> list[dict[str, Any]]:
    root = profile_root(base_dir)
    items: list[dict[str, Any]] = []
    for folder in sorted(root.iterdir(), key=lambda p: p.name.lower() if p.is_dir() else p.name):
        if not folder.is_dir():
            continue
        state_path = folder / "profile.json"
        state = load_json(state_path, {})
        if not isinstance(state, dict):
            continue
        state.setdefault("name", folder.name)
        state.setdefault("display_name", folder.name)
        state["exists"] = True
        state["item_count"] = len(state.get("history") or [])
        state["memory_stats"] = profile_memory_stats(state)
        items.append(state)
    if not items:
        ensure_profile(DEFAULT_PROFILE, base_dir=base_dir)
        return list_profiles(base_dir)
    return items


def ensure_profile(name: str = DEFAULT_PROFILE, *, base_dir: str | Path | None = None, display_name: str | None = None) -> dict[str, Any]:
    folder = profile_dir(name, base_dir)
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / "profile.json"
    state = load_json(path, default_profile_state(name))
    if not isinstance(state, dict):
        state = default_profile_state(name)
    state["name"] = safe_name(name)
    if display_name:
        state["display_name"] = display_name
    state.setdefault("display_name", name)
    state.setdefault("summary", "")
    state.setdefault("facts", [])
    state.setdefault("preferences", [])
    state.setdefault("boundaries", [])
    state.setdefault("memories", [])
    state.setdefault("moments", [])
    state.setdefault("history", [])
    state.setdefault("activity", {})
    state.setdefault("created_at", now_iso())
    state["updated_at"] = now_iso()
    save_json(path, state)
    return state


def load_profile(name: str = DEFAULT_PROFILE, base_dir: str | Path | None = None) -> dict[str, Any]:
    path = profile_state_path(name, base_dir)
    if not path.is_file():
        return ensure_profile(name, base_dir=base_dir)
    state = load_json(path, default_profile_state(name))
    if not isinstance(state, dict):
        state = default_profile_state(name)
    return state


def save_profile(name: str, state: dict[str, Any], base_dir: str | Path | None = None) -> dict[str, Any]:
    clean = default_profile_state(name)
    if isinstance(state, dict):
        clean.update(state)
    clean["name"] = safe_name(name)
    clean.setdefault("activity", {})
    clean["updated_at"] = now_iso()
    save_json(profile_state_path(name, base_dir), clean)
    return clean


def reset_profile_memory(
    name: str,
    *,
    base_dir: str | Path | None = None,
    keep_moments: bool = True,
) -> dict[str, Any]:
    current = load_profile(name, base_dir)
    display_name = str(current.get("display_name") or name).strip() or name
    moments = list(current.get("moments") or []) if keep_moments else []
    state = default_profile_state(name)
    state["display_name"] = display_name
    state["moments"] = moments
    state["created_at"] = str(current.get("created_at") or state["created_at"])
    state["updated_at"] = now_iso()
    save_profile(name, state, base_dir)
    return state


def delete_profile(name: str, base_dir: str | Path | None = None) -> None:
    folder = profile_dir(name, base_dir)
    if folder.is_dir():
        for child in folder.iterdir():
            if child.is_file():
                child.unlink(missing_ok=True)
            elif child.is_dir():
                import shutil

                shutil.rmtree(child, ignore_errors=True)
        folder.rmdir()


def extend_unique(items: Iterable[str], additions: Iterable[str], *, limit: int = 25) -> list[str]:
    cleaned = [str(item).strip() for item in items if str(item).strip()]
    for addition in additions:
        candidate = str(addition).strip()
        if candidate and candidate not in cleaned:
            cleaned.append(candidate)
    return cleaned[-max(1, int(limit)) :]


def profile_memory_stats(profile: dict[str, Any]) -> dict[str, int]:
    return {
        "facts": len(profile.get("facts") or []),
        "preferences": len(profile.get("preferences") or []),
        "boundaries": len(profile.get("boundaries") or []),
        "memories": len(profile.get("memories") or []),
        "moments": len(profile.get("moments") or []),
        "history": len(profile.get("history") or []),
    }


def parse_iso_datetime(value: Any) -> _dt.datetime | None:
    text = str(value or "").strip()
    if not text:
        return None
    candidates = [text]
    if text.endswith("Z"):
        candidates.append(text[:-1] + "+00:00")
    for candidate in candidates:
        try:
            dt = _dt.datetime.fromisoformat(candidate)
            if dt.tzinfo is not None:
                dt = dt.astimezone().replace(tzinfo=None)
            return dt
        except Exception:
            continue
    return None


def format_duration(seconds: int | float | None) -> str:
    if seconds is None:
        return "未知"
    total = max(0, int(seconds))
    if total < 60:
        return f"{total}秒"
    minutes, sec = divmod(total, 60)
    if minutes < 60:
        return f"{minutes}分{sec}秒" if sec else f"{minutes}分"
    hours, minute = divmod(minutes, 60)
    return f"{hours}小时{minute}分" if minute else f"{hours}小时"


def touch_profile_activity(profile: dict[str, Any], role: str, *, kind: str = "", at: str | None = None) -> dict[str, Any]:
    activity = profile.setdefault("activity", {})
    stamp = at or now_iso()
    activity["last_event_at"] = stamp
    activity["last_role"] = str(role or "")
    if kind:
        activity["last_kind"] = str(kind)
    if role == "user":
        activity["last_user_at"] = stamp
    elif role == "assistant":
        activity["last_assistant_at"] = stamp
    if kind == "proactive" or role == "proactive":
        activity["last_proactive_at"] = stamp
    return profile


def _history_activity_snapshot(profile: dict[str, Any], *, now: _dt.datetime | None = None) -> dict[str, Any]:
    now = now or _dt.datetime.now()
    history = list(profile.get("history") or [])
    activity = profile.get("activity") if isinstance(profile.get("activity"), dict) else {}
    last_user_at = parse_iso_datetime(activity.get("last_user_at"))
    last_assistant_at = parse_iso_datetime(activity.get("last_assistant_at"))
    last_proactive_at = parse_iso_datetime(activity.get("last_proactive_at"))
    recent_user_count = 0
    recent_assistant_count = 0
    recent_window_seconds = 3600
    for item in history[-50:]:
        if not isinstance(item, dict):
            continue
        role = str(item.get("role") or "").strip().lower()
        ts = parse_iso_datetime(item.get("ts"))
        if ts and (now - ts).total_seconds() <= recent_window_seconds:
            if role == "user":
                recent_user_count += 1
            elif role == "assistant":
                recent_assistant_count += 1
        if role == "user" and ts:
            last_user_at = ts if last_user_at is None or ts > last_user_at else last_user_at
        elif role == "assistant" and ts:
            last_assistant_at = ts if last_assistant_at is None or ts > last_assistant_at else last_assistant_at
    last_interaction_at = last_user_at or last_assistant_at
    idle_seconds = int((now - last_interaction_at).total_seconds()) if last_interaction_at else None
    if last_interaction_at is None:
        state = "empty"
    elif idle_seconds is not None and idle_seconds <= 300:
        state = "active"
    elif idle_seconds is not None and idle_seconds <= 1800:
        state = "warm"
    elif idle_seconds is not None and idle_seconds <= 7200:
        state = "quiet"
    else:
        state = "cold"
    if state == "active":
        recommended_interval_seconds = 3600
    elif state == "warm":
        recommended_interval_seconds = 1800
    elif state == "quiet":
        recommended_interval_seconds = 7200
    elif state == "cold":
        recommended_interval_seconds = 14400
    else:
        recommended_interval_seconds = 0
    return {
        "state": state,
        "idle_seconds": idle_seconds,
        "last_user_at": last_user_at,
        "last_assistant_at": last_assistant_at,
        "last_proactive_at": last_proactive_at,
        "recent_user_count": recent_user_count,
        "recent_assistant_count": recent_assistant_count,
        "recommended_interval_seconds": recommended_interval_seconds,
    }


def _in_quiet_hours(now: _dt.datetime, quiet_hours: Any) -> bool:
    if not isinstance(quiet_hours, dict):
        return False
    try:
        start = int(quiet_hours.get("start", 23))
        end = int(quiet_hours.get("end", 8))
    except Exception:
        return False
    if start == end:
        return False
    hour = now.hour
    if start < end:
        return start <= hour < end
    return hour >= start or hour < end


def provider_ready(cfg: dict[str, Any]) -> bool:
    base_url = str(cfg.get("base_url") or "").strip()
    main_model = str(cfg.get("main_model") or "").strip()
    state_model = str(cfg.get("state_model") or "").strip()
    review_model = str(cfg.get("review_model") or "").strip()
    if not (base_url and main_model and state_model and review_model):
        return False
    return True


def proactive_decision(
    profile_name: str = DEFAULT_PROFILE,
    *,
    base_dir: str | Path | None = None,
    provider_cfg: dict[str, Any] | None = None,
    now: _dt.datetime | None = None,
) -> dict[str, Any]:
    cfg = provider_cfg or load_provider_config(base_dir)
    profile = load_profile(profile_name, base_dir)
    now = now or _dt.datetime.now()
    snapshot = _history_activity_snapshot(profile, now=now)
    configured = provider_ready(cfg)
    enabled = bool(cfg.get("proactive_enabled", True))
    background_enabled = bool(cfg.get("proactive_background_enabled", True))
    min_idle_seconds = int(cfg.get("proactive_min_idle_seconds") or 900)
    min_gap_seconds = int(cfg.get("proactive_min_gap_seconds") or 1800)
    last_proactive_at = snapshot.get("last_proactive_at")
    idle_seconds = snapshot.get("idle_seconds")
    reason = "ready"
    eligible = enabled
    if not enabled:
        reason = "disabled"
        eligible = False
    elif not configured:
        reason = "provider_unconfigured"
        eligible = False
    elif snapshot["state"] == "empty":
        reason = "no_context"
        eligible = False
    elif _in_quiet_hours(now, cfg.get("proactive_quiet_hours")):
        reason = "quiet_hours"
        eligible = False
    elif idle_seconds is not None and idle_seconds < min_idle_seconds:
        reason = "recent_user_activity"
        eligible = False
    elif last_proactive_at is not None:
        since_last = int((now - last_proactive_at).total_seconds())
        if since_last < max(min_gap_seconds, int(snapshot["recommended_interval_seconds"] or min_gap_seconds)):
            reason = "cooldown"
            eligible = False
    next_check_in_seconds = 0
    if not eligible:
        if reason == "quiet_hours":
            quiet_hours = cfg.get("proactive_quiet_hours") if isinstance(cfg.get("proactive_quiet_hours"), dict) else {}
            start = int(quiet_hours.get("start", 23)) if isinstance(quiet_hours, dict) else 23
            end = int(quiet_hours.get("end", 8)) if isinstance(quiet_hours, dict) else 8
            if start > end:
                if now.hour >= start:
                    next_check_in_seconds = ((24 - now.hour + end) * 3600) - (now.minute * 60 + now.second)
                else:
                    next_check_in_seconds = ((end - now.hour) * 3600) - (now.minute * 60 + now.second)
            elif start < end:
                if now.hour < end:
                    next_check_in_seconds = ((end - now.hour) * 3600) - (now.minute * 60 + now.second)
                else:
                    next_check_in_seconds = ((24 - now.hour + end) * 3600) - (now.minute * 60 + now.second)
            else:
                next_check_in_seconds = max(60, int(cfg.get("proactive_check_interval_seconds") or 120))
        elif reason == "recent_user_activity" and idle_seconds is not None:
            next_check_in_seconds = max(60, min_idle_seconds - int(idle_seconds))
        elif reason == "cooldown" and last_proactive_at is not None:
            since_last = int((now - last_proactive_at).total_seconds())
            target = max(min_gap_seconds, int(snapshot["recommended_interval_seconds"] or min_gap_seconds))
            next_check_in_seconds = max(60, target - since_last)
        else:
            next_check_in_seconds = max(60, int(cfg.get("proactive_check_interval_seconds") or 120))
    return {
        "ok": True,
        "enabled": enabled,
        "background_enabled": background_enabled,
        "configured": configured,
        "eligible": eligible,
        "reason": reason,
        "state": snapshot["state"],
        "idle_seconds": idle_seconds,
        "recent_user_count": snapshot["recent_user_count"],
        "recent_assistant_count": snapshot["recent_assistant_count"],
        "recommended_interval_seconds": snapshot["recommended_interval_seconds"],
        "next_check_in_seconds": next_check_in_seconds,
        "next_check_in": now_iso() if eligible else (_dt.datetime.now() + _dt.timedelta(seconds=next_check_in_seconds)).isoformat(timespec="seconds"),
        "last_user_at": snapshot["last_user_at"].isoformat(timespec="seconds") if snapshot["last_user_at"] else "",
        "last_assistant_at": snapshot["last_assistant_at"].isoformat(timespec="seconds") if snapshot["last_assistant_at"] else "",
        "last_proactive_at": snapshot["last_proactive_at"].isoformat(timespec="seconds") if snapshot["last_proactive_at"] else "",
    }


def extract_memory_notes(user_text: str, assistant_text: str) -> dict[str, list[str]]:
    user = str(user_text or "").strip()
    assistant = str(assistant_text or "").strip()
    notes = {"facts": [], "preferences": [], "boundaries": [], "memories": []}
    if not user:
        return notes
    if any(token in user for token in ("喜欢", "偏好", "想要", "更希望", "不太喜欢")):
        notes["preferences"].append(user[:80])
    if any(token in user for token in ("不要", "别", "不想", "禁止")):
        notes["boundaries"].append(user[:80])
    if any(token in user for token in ("我是", "我叫", "来自", "职业", "年龄")):
        notes["facts"].append(user[:80])
    if assistant:
        notes["memories"].append(f"Q:{user[:40]} | A:{assistant[:80]}")
    return notes


def update_profile_memory(profile: dict[str, Any], user_text: str, assistant_text: str) -> dict[str, Any]:
    notes = extract_memory_notes(user_text, assistant_text)
    profile["facts"] = extend_unique(profile.get("facts") or [], notes["facts"])
    profile["preferences"] = extend_unique(profile.get("preferences") or [], notes["preferences"])
    profile["boundaries"] = extend_unique(profile.get("boundaries") or [], notes["boundaries"])
    profile["memories"] = extend_unique(profile.get("memories") or [], notes["memories"])
    return profile


def record_moment(
    profile: dict[str, Any],
    text: str,
    *,
    visibility: str = "friends",
    mood: str = "neutral",
    source: str = "manual",
    tags: Iterable[str] | None = None,
    kind: str = "text",
    image_path: str = "",
    image_prompt: str = "",
    image_mode: str = "",
) -> dict[str, Any]:
    content = str(text or "").strip()
    if not content:
        return profile
    moment_tags = []
    for item in tags or []:
        tag = str(item or "").strip()
        if tag and tag not in moment_tags:
            moment_tags.append(tag)
    payload = {
        "id": hashlib.sha1(f"{now_iso()}|{source}|{content}".encode("utf-8")).hexdigest()[:12],
        "text": content[:500],
        "visibility": str(visibility or "friends").strip() or "friends",
        "mood": str(mood or "neutral").strip() or "neutral",
        "source": str(source or "manual").strip() or "manual",
        "kind": str(kind or ("image" if str(image_path or "").strip() else "text")).strip() or "text",
        "tags": moment_tags,
        "ts": now_iso(),
        "image_path": str(image_path or "").strip(),
        "image_prompt": str(image_prompt or "").strip()[:500],
        "image_mode": str(image_mode or "").strip(),
    }
    moments = list(profile.get("moments") or [])
    moments.append(payload)
    profile["moments"] = moments[-80:]
    return profile


def list_moments(profile: dict[str, Any], *, limit: int = 30) -> list[dict[str, Any]]:
    moments = [item for item in (profile.get("moments") or []) if isinstance(item, dict)]
    return list(reversed(moments[-max(1, int(limit)) :]))


def delete_moment(profile: dict[str, Any], moment_id: str) -> dict[str, Any]:
    target = str(moment_id or "").strip()
    moments = [item for item in (profile.get("moments") or []) if isinstance(item, dict)]
    kept = []
    removed = []
    for item in moments:
        if str(item.get("id") or "") == target:
            removed.append(item)
        else:
            kept.append(item)
    profile["moments"] = kept
    return profile


def delete_moment_asset(profile_name: str, moment_id: str, base_dir: str | Path | None = None) -> dict[str, Any]:
    profile = load_profile(profile_name, base_dir)
    target = str(moment_id or "").strip()
    moments = [item for item in (profile.get("moments") or []) if isinstance(item, dict)]
    removed: list[dict[str, Any]] = []
    kept: list[dict[str, Any]] = []
    for item in moments:
        if str(item.get("id") or "") == target:
            removed.append(item)
        else:
            kept.append(item)
    profile["moments"] = kept
    save_profile(profile_name, profile, base_dir)
    for item in removed:
        image_path = str(item.get("image_path") or "").strip()
        if not image_path:
            continue
        try:
            resolved = resolve_media_path(image_path, base_dir)
            if resolved.is_file():
                resolved.unlink()
        except Exception:
            pass
    return profile


def append_history(profile: dict[str, Any], role: str, content: str, *, limit: int = 20) -> dict[str, Any]:
    history = list(profile.get("history") or [])
    history.append({"role": role, "content": content, "ts": now_iso()})
    profile["history"] = history[-max(6, int(limit)) :]
    return profile


def trim_history(history: list[dict[str, Any]], limit: int = 20) -> list[dict[str, Any]]:
    return list(history[-max(6, int(limit)) :])


def compose_system_prompt(profile: dict[str, Any], cfg: dict[str, Any] | None = None) -> str:
    cfg = cfg or {}
    parts = [DEFAULT_SYSTEM_PROMPT]
    summary = str(profile.get("summary") or "").strip()
    if summary:
        parts.append(f"当前摘要：{summary}")
    facts = [str(item).strip() for item in (profile.get("facts") or []) if str(item).strip()]
    prefs = [str(item).strip() for item in (profile.get("preferences") or []) if str(item).strip()]
    bds = [str(item).strip() for item in (profile.get("boundaries") or []) if str(item).strip()]
    if facts:
        parts.append("已知事实：" + "；".join(facts[-4:]))
    if prefs:
        parts.append("偏好：" + "；".join(prefs[-4:]))
    if bds:
        parts.append("边界：" + "；".join(bds[-4:]))
    if cfg.get("persona_style"):
        parts.append("风格补充：" + str(cfg.get("persona_style")).strip())
    return "\n".join(parts)


def _network_available(timeout: float = 4.0) -> bool:
    probe_urls = (
        "https://www.gstatic.com/generate_204",
        "https://www.example.com",
    )
    for url in probe_urls:
        req = urlrequest.Request(url, headers={"User-Agent": f"{APP_NAME}/1.0"})
        try:
            with urlrequest.urlopen(req, timeout=timeout, context=ssl.create_default_context()) as resp:
                if 200 <= int(getattr(resp, "status", 0) or 0) < 500:
                    return True
        except Exception:
            continue
    return False


def _fetch_weather_summary(timeout: float = 5.0) -> str:
    req = urlrequest.Request("https://wttr.in/?format=3", headers={"User-Agent": f"{APP_NAME}/1.0"})
    with urlrequest.urlopen(req, timeout=timeout, context=ssl.create_default_context()) as resp:
        raw = resp.read().decode("utf-8", errors="replace").strip()
        return raw[:120]


def build_external_awareness_context(user_msg: str = "", *, enabled: bool = True) -> dict[str, Any]:
    if not enabled:
        return {"enabled": False, "network_ok": None, "weather": "", "summary": "", "prompt_hint": ""}
    network_ok = _network_available()
    weather = ""
    if network_ok:
        try:
            weather = _fetch_weather_summary()
        except Exception:
            weather = ""
    bits = [f"时间：{now_iso().replace('T', ' ')[:19]}"]
    bits.append("联网：正常" if network_ok else "联网：暂时不可用")
    if weather:
        bits.append(f"天气：{weather}")
    if user_msg and any(token in user_msg for token in ("天气", "外面", "今天", "出门", "下雨", "热不热")):
        bits.append("如果用户在问外部环境，优先用当前联网感知回应。")
    summary = " · ".join(bits)
    return {
        "enabled": True,
        "network_ok": network_ok,
        "weather": weather,
        "summary": summary,
        "prompt_hint": f"外部感知：{summary}",
    }


def _merge_headers(global_headers: Any, role_headers: Any) -> dict[str, str]:
    result: dict[str, str] = {}
    for source in (global_headers, role_headers):
        if isinstance(source, str):
            try:
                source = json.loads(source)
            except Exception:
                source = {}
        if isinstance(source, dict):
            for k, v in source.items():
                if str(k).strip():
                    result[str(k).strip()] = str(v)
    return result


def _role_cfg(cfg: dict[str, Any], role: str) -> dict[str, Any]:
    role_cfg = {}
    roles = cfg.get("roles") or {}
    if isinstance(roles, dict) and isinstance(roles.get(role), dict):
        role_cfg.update(roles[role])
    merged = dict(cfg)
    merged.update(role_cfg)
    return merged


def _auth_headers(cfg: dict[str, Any], role: str) -> dict[str, str]:
    merged = _role_cfg(cfg, role)
    headers = {"Content-Type": "application/json"}
    headers.update(_merge_headers(merged.get("headers"), merged.get("headers_json")))
    api_key = str(merged.get("api_key") or "").strip()
    if api_key:
        protocol = str(merged.get("protocol") or "openai_compatible").strip().lower()
        if protocol == "anthropic":
            headers["x-api-key"] = api_key
            headers["anthropic-version"] = str(merged.get("anthropic_version") or "2023-06-01")
        elif protocol == "gemini":
            pass
        else:
            headers["Authorization"] = f"Bearer {api_key}"
    return headers


def _base_url_for(cfg: dict[str, Any], role: str) -> str:
    merged = _role_cfg(cfg, role)
    base_url = str(merged.get("base_url") or cfg.get("base_url") or "").strip()
    return base_url.rstrip("/")


def _json_request(method: str, url: str, *, headers: dict[str, str], payload: dict[str, Any] | None = None, timeout: float = 60.0) -> dict[str, Any]:
    data = None
    if payload is not None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urlrequest.Request(url, data=data, headers=headers, method=method.upper())
    try:
        with urlrequest.urlopen(req, timeout=timeout, context=ssl.create_default_context()) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
            if not raw.strip():
                return {}
            return json.loads(raw)
    except urlerror.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise ProviderError(f"{exc.code}: {body[:240]}") from exc
    except Exception as exc:
        raise ProviderError(str(exc)) from exc


class ProviderError(RuntimeError):
    pass


def _openai_chat(cfg: dict[str, Any], role: str, messages: list[dict[str, str]], *, max_tokens: int = 512, temperature: float = 0.7, response_format: dict[str, Any] | None = None) -> str:
    merged = _role_cfg(cfg, role)
    base_url = _base_url_for(cfg, role)
    if not base_url:
        raise ProviderError("missing base_url")
    url = f"{base_url}/chat/completions"
    payload: dict[str, Any] = {
        "model": str(merged.get("model") or cfg.get(f"{role}_model") or cfg.get("main_model") or "").strip(),
        "messages": messages,
        "max_tokens": max_tokens,
        "temperature": temperature,
        "stream": False,
    }
    if response_format:
        payload["response_format"] = response_format
    data = _json_request("POST", url, headers=_auth_headers(cfg, role), payload=payload)
    choices = data.get("choices") if isinstance(data, dict) else None
    if isinstance(choices, list) and choices:
        choice = choices[0] or {}
        message = choice.get("message") or {}
        content = message.get("content")
        if content is None and isinstance(choice.get("text"), str):
            content = choice["text"]
        if isinstance(content, str):
            return content.strip()
    if isinstance(data.get("output_text"), str):
        return data["output_text"].strip()
    raise ProviderError("empty completion")


def _anthropic_chat(cfg: dict[str, Any], role: str, messages: list[dict[str, str]], *, max_tokens: int = 512, temperature: float = 0.7) -> str:
    merged = _role_cfg(cfg, role)
    base_url = _base_url_for(cfg, role)
    if not base_url:
        raise ProviderError("missing base_url")
    system_parts = [m["content"] for m in messages if m.get("role") == "system"]
    user_messages = [{"role": m["role"], "content": m["content"]} for m in messages if m.get("role") != "system"]
    url = f"{base_url}/messages"
    payload = {
        "model": str(merged.get("model") or cfg.get(f"{role}_model") or "").strip(),
        "system": "\n".join(system_parts).strip(),
        "messages": user_messages,
        "max_tokens": max_tokens,
        "temperature": temperature,
    }
    data = _json_request("POST", url, headers=_auth_headers(cfg, role), payload=payload)
    content = data.get("content")
    if isinstance(content, list):
        text = "".join(str(item.get("text") or "") for item in content if isinstance(item, dict))
        if text.strip():
            return text.strip()
    if isinstance(data.get("completion"), str):
        return data["completion"].strip()
    raise ProviderError("empty completion")


def _gemini_chat(cfg: dict[str, Any], role: str, messages: list[dict[str, str]], *, max_tokens: int = 512, temperature: float = 0.7) -> str:
    merged = _role_cfg(cfg, role)
    base_url = _base_url_for(cfg, role)
    if not base_url:
        raise ProviderError("missing base_url")
    model = str(merged.get("model") or cfg.get(f"{role}_model") or "").strip()
    system_text = "\n".join(m["content"] for m in messages if m.get("role") == "system").strip()
    contents = []
    for msg in messages:
        role_name = msg.get("role")
        if role_name == "system":
            continue
        parts = [{"text": msg.get("content") or ""}]
        contents.append({"role": "user" if role_name == "user" else "model", "parts": parts})
    payload = {
        "contents": contents,
        "generationConfig": {"temperature": temperature, "maxOutputTokens": max_tokens},
    }
    if system_text:
        payload["systemInstruction"] = {"parts": [{"text": system_text}]}
    url = f"{base_url}/models/{model}:generateContent"
    data = _json_request("POST", url, headers=_auth_headers(cfg, role), payload=payload)
    candidates = data.get("candidates") if isinstance(data, dict) else None
    if isinstance(candidates, list) and candidates:
        cand = candidates[0] or {}
        content = cand.get("content") or {}
        parts = content.get("parts") if isinstance(content, dict) else None
        if isinstance(parts, list):
            text = "".join(str(item.get("text") or "") for item in parts if isinstance(item, dict))
            if text.strip():
                return text.strip()
    raise ProviderError("empty completion")


def provider_chat(cfg: dict[str, Any], role: str, messages: list[dict[str, str]], *, max_tokens: int = 512, temperature: float = 0.7, response_format: dict[str, Any] | None = None) -> str:
    protocol = str(cfg.get("protocol") or "openai_compatible").strip().lower()
    if protocol == "anthropic":
        return _anthropic_chat(cfg, role, messages, max_tokens=max_tokens, temperature=temperature)
    if protocol == "gemini":
        return _gemini_chat(cfg, role, messages, max_tokens=max_tokens, temperature=temperature)
    return _openai_chat(cfg, role, messages, max_tokens=max_tokens, temperature=temperature, response_format=response_format)


def provider_models(cfg: dict[str, Any], role: str | None = None) -> list[dict[str, Any]]:
    models = []
    if role:
        model = str(_role_cfg(cfg, role).get("model") or cfg.get(f"{role}_model") or "").strip()
        if model:
            models.append({"id": model, "role": role})
        return models
    for role_name in ("main", "state", "review"):
        model = str(_role_cfg(cfg, role_name).get("model") or cfg.get(f"{role_name}_model") or "").strip()
        if model:
            models.append({"id": model, "role": role_name})
    image_model = str(cfg.get("image_model") or "").strip()
    if image_model:
        models.append({"id": image_model, "role": "image"})
    return models


def _load_share_font(size: int) -> Any:
    candidates = [
        Path(__file__).resolve().parent / "assets" / "fonts" / "MiSansVF.ttf",
        Path(__file__).resolve().parent / "assets" / "fonts" / "NotoSansCJK-Regular.ttc",
        Path(__file__).resolve().parent / "MiSansVF.ttf",
        Path(__file__).resolve().parent / "NotoSansCJK-Regular.ttc",
        Path("/system/fonts/MiSansVF.ttf"),
        Path("/system/fonts/NotoSansCJK-Regular.ttc"),
    ]
    try:
        from PIL import ImageFont  # type: ignore

        for candidate in candidates:
            try:
                if candidate.is_file():
                    return ImageFont.truetype(str(candidate), size=size)
            except Exception:
                continue
        return ImageFont.load_default()
    except Exception:
        return None


def _wrap_text(draw: Any, text: str, font: Any, max_width: int) -> list[str]:
    raw = " ".join(str(text or "").split())
    if not raw:
        return []
    lines: list[str] = []
    current = ""
    for ch in raw:
        trial = current + ch
        try:
            width = draw.textlength(trial, font=font)
        except Exception:
            width = len(trial) * 12
        if current and width > max_width:
            lines.append(current)
            current = ch
        else:
            current = trial
    if current:
        lines.append(current)
    return lines


def _style_palette(style: str, mood: str) -> tuple[tuple[int, int, int], tuple[int, int, int], tuple[int, int, int], tuple[int, int, int]]:
    key = f"{style}|{mood}"
    digest = hashlib.sha1(key.encode("utf-8")).digest()
    colors = []
    for index in range(4):
        base = digest[index * 3 : index * 3 + 3]
        colors.append((70 + base[0] % 140, 70 + base[1] % 140, 70 + base[2] % 140))
    return colors[0], colors[1], colors[2], colors[3]


def _provider_image_prompt(profile: dict[str, Any], user_prompt: str, style: str, mood: str) -> str:
    display_name = str(profile.get("display_name") or profile.get("name") or DEFAULT_PROFILE).strip()
    summary = str(profile.get("summary") or "").strip()
    memories = [str(item).strip() for item in (profile.get("memories") or []) if str(item).strip()]
    context_bits = [f"角色：{display_name}"]
    if summary:
        context_bits.append(f"状态：{summary[:120]}")
    if memories:
        context_bits.append(f"记忆：{memories[-1][:90]}")
    prompt = str(user_prompt or "").strip()
    if not prompt:
        prompt = "适合朋友圈分享的日常照片，真实、自然、有生活感"
    style = str(style or "朋友圈感").strip()
    mood = str(mood or "平静").strip()
    return f"{style}，{mood}，{prompt}。{ '；'.join(context_bits) }。画面干净，细节丰富，适合分享。"


def _provider_image_bytes(cfg: dict[str, Any], prompt: str) -> tuple[bytes | None, dict[str, Any]]:
    base_url = str(cfg.get("base_url") or "").strip().rstrip("/")
    api_key = str(cfg.get("api_key") or "").strip()
    model = str(cfg.get("image_model") or "").strip()
    if not (base_url and model):
        return None, {"mode": "local", "reason": "missing_image_config"}
    headers = {"Content-Type": "application/json"}
    headers.update(_merge_headers(cfg.get("headers"), None))
    protocol = str(cfg.get("protocol") or "openai_compatible").strip().lower()
    if api_key:
        if protocol == "anthropic":
            headers["x-api-key"] = api_key
            headers["anthropic-version"] = str(cfg.get("anthropic_version") or "2023-06-01")
        else:
            headers["Authorization"] = f"Bearer {api_key}"
    payload: dict[str, Any] = {"model": model, "prompt": prompt, "n": 1}
    size = str(cfg.get("image_size") or "1024x1024").strip()
    if size:
        payload["size"] = size
    payload["response_format"] = "b64_json"
    try:
        data = _json_request("POST", f"{base_url}/images/generations", headers=headers, payload=payload, timeout=120.0)
    except Exception as exc:
        return None, {"mode": "local", "reason": str(exc)}
    items = data.get("data") if isinstance(data, dict) else None
    if isinstance(items, list) and items:
        item = items[0] or {}
        if isinstance(item, dict):
            if item.get("b64_json"):
                try:
                    raw_b64 = str(item["b64_json"]).strip()
                    if "," in raw_b64 and raw_b64.lower().startswith("data:"):
                        raw_b64 = raw_b64.split(",", 1)[1]
                    return base64.b64decode(raw_b64), {"mode": "provider", "provider": protocol, "model": model, "revised_prompt": str(item.get("revised_prompt") or prompt)}
                except Exception as exc:
                    return None, {"mode": "local", "reason": str(exc)}
            image_url = str(item.get("url") or "").strip()
            if image_url:
                try:
                    req = urlrequest.Request(image_url, headers={"User-Agent": f"{APP_NAME}/1.0"})
                    with urlrequest.urlopen(req, timeout=120.0, context=ssl.create_default_context()) as resp:
                        return resp.read(), {"mode": "provider", "provider": protocol, "model": model, "revised_prompt": str(item.get("revised_prompt") or prompt)}
                except Exception as exc:
                    return None, {"mode": "local", "reason": str(exc)}
    return None, {"mode": "local", "reason": "empty_image_response"}


def render_local_share_image(profile: dict[str, Any], prompt: str, *, style: str = "朋友圈感", mood: str = "平静", title: str = "") -> bytes:
    from PIL import Image, ImageDraw, ImageFilter  # type: ignore

    width, height = 1080, 1440
    top, bottom, accent_a, accent_b = _style_palette(style, mood)
    base = Image.new("RGB", (width, height), bottom)
    gradient = Image.new("L", (1, height))
    for y in range(height):
        gradient.putpixel((0, y), int(255 * y / max(1, height - 1)))
    gradient = gradient.resize((width, height))
    overlay_top = Image.new("RGB", (width, height), top)
    base = Image.composite(overlay_top, base, gradient)
    layer = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    draw = ImageDraw.Draw(layer)
    random.seed(hashlib.sha1(f"{style}|{mood}|{prompt}".encode("utf-8")).hexdigest())
    for _ in range(7):
        r = random.randint(90, 220)
        x = random.randint(-120, width - 60)
        y = random.randint(-80, height - 60)
        color = (
            int((accent_a[0] + random.randint(-30, 30)) % 255),
            int((accent_a[1] + random.randint(-30, 30)) % 255),
            int((accent_a[2] + random.randint(-30, 30)) % 255),
            random.randint(40, 90),
        )
        draw.ellipse((x, y, x + r, y + r), fill=color)
    for _ in range(4):
        w = random.randint(180, 420)
        h = random.randint(22, 52)
        x = random.randint(60, width - w - 60)
        y = random.randint(120, height - h - 120)
        draw.rounded_rectangle((x, y, x + w, y + h), radius=h // 2, fill=(
            int((accent_b[0] + random.randint(-20, 20)) % 255),
            int((accent_b[1] + random.randint(-20, 20)) % 255),
            int((accent_b[2] + random.randint(-20, 20)) % 255),
            random.randint(22, 48),
        ))
    layer = layer.filter(ImageFilter.GaussianBlur(30))
    canvas = Image.alpha_composite(base.convert("RGBA"), layer)
    draw = ImageDraw.Draw(canvas)

    card_margin = 72
    card_top = 140
    card_bottom = height - 160
    draw.rounded_rectangle((card_margin, card_top, width - card_margin, card_bottom), radius=42, fill=(255, 255, 255, 240))
    draw.rounded_rectangle((card_margin, card_top, width - card_margin, card_bottom), radius=42, outline=(255, 255, 255, 160), width=2)

    avatar_box = (card_margin + 44, card_top + 44)
    avatar_size = 110
    initials = _initials(str(profile.get("display_name") or profile.get("name") or DEFAULT_PROFILE))
    draw.ellipse((avatar_box[0], avatar_box[1], avatar_box[0] + avatar_size, avatar_box[1] + avatar_size), fill=accent_a + (255,))
    avatar_font = _load_share_font(48)
    if avatar_font is not None:
        try:
            bbox = draw.textbbox((0, 0), initials[:2], font=avatar_font)
            tw = bbox[2] - bbox[0]
            th = bbox[3] - bbox[1]
        except Exception:
            tw = th = 0
        draw.text((avatar_box[0] + (avatar_size - tw) / 2, avatar_box[1] + (avatar_size - th) / 2 - 4), initials[:2], font=avatar_font, fill=(255, 255, 255, 255))

    title_font = _load_share_font(38)
    sub_font = _load_share_font(24)
    body_font = _load_share_font(34)
    small_font = _load_share_font(22)
    name = str(profile.get("display_name") or profile.get("name") or DEFAULT_PROFILE)
    draw.text((card_margin + 176, card_top + 52), name, font=title_font, fill=(24, 28, 36, 255))
    meta_line = f"{style} · {mood}"
    draw.text((card_margin + 176, card_top + 104), meta_line, font=sub_font, fill=(86, 92, 104, 255))

    body_top = card_top + 190
    body_left = card_margin + 44
    body_right = width - card_margin - 44
    body_text = str(prompt or "").strip() or "今天想分享一点轻松的生活感。"
    lines = _wrap_text(draw, body_text, body_font, body_right - body_left)
    cursor_y = body_top
    for line in lines[:12]:
        draw.text((body_left, cursor_y), line, font=body_font, fill=(28, 32, 42, 255))
        try:
            bbox = draw.textbbox((0, 0), line, font=body_font)
            line_h = bbox[3] - bbox[1]
        except Exception:
            line_h = 38
        cursor_y += max(48, line_h + 10)

    footer_text = f"{now_iso().replace('T', ' ')[:19]}  ·  Companion"
    draw.text((body_left, card_bottom - 66), footer_text, font=small_font, fill=(112, 118, 128, 255))

    final = canvas.convert("RGB").filter(ImageFilter.SMOOTH_MORE)
    import io

    buffer = io.BytesIO()
    final.save(buffer, format="PNG", optimize=True)
    return buffer.getvalue()


def generate_share_image(
    profile_name: str,
    prompt: str,
    *,
    base_dir: str | Path | None = None,
    provider_cfg: dict[str, Any] | None = None,
    style: str = "朋友圈感",
    mood: str = "平静",
    title: str = "",
) -> dict[str, Any]:
    cfg = provider_cfg or load_provider_config(base_dir)
    profile = load_profile(profile_name, base_dir)
    refined_prompt = _provider_image_prompt(profile, prompt, style, mood)
    image_bytes, meta = _provider_image_bytes(cfg, refined_prompt)
    if image_bytes is None:
        image_bytes = render_local_share_image(profile, prompt or refined_prompt, style=style, mood=mood, title=title)
    image_id = hashlib.sha1(f"{now_iso()}|{profile_name}|{prompt}|{style}|{mood}".encode("utf-8")).hexdigest()[:14]
    folder = profile_media_root(profile_name, base_dir)
    path = folder / f"{image_id}.png"
    path.write_bytes(image_bytes)
    rel_path = str(path.relative_to(ensure_tree(base_dir)["root"]))
    result = {
        "ok": True,
        "profile": profile_name,
        "image_id": image_id,
        "image_path": rel_path,
        "image_abs_path": str(path),
        "prompt": prompt,
        "refined_prompt": refined_prompt,
        "mode": str(meta.get("mode") or "local"),
        "provider": str(meta.get("provider") or ""),
        "model": str(meta.get("model") or cfg.get("image_model") or ""),
        "revised_prompt": str(meta.get("revised_prompt") or refined_prompt),
        "title": title or prompt[:40] or "分享图",
    }
    return result


def provider_health(cfg: dict[str, Any], role: str) -> dict[str, Any]:
    try:
        model = str(_role_cfg(cfg, role).get("model") or cfg.get(f"{role}_model") or "").strip()
        if not model:
            return {"ok": False, "role": role, "error": "missing_model"}
        reply = provider_chat(
            cfg,
            role,
            [{"role": "system", "content": "只回复 ok。"}, {"role": "user", "content": "ok"}],
            max_tokens=8,
            temperature=0.0,
        )
        return {"ok": bool(reply), "role": role, "reply": reply[:80], "model": model}
    except Exception as exc:
        return {"ok": False, "role": role, "error": str(exc)}


def needs_review(text: str) -> bool:
    lowered = str(text or "").lower()
    if not lowered.strip():
        return False
    drift_flags = ["as an ai", "i am an ai", "assistant", "system prompt", "model", "openai", "claude", "gemini"]
    if any(flag in lowered for flag in drift_flags):
        return True
    if len(text.strip()) > 220:
        return True
    return False


def rewrite_with_review(cfg: dict[str, Any], profile: dict[str, Any], user_text: str, draft: str) -> str:
    if not cfg.get("rewrite_on_drift", True):
        return draft
    if not needs_review(draft):
        return draft
    review_model = str(_role_cfg(cfg, "review").get("model") or cfg.get("review_model") or "").strip()
    if not review_model:
        return draft
    messages = [
        {"role": "system", "content": "只做轻量润色，不改变含义。让回复更自然，更像真人，避免 AI 腔、套话和生硬转折，尽量简短。"},
        {"role": "user", "content": f"用户原话：{user_text}\n原始回复：{draft}\n请直接输出润色后的回复："},
    ]
    try:
        rewritten = provider_chat(cfg, "review", messages, max_tokens=min(200, max(60, len(draft) + 40)), temperature=0.35)
        return rewritten.strip() or draft
    except Exception:
        return draft


def build_chat_messages(profile: dict[str, Any], user_text: str, cfg: dict[str, Any] | None = None) -> list[dict[str, str]]:
    cfg = cfg or {}
    history = list(profile.get("history") or [])
    history = trim_history(history, int(cfg.get("history_limit") or 20))
    messages = [{"role": "system", "content": compose_system_prompt(profile, cfg)}]
    summary = str(profile.get("summary") or "").strip()
    if summary:
        messages.append({"role": "system", "content": f"历史摘要：{summary}"})
    external = build_external_awareness_context(user_text, enabled=bool(cfg.get("external_awareness_enabled", True)))
    if external.get("prompt_hint"):
        messages.append({"role": "system", "content": external["prompt_hint"]})
    for item in history:
        role = str(item.get("role") or "assistant").strip() or "assistant"
        content = str(item.get("content") or "").strip()
        if content:
            messages.append({"role": role, "content": content})
    messages.append({"role": "user", "content": user_text})
    return messages


def summarise_profile(profile: dict[str, Any]) -> str:
    facts = [str(item).strip() for item in (profile.get("facts") or []) if str(item).strip()]
    prefs = [str(item).strip() for item in (profile.get("preferences") or []) if str(item).strip()]
    bds = [str(item).strip() for item in (profile.get("boundaries") or []) if str(item).strip()]
    bits = []
    if facts:
        bits.append("事实：" + "；".join(facts[-3:]))
    if prefs:
        bits.append("偏好：" + "；".join(prefs[-3:]))
    if bds:
        bits.append("边界：" + "；".join(bds[-3:]))
    return "\n".join(bits)


def chat_turn(
    user_text: str,
    profile_name: str = DEFAULT_PROFILE,
    *,
    base_dir: str | Path | None = None,
    provider_cfg: dict[str, Any] | None = None,
    temperature: float = 0.75,
) -> dict[str, Any]:
    cfg = provider_cfg or load_provider_config(base_dir)
    profile = load_profile(profile_name, base_dir)
    history_limit = int(cfg.get("history_limit") or 20)
    touch_profile_activity(profile, "user")
    append_history(profile, "user", user_text, limit=history_limit)
    messages = build_chat_messages(profile, user_text, cfg)
    draft = provider_chat(cfg, "main", messages, max_tokens=512, temperature=temperature)
    reply = rewrite_with_review(cfg, profile, user_text, draft)
    touch_profile_activity(profile, "assistant")
    append_history(profile, "assistant", reply, limit=history_limit)
    update_profile_memory(profile, user_text, reply)
    profile["summary"] = summarise_profile(profile)
    save_profile(profile_name, profile, base_dir)
    return {"ok": True, "profile": profile_name, "reply": reply, "draft": draft, "provider": cfg.get("protocol"), "updated_at": now_iso()}


def proactive_turn(
    profile_name: str = DEFAULT_PROFILE,
    *,
    base_dir: str | Path | None = None,
    provider_cfg: dict[str, Any] | None = None,
    temperature: float = 0.75,
    force: bool = True,
) -> dict[str, Any]:
    cfg = provider_cfg or load_provider_config(base_dir)
    profile = load_profile(profile_name, base_dir)
    decision = proactive_decision(profile_name, base_dir=base_dir, provider_cfg=cfg)
    if not force and not decision.get("eligible"):
        return {"ok": True, "skipped": True, "decision": decision, "profile": profile_name}
    messages = [
        {"role": "system", "content": compose_system_prompt(profile, cfg)},
        {"role": "system", "content": build_external_awareness_context("", enabled=bool(cfg.get("external_awareness_enabled", True))).get("prompt_hint") or ""},
        {
            "role": "system",
            "content": (
                "你现在要主动发起一段自然对话。"
                "目标是真实、轻微、不打扰，像一个会看状态的人在找话题。"
                "不要提系统提示词、模型、平台或训练过程。"
                f"当前状态：{decision['state']}，距离上次用户交互约 {format_duration(decision.get('idle_seconds'))}。"
                "如果状态偏忙，就更短一点；如果状态偏静，就自然一点。"
            ),
        },
    ]
    draft = provider_chat(cfg, "main", messages, max_tokens=256, temperature=temperature)
    reply = rewrite_with_review(cfg, profile, "", draft)
    touch_profile_activity(profile, "assistant", kind="proactive")
    append_history(profile, "assistant", reply, limit=int(cfg.get("history_limit") or 20))
    if bool(cfg.get("moments_auto_post_enabled", False)):
        record_moment(profile, reply, visibility="friends", mood="warm", source="proactive", tags=["主动消息"])
    profile["summary"] = summarise_profile(profile)
    save_profile(profile_name, profile, base_dir)
    return {"ok": True, "profile": profile_name, "reply": reply, "draft": draft, "provider": cfg.get("protocol"), "updated_at": now_iso(), "decision": decision}


def export_profile(profile_name: str, base_dir: str | Path | None = None) -> dict[str, Any]:
    profile = load_profile(profile_name, base_dir)
    return json.loads(json.dumps(profile, ensure_ascii=False))


def import_profile(profile_name: str, payload: dict[str, Any], base_dir: str | Path | None = None) -> dict[str, Any]:
    profile = default_profile_state(profile_name)
    if isinstance(payload, dict):
        profile.update(payload)
    return save_profile(profile_name, profile, base_dir)
