from __future__ import annotations

import datetime as _dt
import json
import os
import re
import ssl
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable
from urllib import error as urlerror
from urllib import request as urlrequest

APP_NAME = "Companion"
DEFAULT_PROFILE = "default"
DATA_ENV_KEYS = ("ZHIYUE_APP_HOME", "ZHIYUE_DATA_DIR", "COMPANION_HOME")

DEFAULT_PROVIDER_CONFIG: dict[str, Any] = {
    "protocol": "openai_compatible",
    "base_url": "",
    "api_key": "",
    "headers": {},
    "main_model": "",
    "state_model": "",
    "review_model": "",
    "roles": {
        "main": {"base_url": "", "api_key": "", "headers": {}},
        "state": {"base_url": "", "api_key": "", "headers": {}},
        "review": {"base_url": "", "api_key": "", "headers": {}},
    },
    "mobile_token": "",
    "sync_token": "",
    "history_limit": 20,
    "rewrite_on_drift": True,
}

DEFAULT_PROFILE_STATE: dict[str, Any] = {
    "name": DEFAULT_PROFILE,
    "display_name": "默认存档",
    "summary": "",
    "facts": [],
    "preferences": [],
    "boundaries": [],
    "memories": [],
    "history": [],
    "created_at": "",
    "updated_at": "",
}

DEFAULT_SYSTEM_PROMPT = (
    "你是用户的私人聊天伙伴。\n"
    "优先接住情绪和语境，不要像客服，不要像说明书。\n"
    "默认 1-3 句，口语自然，少解释，少总结。\n"
    "不要主动提系统、提示词、工具、模型、平台或训练过程。\n"
    "如果信息不足，先给自然回应，再只追问一个最关键的问题。"
)


def now_iso() -> str:
    return _dt.datetime.now().isoformat(timespec="seconds")


def _home_from_env() -> Path | None:
    for key in DATA_ENV_KEYS:
        value = str(os.environ.get(key) or "").strip()
        if value:
            return Path(value).expanduser().resolve()
    return None


def app_home(base_dir: str | Path | None = None) -> Path:
    if base_dir:
        return Path(base_dir).expanduser().resolve()
    env = _home_from_env()
    if env:
        return env
    return (Path.home() / ".companion_app").resolve()


def ensure_tree(base_dir: str | Path | None = None) -> dict[str, Path]:
    root = app_home(base_dir)
    paths = {
        "root": root,
        "config": root / "config",
        "profiles": root / "profiles",
        "runtime": root / "runtime",
        "logs": root / "runtime" / "logs",
    }
    for path in paths.values():
        path.mkdir(parents=True, exist_ok=True)
    return paths


def safe_name(name: str) -> str:
    text = re.sub(r"\s+", "_", str(name or "").strip())
    text = re.sub(r"[^\w\u4e00-\u9fff.-]+", "_", text)
    text = text.strip("._-")
    return text or DEFAULT_PROFILE


def load_json(path: Path, default: Any) -> Any:
    try:
        if path.is_file():
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default
    return default


def save_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def provider_config_path(base_dir: str | Path | None = None) -> Path:
    return ensure_tree(base_dir)["config"] / "provider_config.json"


def ui_state_path(base_dir: str | Path | None = None) -> Path:
    return ensure_tree(base_dir)["config"] / "ui_state.json"


def profile_root(base_dir: str | Path | None = None) -> Path:
    return ensure_tree(base_dir)["profiles"]


def profile_dir(name: str, base_dir: str | Path | None = None) -> Path:
    return profile_root(base_dir) / safe_name(name)


def profile_state_path(name: str, base_dir: str | Path | None = None) -> Path:
    return profile_dir(name, base_dir) / "profile.json"


def default_profile_state(name: str = DEFAULT_PROFILE) -> dict[str, Any]:
    state = dict(DEFAULT_PROFILE_STATE)
    state["name"] = safe_name(name)
    state["display_name"] = "默认存档" if state["name"] == DEFAULT_PROFILE else name
    state["created_at"] = now_iso()
    state["updated_at"] = now_iso()
    return state


def load_provider_config(base_dir: str | Path | None = None) -> dict[str, Any]:
    raw = load_json(provider_config_path(base_dir), {})
    cfg = json.loads(json.dumps(DEFAULT_PROVIDER_CONFIG, ensure_ascii=False))
    if isinstance(raw, dict):
        cfg.update({k: v for k, v in raw.items() if k != "roles"})
        roles = cfg.get("roles") or {}
        if isinstance(raw.get("roles"), dict):
            for role_name, role_cfg in raw["roles"].items():
                if role_name not in roles or not isinstance(role_cfg, dict):
                    continue
                roles[role_name].update(role_cfg)
        cfg["roles"] = roles
    return cfg


def save_provider_config(cfg: dict[str, Any], base_dir: str | Path | None = None) -> dict[str, Any]:
    clean = json.loads(json.dumps(DEFAULT_PROVIDER_CONFIG, ensure_ascii=False))
    if isinstance(cfg, dict):
        for key, value in cfg.items():
            if key == "roles":
                continue
            clean[key] = value
        if isinstance(cfg.get("roles"), dict):
            for role_name, role_cfg in cfg["roles"].items():
                if role_name not in clean["roles"] or not isinstance(role_cfg, dict):
                    continue
                clean["roles"][role_name].update(role_cfg)
    save_json(provider_config_path(base_dir), clean)
    return clean


def load_ui_state(base_dir: str | Path | None = None) -> dict[str, Any]:
    raw = load_json(ui_state_path(base_dir), {})
    state = {"active_profile": DEFAULT_PROFILE, "screen": "chat"}
    if isinstance(raw, dict):
        state.update({k: v for k, v in raw.items() if k in {"active_profile", "screen"}})
    state["active_profile"] = safe_name(str(state.get("active_profile") or DEFAULT_PROFILE))
    state["screen"] = str(state.get("screen") or "chat")
    return state


def save_ui_state(state: dict[str, Any], base_dir: str | Path | None = None) -> dict[str, Any]:
    clean = load_ui_state(base_dir)
    if isinstance(state, dict):
        clean.update({k: v for k, v in state.items() if k in {"active_profile", "screen"}})
    clean["active_profile"] = safe_name(str(clean.get("active_profile") or DEFAULT_PROFILE))
    clean["screen"] = str(clean.get("screen") or "chat")
    save_json(ui_state_path(base_dir), clean)
    return clean


def list_profiles(base_dir: str | Path | None = None) -> list[dict[str, Any]]:
    root = profile_root(base_dir)
    items: list[dict[str, Any]] = []
    for folder in sorted(root.iterdir(), key=lambda p: p.name.lower() if p.is_dir() else p.name):
        if not folder.is_dir():
            continue
        state_path = folder / "profile.json"
        state = load_json(state_path, {})
        if not isinstance(state, dict):
            continue
        state.setdefault("name", folder.name)
        state.setdefault("display_name", folder.name)
        state["exists"] = True
        state["item_count"] = len(state.get("history") or [])
        items.append(state)
    if not items:
        ensure_profile(DEFAULT_PROFILE, base_dir=base_dir)
        return list_profiles(base_dir)
    return items


def ensure_profile(name: str = DEFAULT_PROFILE, *, base_dir: str | Path | None = None, display_name: str | None = None) -> dict[str, Any]:
    folder = profile_dir(name, base_dir)
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / "profile.json"
    state = load_json(path, default_profile_state(name))
    if not isinstance(state, dict):
        state = default_profile_state(name)
    state["name"] = safe_name(name)
    if display_name:
        state["display_name"] = display_name
    state.setdefault("display_name", name)
    state.setdefault("summary", "")
    state.setdefault("facts", [])
    state.setdefault("preferences", [])
    state.setdefault("boundaries", [])
    state.setdefault("memories", [])
    state.setdefault("history", [])
    state.setdefault("created_at", now_iso())
    state["updated_at"] = now_iso()
    save_json(path, state)
    return state


def load_profile(name: str = DEFAULT_PROFILE, base_dir: str | Path | None = None) -> dict[str, Any]:
    path = profile_state_path(name, base_dir)
    if not path.is_file():
        return ensure_profile(name, base_dir=base_dir)
    state = load_json(path, default_profile_state(name))
    if not isinstance(state, dict):
        state = default_profile_state(name)
    return state


def save_profile(name: str, state: dict[str, Any], base_dir: str | Path | None = None) -> dict[str, Any]:
    clean = default_profile_state(name)
    if isinstance(state, dict):
        clean.update(state)
    clean["name"] = safe_name(name)
    clean["updated_at"] = now_iso()
    save_json(profile_state_path(name, base_dir), clean)
    return clean


def delete_profile(name: str, base_dir: str | Path | None = None) -> None:
    folder = profile_dir(name, base_dir)
    if folder.is_dir():
        for child in folder.iterdir():
            if child.is_file():
                child.unlink(missing_ok=True)
            elif child.is_dir():
                import shutil

                shutil.rmtree(child, ignore_errors=True)
        folder.rmdir()


def extend_unique(items: Iterable[str], additions: Iterable[str], *, limit: int = 25) -> list[str]:
    cleaned = [str(item).strip() for item in items if str(item).strip()]
    for addition in additions:
        candidate = str(addition).strip()
        if candidate and candidate not in cleaned:
            cleaned.append(candidate)
    return cleaned[-max(1, int(limit)) :]


def extract_memory_notes(user_text: str, assistant_text: str) -> dict[str, list[str]]:
    user = str(user_text or "").strip()
    assistant = str(assistant_text or "").strip()
    notes = {"facts": [], "preferences": [], "boundaries": [], "memories": []}
    if not user:
        return notes
    if any(token in user for token in ("喜欢", "爱", "偏好", "讨厌")):
        notes["preferences"].append(user[:80])
    if any(token in user for token in ("不要", "别", "不要再", "别再")):
        notes["boundaries"].append(user[:80])
    if any(token in user for token in ("我叫", "我是", "我在", "我用", "我有")):
        notes["facts"].append(user[:80])
    if assistant:
        notes["memories"].append(f"Q:{user[:40]} | A:{assistant[:80]}")
    return notes


def update_profile_memory(profile: dict[str, Any], user_text: str, assistant_text: str) -> dict[str, Any]:
    notes = extract_memory_notes(user_text, assistant_text)
    profile["facts"] = extend_unique(profile.get("facts") or [], notes["facts"])
    profile["preferences"] = extend_unique(profile.get("preferences") or [], notes["preferences"])
    profile["boundaries"] = extend_unique(profile.get("boundaries") or [], notes["boundaries"])
    profile["memories"] = extend_unique(profile.get("memories") or [], notes["memories"])
    return profile


def append_history(profile: dict[str, Any], role: str, content: str, *, limit: int = 20) -> dict[str, Any]:
    history = list(profile.get("history") or [])
    history.append({"role": role, "content": content, "ts": now_iso()})
    profile["history"] = history[-max(6, int(limit)) :]
    return profile


def trim_history(history: list[dict[str, Any]], limit: int = 20) -> list[dict[str, Any]]:
    return list(history[-max(6, int(limit)) :])


def compose_system_prompt(profile: dict[str, Any], cfg: dict[str, Any] | None = None) -> str:
    cfg = cfg or {}
    parts = [DEFAULT_SYSTEM_PROMPT]
    summary = str(profile.get("summary") or "").strip()
    if summary:
        parts.append(f"最近摘要：{summary}")
    facts = [str(item).strip() for item in (profile.get("facts") or []) if str(item).strip()]
    prefs = [str(item).strip() for item in (profile.get("preferences") or []) if str(item).strip()]
    bds = [str(item).strip() for item in (profile.get("boundaries") or []) if str(item).strip()]
    if facts:
        parts.append("已知事实：" + "；".join(facts[-4:]))
    if prefs:
        parts.append("偏好：" + "；".join(prefs[-4:]))
    if bds:
        parts.append("边界：" + "；".join(bds[-4:]))
    if cfg.get("persona_style"):
        parts.append("风格约束：" + str(cfg.get("persona_style")).strip())
    return "\n".join(parts)


def _merge_headers(global_headers: Any, role_headers: Any) -> dict[str, str]:
    result: dict[str, str] = {}
    for source in (global_headers, role_headers):
        if isinstance(source, str):
            try:
                source = json.loads(source)
            except Exception:
                source = {}
        if isinstance(source, dict):
            for k, v in source.items():
                if str(k).strip():
                    result[str(k).strip()] = str(v)
    return result


def _role_cfg(cfg: dict[str, Any], role: str) -> dict[str, Any]:
    role_cfg = {}
    roles = cfg.get("roles") or {}
    if isinstance(roles, dict) and isinstance(roles.get(role), dict):
        role_cfg.update(roles[role])
    merged = dict(cfg)
    merged.update(role_cfg)
    return merged


def _auth_headers(cfg: dict[str, Any], role: str) -> dict[str, str]:
    merged = _role_cfg(cfg, role)
    headers = {"Content-Type": "application/json"}
    headers.update(_merge_headers(merged.get("headers"), merged.get("headers_json")))
    api_key = str(merged.get("api_key") or "").strip()
    if api_key:
        protocol = str(merged.get("protocol") or "openai_compatible").strip().lower()
        if protocol == "anthropic":
            headers["x-api-key"] = api_key
            headers["anthropic-version"] = str(merged.get("anthropic_version") or "2023-06-01")
        elif protocol == "gemini":
            pass
        else:
            headers["Authorization"] = f"Bearer {api_key}"
    return headers


def _base_url_for(cfg: dict[str, Any], role: str) -> str:
    merged = _role_cfg(cfg, role)
    base_url = str(merged.get("base_url") or cfg.get("base_url") or "").strip()
    return base_url.rstrip("/")


def _json_request(method: str, url: str, *, headers: dict[str, str], payload: dict[str, Any] | None = None, timeout: float = 60.0) -> dict[str, Any]:
    data = None
    if payload is not None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urlrequest.Request(url, data=data, headers=headers, method=method.upper())
    try:
        with urlrequest.urlopen(req, timeout=timeout, context=ssl.create_default_context()) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
            if not raw.strip():
                return {}
            return json.loads(raw)
    except urlerror.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise ProviderError(f"{exc.code}: {body[:240]}") from exc
    except Exception as exc:
        raise ProviderError(str(exc)) from exc


class ProviderError(RuntimeError):
    pass


def _openai_chat(cfg: dict[str, Any], role: str, messages: list[dict[str, str]], *, max_tokens: int = 512, temperature: float = 0.7, response_format: dict[str, Any] | None = None) -> str:
    merged = _role_cfg(cfg, role)
    base_url = _base_url_for(cfg, role)
    if not base_url:
        raise ProviderError("missing base_url")
    url = f"{base_url}/chat/completions"
    payload: dict[str, Any] = {
        "model": str(merged.get("model") or cfg.get(f"{role}_model") or cfg.get("main_model") or "").strip(),
        "messages": messages,
        "max_tokens": max_tokens,
        "temperature": temperature,
        "stream": False,
    }
    if response_format:
        payload["response_format"] = response_format
    data = _json_request("POST", url, headers=_auth_headers(cfg, role), payload=payload)
    choices = data.get("choices") if isinstance(data, dict) else None
    if isinstance(choices, list) and choices:
        choice = choices[0] or {}
        message = choice.get("message") or {}
        content = message.get("content")
        if content is None and isinstance(choice.get("text"), str):
            content = choice["text"]
        if isinstance(content, str):
            return content.strip()
    if isinstance(data.get("output_text"), str):
        return data["output_text"].strip()
    raise ProviderError("empty completion")


def _anthropic_chat(cfg: dict[str, Any], role: str, messages: list[dict[str, str]], *, max_tokens: int = 512, temperature: float = 0.7) -> str:
    merged = _role_cfg(cfg, role)
    base_url = _base_url_for(cfg, role)
    if not base_url:
        raise ProviderError("missing base_url")
    system_parts = [m["content"] for m in messages if m.get("role") == "system"]
    user_messages = [{"role": m["role"], "content": m["content"]} for m in messages if m.get("role") != "system"]
    url = f"{base_url}/messages"
    payload = {
        "model": str(merged.get("model") or cfg.get(f"{role}_model") or "").strip(),
        "system": "\n".join(system_parts).strip(),
        "messages": user_messages,
        "max_tokens": max_tokens,
        "temperature": temperature,
    }
    data = _json_request("POST", url, headers=_auth_headers(cfg, role), payload=payload)
    content = data.get("content")
    if isinstance(content, list):
        text = "".join(str(item.get("text") or "") for item in content if isinstance(item, dict))
        if text.strip():
            return text.strip()
    if isinstance(data.get("completion"), str):
        return data["completion"].strip()
    raise ProviderError("empty completion")


def _gemini_chat(cfg: dict[str, Any], role: str, messages: list[dict[str, str]], *, max_tokens: int = 512, temperature: float = 0.7) -> str:
    merged = _role_cfg(cfg, role)
    base_url = _base_url_for(cfg, role)
    if not base_url:
        raise ProviderError("missing base_url")
    model = str(merged.get("model") or cfg.get(f"{role}_model") or "").strip()
    system_text = "\n".join(m["content"] for m in messages if m.get("role") == "system").strip()
    contents = []
    for msg in messages:
        role_name = msg.get("role")
        if role_name == "system":
            continue
        parts = [{"text": msg.get("content") or ""}]
        contents.append({"role": "user" if role_name == "user" else "model", "parts": parts})
    payload = {
        "contents": contents,
        "generationConfig": {"temperature": temperature, "maxOutputTokens": max_tokens},
    }
    if system_text:
        payload["systemInstruction"] = {"parts": [{"text": system_text}]}
    url = f"{base_url}/models/{model}:generateContent"
    data = _json_request("POST", url, headers=_auth_headers(cfg, role), payload=payload)
    candidates = data.get("candidates") if isinstance(data, dict) else None
    if isinstance(candidates, list) and candidates:
        cand = candidates[0] or {}
        content = cand.get("content") or {}
        parts = content.get("parts") if isinstance(content, dict) else None
        if isinstance(parts, list):
            text = "".join(str(item.get("text") or "") for item in parts if isinstance(item, dict))
            if text.strip():
                return text.strip()
    raise ProviderError("empty completion")


def provider_chat(cfg: dict[str, Any], role: str, messages: list[dict[str, str]], *, max_tokens: int = 512, temperature: float = 0.7, response_format: dict[str, Any] | None = None) -> str:
    protocol = str(cfg.get("protocol") or "openai_compatible").strip().lower()
    if protocol == "anthropic":
        return _anthropic_chat(cfg, role, messages, max_tokens=max_tokens, temperature=temperature)
    if protocol == "gemini":
        return _gemini_chat(cfg, role, messages, max_tokens=max_tokens, temperature=temperature)
    return _openai_chat(cfg, role, messages, max_tokens=max_tokens, temperature=temperature, response_format=response_format)


def provider_models(cfg: dict[str, Any], role: str | None = None) -> list[dict[str, Any]]:
    models = []
    if role:
        model = str(_role_cfg(cfg, role).get("model") or cfg.get(f"{role}_model") or "").strip()
        if model:
            models.append({"id": model, "role": role})
        return models
    for role_name in ("main", "state", "review"):
        model = str(_role_cfg(cfg, role_name).get("model") or cfg.get(f"{role_name}_model") or "").strip()
        if model:
            models.append({"id": model, "role": role_name})
    return models


def provider_health(cfg: dict[str, Any], role: str) -> dict[str, Any]:
    try:
        model = str(_role_cfg(cfg, role).get("model") or cfg.get(f"{role}_model") or "").strip()
        if not model:
            return {"ok": False, "role": role, "error": "missing_model"}
        reply = provider_chat(
            cfg,
            role,
            [{"role": "system", "content": "只回复 ok"}, {"role": "user", "content": "ok"}],
            max_tokens=8,
            temperature=0.0,
        )
        return {"ok": bool(reply), "role": role, "reply": reply[:80], "model": model}
    except Exception as exc:
        return {"ok": False, "role": role, "error": str(exc)}


def needs_review(text: str) -> bool:
    lowered = str(text or "").lower()
    if not lowered.strip():
        return False
    drift_flags = ["as an ai", "i am an ai", "assistant", "system prompt", "model", "openai", "claude", "gemini"]
    if any(flag in lowered for flag in drift_flags):
        return True
    if len(text.strip()) > 220:
        return True
    return False


def rewrite_with_review(cfg: dict[str, Any], profile: dict[str, Any], user_text: str, draft: str) -> str:
    if not cfg.get("rewrite_on_drift", True):
        return draft
    if not needs_review(draft):
        return draft
    review_model = str(_role_cfg(cfg, "review").get("model") or cfg.get("review_model") or "").strip()
    if not review_model:
        return draft
    messages = [
        {"role": "system", "content": "你只负责改写，不解释。把回复改得更自然、更像真实聊天，避免AI/工具自曝，保持原意，简短一点。"},
        {"role": "user", "content": f"用户：{user_text}\n原回复：{draft}\n请直接输出改写后的回复："},
    ]
    try:
        rewritten = provider_chat(cfg, "review", messages, max_tokens=min(200, max(60, len(draft) + 40)), temperature=0.35)
        return rewritten.strip() or draft
    except Exception:
        return draft


def build_chat_messages(profile: dict[str, Any], user_text: str, cfg: dict[str, Any] | None = None) -> list[dict[str, str]]:
    cfg = cfg or {}
    history = list(profile.get("history") or [])
    history = trim_history(history, int(cfg.get("history_limit") or 20))
    messages = [{"role": "system", "content": compose_system_prompt(profile, cfg)}]
    summary = str(profile.get("summary") or "").strip()
    if summary:
        messages.append({"role": "system", "content": f"历史摘要：{summary}"})
    for item in history:
        role = str(item.get("role") or "assistant").strip() or "assistant"
        content = str(item.get("content") or "").strip()
        if content:
            messages.append({"role": role, "content": content})
    messages.append({"role": "user", "content": user_text})
    return messages


def summarise_profile(profile: dict[str, Any]) -> str:
    facts = [str(item).strip() for item in (profile.get("facts") or []) if str(item).strip()]
    prefs = [str(item).strip() for item in (profile.get("preferences") or []) if str(item).strip()]
    bds = [str(item).strip() for item in (profile.get("boundaries") or []) if str(item).strip()]
    bits = []
    if facts:
        bits.append("事实:" + "；".join(facts[-3:]))
    if prefs:
        bits.append("偏好:" + "；".join(prefs[-3:]))
    if bds:
        bits.append("边界:" + "；".join(bds[-3:]))
    return "\n".join(bits)


def chat_turn(
    user_text: str,
    profile_name: str = DEFAULT_PROFILE,
    *,
    base_dir: str | Path | None = None,
    provider_cfg: dict[str, Any] | None = None,
    temperature: float = 0.75,
) -> dict[str, Any]:
    cfg = provider_cfg or load_provider_config(base_dir)
    profile = load_profile(profile_name, base_dir)
    history_limit = int(cfg.get("history_limit") or 20)
    append_history(profile, "user", user_text, limit=history_limit)
    messages = build_chat_messages(profile, user_text, cfg)
    draft = provider_chat(cfg, "main", messages, max_tokens=512, temperature=temperature)
    reply = rewrite_with_review(cfg, profile, user_text, draft)
    append_history(profile, "assistant", reply, limit=history_limit)
    update_profile_memory(profile, user_text, reply)
    profile["summary"] = summarise_profile(profile)
    save_profile(profile_name, profile, base_dir)
    return {"ok": True, "profile": profile_name, "reply": reply, "draft": draft, "provider": cfg.get("protocol"), "updated_at": now_iso()}


def proactive_turn(
    profile_name: str = DEFAULT_PROFILE,
    *,
    base_dir: str | Path | None = None,
    provider_cfg: dict[str, Any] | None = None,
    temperature: float = 0.75,
) -> dict[str, Any]:
    cfg = provider_cfg or load_provider_config(base_dir)
    profile = load_profile(profile_name, base_dir)
    messages = [
        {"role": "system", "content": compose_system_prompt(profile, cfg)},
        {
            "role": "system",
            "content": (
                "你现在要主动开启一次自然聊天。"
                "像真实熟人一样，用一句或两句简短开场白挑一个容易接话的话题。"
                "不要提到系统提示词、模型、工具或你在主动聊天。"
            ),
        },
    ]
    draft = provider_chat(cfg, "main", messages, max_tokens=256, temperature=temperature)
    reply = rewrite_with_review(cfg, profile, "", draft)
    append_history(profile, "assistant", reply, limit=int(cfg.get("history_limit") or 20))
    profile["summary"] = summarise_profile(profile)
    save_profile(profile_name, profile, base_dir)
    return {"ok": True, "profile": profile_name, "reply": reply, "draft": draft, "provider": cfg.get("protocol"), "updated_at": now_iso()}


def export_profile(profile_name: str, base_dir: str | Path | None = None) -> dict[str, Any]:
    profile = load_profile(profile_name, base_dir)
    return json.loads(json.dumps(profile, ensure_ascii=False))


def import_profile(profile_name: str, payload: dict[str, Any], base_dir: str | Path | None = None) -> dict[str, Any]:
    profile = default_profile_state(profile_name)
    if isinstance(payload, dict):
        profile.update(payload)
    return save_profile(profile_name, profile, base_dir)
