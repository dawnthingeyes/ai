from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from urllib import request as urlrequest


ROOT = Path(__file__).resolve().parent


def _get_json(url: str, timeout: float = 3.0) -> dict:
    with urlrequest.urlopen(url, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _post_json(url: str, payload: dict, timeout: float = 5.0) -> dict:
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urlrequest.Request(url, data=data, headers={"Content-Type": "application/json"}, method="POST")
    with urlrequest.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _wait(url: str, timeout_s: float = 10.0) -> bool:
    end = time.time() + timeout_s
    while time.time() < end:
        try:
            _get_json(url, timeout=1.5)
            return True
        except Exception:
            time.sleep(0.2)
    return False


def main() -> int:
    tmp = Path(tempfile.mkdtemp(prefix="companion_smoke_"))
    mock = subprocess.Popen([sys.executable, str(ROOT / "mock_openai_server.py")], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    svc_out = tmp / "service.out.log"
    svc_err = tmp / "service.err.log"
    try:
        cfg_dir = tmp / "config"
        cfg_dir.mkdir(parents=True, exist_ok=True)
        (cfg_dir / "provider_config.json").write_text(
            json.dumps(
                {
                    "protocol": "openai_compatible",
                    "base_url": "http://127.0.0.1:9010/v1",
                    "api_key": "",
                    "headers": {},
                    "main_model": "mock-main",
                    "state_model": "mock-state",
                    "review_model": "mock-review",
                    "roles": {
                        "main": {"base_url": "", "api_key": "", "headers": {}},
                        "state": {"base_url": "", "api_key": "", "headers": {}},
                        "review": {"base_url": "", "api_key": "", "headers": {}},
                    },
                    "mobile_token": "",
                    "sync_token": "",
                    "history_limit": 10,
                    "rewrite_on_drift": True,
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
        env = os.environ.copy()
        env["ZHIYUE_APP_HOME"] = str(tmp)
        env["ZHIYUE_PORT"] = "8908"
        svc = subprocess.Popen(
            [sys.executable, str(ROOT / "service.py")],
            env=env,
            stdout=svc_out.open("wb"),
            stderr=svc_err.open("wb"),
        )
        try:
            base = "http://127.0.0.1:8908"
            if not _wait(base + "/api/health", 12):
                print("FAIL: health timeout")
                print("--- service stdout ---")
                print(svc_out.read_text(encoding="utf-8", errors="replace"))
                print("--- service stderr ---")
                print(svc_err.read_text(encoding="utf-8", errors="replace"))
                return 2
            health = _get_json(base + "/api/health")
            if not health.get("ok"):
                print("FAIL: health not ok")
                return 2
            profiles = _get_json(base + "/api/profiles")
            if not profiles.get("profiles"):
                print("FAIL: missing default profile")
                return 2
            test = _post_json(base + "/api/provider/test", {"roles": ["main", "state", "review"]})
            if not test.get("ok"):
                print("FAIL: provider test failed", test)
                return 2
            sync_health = _get_json(base + "/api/mobile-sync/health")
            if not sync_health.get("ok"):
                print("FAIL: sync health failed", sync_health)
                return 2
            sync_pull = _post_json(base + "/api/mobile-sync/pull", {"profile": "default"})
            if sync_pull.get("profile") != "default":
                print("FAIL: sync pull failed", sync_pull)
                return 2
            proactive = _get_json(base + "/api/proactive/status")
            if not proactive.get("ok"):
                print("FAIL: proactive status failed", proactive)
                return 2
            chat = _post_json(base + "/api/chat", {"profile": "default", "message": "你好"})
            if "mock:你好" not in str(chat.get("reply") or ""):
                print("FAIL: chat reply mismatch", chat)
                return 2
            proactive_turn = _post_json(base + "/api/chat/proactive", {"profile": "default", "respect_state": True})
            if proactive_turn.get("skipped") not in {True, False, None}:
                print("FAIL: proactive turn malformed", proactive_turn)
                return 2
            device_action = _post_json(base + "/api/device/action", {"action": "home", "dry_run": True})
            if not device_action.get("ok") or device_action.get("action") != "home":
                print("FAIL: device action failed", device_action)
                return 2
            v1 = _post_json(
                base + "/v1/chat/completions",
                {"profile": "default", "messages": [{"role": "user", "content": "再来一句"}], "model": "mock-main"},
            )
            if "choices" not in v1:
                print("FAIL: v1 response missing choices", v1)
                return 2
            print("OK: smoke test passed")
            return 0
        finally:
            for proc in (svc,):
                try:
                    proc.terminate()
                except Exception:
                    pass
            try:
                svc.wait(timeout=3)
            except Exception:
                try:
                    svc.kill()
                except Exception:
                    pass
    finally:
        try:
            mock.terminate()
        except Exception:
            pass
        try:
            mock.wait(timeout=3)
        except Exception:
            try:
                mock.kill()
            except Exception:
                pass
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())
