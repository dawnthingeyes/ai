from __future__ import annotations

import json
import os
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import app_core as core


BASE_DIR = Path(os.environ.get("ZHIYUE_APP_HOME") or os.environ.get("ANDROID_PRIVATE") or "").expanduser().resolve() if os.environ.get("ZHIYUE_APP_HOME") or os.environ.get("ANDROID_PRIVATE") else core.app_home()
PORT = int(os.environ.get("ZHIYUE_PORT", "8908"))
HOST = os.environ.get("ZHIYUE_HOST", "127.0.0.1").strip() or "127.0.0.1"


def _auth_token(headers: dict[str, str], query: dict[str, list[str]]) -> str:
    bearer = str(headers.get("Authorization") or "").strip()
    if bearer.lower().startswith("bearer "):
        return bearer[7:].strip()
    return (
        str(headers.get("X-Companion-Token") or "").strip()
        or str(query.get("token", [""])[0]).strip()
    )


def _check_required_token(headers: dict[str, str], query: dict[str, list[str]], *, kind: str) -> bool:
    cfg = core.load_provider_config(BASE_DIR)
    expected = str(cfg.get(f"{kind}_token") or "").strip()
    if not expected:
        return True
    if _auth_token(headers, query) != expected:
        return False
    return True


class CompanionHandler(BaseHTTPRequestHandler):
    server_version = "Companion/1.0"

    def log_message(self, *_):
        return

    def _path(self) -> str:
        return urlparse(self.path).path

    def _query(self) -> dict[str, list[str]]:
        return parse_qs(urlparse(self.path).query)

    def _read_json(self) -> dict:
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0:
            return {}
        raw = self.rfile.read(length).decode("utf-8", errors="replace").strip()
        if not raw:
            return {}
        data = json.loads(raw)
        return data if isinstance(data, dict) else {}

    def _send_json(self, payload: dict, status: int = 200):
        raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def _require_mobile(self) -> bool:
        return _check_required_token(dict(self.headers), self._query(), kind="mobile")

    def _require_sync(self) -> bool:
        return _check_required_token(dict(self.headers), self._query(), kind="sync")

    def do_GET(self):
        path = self._path()
        if path == "/api/health":
            cfg = core.load_provider_config(BASE_DIR)
            configured = any(str(cfg.get(key) or "").strip() for key in ("base_url", "main_model", "state_model", "review_model"))
            self._send_json(
                {
                    "ok": True,
                    "configured": configured,
                    "profiles": len(core.list_profiles(BASE_DIR)),
                    "active_profile": core.load_ui_state(BASE_DIR).get("active_profile"),
                }
            )
            return
        if path == "/api/provider/config":
            if not self._require_mobile():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            cfg = core.load_provider_config(BASE_DIR)
            masked = dict(cfg)
            for secret_key in ("api_key", "mobile_token", "sync_token"):
                if masked.get(secret_key):
                    masked[secret_key] = "***"
            for role_name, role_cfg in (masked.get("roles") or {}).items():
                if isinstance(role_cfg, dict) and role_cfg.get("api_key"):
                    role_cfg["api_key"] = "***"
            self._send_json({"ok": True, "config": masked})
            return
        if path == "/api/profiles":
            if not self._require_mobile():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            active = core.load_ui_state(BASE_DIR).get("active_profile") or core.DEFAULT_PROFILE
            self._send_json({"ok": True, "active_profile": active, "profiles": core.list_profiles(BASE_DIR)})
            return
        if path == "/api/chat/history":
            if not self._require_mobile():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            profile_name = core.safe_name(self._query().get("profile", [core.DEFAULT_PROFILE])[0])
            profile = core.load_profile(profile_name, BASE_DIR)
            self._send_json({"ok": True, "profile": profile_name, "history": profile.get("history") or [], "summary": profile.get("summary") or ""})
            return
        if path == "/api/mobile-sync/health":
            if not self._require_sync():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            self._send_json({"ok": True, "profiles": len(core.list_profiles(BASE_DIR)), "active_profile": core.load_ui_state(BASE_DIR).get("active_profile")})
            return
        if path == "/api/mobile-sync/pull":
            if not self._require_sync():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            profile_name = core.safe_name(self._query().get("profile", [core.DEFAULT_PROFILE])[0])
            profile = core.load_profile(profile_name, BASE_DIR)
            self._send_json({"ok": True, "profile": profile_name, "profile_state": profile, "provider_config": core.load_provider_config(BASE_DIR)})
            return
        if path == "/v1/models":
            if not self._require_mobile():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            cfg = core.load_provider_config(BASE_DIR)
            models = []
            for item in core.provider_models(cfg):
                models.append({"id": item["id"], "object": "model", "owned_by": item.get("role") or "provider"})
            if not models:
                models = [
                    {"id": "main", "object": "model", "owned_by": "main"},
                    {"id": "state", "object": "model", "owned_by": "state"},
                    {"id": "review", "object": "model", "owned_by": "review"},
                ]
            self._send_json({"object": "list", "data": models})
            return
        self._send_json({"ok": False, "error": "not_found"}, 404)

    def do_POST(self):
        path = self._path()
        payload = self._read_json()
        if path == "/api/provider/config":
            if not self._require_mobile():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            cfg = core.save_provider_config(payload if isinstance(payload, dict) else {}, BASE_DIR)
            self._send_json({"ok": True, "config": cfg})
            return
        if path == "/api/provider/test":
            if not self._require_mobile():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            cfg = core.load_provider_config(BASE_DIR)
            roles = payload.get("roles") if isinstance(payload.get("roles"), list) else ["main", "state", "review"]
            results = {role: core.provider_health(cfg, role) for role in roles if str(role) in {"main", "state", "review"}}
            self._send_json({"ok": all(item.get("ok") for item in results.values()), "results": results})
            return
        if path == "/api/profiles":
            if not self._require_mobile():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            name = core.safe_name(str(payload.get("profile") or payload.get("profile_name") or core.DEFAULT_PROFILE))
            display_name = str(payload.get("display_name") or name).strip()
            state = core.ensure_profile(name, base_dir=BASE_DIR, display_name=display_name)
            core.save_ui_state({"active_profile": name}, BASE_DIR)
            self._send_json({"ok": True, "profile": state})
            return
        if path == "/api/chat":
            if not self._require_mobile():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            message = str(payload.get("message") or payload.get("text") or "").strip()
            if not message:
                self._send_json({"ok": False, "error": "missing_message"}, 400)
                return
            profile_name = core.safe_name(str(payload.get("profile") or payload.get("profile_name") or core.DEFAULT_PROFILE))
            cfg = core.load_provider_config(BASE_DIR)
            try:
                result = core.chat_turn(message, profile_name, base_dir=BASE_DIR, provider_cfg=cfg)
                self._send_json(result)
            except Exception as exc:
                self._send_json({"ok": False, "error": str(exc)}, 500)
            return
        if path == "/api/mobile-sync/pull":
            if not self._require_sync():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            profile_name = core.safe_name(str(payload.get("profile") or payload.get("profile_name") or core.DEFAULT_PROFILE))
            profile = core.load_profile(profile_name, BASE_DIR)
            self._send_json({"ok": True, "profile": profile_name, "profile_state": profile, "provider_config": core.load_provider_config(BASE_DIR)})
            return
        if path == "/api/mobile-sync/push":
            if not self._require_sync():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            profile_name = core.safe_name(str(payload.get("profile") or payload.get("profile_name") or core.DEFAULT_PROFILE))
            incoming = payload.get("profile_state") if isinstance(payload.get("profile_state"), dict) else {}
            merged = core.import_profile(profile_name, incoming, BASE_DIR)
            self._send_json({"ok": True, "profile": profile_name, "profile_state": merged})
            return
        if path == "/v1/chat/completions":
            if not self._require_mobile():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            messages = payload.get("messages") if isinstance(payload.get("messages"), list) else []
            profile_name = core.safe_name(str(payload.get("profile") or payload.get("profile_name") or core.DEFAULT_PROFILE))
            cfg = core.load_provider_config(BASE_DIR)
            if not messages:
                user_text = str(payload.get("input") or payload.get("message") or "").strip()
                if not user_text:
                    self._send_json({"error": "missing_messages"}, 400)
                    return
                try:
                    result = core.chat_turn(user_text, profile_name, base_dir=BASE_DIR, provider_cfg=cfg)
                    reply = result["reply"]
                except Exception as exc:
                    self._send_json({"error": str(exc)}, 500)
                    return
            else:
                profile = core.load_profile(profile_name, BASE_DIR)
                prompt = core.compose_system_prompt(profile, cfg)
                raw_messages = [{"role": "system", "content": prompt}]
                for message in messages[-20:]:
                    if isinstance(message, dict):
                        role = str(message.get("role") or "user")
                        content = str(message.get("content") or "")
                        if content.strip():
                            raw_messages.append({"role": role, "content": content})
                try:
                    reply = core.provider_chat(
                        cfg,
                        "main",
                        raw_messages,
                        max_tokens=int(payload.get("max_tokens") or 512),
                        temperature=float(payload.get("temperature") or 0.75),
                    )
                    last_user = ""
                    for message in reversed(messages):
                        if isinstance(message, dict) and str(message.get("role") or "").lower() == "user":
                            last_user = str(message.get("content") or "")
                            break
                    reply = core.rewrite_with_review(cfg, profile, last_user, reply)
                    if last_user:
                        core.append_history(profile, "user", last_user, limit=int(cfg.get("history_limit") or 20))
                    core.append_history(profile, "assistant", reply, limit=int(cfg.get("history_limit") or 20))
                    core.update_profile_memory(profile, last_user, reply)
                    profile["summary"] = core.summarise_profile(profile)
                    core.save_profile(profile_name, profile, BASE_DIR)
                except Exception as exc:
                    self._send_json({"error": str(exc)}, 500)
                    return
            timestamp = int(time.time())
            self._send_json(
                {
                    "id": f"chatcmpl-{timestamp}",
                    "object": "chat.completion",
                    "created": timestamp,
                    "model": str(payload.get("model") or core.load_provider_config(BASE_DIR).get("main_model") or "main"),
                    "choices": [
                        {
                            "index": 0,
                            "message": {"role": "assistant", "content": reply},
                            "finish_reason": "stop",
                        }
                    ],
                }
            )
            return
        self._send_json({"ok": False, "error": "not_found"}, 404)

    def do_DELETE(self):
        path = self._path()
        if path.startswith("/api/profiles/"):
            if not self._require_mobile():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            name = core.safe_name(path.rsplit("/", 1)[-1])
            if name == core.DEFAULT_PROFILE:
                state = core.ensure_profile(name, base_dir=BASE_DIR)
            else:
                core.delete_profile(name, BASE_DIR)
                state = core.ensure_profile(core.DEFAULT_PROFILE, base_dir=BASE_DIR)
                core.save_ui_state({"active_profile": core.DEFAULT_PROFILE}, BASE_DIR)
            self._send_json({"ok": True, "profile": state})
            return
        self._send_json({"ok": False, "error": "not_found"}, 404)

    def do_PATCH(self):
        path = self._path()
        if path.startswith("/api/profiles/"):
            if not self._require_mobile():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            name = core.safe_name(path.rsplit("/", 1)[-1])
            payload = self._read_json()
            state = core.load_profile(name, BASE_DIR)
            if isinstance(payload, dict):
                if "display_name" in payload:
                    state["display_name"] = str(payload["display_name"]).strip() or name
                if payload.get("clear"):
                    state = core.default_profile_state(name)
                    state["display_name"] = str(payload.get("display_name") or state["display_name"])
                if payload.get("reset_memory"):
                    state["summary"] = ""
                    state["facts"] = []
                    state["preferences"] = []
                    state["boundaries"] = []
                    state["memories"] = []
                    state["history"] = []
            core.save_profile(name, state, BASE_DIR)
            self._send_json({"ok": True, "profile": state})
            return
        self._send_json({"ok": False, "error": "not_found"}, 404)


def main() -> int:
    core.ensure_tree(BASE_DIR)
    server = ThreadingHTTPServer((HOST, PORT), CompanionHandler)
    print(f"Companion service listening on http://{HOST}:{PORT}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

