from __future__ import annotations

import json
import os
import time
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse
from urllib import request as urlrequest
from urllib import error as urlerror

import app_core as core
import device_actions as device


BASE_DIR = core.app_home()
PORT = int(os.environ.get("ZHIYUE_PORT", "8908"))
HOST = os.environ.get("ZHIYUE_HOST", "127.0.0.1").strip() or "127.0.0.1"
STATE_LOCK = threading.RLock()
BACKGROUND_STOP = threading.Event()
BACKGROUND_THREAD: threading.Thread | None = None
SERVER_THREAD: threading.Thread | None = None


def _health_url() -> str:
    return f"http://{HOST}:{PORT}/api/health"


def is_running(timeout: float = 0.6) -> bool:
    try:
        with urlrequest.urlopen(_health_url(), timeout=timeout) as resp:
            return 200 <= getattr(resp, "status", 0) < 500
    except Exception:
        return False


def _serve() -> None:
    try:
        main()
    except Exception:
        return


def ensure_running(wait_seconds: float = 2.0) -> bool:
    global SERVER_THREAD
    if is_running():
        return True
    if SERVER_THREAD is None or not SERVER_THREAD.is_alive():
        SERVER_THREAD = threading.Thread(target=_serve, daemon=True, name="companion-http")
        SERVER_THREAD.start()
    deadline = time.time() + max(0.0, float(wait_seconds))
    while time.time() < deadline:
        if is_running():
            return True
        time.sleep(0.1)
    return is_running()


def _auth_token(headers: dict[str, str], query: dict[str, list[str]]) -> str:
    bearer = str(headers.get("Authorization") or "").strip()
    if bearer.lower().startswith("bearer "):
        return bearer[7:].strip()
    return (
        str(headers.get("X-Companion-Token") or "").strip()
        or str(query.get("token", [""])[0]).strip()
    )


def _check_required_token(headers: dict[str, str], query: dict[str, list[str]], *, kind: str) -> bool:
    cfg = core.load_provider_config(BASE_DIR)
    expected = str(cfg.get(f"{kind}_token") or "").strip()
    if not expected:
        return True
    if _auth_token(headers, query) != expected:
        return False
    return True


def _notify_local(title: str, text: str) -> bool:
    message = str(text or "").strip()
    if not message:
        return False
    try:
        from plyer import notification  # type: ignore

        notification.notify(title=title, message=message, app_name="Companion", timeout=5)
        return True
    except Exception:
        pass
    try:
        from jnius import autoclass  # type: ignore

        PythonActivity = autoclass("org.kivy.android.PythonActivity")
        Context = autoclass("android.content.Context")
        BuildVersion = autoclass("android.os.Build$VERSION")
        Build = autoclass("android.os.Build")
        NotificationChannel = autoclass("android.app.NotificationChannel")
        NotificationManager = autoclass("android.app.NotificationManager")
        NotificationBuilder = autoclass("androidx.core.app.NotificationCompat$Builder")

        context = PythonActivity.mActivity
        manager = context.getSystemService(Context.NOTIFICATION_SERVICE)
        channel_id = "companion_proactive"
        if int(BuildVersion.SDK_INT) >= 26:
            channel = NotificationChannel(channel_id, "Companion", NotificationManager.IMPORTANCE_DEFAULT)
            manager.createNotificationChannel(channel)
        builder = NotificationBuilder(context, channel_id)
        builder.setContentTitle(title)
        builder.setContentText(message[:120])
        builder.setSmallIcon(context.getApplicationInfo().icon)
        builder.setAutoCancel(True)
        manager.notify(int(time.time()) & 0x7FFFFFFF, builder.build())
        return True
    except Exception:
        try:
            from jnius import autoclass  # type: ignore

            PythonActivity = autoclass("org.kivy.android.PythonActivity")
            Context = autoclass("android.content.Context")
            BuildVersion = autoclass("android.os.Build$VERSION")
            Build = autoclass("android.os.Build")
            NotificationChannel = autoclass("android.app.NotificationChannel")
            NotificationManager = autoclass("android.app.NotificationManager")
            NotificationBuilder = autoclass("android.app.Notification$Builder")

            context = PythonActivity.mActivity
            manager = context.getSystemService(Context.NOTIFICATION_SERVICE)
            channel_id = "companion_proactive"
            if int(BuildVersion.SDK_INT) >= 26:
                channel = NotificationChannel(channel_id, "Companion", NotificationManager.IMPORTANCE_DEFAULT)
                manager.createNotificationChannel(channel)
                builder = NotificationBuilder(context, channel_id)
            else:
                builder = NotificationBuilder(context)
            builder.setContentTitle(title)
            builder.setContentText(message[:120])
            builder.setSmallIcon(context.getApplicationInfo().icon)
            builder.setAutoCancel(True)
            manager.notify(int(time.time()) & 0x7FFFFFFF, builder.build())
            return True
        except Exception:
            return False


def _background_proactive_loop():
    while not BACKGROUND_STOP.is_set():
        try:
            cfg = core.load_provider_config(BASE_DIR)
            interval = max(30, int(cfg.get("proactive_check_interval_seconds") or 120))
            if not bool(cfg.get("proactive_background_enabled", True)):
                BACKGROUND_STOP.wait(interval)
                continue
            if not core.provider_ready(cfg):
                BACKGROUND_STOP.wait(interval)
                continue
            active_profile = core.load_ui_state(BASE_DIR).get("active_profile") or core.DEFAULT_PROFILE
            decision = core.proactive_decision(active_profile, base_dir=BASE_DIR, provider_cfg=cfg)
            if decision.get("eligible"):
                with STATE_LOCK:
                    result = core.proactive_turn(active_profile, base_dir=BASE_DIR, provider_cfg=cfg, force=False)
                if not result.get("skipped"):
                    if bool(cfg.get("proactive_push_notifications", True)):
                        _notify_local("Companion 主动消息", str(result.get("reply") or "").strip() or "收到一条主动消息")
                decision = result.get("decision") or decision
            interval = max(30, int(decision.get("next_check_in_seconds") or interval))
            BACKGROUND_STOP.wait(interval)
        except Exception:
            BACKGROUND_STOP.wait(60)


class CompanionHandler(BaseHTTPRequestHandler):
    server_version = "Companion/1.0"

    def log_message(self, *_):
        return

    def _path(self) -> str:
        return urlparse(self.path).path

    def _query(self) -> dict[str, list[str]]:
        return parse_qs(urlparse(self.path).query)

    def _read_json(self) -> dict:
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0:
            return {}
        raw = self.rfile.read(length).decode("utf-8", errors="replace").strip()
        if not raw:
            return {}
        data = json.loads(raw)
        return data if isinstance(data, dict) else {}

    def _send_json(self, payload: dict, status: int = 200):
        raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def _require_mobile(self) -> bool:
        return _check_required_token(dict(self.headers), self._query(), kind="mobile")

    def _require_sync(self) -> bool:
        return _check_required_token(dict(self.headers), self._query(), kind="sync")

    def do_GET(self):
        path = self._path()
        if path == "/api/health":
            cfg = core.load_provider_config(BASE_DIR)
            configured = core.provider_ready(cfg)
            active_profile = core.load_ui_state(BASE_DIR).get("active_profile") or core.DEFAULT_PROFILE
            self._send_json(
                {
                    "ok": True,
                    "configured": configured,
                    "profiles": len(core.list_profiles(BASE_DIR)),
                    "active_profile": active_profile,
                    "proactive": core.proactive_decision(active_profile, base_dir=BASE_DIR, provider_cfg=cfg),
                }
            )
            return
        if path == "/api/proactive/status":
            if not self._require_mobile():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            cfg = core.load_provider_config(BASE_DIR)
            active_profile = core.load_ui_state(BASE_DIR).get("active_profile") or core.DEFAULT_PROFILE
            self._send_json({"ok": True, "profile": active_profile, "decision": core.proactive_decision(active_profile, base_dir=BASE_DIR, provider_cfg=cfg)})
            return
        if path == "/api/provider/config":
            if not self._require_mobile():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            cfg = core.load_provider_config(BASE_DIR)
            masked = dict(cfg)
            for secret_key in ("api_key", "mobile_token", "sync_token"):
                if masked.get(secret_key):
                    masked[secret_key] = "***"
            for role_name, role_cfg in (masked.get("roles") or {}).items():
                if isinstance(role_cfg, dict) and role_cfg.get("api_key"):
                    role_cfg["api_key"] = "***"
            self._send_json({"ok": True, "config": masked})
            return
        if path == "/api/profiles":
            if not self._require_mobile():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            active = core.load_ui_state(BASE_DIR).get("active_profile") or core.DEFAULT_PROFILE
            self._send_json({"ok": True, "active_profile": active, "profiles": core.list_profiles(BASE_DIR)})
            return
        if path == "/api/chat/history":
            if not self._require_mobile():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            profile_name = core.safe_name(self._query().get("profile", [core.DEFAULT_PROFILE])[0])
            profile = core.load_profile(profile_name, BASE_DIR)
            self._send_json({"ok": True, "profile": profile_name, "history": profile.get("history") or [], "summary": profile.get("summary") or ""})
            return
        if path == "/api/external/context":
            if not self._require_mobile():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            profile_name = core.safe_name(self._query().get("profile", [core.DEFAULT_PROFILE])[0])
            profile = core.load_profile(profile_name, BASE_DIR)
            external = core.build_external_awareness_context("", enabled=bool(core.load_provider_config(BASE_DIR).get("external_awareness_enabled", True)))
            self._send_json({"ok": True, "profile": profile_name, "external": external, "device": device.read_device_status(), "profile_state": profile})
            return
        if path == "/api/memory":
            if not self._require_mobile():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            profile_name = core.safe_name(self._query().get("profile", [core.DEFAULT_PROFILE])[0])
            profile = core.load_profile(profile_name, BASE_DIR)
            self._send_json(
                {
                    "ok": True,
                    "profile": profile_name,
                    "profile_state": profile,
                    "history": profile.get("history") or [],
                    "moments": core.list_moments(profile, limit=50),
                    "memory_stats": {
                        "facts": len(profile.get("facts") or []),
                        "preferences": len(profile.get("preferences") or []),
                        "boundaries": len(profile.get("boundaries") or []),
                        "memories": len(profile.get("memories") or []),
                        "moments": len(profile.get("moments") or []),
                    },
                }
            )
            return
        if path == "/api/moments":
            if not self._require_mobile():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            profile_name = core.safe_name(self._query().get("profile", [core.DEFAULT_PROFILE])[0])
            profile = core.load_profile(profile_name, BASE_DIR)
            self._send_json({"ok": True, "profile": profile_name, "moments": core.list_moments(profile, limit=50), "profile_state": profile})
            return
        if path == "/api/mobile-sync/health":
            if not self._require_sync():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            self._send_json({"ok": True, "profiles": len(core.list_profiles(BASE_DIR)), "active_profile": core.load_ui_state(BASE_DIR).get("active_profile")})
            return
        if path == "/api/mobile-sync/pull":
            if not self._require_sync():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            profile_name = core.safe_name(self._query().get("profile", [core.DEFAULT_PROFILE])[0])
            profile = core.load_profile(profile_name, BASE_DIR)
            self._send_json({"ok": True, "profile": profile_name, "profile_state": profile, "provider_config": core.load_provider_config(BASE_DIR)})
            return
        if path == "/v1/models":
            if not self._require_mobile():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            cfg = core.load_provider_config(BASE_DIR)
            models = []
            for item in core.provider_models(cfg):
                models.append({"id": item["id"], "object": "model", "owned_by": item.get("role") or "provider"})
            if not models:
                models = [
                    {"id": "main", "object": "model", "owned_by": "main"},
                    {"id": "state", "object": "model", "owned_by": "state"},
                    {"id": "review", "object": "model", "owned_by": "review"},
                ]
            self._send_json({"object": "list", "data": models})
            return
        self._send_json({"ok": False, "error": "not_found"}, 404)

    def do_POST(self):
        path = self._path()
        payload = self._read_json()
        if path == "/api/provider/config":
            if not self._require_mobile():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            with STATE_LOCK:
                cfg = core.save_provider_config(payload if isinstance(payload, dict) else {}, BASE_DIR)
            self._send_json({"ok": True, "config": cfg})
            return
        if path == "/api/provider/test":
            if not self._require_mobile():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            cfg = core.load_provider_config(BASE_DIR)
            roles = payload.get("roles") if isinstance(payload.get("roles"), list) else ["main", "state", "review"]
            results = {role: core.provider_health(cfg, role) for role in roles if str(role) in {"main", "state", "review"}}
            self._send_json({"ok": all(item.get("ok") for item in results.values()), "results": results})
            return
        if path == "/api/profiles":
            if not self._require_mobile():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            name = core.safe_name(str(payload.get("profile") or payload.get("profile_name") or core.DEFAULT_PROFILE))
            display_name = str(payload.get("display_name") or name).strip()
            with STATE_LOCK:
                state = core.ensure_profile(name, base_dir=BASE_DIR, display_name=display_name)
                core.save_ui_state({"active_profile": name}, BASE_DIR)
            self._send_json({"ok": True, "profile": state})
            return
        if path == "/api/chat":
            if not self._require_mobile():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            message = str(payload.get("message") or payload.get("text") or "").strip()
            if not message:
                self._send_json({"ok": False, "error": "missing_message"}, 400)
                return
            profile_name = core.safe_name(str(payload.get("profile") or payload.get("profile_name") or core.DEFAULT_PROFILE))
            cfg = core.load_provider_config(BASE_DIR)
            try:
                with STATE_LOCK:
                    result = core.chat_turn(message, profile_name, base_dir=BASE_DIR, provider_cfg=cfg)
                self._send_json(result)
            except Exception as exc:
                self._send_json({"ok": False, "error": str(exc)}, 500)
            return
        if path == "/api/chat/proactive":
            if not self._require_mobile():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            profile_name = core.safe_name(str(payload.get("profile") or payload.get("profile_name") or core.DEFAULT_PROFILE))
            cfg = core.load_provider_config(BASE_DIR)
            try:
                force = not bool(payload.get("respect_state"))
                with STATE_LOCK:
                    result = core.proactive_turn(profile_name, base_dir=BASE_DIR, provider_cfg=cfg, force=force)
                self._send_json(result)
            except Exception as exc:
                self._send_json({"ok": False, "error": str(exc)}, 500)
            return
        if path == "/api/device/action":
            if not self._require_mobile():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            action = str(payload.get("action") or "").strip()
            target = str(payload.get("target") or payload.get("package") or "").strip()
            dry_run = bool(payload.get("dry_run"))
            self._send_json(device.perform_device_action(action, target=target, dry_run=dry_run))
            return
        if path == "/api/device/status":
            if not self._require_mobile():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            self._send_json({"ok": True, "device": device.read_device_status()})
            return
        if path == "/api/moments":
            if not self._require_mobile():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            profile_name = core.safe_name(str(payload.get("profile") or payload.get("profile_name") or self._query().get("profile", [core.DEFAULT_PROFILE])[0]))
            profile = core.load_profile(profile_name, BASE_DIR)
            text = str(payload.get("text") or payload.get("content") or "").strip()
            image_path = str(payload.get("image_path") or "").strip()
            if text or image_path:
                with STATE_LOCK:
                    profile = core.record_moment(
                        profile,
                        text or str(payload.get("title") or "分享"),
                        visibility=str(payload.get("visibility") or "friends"),
                        mood=str(payload.get("mood") or "neutral"),
                        source=str(payload.get("source") or "manual"),
                        tags=payload.get("tags") if isinstance(payload.get("tags"), list) else [],
                        kind=str(payload.get("kind") or ("image" if image_path else "text")),
                        image_path=image_path,
                        image_prompt=str(payload.get("image_prompt") or ""),
                        image_mode=str(payload.get("image_mode") or ""),
                    )
                    core.save_profile(profile_name, profile, BASE_DIR)
            self._send_json({"ok": True, "profile": profile_name, "moments": core.list_moments(profile, limit=50), "profile_state": profile})
            return
        if path == "/api/images/generate":
            if not self._require_mobile():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            profile_name = core.safe_name(str(payload.get("profile") or payload.get("profile_name") or core.DEFAULT_PROFILE))
            prompt = str(payload.get("prompt") or payload.get("text") or "").strip()
            style = str(payload.get("style") or "朋友圈感").strip()
            mood = str(payload.get("mood") or "平静").strip()
            title = str(payload.get("title") or "").strip()
            publish = str(payload.get("publish") or "").strip().lower() in {"1", "true", "yes", "on"}
            tags = payload.get("tags") if isinstance(payload.get("tags"), list) else []
            try:
                with STATE_LOCK:
                    image = core.generate_share_image(profile_name, prompt, base_dir=BASE_DIR, provider_cfg=core.load_provider_config(BASE_DIR), style=style, mood=mood, title=title)
                    profile = core.load_profile(profile_name, BASE_DIR)
                    moment = None
                    if publish:
                        moment = core.record_moment(
                            profile,
                            text=title or prompt or image.get("revised_prompt") or "分享图",
                            visibility=str(payload.get("visibility") or "friends"),
                            mood=mood,
                            source="image",
                            tags=tags + ["生图"],
                            kind="image",
                            image_path=str(image.get("image_path") or ""),
                            image_prompt=str(image.get("refined_prompt") or prompt),
                            image_mode=str(image.get("mode") or ""),
                        )
                        core.save_profile(profile_name, moment, BASE_DIR)
                payload_out = {"ok": True, "profile": profile_name, "image": image}
                if publish:
                    payload_out["moment"] = core.list_moments(core.load_profile(profile_name, BASE_DIR), limit=1)[0]
                self._send_json(payload_out)
            except Exception as exc:
                self._send_json({"ok": False, "error": str(exc)}, 500)
            return
        if path == "/api/mobile-sync/pull":
            if not self._require_sync():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            profile_name = core.safe_name(str(payload.get("profile") or payload.get("profile_name") or core.DEFAULT_PROFILE))
            profile = core.load_profile(profile_name, BASE_DIR)
            self._send_json({"ok": True, "profile": profile_name, "profile_state": profile, "provider_config": core.load_provider_config(BASE_DIR)})
            return
        if path == "/api/mobile-sync/push":
            if not self._require_sync():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            profile_name = core.safe_name(str(payload.get("profile") or payload.get("profile_name") or core.DEFAULT_PROFILE))
            incoming = payload.get("profile_state") if isinstance(payload.get("profile_state"), dict) else {}
            with STATE_LOCK:
                merged = core.import_profile(profile_name, incoming, BASE_DIR)
            self._send_json({"ok": True, "profile": profile_name, "profile_state": merged})
            return
        if path == "/v1/chat/completions":
            if not self._require_mobile():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            messages = payload.get("messages") if isinstance(payload.get("messages"), list) else []
            profile_name = core.safe_name(str(payload.get("profile") or payload.get("profile_name") or core.DEFAULT_PROFILE))
            cfg = core.load_provider_config(BASE_DIR)
            if not messages:
                user_text = str(payload.get("input") or payload.get("message") or "").strip()
                if not user_text:
                    self._send_json({"error": "missing_messages"}, 400)
                    return
                try:
                    with STATE_LOCK:
                        result = core.chat_turn(user_text, profile_name, base_dir=BASE_DIR, provider_cfg=cfg)
                    reply = result["reply"]
                except Exception as exc:
                    self._send_json({"error": str(exc)}, 500)
                    return
            else:
                profile = core.load_profile(profile_name, BASE_DIR)
                prompt = core.compose_system_prompt(profile, cfg)
                raw_messages = [{"role": "system", "content": prompt}]
                for message in messages[-20:]:
                    if isinstance(message, dict):
                        role = str(message.get("role") or "user")
                        content = str(message.get("content") or "")
                        if content.strip():
                            raw_messages.append({"role": role, "content": content})
                try:
                    with STATE_LOCK:
                        reply = core.provider_chat(
                            cfg,
                            "main",
                            raw_messages,
                            max_tokens=int(payload.get("max_tokens") or 512),
                            temperature=float(payload.get("temperature") or 0.75),
                        )
                        last_user = ""
                        for message in reversed(messages):
                            if isinstance(message, dict) and str(message.get("role") or "").lower() == "user":
                                last_user = str(message.get("content") or "")
                                break
                        reply = core.rewrite_with_review(cfg, profile, last_user, reply)
                        if last_user:
                            core.append_history(profile, "user", last_user, limit=int(cfg.get("history_limit") or 20))
                            core.touch_profile_activity(profile, "user")
                        core.append_history(profile, "assistant", reply, limit=int(cfg.get("history_limit") or 20))
                        core.touch_profile_activity(profile, "assistant")
                        core.update_profile_memory(profile, last_user, reply)
                        profile["summary"] = core.summarise_profile(profile)
                        core.save_profile(profile_name, profile, BASE_DIR)
                except Exception as exc:
                    self._send_json({"error": str(exc)}, 500)
                    return
            timestamp = int(time.time())
            self._send_json(
                {
                    "id": f"chatcmpl-{timestamp}",
                    "object": "chat.completion",
                    "created": timestamp,
                    "model": str(payload.get("model") or core.load_provider_config(BASE_DIR).get("main_model") or "main"),
                    "choices": [
                        {
                            "index": 0,
                            "message": {"role": "assistant", "content": reply},
                            "finish_reason": "stop",
                        }
                    ],
                }
            )
            return
        self._send_json({"ok": False, "error": "not_found"}, 404)

    def do_DELETE(self):
        path = self._path()
        if path.startswith("/api/moments/"):
            if not self._require_mobile():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            moment_id = path.rsplit("/", 1)[-1]
            profile_name = core.safe_name(self._query().get("profile", [core.DEFAULT_PROFILE])[0])
            with STATE_LOCK:
                profile = core.delete_moment_asset(profile_name, moment_id, BASE_DIR)
            self._send_json({"ok": True, "profile": profile_name, "moments": core.list_moments(profile, limit=50), "profile_state": profile})
            return
        if path.startswith("/api/profiles/"):
            if not self._require_mobile():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            name = core.safe_name(path.rsplit("/", 1)[-1])
            with STATE_LOCK:
                if name == core.DEFAULT_PROFILE:
                    state = core.ensure_profile(name, base_dir=BASE_DIR)
                else:
                    core.delete_profile(name, BASE_DIR)
                    state = core.ensure_profile(core.DEFAULT_PROFILE, base_dir=BASE_DIR)
                    core.save_ui_state({"active_profile": core.DEFAULT_PROFILE}, BASE_DIR)
            self._send_json({"ok": True, "profile": state})
            return
        self._send_json({"ok": False, "error": "not_found"}, 404)

    def do_PATCH(self):
        path = self._path()
        if path.startswith("/api/profiles/"):
            if not self._require_mobile():
                self._send_json({"ok": False, "error": "unauthorized"}, 401)
                return
            name = core.safe_name(path.rsplit("/", 1)[-1])
            payload = self._read_json()
            state = core.load_profile(name, BASE_DIR)
            if isinstance(payload, dict):
                if "display_name" in payload:
                    state["display_name"] = str(payload["display_name"]).strip() or name
                if payload.get("clear"):
                    state = core.default_profile_state(name)
                    state["display_name"] = str(payload.get("display_name") or state["display_name"])
                if payload.get("reset_memory"):
                    state = core.reset_profile_memory(name, base_dir=BASE_DIR, keep_moments=True)
                    state["display_name"] = str(payload.get("display_name") or state.get("display_name") or name)
            with STATE_LOCK:
                core.save_profile(name, state, BASE_DIR)
            self._send_json({"ok": True, "profile": state})
            return
        self._send_json({"ok": False, "error": "not_found"}, 404)


def _start_background_worker():
    global BACKGROUND_THREAD
    if BACKGROUND_THREAD and BACKGROUND_THREAD.is_alive():
        return
    BACKGROUND_STOP.clear()
    BACKGROUND_THREAD = threading.Thread(target=_background_proactive_loop, daemon=True, name="companion-proactive")
    BACKGROUND_THREAD.start()


def main() -> int:
    core.ensure_tree(BASE_DIR)
    _start_background_worker()
    server = ThreadingHTTPServer((HOST, PORT), CompanionHandler)
    print(f"Companion service listening on http://{HOST}:{PORT}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        BACKGROUND_STOP.set()
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
