[app]
title = Companion
package.name = companion
package.domain = com.companion
source.dir = .
source.include_exts = py,png,jpg,jpeg,kv,json,txt,md,ttf,ttc
version = 0.1.0

requirements = python3,kivy,plyer,pillow
source.exclude_patterns = __pycache__/*,*.pyc,*.pyo,*.zip,*.apk,*.log,*.ps1,*.bat,*.md,*.txt,work_patch/*,platform-tools/*,run_logs/*,outputs/*,.github/*,companion_repo_bundle.zip,companion-apk-run*.zip,logcat.txt

orientation = portrait
fullscreen = 0

services = companion:service.py:foreground:sticky

android.permissions = INTERNET,ACCESS_NETWORK_STATE,FOREGROUND_SERVICE,WAKE_LOCK,POST_NOTIFICATIONS,QUERY_ALL_PACKAGES
android.api = 32
android.minapi = 24
android.archs = arm64-v8a
android.accept_sdk_license = True

[buildozer]
log_level = 2
warn_on_root = 1
