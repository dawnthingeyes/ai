[app]
title = Companion
package.name = companion
package.domain = com.companion
source.dir = .
source.include_exts = py,png,jpg,jpeg,kv,json,txt,md
version = 0.1.0

requirements = python3,kivy

orientation = portrait
fullscreen = 0

services = companion:service.py:foreground:sticky

android.permissions = INTERNET,FOREGROUND_SERVICE,WAKE_LOCK,POST_NOTIFICATIONS
android.api = 32
android.minapi = 24
android.archs = arm64-v8a
android.accept_sdk_license = True

[buildozer]
log_level = 2
warn_on_root = 1
