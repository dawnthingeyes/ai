from __future__ import annotations

from typing import Any


def _android_ctx():
    try:
        from jnius import autoclass  # type: ignore

        PythonActivity = autoclass("org.kivy.android.PythonActivity")
        Intent = autoclass("android.content.Intent")
        Uri = autoclass("android.net.Uri")
        Settings = autoclass("android.provider.Settings")
        return {
            "activity": PythonActivity.mActivity,
            "context": PythonActivity.mActivity,
            "Intent": Intent,
            "Uri": Uri,
            "Settings": Settings,
        }
    except Exception:
        return None


def _build_result(action: str, *, ok: bool, error: str = "", detail: str = "", dry_run: bool = False, target: str = "") -> dict[str, Any]:
    return {
        "ok": ok,
        "action": action,
        "target": target,
        "detail": detail,
        "error": error,
        "dry_run": dry_run,
    }


def perform_device_action(action: str, target: str = "", *, dry_run: bool = False) -> dict[str, Any]:
    name = str(action or "").strip().lower()
    target = str(target or "").strip()
    if not name:
        return _build_result(name, ok=False, error="missing_action", target=target, dry_run=dry_run)
    if dry_run:
        return _build_result(name, ok=True, detail="dry_run", target=target, dry_run=True)

    ctx = _android_ctx()
    if not ctx:
        return _build_result(name, ok=False, error="android_unavailable", target=target)

    try:
        activity = ctx["activity"]
        context = ctx["context"]
        Intent = ctx["Intent"]
        Uri = ctx["Uri"]
        Settings = ctx["Settings"]

        if name == "home":
            intent = Intent(Intent.ACTION_MAIN)
            intent.addCategory(Intent.CATEGORY_HOME)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            activity.startActivity(intent)
            return _build_result(name, ok=True, detail="home", target=target)

        if name == "app":
            if not target:
                return _build_result(name, ok=False, error="missing_package", target=target)
            pm = context.getPackageManager()
            intent = pm.getLaunchIntentForPackage(target)
            if intent is None:
                return _build_result(name, ok=False, error="package_not_found", target=target)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            activity.startActivity(intent)
            return _build_result(name, ok=True, detail="launch_app", target=target)

        if name == "app_details":
            if not target:
                return _build_result(name, ok=False, error="missing_package", target=target)
            intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            intent.setData(Uri.parse(f"package:{target}"))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            activity.startActivity(intent)
            return _build_result(name, ok=True, detail="app_details", target=target)

        if name == "notifications":
            intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
            intent.putExtra(Settings.EXTRA_APP_PACKAGE, context.getPackageName())
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            activity.startActivity(intent)
            return _build_result(name, ok=True, detail="notification_settings", target=target)

        if name == "battery":
            intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            activity.startActivity(intent)
            return _build_result(name, ok=True, detail="battery_settings", target=target)

        if name == "accessibility":
            intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            activity.startActivity(intent)
            return _build_result(name, ok=True, detail="accessibility_settings", target=target)

        return _build_result(name, ok=False, error="unsupported_action", target=target)
    except Exception as exc:
        return _build_result(name, ok=False, error=str(exc), target=target)
