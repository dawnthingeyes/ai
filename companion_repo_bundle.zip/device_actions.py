from __future__ import annotations

from typing import Any


def _android_ctx():
    try:
        from jnius import autoclass  # type: ignore

        PythonActivity = autoclass("org.kivy.android.PythonActivity")
        Intent = autoclass("android.content.Intent")
        Uri = autoclass("android.net.Uri")
        Settings = autoclass("android.provider.Settings")
        return {
            "activity": PythonActivity.mActivity,
            "context": PythonActivity.mActivity,
            "Intent": Intent,
            "Uri": Uri,
            "Settings": Settings,
        }
    except Exception:
        return None


def _build_result(action: str, *, ok: bool, error: str = "", detail: str = "", dry_run: bool = False, target: str = "") -> dict[str, Any]:
    return {
        "ok": ok,
        "action": action,
        "target": target,
        "detail": detail,
        "error": error,
        "dry_run": dry_run,
    }


def read_device_status() -> dict[str, Any]:
    ctx = _android_ctx()
    if not ctx:
        return {"ok": False, "error": "android_unavailable"}
    try:
        from jnius import autoclass  # type: ignore

        activity = ctx["activity"]
        context = ctx["context"]
        Intent = ctx["Intent"]
        battery_intent_filter = autoclass("android.content.IntentFilter")
        BatteryManager = autoclass("android.os.BatteryManager")
        ConnectivityManager = autoclass("android.net.ConnectivityManager")
        BuildVersion = autoclass("android.os.Build$VERSION")
        NetworkCapabilities = autoclass("android.net.NetworkCapabilities")
        Context = autoclass("android.content.Context")

        status: dict[str, Any] = {"ok": True}
        try:
            battery_filter = battery_intent_filter(Intent.ACTION_BATTERY_CHANGED)
            battery_intent = context.registerReceiver(None, battery_filter)
            if battery_intent is not None:
                level = int(battery_intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1))
                scale = int(battery_intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1))
                plugged = int(battery_intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0))
                status["battery_level"] = int((level * 100 / scale)) if level >= 0 and scale > 0 else None
                status["charging"] = bool(plugged)
        except Exception:
            pass
        try:
            cm = context.getSystemService(Context.CONNECTIVITY_SERVICE)  # type: ignore[name-defined]
            if cm is not None:
                if int(BuildVersion.SDK_INT) >= 23:
                    network = cm.getActiveNetwork()
                    caps = cm.getNetworkCapabilities(network) if network is not None else None
                    if caps is not None:
                        status["network"] = "wifi" if caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) else "mobile" if caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) else "other"
                        status["online"] = bool(caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET))
                else:
                    info = cm.getActiveNetworkInfo()
                    if info is not None:
                        status["network"] = str(info.getTypeName() or "").lower()
                        status["online"] = bool(info.isConnected())
        except Exception:
            pass
        status["package"] = context.getPackageName()
        return status
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def perform_device_action(action: str, target: str = "", *, dry_run: bool = False) -> dict[str, Any]:
    name = str(action or "").strip().lower()
    target = str(target or "").strip()
    if not name:
        return _build_result(name, ok=False, error="missing_action", target=target, dry_run=dry_run)
    if dry_run:
        return _build_result(name, ok=True, detail="dry_run", target=target, dry_run=True)

    ctx = _android_ctx()
    if not ctx:
        return _build_result(name, ok=False, error="android_unavailable", target=target)

    try:
        activity = ctx["activity"]
        context = ctx["context"]
        Intent = ctx["Intent"]
        Uri = ctx["Uri"]
        Settings = ctx["Settings"]

        if name == "home":
            intent = Intent(Intent.ACTION_MAIN)
            intent.addCategory(Intent.CATEGORY_HOME)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            activity.startActivity(intent)
            return _build_result(name, ok=True, detail="home", target=target)

        if name == "app":
            if not target:
                return _build_result(name, ok=False, error="missing_package", target=target)
            pm = context.getPackageManager()
            intent = pm.getLaunchIntentForPackage(target)
            if intent is None:
                return _build_result(name, ok=False, error="package_not_found", target=target)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            activity.startActivity(intent)
            return _build_result(name, ok=True, detail="launch_app", target=target)

        if name == "app_details":
            if not target:
                return _build_result(name, ok=False, error="missing_package", target=target)
            intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            intent.setData(Uri.parse(f"package:{target}"))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            activity.startActivity(intent)
            return _build_result(name, ok=True, detail="app_details", target=target)

        if name == "notifications":
            intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
            intent.putExtra(Settings.EXTRA_APP_PACKAGE, context.getPackageName())
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            activity.startActivity(intent)
            return _build_result(name, ok=True, detail="notification_settings", target=target)

        if name == "battery":
            intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            activity.startActivity(intent)
            return _build_result(name, ok=True, detail="battery_settings", target=target)

        if name == "accessibility":
            intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            activity.startActivity(intent)
            return _build_result(name, ok=True, detail="accessibility_settings", target=target)

        return _build_result(name, ok=False, error="unsupported_action", target=target)
    except Exception as exc:
        return _build_result(name, ok=False, error=str(exc), target=target)
